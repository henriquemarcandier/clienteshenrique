<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark">Home</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?=URL?>">Home</a></li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <!-- Small boxes (Stat box) -->
                <div class="row" id="conteudo">
                    <img src="<?=URL?>admin/img/loader.gif" width="20"> Aguarde... Carregando...
                    <!-- ./col -->
                </div>
                <!-- /.row -->
                <!-- Main row -->
                <div class="row">
                    <!-- Left col -->
                    <section class="col-lg-12 connectedSortable">
                        <!-- Custom tabs (Charts with tabs)-->
                        <div class="card" style="cursor:pointer" onclick="location.href='<?=URL?>admin/contadorSite'">
                            <div class="card" style="border:none; height:30px">
                                <h3 class="card" style="cursor:pointer">
                                    <i class="fas fa-chart-pie mr-1" style="float:left; position:absolute"></i>
                                    <span style="float:left; position:absolute; left:5%">Contador do Site esse Mês</span>
                                </h3>
                            </div>
                        </div>
                        <div id="contadorSite">
                            <img src="<?=URL?>admin/img/loader.gif" width="20"> Aguarde... Carregando...
                        </div>

                    </section>
            </div><!-- /.container-fluid -->
        </section>
        <!-- /.content -->
    </div>
    <script>window.setInterval('verificaNovamente("index", "<?=URL?>")', 60000); window.setTimeout('verificaNovamente("index", "<?=URL?>")', 2000); </script>