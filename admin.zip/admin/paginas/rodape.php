    <!-- /.content-wrapper -->
    <footer class="main-footer">
        <strong>&copy; <?php $vet1 = explode('-', $versions[0]->date); echo $vet1[0];?>-<?=date('Y')?> <a href="https://www.bhcommerce.com.br" target="_blank">BH Commerce</a>.</strong>
        Todos os direitos reservados.
        <div class="float-right d-none d-sm-inline-block">
            <b>Versão</b> <a href="#" data-toggle="modal" data-target="#modalVersoes" style="background-color: #E5F1FB; color: #000000; padding7px; text-decoration:none"><img src="<?=URL?>assets/img/upload/<?=$versions[0]->img?>" width="35"></a>
        </div>
    </footer>

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
        <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->
<div class="modal fade" id="modalVersoes" tabindex="-1" role="dialog" aria-labelledby="modalVersoes" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Versões do Sistema</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" id="visualizacaoVersoes">
                <h5 class="modal-title">Versão Atual</h5>
                <table width="100%" border="0" cellpadding="0" cellspacing="0">
                    <tr>
                        <td style="width:200px"><img src="<?=URL?>assets/img/upload/<?=$versions[0]->img?>" width="200"></td>
                        <td style="vertical-align: top">
                            <h5 class="modal-title">Versão <?=$versions[0]->name?> - <?=$vet1[2]."/".$vet1[1]."/".$vet1[0]?></h5>
                            <p><?=($versions[0]->description)?></p>
                        </td>
                    </tr>
                </table>
                <?php if (count($versions) >= 2){?>
                    <h5 class="modal-title">Outras Versões</h5>
                    <table width="100%" border="0" cellpadding="0" cellspacing="0">
                        <?php foreach ($versions as $key => $value){
                            if ($versions[0]->id != $value->id){?>
                                <tr>
                                    <td style="width:50px" valign="top"><img src="<?=URL?>admin/img/upload/<?=$value->img?>" width="50"></td>
                                    <td style="vertical-align: top"><h5 class="modal-title">Versão <?=$value->name?> - <?php $vet1 = explode('-', $value->date); echo $vet1[2]."/".$vet1[1]."/".$vet1[0];?></h5><p><?=($value->description)?></p></td>
                                </tr>
                            <?php }
                        }
                        ?>
                    </table>
                <?php } ?>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
            </div>
        </div>
    </div>
</div>

<!-- jQuery -->
<script src="<?=URL?>admin/plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="<?=URL?>admin/plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
    $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="<?=URL?>admin/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- ChartJS -->
<script src="<?=URL?>admin/plugins/chart.js/Chart.min.js"></script>
<!-- Sparkline -->
<script src="<?=URL?>admin/plugins/sparklines/sparkline.js"></script>
<!-- JQVMap -->
<script src="<?=URL?>admin/plugins/jqvmap/jquery.vmap.min.js"></script>
<script src="<?=URL?>admin/plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
<!-- jQuery Knob Chart -->
<script src="<?=URL?>admin/plugins/jquery-knob/jquery.knob.min.js"></script>
<!-- daterangepicker -->
<script src="<?=URL?>admin/plugins/moment/moment.min.js"></script>
<script src="<?=URL?>admin/plugins/daterangepicker/daterangepicker.js"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="<?=URL?>admin/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- Summernote -->
<script src="<?=URL?>admin/plugins/summernote/summernote-bs4.min.js"></script>
<!-- overlayScrollbars -->
<script src="<?=URL?>admin/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="<?=URL?>admin/dist/js/adminlte.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="<?=URL?>admin/dist/js/pages/dashboard.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?=URL?>admin/dist/js/demo.js"></script>
<script src="<?=URL?>admin/dist/js/scripts.js"></script>
</body>
</html>