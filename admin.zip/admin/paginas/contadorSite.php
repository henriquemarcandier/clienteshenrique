<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Contador do Site</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?=URL?>admin">Home</a></li>
                        <li class="breadcrumb-item">Contadores</li>
                        <li class="breadcrumb-item active"><a href="<?=URL?>admin/contadorSite">Contador do Site</a></li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
    <div class="container-fluid">
        <div class="block-header">
            <h2 style="cursor: pointer" onclick="abreFecha('filtro')">Filtro</h2>
        </div>
        <div class="media text-muted pt-3" id="filtro" style="display:none">
            <div style="width:100%">
                <label for="dataFiltro">Por Data Inícial: </label>
                <input class="form-control" id="dataFiltro" name="dataFiltro" type="date" value="{{date('Y-m-')}}01">
            </div>
            <div style="width:100%">
                <label for="dataFimFiltro">Por Data Final: </label>
                <input class="form-control" id="dataFimFiltro" name="dataFimFiltro" type="date" value="{{date('Y-m-d')}}">
            </div>
            <button type="button" class="btn btn-primary" onclick='verificaNovamente("contador", "<?=URL?>", "<?=$_SESSION['user']['id']?>")'>Filtrar</button>
        </div>
    </div>
    <section class="content">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <!-- /.card-header -->
                    <div class="card-body" id="conteudo">
                        <img src="<?=URL?>admin/img/loader.gif" width="20"> Aguarde... Carregando...
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
        </div>
    </section>
</div>
<script>
    window.setInterval('verificaNovamente("contador", "<?=URL?>", "<?=$_SESSION['user']['id']?>")', 60000); window.setTimeout('verificaNovamente("contador", "<?=URL?>", "<?=$_SESSION['user']['id']?>")', 2000);
</script>