<div style="text-align:center">
<button class='btn btn-danger' onclick="location.href='<?=URL?>admin'">Página não encontrada ou você não tem permissão para visualizar esta página!</button>
</div>