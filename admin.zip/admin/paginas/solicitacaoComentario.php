<div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-5">
                        <h1>Solicitações de Comentários</h1>
                    </div>
                    <div class="col-sm-7">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?=URL?>admin">Home</a></li>
                            <li class="breadcrumb-item">Orçamentos</li>
                            <li class="breadcrumb-item active"><a href="<?=URL?>admin/solicitacaoComentario">Solicitações de Comentários</a></li>
                        </ol>
                    </div>
                </div>
            </div><!-- /.container-fluid -->
        </section>



<div class="my-3 p-3 bg-white rounded shadow-sm">
        <input type="hidden" name="tipo" id="tipo" value="categorias">
    <input type="hidden" name="pagina" id="pagina" value="1">

    <div class="media text-muted pt-3" id="conteudo">
        <img src="<?=URL?>admin/img/loader.gif" width="20"> Aguarde... Carregando...
    </div>
    <div id="contadorSite"></div>

</div>
<div class="modal fade" id="modalEdicao" tabindex="-1" role="dialog" aria-labelledby="modalEdicao" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Edição de Solicitação de Comentário</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="edicaoSolicitacaoComentario">
                <div class="modal-body">
                    <input type="hidden" name="urlEdicao" id="urlEdicao" value="<?=URL?>">
                    <input type="hidden" name="idEdicao" id="idEdicao" value="Aguarde... Carregando...">
                    <input type="hidden" name="idUserEdicao" id="idUserEdicao" value="Aguarde... Carregando...">
                    <label for="avaliacaoEdicao">Avaliação: </label>
                    <div id="avaliacaoEdicao"><img src="<?=URL?>admin/img/loader.gif" width="20"> Aguarde... Carregando...</div>
                    <label for="mensagemEdicao">Mensagem: </label>
                    <textarea name="mensagemEdicao" id="mensagemEdicao" class="form-control">Aguarde... Carregando...</textarea>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary" id="botaoEditar" style="display:none">Editar</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                </div>
            </form>
        </div>
    </div>
</div>
<div class="modal fade" id="modalVisualizacao" tabindex="-1" role="dialog" aria-labelledby="modalVisualizacao" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Visualização de Comentário de Produto</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" id="visualizacaoComentarioProduto">
                <img src="<?=URL?>admin/img/loader.gif" width="20"> Aguarde... Carregando...
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
            </div>
        </div>
    </div>
</div>

    </div>
<script>
    window.setInterval('verificaNovamente("solicitacaoComentario", "<?=URL?>", "<?=$_SESSION['user']['id']?>")', 60000); window.setTimeout('verificaNovamente("solicitacaoComentario", "<?=URL?>", "<?=$_SESSION['user']['id']?>")', 8000);
</script>