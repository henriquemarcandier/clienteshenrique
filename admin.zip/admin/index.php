<?php
error_reporting(0);
ini_set('display_erros', 'off');
@session_start();
$url = $_SERVER['REQUEST_URI'];
$vet = explode("/", $url);
array_shift($vet);
array_shift($vet);
$exp = explode('?', $vet[1]);
$vet[1] = $exp[0];
$link = "https://localhost/clientes/";
if($vet[0]){
    $link .= $vet[0]."/";
}
if ($vet[1]){
    $link .= $vet[1]."/";
}
if ($vet[2]){
    $link .= $vet[2]."/";
}
if (!$_SERVER['HTTPS']){
    header('location: '.$link);
    die();
}
require_once('connect.php');
if (!$_SESSION['user'] && !preg_match("/login/", $_SERVER['REQUEST_URI'])  && !preg_match("/esqueceu-sua-senha/", $_SERVER['REQUEST_URI'])  && !preg_match("/cadastro/", $_SERVER['REQUEST_URI'])){
    ?>
    <script>
            location.href="<?=URL?>admin/login/<?=$vet[1]?>";
    </script>
    <?php
}
$param = $vet[1];
if ($vet[1] == 'logout'){
    $sql = "INSERT INTO logs (user, action, created_at, updated_at) VALUES ('".$_SESSION['user']['id']."', 'Efetuou logout no sistema!', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
    mysqli_query($con, $sql);
    $_SESSION['user'] = "";
    ?>
    <script>
            location.href="<?=URL?>admin/login";
    </script>
    <?php
}
if ($vet[1] == 'login'){
    require_once(DIRETORIO."admin/paginas/formLogin.php");
}
elseif ($vet[1] == 'esqueceu-sua-senha'){
    require_once(DIRETORIO."admin/paginas/formForgotPassword.php");
}
elseif ($vet[1] == 'cadastro'){
    require_once(DIRETORIO."admin/paginas/formCadaster.php");
}
else{
    require_once(DIRETORIO."admin/pegaSqls.php");
    require_once(DIRETORIO."admin/paginas/cabecalho.php");
    if (!$vet[1] || $vet[1] == 'principal'){
        require_once(DIRETORIO."admin/paginas/index.php");
    }
    elseif ($vet[1] == 'semPermissao'){ 
        require_once(DIRETORIO."admin/paginas/semPermissao.php");
    }
    elseif ($permissao->view){
    if ($vet[1] == 'contadorSite'){
        require_once(DIRETORIO."admin/paginas/contadorSite.php");
    }
    elseif ($vet[1] == 'contadorPagina'){
        require_once(DIRETORIO."admin/paginas/contadorPagina.php");
    }
    elseif ($vet[1] == 'contadorSubitem'){
        require_once(DIRETORIO."admin/paginas/contadorSubitem.php");
    }
    elseif ($vet[1] == 'faleConosco'){
        require_once(DIRETORIO."admin/paginas/faleConosco.php");
    }
    elseif ($vet[1] == 'clientes'){
        require_once(DIRETORIO."admin/paginas/clientes.php");
    }
    elseif ($vet[1] == 'banner'){
         require_once(DIRETORIO."admin/paginas/banner.php");
    }
    elseif ($vet[1] == 'pagina'){
        require_once(DIRETORIO."admin/paginas/pagina.php");
    }
    elseif ($vet[1] == 'subitems'){
        require_once(DIRETORIO."admin/paginas/subitems.php");
    }
    elseif ($vet[1] == 'categorias'){
        require_once(DIRETORIO."admin/paginas/categorias.php");
    }
    elseif ($vet[1] == 'paramSite'){
        require_once(DIRETORIO."admin/paginas/paramSite.php");
    }
    elseif ($vet[1] == 'paramAdmin'){
        require_once(DIRETORIO."admin/paginas/paramAdmin.php");
    }
    elseif ($vet[1] == 'versao'){
        require_once(DIRETORIO."admin/paginas/versao.php");
    }
    elseif ($vet[1] == 'redesSociais'){
        require_once(DIRETORIO."admin/paginas/redesSociais.php");
    }
    elseif ($vet[1] == 'usuarios'){
        require_once(DIRETORIO."admin/paginas/usuarios.php");
    }
    elseif ($vet[1] == 'tiposModulo'){
        require_once(DIRETORIO."admin/paginas/tiposModulo.php");
    }
    elseif ($vet[1] == 'modulos'){
        require_once(DIRETORIO."admin/paginas/modulo.php");
    }
    elseif ($vet[1] == 'permissao'){
        require_once(DIRETORIO."admin/paginas/permissao.php");
    }
    elseif ($vet[1] == 'logsAcesso'){
        require_once(DIRETORIO."admin/paginas/logsAcesso.php");
    }
    elseif ($vet[1] == 'usuarios-pre'){
        require_once(DIRETORIO."admin/paginas/usuariosPre.php");
    }
    else{
        require_once(DIRETORIO."admin/paginas/paginaNaoEncontrada.php");
    }
    }
    else{
        require_once(DIRETORIO."admin/paginas/semPermissao.php");
    }
    require_once(DIRETORIO."admin/paginas/rodape.php");
}
?>