<?php
$sql = "SELECT * FROM users WHERE id = '".$_SESSION['user']['id']."'";
$query = mysqli_query($con, $sql);
$usuario = mysqli_fetch_object($query);
$sql = "SELECT * FROM users";
$query = mysqli_query($con, $sql);
if (mysqli_num_rows($query)){
    while ($row = mysqli_fetch_object($query)){
        $users[] = $row;
    }
}
$sql = "SELECT * FROM type_modules WHERE status = '1'";
$query = mysqli_query($con, $sql);
if (mysqli_num_rows($query)){
    while ($row = mysqli_fetch_object($query)){
        $typesModules[] = $row;
    }
}
$i = 0;
$sql = "SELECT * FROM modules WHERE status = '1'";
$query = mysqli_query($con, $sql);
if (mysqli_num_rows($query)){
    while ($row = mysqli_fetch_object($query)){
        if ($row->slug == $vet[1]){
            $moduloE = $row;
        }
        $modules[$i] = $row;
        $i++;
    }
}
if(count($moduloE)){
    $sql = "SELECT * FROM permissions WHERE user = '".$usuario->id."' AND module = '".$moduloE->id."'";
    $query = mysqli_query($con, $sql);
    $permissao = mysqli_fetch_object($query);
}
$sql = "SELECT * FROM permissions WHERE user = '".$_SESSION['user']['id']."' AND view = '1'";
$query = mysqli_query($con, $sql);
if (mysqli_num_rows($query)){
    while ($row = mysqli_fetch_object($query)){
        $permission[$row->module] = $row;
    }
}
$i = 0;
$sql = "SELECT * FROM versions WHERE date <= '".date('Y-m-d')."'ORDER BY date DESC";
$query = mysqli_query($con, $sql);
if (mysqli_num_rows($query)){
    while ($row = mysqli_fetch_object($query)){
        $versions[$i] = $row;
        $i++;
    }
}
$i = 0;
$sql = "SELECT * FROM categories";
$query = mysqli_query($con, $sql);
if (mysqli_num_rows($query)){
    while ($row = mysqli_fetch_object($query)){
        $categories[$i] = $row;
        $i++;
    }
}
$i = 0;
$sql = "SELECT * FROM pages";
$query = mysqli_query($con, $sql);
if (mysqli_num_rows($query)){
    while ($row = mysqli_fetch_object($query)){
        $pages[$i] = $row;
        $i++;
    }
}
$i = 0;
$sql = "SELECT * FROM subitems";
$query = mysqli_query($con, $sql);
if (mysqli_num_rows($query)){
    while ($row = mysqli_fetch_object($query)){
        $subitems[$i] = $row;
        $i++;
    }
}
$i = 0;
$sql = "SELECT * FROM banners";
$query = mysqli_query($con, $sql);
if (mysqli_num_rows($query)){
    while ($row = mysqli_fetch_object($query)){
        $banners[$i] = $row;
        $i++;
    }
}
$i = 0;
$sql = "SELECT * FROM departaments";
$query = mysqli_query($con, $sql);
if (mysqli_num_rows($query)){
    while ($row = mysqli_fetch_object($query)){
        $departaments[$i] = $row;
        $i++;
    }
}
$i = 0;
$sql = "SELECT * FROM brands";
$query = mysqli_query($con, $sql);
if (mysqli_num_rows($query)){
    while ($row = mysqli_fetch_object($query)){
        $brands[$i] = $row;
        $i++;
    }
}
$i = 0;
$sql = "SELECT * FROM suggestions";
$query = mysqli_query($con, $sql);
if (mysqli_num_rows($query)){
    while ($row = mysqli_fetch_object($query)){
        $suggestions[$i] = $row;
        $i++;
    }
}
$i = 0;
$sql = "SELECT * FROM stamps";
$query = mysqli_query($con, $sql);
if (mysqli_num_rows($query)){
    while ($row = mysqli_fetch_object($query)){
        $stamps[$i] = $row;
        $i++;
    }
}
$i = 0;
$sql = "SELECT * FROM relationships";
$query = mysqli_query($con, $sql);
if (mysqli_num_rows($query)){
    while ($row = mysqli_fetch_object($query)){
        $relationships[$i] = $row;
        $i++;
    }
}
$i = 0;
$sql = "SELECT * FROM products";
$query = mysqli_query($con, $sql);
if (mysqli_num_rows($query)){
    while ($row = mysqli_fetch_object($query)){
        $products[$i] = $row;
        $i++;
    }
}
$i = 0;
$sql = "SELECT * FROM types_services";
$query = mysqli_query($con, $sql);
if (mysqli_num_rows($query)){
    while ($row = mysqli_fetch_object($query)){
        $types_services[$i] = $row;
        $i++;
    }
}
$i = 0;
$sql = "SELECT * FROM banners_type";
$query = mysqli_query($con, $sql);
if (mysqli_num_rows($query)){
    while ($row = mysqli_fetch_object($query)){
        $banners_type[$i] = $row;
        $i++;
    }
}
$i = 0;
$sql = "SELECT * FROM social_networks WHERE status = '1'";
$query = mysqli_query($con, $sql);
if (mysqli_num_rows($query)){
    while ($row = mysqli_fetch_object($query)){
        $social_networks[$i] = $row;
        $i++;
    }
}
$i = 0;
$sql = "SELECT * FROM attributes";
$query = mysqli_query($con, $sql);
if (mysqli_num_rows($query)){
    while ($row = mysqli_fetch_object($query)){
        $attributes[$i] = $row;
        $i++;
    }
}
$i = 0;
$sql = "SELECT * FROM targets";
$query = mysqli_query($con, $sql);
if (mysqli_num_rows($query)){
    while ($row = mysqli_fetch_object($query)){
        $targets[$i] = $row;
        $i++;
    }
}
$i = 0;
$sql = "SELECT * FROM positions";
$query = mysqli_query($con, $sql);
if (mysqli_num_rows($query)){
    while ($row = mysqli_fetch_object($query)){
        $positions[$i] = $row;
        $i++;
    }
}
$i = 0;
$sql = "SELECT * FROM time_banners";
$query = mysqli_query($con, $sql);
if (mysqli_num_rows($query)){
    while ($row = mysqli_fetch_object($query)){
        $time_banners[$i] = $row;
        $i++;
    }
}
$i = 0;
$sql = "SELECT * FROM param_admins";
$query = mysqli_query($con, $sql);
if (mysqli_num_rows($query)){
    while ($row = mysqli_fetch_object($query)){
        $paramAdmin[$row->name] = ($row->value);
        $i++;
    }
}
if (!$vet[1] || $vet[1] == 'principal'){
    $acao = "Visualizou a tela inicial do sistema";
}
elseif ($vet[1] == 'contadorSite'){
    $acao = ("Visualizou o contador do site");
}
elseif ($vet[1] == 'itens-excluidos'){
    $acao = ("Visualizou os ítens excluídos do site");
}
elseif ($vet[1] == 'contadorPagina'){
    $acao = ("Visualizou o contador por página");
}
elseif ($vet[1] == 'contadorSubitem'){
    $acao = ("Visualizou o contador por subítem");
}
elseif ($vet[1] == 'contadorBanner'){
    $acao = ("Visualizou o contador por banner");
}
elseif ($vet[1] == 'contadorDepartamento'){
    $acao = ("Visualizou o contador por departamento");
}
elseif ($vet[1] == 'contadorMarca'){
    $acao = ("Visualizou o contador por marca");
}
elseif ($vet[1] == 'contadorSugestao'){
    $acao = ("Visualizou o contador por sugestão");
}
elseif ($vet[1] == 'contadorBusca'){
    $acao = ("Visualizou o contador por busca");
}
elseif ($vet[1] == 'contadorProduto'){
    $acao = ("Visualizou o contador por produto");
}
elseif ($vet[1] == 'contadorRedeSocial'){
    $acao = ("Visualizou o contador por rede social");
}
elseif ($vet[1] == 'logsCliente'){
    $acao = ("Visualizou os logs de clientes no site");
}
elseif ($vet[1] == 'newsletter'){
    $acao = ("Visualizou as assinaturas em newsletter");
}
elseif ($vet[1] == 'anuncie'){
    $acao = ("Visualizou os anuncies aqui do site");
}
elseif ($vet[1] == 'faleConosco'){
    $acao = ("Visualizou os Fale Conoscos do Site");
}
elseif ($vet[1] == 'listarOrcamentos'){
    $acao = ("Visualizou os orçamentos do site");
}
elseif ($vet[1] == 'valorVendidoPorStatus'){
    $acao = ("Visualizou o valor vendido por status do orçamento do site");
}
elseif ($vet[1] == 'cliente'){
    $acao = ("Visualizou os clientes do site");
}
elseif ($vet[1] == 'solicitacaoComentario'){
    $acao = ("Visualizou as solicitações de alteração de comentário do site");
}
elseif ($vet[1] == 'status'){
    $acao = ("Visualizou os status do orçamento do site");
}
elseif ($vet[1] == 'comentariosProduto'){
    $acao = ("Visualizou os comentários de produto do site");
}
elseif ($vet[1] == 'solicitacoesComentario'){
    $acao = ("Visualizou as solicitações de alteração de comentário de produto do site");
}
elseif ($vet[1] == 'type_documents'){
    $acao = ("Visualizou os tipos de documento do site");
}
elseif ($vet[1] == 'banner'){
    $acao = ("Visualizou os banners do site");
}
elseif ($vet[1] == 'pagina'){
    $acao = ("Visualizou as páginas do site");
}
elseif ($vet[1] == 'subitems'){
    $acao = ("Visualizou os subítens do site");
}
elseif ($vet[1] == 'atributos'){
    $acao = ("Visualizou os atributos do site");
}
elseif ($vet[1] == 'departamentos'){
    $acao = ("Visualizou os departamentos do site");
}
elseif ($vet[1] == 'marcas'){
    $acao = ("Visualizou as marcas do site");
}
elseif ($vet[1] == 'selos'){
    $acao = ("Visualizou os selos do site");
}
elseif ($vet[1] == 'sugestoes'){
    $acao = ("Visualizou as sugestões do site");
}
elseif ($vet[1] == 'relacionamentos'){
    $acao = ("Visualizou os relacionamentos do site");
}
elseif ($vet[1] == 'produto'){
    $acao = ("Visualizou os produtos do site");
}
elseif ($vet[1] == 'tiposProduto'){
    $acao = ("Visualizou os tipos de produto do site");
}
elseif ($vet[1] == 'formasPagamento'){
    $acao = ("Visualizou as formas de pagamento do site");
}
elseif ($vet[1] == 'cupomDesconto'){
    $acao = ("Visualizou os cupons de desconto do site");
}
elseif ($vet[1] == 'paramSite'){
    $acao = ("Visualizou os parâmetros do site");
}
elseif ($vet[1] == 'paramAdmin'){
    $acao = ("Visualizou os parâmetros do administrativo");
}
elseif ($vet[1] == 'versao'){
    $acao = ("Visualizou as versões do administrativo");
}
elseif ($vet[1] == 'idiomas'){
    $acao = ("Visualizou os idiomas do sistema");
}
elseif ($vet[1] == 'coins'){
    $acao = ("Visualizou as moedas do sistema");
}
elseif ($vet[1] == 'parceiros'){
    $acao = ("Visualizou os parceiros do site");
}
elseif ($vet[1] == 'nacionalidade'){
    $acao = ("Visualizou as nacionalidades do site");
}
elseif ($vet[1] == 'pais'){
    $acao = ("Visualizou os países do site");
}
elseif ($vet[1] == 'redesSociais'){
    $acao = ("Visualizou as redes sociais do site");
}
elseif ($vet[1] == 'types_services'){
    $acao = ("Visualizou os tipos de serviços do site");
}
elseif ($vet[1] == 'types_versions'){
    $acao = ("Visualizou os tipos de versões do site");
}
elseif ($vet[1] == 'categories'){
    $acao = ("Visualizou as categorias do site");
}
elseif ($vet[1] == 'priorities'){
    $acao = ("Visualizou as prioridades do site");
}
elseif ($vet[1] == 'target'){
    $acao = ("Visualizou os targets do site");
}
elseif ($vet[1] == 'position'){
    $acao = ("Visualizou as posições do banner do site");
}
elseif ($vet[1] == 'time_banner'){
    $acao = ("Visualizou os tempos de banner do site");
}
elseif ($vet[1] == 'usuarios'){
    $acao = ("Visualizou os usuários do sistema");
}
elseif ($vet[1] == 'tiposModulo'){
    $acao = ("Visualizou os tipos de módulo do sistema");
}
elseif ($vet[1] == 'modulos'){
    $acao = ("Visualizou os módulos do sistema");
}
elseif ($vet[1] == 'permissao'){
    $acao = ("Visualizou as permissões do sistema");
}
elseif ($vet[1] == 'logsAcesso'){
    $acao = ("Visualizou os logs de usuários do sistema");
}
elseif ($vet[1] == 'usuarios-pre'){
    $acao = ("Visualizou os usuários pré-cadastrados do sistema");
}
if ($acao){
    $sql = "INSERT INTO logs (user, action, created_at, updated_at) VALUES ('".$_SESSION['user']['id']."', '".$acao."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
    mysqli_query($con, $sql);
}
?>