<?php
date_default_timezone_set('America/Sao_Paulo');
require_once('connect.php');
$sql = "SELECT * FROM param_sites";
$query = mysqli_query($con, $sql);
while ($row = mysqli_fetch_array($query)){
    $parametrosSite[$row['name']] = ($row['value']);
}
switch ($_GET['acao']) {
    case "importarCoins":
        $sql = "SELECT * FROM coins WHERE url != '' ";
        $query = mysqli_query($con, $sql);
        while ($row = mysqli_fetch_array($query)){
            /* Inicializa a biblioteca cURL */
            $ch = curl_init();/* Define as configurações da requisição */
            curl_setopt_array($ch, [
                /* Informa a URL */
                CURLOPT_URL            => $row['url'],
                
                /* Informa que deseja capturar o retorno */
                CURLOPT_RETURNTRANSFER => true,
                
                /* Permite o redirecionamento */
                CURLOPT_FOLLOWLOCATION => true,
                
                /* Informa que o tipo da requisição é POST */
                CURLOPT_POST           => true,
                
                /* Converte os dados para application/x-www-form-urlencoded */
                CURLOPT_POSTFIELDS     => http_build_query($fields),
                
                /**
                 * Habilita a escrita de Cookies
                 *(É obrigatório para alguns sites)
                 */
                CURLOPT_COOKIEJAR      => 'cookies.txt',
                
                /* Desabilita a verificação do SSL,
                 * caso você possua, pode deixar habilitado
                 */
                CURLOPT_SSL_VERIFYPEER => false,
            ]);/* Executa a requisição e captura o retorno */
            $response = curl_exec($ch);/* Captura eventuais erros */
            $error = curl_error($ch);/* Captura a informação da requisição */
            $info = curl_getinfo($ch);/* Fecha a conexão */
            curl_close($ch);
            $dom = new domDocument();
            echo $response;
        }
        break;
    case "contabilizaExibicoesBanner":
        $sql = "SELECT * FROM banners WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)) {
            $row = mysqli_fetch_array($query);
            $exibitions = $row['exibitions'] + 1;
            $sql = "UPDATE banners SET exibitions = '".$exibitions."' WHERE id = '".$_REQUEST['id']."'";
            mysqli_query($con, $sql);
            echo "1|-|".$row['link'];
        }
        else{
            echo "0|-|Não foi encontrado banner com o id informado!";
        }
        break;
    case "marcarBannerVisitadoEPegarUrl":
        $sql = "SELECT * FROM banners WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)) {
            $row = mysqli_fetch_array($query);
        }
        $sql = "SELECT * FROM counters_banners WHERE data = '".date('Y-m-d')."' AND banner = '".$row['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $row2 = mysqli_fetch_array($query);
            $acessos = $row2['acessos'] + 1;
            $sql = "UPDATE counters_banners SET acessos = '".$acessos."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$row2['id']."'";
            mysqli_query($con, $sql);
        }
        else{
            $sql = "INSERT INTO counters_banners (banner, data, acessos, created_at, updated_at) VALUES ('".$row['id']."', '".date('Y-m-d')."', '1', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
            mysqli_query($con, $sql);
        }
        $clicks = $row['clicks'] + 1;
        $sql = "UPDATE banners SET clicks = '".$clicks."' WHERE id = '".$_REQUEST['id']."'";
        mysqli_query($con, $sql);
        echo "1|-|".$row['link'];
        break;
    case "redirecionaRedeSocial":
        $sql = "SELECT * FROM social_networks WHERE slug = '".$_REQUEST['slug']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)) {
            $row = mysqli_fetch_array($query);
            $cliques = $row['cliques'] + 1;
            $sql = "UPDATE social_networks SET cliques = '" . $cliques . "' WHERE id = '" . $row['id'] . "'";
            mysqli_query($con, $sql);
            echo "1|-|" . ($row['link']);
        }
        else{
            echo "0|-|Não foi encontrada nenhuma rede social com a url informada!";
        }
        break;
    case "vejaUmExemplo":
        $sql = "SELECT * FROM subitems WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        if ($row['descriptionVejaUmExemplo'] != '') {
            if ($_REQUEST['id'] == 1) {
                $nomeEscreve = "a Loja Virtual da BH Commerce";
            } elseif ($_REQUEST['id'] == 2) {
                $nomeEscreve = "o Site da BH Commerce";
            } elseif ($_REQUEST['id'] == 3) {
                $nomeEscreve = "o Site Internacionalizado da BH Commerce";
            } elseif ($_REQUEST['id'] == 4) {
                $nomeEscreve = "o Sistema Escolar da BH Commerce";
            } elseif ($_REQUEST['id'] == 5) {
                $nomeEscreve = "o Sistema de Caixa da BH Commerce";
            } elseif ($_REQUEST['id'] == 6) {
                $nomeEscreve = "o Catálogo Virtual da BH Commerce";
            }
            echo "1|-|Veja o exemplo d" . $nomeEscreve . "|-|".(nl2br(str_replace("##URL##", URL_SITE, $row['descriptionVejaUmExemplo'])));
        }
        else{
            echo "0|-|Sem o id com o texto do veja um exemplo cadastrado!";
        }
        break;
    case "selectFormaPagamentoPedido":
        $sql = "SELECT * FROM requests WHERE id = '".$_REQUEST['idPedido']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $row = mysqli_fetch_array($query);
            $subtotal = $row['subtotal'];
            if ($_REQUEST['idFormaPagamento'] == 1){
                $descontoAVista = $subtotal * $parametrosSite['descontoAVista'];
                $mostraDescontoAVista = 1;
            }
            else{
                $descontoAVista = 0;
                $mostraDescontoAVista = 0;
            }
            $total = $subtotal - $descontoAVista;
            echo "1|-|".$mostraDescontoAVista."|-|Desconto à Vista: <b style='color:#003300'>- R$ ".number_format($descontoAVista, 2, ',', '.')."</b>|-|Total: <b style='color:#000033'>R$ ".number_format($total, 2, ',', '.');
        }
        break;
    case "formCadastro":
        $sql = "SELECT * FROM users WHERE email = '".$_REQUEST['email']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)) {
            echo "0|-|Já existe um usuáio cadastrado com esse email! Clique em 'Esqueci a minha senha' caso tenha se esquecido da sua senha ou em 'Login' para se logar no sistema!";
        }
        else{
            $sql = "SELECT * FROM users_pre WHERE email = '".$_REQUEST['email']."'";
            $query = mysqli_query($con, $sql);
            if (mysqli_num_rows($query)) {
                echo "0|-|Já existe um usuáio pre-cadastrado com esse email! Aguarde ele ser checado que você vai receber um email nosso informando isso!";
            }
            else{
                if ($_REQUEST['password'] != $_REQUEST['password2']){
                    echo "0|-|As senhas digitadas não conferem. Confira!";
                }
                else {
                    $sql = "INSERT INTO user_pres (name, email, password, created_at, updated_at) VALUES ('".$_REQUEST['nome']."', '".$_REQUEST['email']."', '".md5($_REQUEST['password'])."', now(), now())";
                    mysqli_query($con, $sql);
                    $htmlEnvia = '<html><head><title>Pré cadastro efetuado com sucesso!</title></head><body><table width="100%" cellspacing="0" cellpadding="0" border="0"><tr><td valign="top" width="200" style="text-align: center"><img src="'.URL.'admin/img//logo.png" width="180"></td><td>Olá,<br><br>Viemos informar que foi feito um novo pré-cadastro no admin do site.<br><br>Nome: '.$_REQUEST['nome'].'<br>Email: '.$_REQUEST['email'].'<br><br>Para visualizar os pré-cadastros no admin, <a href="'.URL.'admin/usuarios-pre">clique aqui</a>.<br><br>Atenciosamente,<br><br>Equipe <a href="https://www.bhcommerce.com.br">BH Commerce</a></td></tr></table></body></html>';
                    $nomeEnvia = "Henrique - BH Commerce";
                    $emailEnvia = "henrique@bhcommerce.com.br";
                    $assuntoEnvia = "BH Commerce - Pré-cadastro efetuado com sucesso";
                    $cabecalhoEmail = "Content-Type: text/html; charset=iso-8859-1\n";
                    $cabecalhoEmail .= "From: Contato - BH Commerce<contato@bhcommerce.com.br>\nReply-To: Henrique Marcandier - BH Commerce<henrique@bhcommerce.com.br>";
                    //enviarEmail($parametrosSite['email'], "Contato - ".$parametrosSite['title'], $parametrosSite['email'], "Contato - ".$parametrosSite['title'], ($assuntoEnvia), ($htmlEnvia));
                    mail($nomeEnvia."<".$emailEnvia.">", ($assuntoEnvia), ($htmlEnvia), $cabecalhoEmail);
                    echo "1";
                }
            }
        }
        break;
    case "formLogin":
        $sql = "SELECT * FROM users WHERE email = '".$_REQUEST['email']."' AND password = '".md5($_REQUEST['password'])."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $row = mysqli_fetch_array($query);
            $_SESSION['user'] = $row;
            $action = "Se logou no sistema";
            $idUser = $_SESSION['user']['id'];
            $sql = "INSERT INTO logs (user, action, created_at, updated_at) VALUES ('".$idUser."', '".$action."', now(), now())";
            mysqli_query($con, $sql);
            echo "1";
        }
        else{
            echo "0|-|Login e/ou senha inválidos! Confira!";
        }
        break;
    case "formAlterarSenha":
        if ($_REQUEST['senhaAlterarSenha'] != $_REQUEST['redigitoSenhaAlterarSenha']){
            echo "0|-|Informe senhhas iguais!";
        }
        else {
            $sql = "UPDATE clients SET password = '".md5($_REQUEST['senhaAlterarSenha'])."', remember_token = '', updated_at = now() WHERE id = '".$_REQUEST['idUsuario']."'";
            echo $sql;
            mysqli_query($con, $sql);
            $sql = "SELECT * FROM clients WHERE id = '".$_REQUEST['idUsuario']."'";
            $query = mysqli_query($con, $sql);
            $row = mysqli_fetch_array($query);
            $_SESSION['cliente']['id'] = $row['id'];
            $_SESSION['cliente']['nome'] = $row['name'];
            $_SESSION['cliente']['email'] = $row['email'];
            echo "1";
        }
        break;
    case "formAtualizarSenha":
        if ($_REQUEST['senhaAlterarSenha'] != $_REQUEST['senha2AlterarSenha']){
            echo "0|-|Informe senhhas iguais!";
        }
        else {
            $sql = "UPDATE clients SET password = '".md5($_REQUEST['senhaAlterarSenha'])."', remember_token = '', updated_at = now() WHERE id = '".$_SESSION['cliente']['id']."'";
            mysqli_query($con, $sql);
            echo "1";
        }
        break;
    case "verificaPedidos":
        $sql = "SELECT a.*, b.name AS nomeStatus, b.sigla AS siglaStatus FROM requests a INNER JOIN requests_statuses b ON (a.status = b.id) WHERE a.client = '".$_SESSION['cliente']['id']."' ORDER BY a.created_at DESC";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)) {
            $html = '1|-|';
            $i = 0;
            while ($row = mysqli_fetch_array($query)){
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = $vet2[2]."/".$vet2[1]."/".$vet2[0]." às <br>".$vet[1]."h";
                $html .= '<a class="btn btn-';
                if ($row['status'] == 1){
                    $html .= "black";
                }
                elseif ($row['status'] == 2){
                    $html .= "yellow";
                }
                elseif ($row['status'] == 3){
                    $html .= "warning";
                }
                elseif ($row['status'] == 4){
                    $html .= "primary";
                }
                elseif ($row['status'] == 5){
                    $html .= "success";
                }
                elseif ($row['status'] == 6){
                    $html .= "danger";
                }
                $html .= '" style="float:left; width:230px; cursor:pointer; padding:15px; margin:5px;" title="Pedido '.br2nl(sprintf("%06s", $row['id']).'<br>Status do Pedido: '.($row['nomeStatus']).'<br>Data do Pedido: '.strip_tags($row['created_at']).'<br>Ver maiores informações do pedido" onclick=abreDetalhesPedido("'.$row['id'].'","'.URL_SITE).'")>
                            <h2 style="color: #fff;">Pedido '.sprintf("%06s\n", $row['id']).'</h2>
                            <p>Status do Pedido: <b>'.$row['siglaStatus'].'</b><br>Data: <b>'.$row['created_at'].'</b></p>
                                </a>';
                $i++;
            }
            $quantas = ceil($i / 4);
            for ($i = 1; $i <= $quantas; $i++) {
                $html .= '<br><br><br><br><br><br><br>';
            }
            echo $html;
        }
        else{
            echo "1|-|<button class='btn btn-danger' data-bs-dismiss='modal'>Nenhum pedido encontrado até o momento!</button>";
        }
        break;
    case "formEsqueceuSuaSenha":
        $sql = "SELECT * FROM users WHERE email = '".$_REQUEST['email']."'";
        $query = mysqli_query ($con, $sql);
        if (mysqli_num_rows($query)){
            $row = mysqli_fetch_array($query);
            $digitos = rand(0,9).rand(0,9).rand(0,9).rand(0,9).rand(0,9).rand(0,9);
            $sql = "UPDATE users SET remember_token = '".$digitos."' WHERE id = '".$row['id']."'";
            mysqli_query($con,  $sql);
            $html = "<html>
                    <head>
                        <title>BH Commerce - Esqueceu sua senha</title>
<                   </head>
                    <body>
                        <table width='100%' cellspacing='0' cellpadding='0' border='0'>
                            <tr>
                                <td width='100' style='text-align:center' valign='top'><img src='".URL."admin/img/logo.png' width='90'></td>
                                <td>Olá <b>".$row['name']."</b>,<br><br>
                                Este email é porque você solicitou em nosso site um lembrete da sua senha!<br><br>
                                Para alterar a sua senha, <a href='".URL."alterar-senha.php?codigo=".$digitos."'>clique aqui</a>.<br><br>
                                Atenciosamente,<br><br>
                                Equipe <a href='https://www.bhcommerce.com.br'>BH Commerce</a></td>
<                           </tr>
                        </table>
                   </body>
                   </table>";
            $cabecalhoEmail = "Content-Type: text/html; charset=iso-8859-1\n";
            $cabecalhoEmail .= "From: Contato - BH Commerce<contato@bhcommerce.com.br>\nReply-To: Henrique Marcandier - BH Commerce<henrique@bhcommerce.com.br>";
            //enviarEmail($parametrosSite['email'], "Contato - ".$parametrosSite['title'], $row['email'], $row['name'], ("BH Commerce - Esqueceu sua senha?"), ($html));
            mail($row['name']."<".$row['email'].">", "BH Commerce - Esqueceu sua senha?", ($html), $cabecalhoEmail);
            echo "1|-|".$html;
        }
        else{
            echo "0|-|Esse email não está cadastrado em nossa base de dados!";
        }
        break;
    case 'aprovarUsuario':
        $sql = "SELECT * FROM user_pres WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        $sql = "DELETE FROM user_pres WHERE id = '".$_REQUEST['id']."'";
        mysqli_query($con, $sql);
        $sql = "INSERT INTO users (name, email, password, created_at, updated_at) VALUES ('".$row['name']."', '".$row['email']."', '".$row['password']."', now(), now())";
        mysqli_query($con, $sql);
        $html = "<html>
                    <head>
                        <title>BH Commerce - Cadastro Liberado no Admin com Sucesso!</title>
<                   </head>
                    <body>
                        <table width='100%' cellspacing='0' cellpadding='0' border='0'>
                            <tr>
                                <td width='100' style='text-align:center' valign='top'><img src='".URL."admin/img/logo.png' width='90'></td>
                                <td>Olá <b>".$row['name']."</b>,<br><br>
                                Este email é para informar que o seu cadastro foi liberado com sucesso no admin de nosso site!<br><br>
                                Para acessar nosso admin, <a href='https://www.bhcommerce.com.br/admin'>clique aqui</a>.<br><br>
                                Seu email: ".$row['email']."<br><br>
                                Atenciosamente,<br><br>
                                Equipe <a href='https://www.bhcommerce.com.br'>BH Commerce</a></td>
<                           </tr>
                        </table>
                   </body>
                   </table>";
        $cabecalhoEmail = "Content-Type: text/html; charset=iso-8859-1\n";
        $cabecalhoEmail .= "From: Contato - BH Commerce<contato@bhcommerce.com.br>\nReply-To: Henrique Marcandier - BH Commerce<henrique@bhcommerce.com.br>";
        //enviarEmail($parametrosSite['email'], "Contato - ".$parametrosSite['title'], $row['email'], $row['name'], ("BH Commerce - Cadastro Liberado no Admin com Sucesso!"), ($html));
        mail($row['name']."<".$row['email'].">", "BH Commerce - Cadastro Liberado no Admin com Sucesso!", $html, $cabecalhoEmail);
        echo "1";
        break;
    case "aprovarAnuncie":
        $sql = "SELECT a.*, b.days FROM anuncie_aqui a INNER JOIN banners_type b ON (a.tipo_banner = b.id) WHERE a.id = '".$_REQUEST['id']."' AND a.aprovado = '0'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $row = mysqli_fetch_array($query);
            $slug = retirarAcentos($row['nome_banner']);
            $dias_adiciona = $row['days'];
            if ($dias_adiciona != 'eterno'){
                $date = date('Y-m-d H:i:s');
                $celke_data_inicio = strtotime($date);
                $celke_data_fim = '+'.$dias_adiciona.' day';
                $validade = date('Y-m-d', strtotime($celke_data_fim));
            }
            else{
                $validade = "9999-12-31";
            }
            $i = 1;
            $sql = "INSERT INTO banners (name, link, target, status, position, validade, created_at, updated_at) VALUES ('".$row['nome_banner']."', '".$row['link_banner']."', '".$row['target_banner']."', '1', '".$row['posicao_banner']."', '".$validade."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
            $query = mysqli_query($con, $sql) or die(mysqli_error($con));
            $idBanner = mysqli_insert_id($con);
            if (preg_match("/jpg/", $row['img'])){
                $tipo = ".jpg";
            }
            elseif (preg_match("/gif/", $row['img'])){
                $tipo = ".gif";
            }
            elseif (preg_match("/png/", $row['img'])){
                $tipo = ".png";
            }
            elseif (preg_match("/bmp/", $row['img'])){
                $tipo = ".bmp";
            }
            elseif (preg_match("/webp/", $row['img'])){
                $tipo = ".webp";
            }
            copy(DIRETORIO."assets/img/upload/".$row['img'], DIRETORIO."assets/img/upload/banner".$idBanner.$tipo);
            $sql = "UPDATE banners SET img = 'banner".$idBanner.$tipo."' WHERE id = '".$idBanner."'";
            mysqli_query($con, $sql);
            $sql = "UPDATE anuncie_aqui SET aprovado = '1' WHERE id = '".$row['id']."'";
            mysqli_query($con, $sql);
            echo "1";
        }
        break;
    case "editar":
        switch ($_REQUEST['table']){
            case "pedido":
                $sql = "SELECT a.*, b.name AS nomeCliente, b.email AS emailCliente FROM requests a INNER JOIN clients b ON (a.client = b.id) WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $vet = explode(' ', $row['created_at']);
                $vet1 = explode('-', $vet[0]);
                $subtotal = $row['subtotal'];
                if ($row['paymentMethod'] != $_REQUEST['formaPagamentoEditar']){
                    if ($_REQUEST['formaPagamentoEditar'] == 1){
                        $descontoAVista = $subtotal * $parametrosSite['descontoAVista'];
                    }
                    else{
                        $descontoAVista = 0;
                    }
                    $total = $subtotal - $descontoAVista;
                    $sql = "UPDATE requests SET descontoAVista = '".$descontoAVista."', total = '".$total."' WHERE id = '".$_REQUEST['id']."'";
                    mysqli_query($con, $sql);
                }
                if ($row['status'] != $_REQUEST['statusEditar'] && $_REQUEST['statusEditar'] == 4){
                    $assunto = "BH Commerce - Pedido ".sprintf("%06s\n", $row['id'])." alterado para Pedido Pago - Aguardando a execução da BH Commerce";
                    $corpoEmail = ("<html><head><title>BH Commerce - Pedido ".sprintf("%06s\n", $row['id'])." alterado para Pedido Pago - Aguardando a execução da BH Commerce</title><body><table width='100%' border='0' cellpadding='0' cellspacing='0'><tr><td width='30%' style='text-align:center' valign='top'><img src='".URL."admin/img/logo.png' width='100'></td><td>Olá <b>".$row['nomeCliente']."</b>,<br><br>Este email é pra informar da alteração do status do seu pedido ".sprintf("%06s\n", $row['id'])." para pedido pago - aguardando a execução da BH Commerce, que foi feito em ".$vet1[2]."/".$vet1[1]."/".$vet1[0]." às ".$vet[1]."h em nosso site.<br><br>Solicitamos que aguarde um prazo máximo de até 60 dias para que o seu site ou sistema fique pronto!</b>.<br><br>Atenciosamente<br><br>Equipe <a href='https://www.bhcommerce.com.br'>BH Commerce</a></td></tr></table></body></head></html>");
                    $cabecalhoEmail = "Content-Type: text/html; charset=iso-8859-1\n";
                    $cabecalhoEmail .= "From: ".$parametrosSite['title']."<".$parametrosSite['email'].">\nReply-To: ".$parametrosSite['title']."<".$parametrosSite['email'].">";
                    //enviarEmail($parametrosSite['email'], "Contato - ".$parametrosSite['title'], $row['emailCliente'], $row['nomeCliente'], ($assunto), ($html));
                    mail($row['nomeCliente']."<".$row['emailCliente'].">", $assunto, $corpoEmail, $cabecalhoEmail);

                }
                if ($row['status'] != $_REQUEST['statusEditar'] && $_REQUEST['statusEditar'] == 5){
                    $assunto = "BH Commerce - Pedido ".sprintf("%06s\n", $row['id'])." alterado para Pedido Pago e Entregue";
                    $corpoEmail = ("<html><head><title>BH Commerce - Pedido ".sprintf("%06s\n", $row['id'])." alterado para Pedido Pago - Aguardando a execução da BH CommerceEntregue</title><body><table width='100%' border='0' cellpadding='0' cellspacing='0'><tr><td width='30%' style='text-align:center' valign='top'><img src='".URL."admin/img/logo.png' width='100'></td><td>Olá <b>".$row['nomeCliente']."</b>,<br><br>Este email é pra informar da alteração do status do seu pedido ".sprintf("%06s\n", $row['id'])." para pedido pago e entregue, que foi feito em ".$vet1[2]."/".$vet1[1]."/".$vet1[0]." às ".$vet[1]."h em nosso site.</b>.<br><br>Atenciosamente<br><br>Equipe <a href='https://www.bhcommerce.com.br'>BH Commerce</a></td></tr></table></body></head></html>");
                    $cabecalhoEmail = "Content-Type: text/html; charset=iso-8859-1\n";
                    $cabecalhoEmail .= "From: ".$parametrosSite['title']."<".$parametrosSite['email'].">\nReply-To: ".$parametrosSite['title']."<".$parametrosSite['email'].">";
                    //enviarEmail($parametrosSite['email'], "Contato - ".$parametrosSite['title'], $row['emailCliente'], $row['nomeCliente'], ($assunto), ($html));
                    mail($row['nomeCliente']."<".$row['emailCliente'].">", $assunto, $corpoEmail, $cabecalhoEmail);
                }
                if ($row['status'] != $_REQUEST['statusEditar'] && $_REQUEST['statusEditar'] == 6){
                    $assunto = "BH Commerce - Pedido ".sprintf("%06s\n", $row['id'])." alterado para Pedido Cancelado";
                    $corpoEmail = ("<html><head><title>BH Commerce - Pedido ".sprintf("%06s\n", $row['id'])." alterado para Pedido Cancelado</title><body><table width='100%' border='0' cellpadding='0' cellspacing='0'><tr><td width='30%' style='text-align:center' valign='top'><img src='".URL."admin/img/logo.png' width='100'></td><td>Olá <b>".$row['nomeCliente']."</b>,<br><br>Este email é pra informar da alteração do status do seu pedido ".sprintf("%06s\n", $row['id'])." para pedido cancelado, que foi feito em ".$vet1[2]."/".$vet1[1]."/".$vet1[0]." às ".$vet[1]."h em nosso site.</b>.<br><br>Atenciosamente<br><br>Equipe <a href='https://www.bhcommerce.com.br'>BH Commerce</a></td></tr></table></body></head></html>");
                    $cabecalhoEmail = "Content-Type: text/html; charset=iso-8859-1\n";
                    $cabecalhoEmail .= "From: ".$parametrosSite['title']."<".$parametrosSite['email'].">\nReply-To: ".$parametrosSite['title']."<".$parametrosSite['email'].">";
                    //enviarEmail($parametrosSite['email'], "Contato - ".$parametrosSite['title'], $row['emailCliente'], $row['nomeCliente'], ($assunto), ($html));
                    mail($row['nomeCliente']."<".$row['emailCliente'].">", $assunto, $corpoEmail, $cabecalhoEmail);
                }
                if ($_REQUEST['enderecoEditar'] && $_REQUEST['enderecoEditar'] != 'new'){
                    $sql = "SELECT * FROM addresses WHERE id = '".$_REQUEST['enderecoEditar']."'";
                    $query = mysqli_query($con, $sql);
                    if (mysqli_num_rows($query)) {
                        $row2 = mysqli_fetch_array($query);
                        $sql = "UPDATE requests_addresses SET cep = '" . $row2['cep'] . "', address = '" . $row2['address'] . "', number = '" . $row2['number'] . "', complement = '" . $row2['complement'] . "', neighborhood = '" . $row2['neighborhood'] . "', city = '" . $row2['city'] . "', state = '" . $row2['state'] . "', referencia = '" . $row2['referencia'] . "' WHERE idRequest = '" . $_REQUEST['id'] . "'";
                        mysqli_query($con, $sql);
                    }
                }
                $_REQUEST['statusEditar'] = (!$_REQUEST['statusEditar']) ? $_REQUEST['statusGrava'] : $_REQUEST['statusEditar'];
                $_REQUEST['formaPagamentoEditar'] = (!$_REQUEST['formaPagamentoEditar']) ? $_REQUEST['formaPagamentoGrava'] : $_REQUEST['formaPagamentoEditar'];
                $_REQUEST['clientesEditar'] = (!$_REQUEST['clientesEditar']) ? $_REQUEST['clienteGrava'] : $_REQUEST['clientesEditar'];
                $_REQUEST['enderecoEditar'] = (!$_REQUEST['enderecoEditar']) ? $_REQUEST['enderecoGrava'] : $_REQUEST['enderecoEditar'];
                $sql = "UPDATE requests SET status = '".($_REQUEST['statusEditar'])."', paymentMethod = '".($_REQUEST['formaPagamentoEditar'])."', client = '".($_REQUEST['clienteEditar'])."', address = '".$_REQUEST['enderecoEditar']."', updated_at = now() WHERE id = '".$_REQUEST['id']."'";
                $artigo = "o";
                break;
            case "anuncie":
                $sql = "SELECT a.* FROM anuncie_aqui a WHERE a.id = '".$_REQUEST['idEdicao']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                if($row['status'] != $_REQUEST['statusEdicao'] && $_REQUEST['statusEdicao'] == 2){
                    $nomelQuem = ($_REQUEST['nomeEdicao']);
                    $emailQuem = ($_REQUEST['emailEdicao']);
                    $vet = explode(' ', $row['created_at']);
                    $vet2 = explode('-', $vet[0]);
                    $row['created_at'] = $vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h";
                    $assunto = $parametrosSite['title']." - Resposta ao anuncie aqui enviado em nosso site";
                    $corpoEmail = ("<html><head><title>Resposta ao ANUNCIE AQUI enviado em nosso site</title><body><table width='100%' border='0' cellpadding='0' cellspacing='0'><tr><td width='30%' style='text-align:center' valign='top'><img src='".URL."admin/img/logo.png' width='100'></td><td>Olá <b>".$_REQUEST['nomeEdicao']."</b>,<br><br>Este email é pra informar da resposta ao Anuncie Aqui enviado em <b>".$row['created_at']."</b>.<br><br><b>Dados do Fale Conosco</b><br><br>Assunto: <b>".($row['subject'])."</b><br>Telefone: <b>".($row['phone'])."</b><br></b><br>Mensagem: <b>".(nl2br($row['text']))."</b><br>Resposta: <b>".(nl2br($_REQUEST['respostaEdicao']))."</b><br><br>Atenciosamente<br><br>Equipe <a href='".URL."'>".$parametrosSite['title']."</a><hr noshade><center>Email desenvolvido pela <a href='https://www.bhcommerce.com.br'>BH Commerce</a></center><hr noshade></td></tr></table></body></head></html>");
                    $cabecalhoEmail = "Content-Type: text/html; charset=iso-8859-1\n";
                    $cabecalhoEmail .= "From: Henrique Marcandier - BH Commerce<henrique@bhcommerce.com.br>\nReply-To: Henrique Marcandier - BH Commerce<henrique@bhcommerce.com.br>";
                    mail($nomelQuem."<".$emailQuem.">", $assunto, $corpoEmail, $cabecalhoEmail);
                    //enviarEmail($parametrosSite['email'], $parametrosSite['title'], $emailQuem, $nomelQuem, $assunto, $corpoEmail);
                }
                if ($_FILES['imagemEdicao'] && $_FILES['imagemEdicao']['error'] == 0){
                    $filesImg = $_FILES['imagemEdicao']['tmp_name'];
                    $nameImg = $_FILES['imagemEdicao']['name'];
                    $qualEdicao = "anuncieAqui";
                    $tableEditar = "anuncie_aqui";
                }
                $sql = ("UPDATE anuncie_aqui SET name = '".($_REQUEST['nomeEdicao'])."', email = '".($_REQUEST['emailEdicao'])."', subject = '".($_REQUEST['assuntoEdicao'])."', text = '".$_REQUEST['mensagemEdicao']."', phone = '".$_REQUEST['telefoneEdicao']."', phone = '".$_REQUEST['telefoneEdicao']."', status = '".($_REQUEST['statusEdicao'])."', answer = '".($_REQUEST['respostaEdicao'])."', nome_banner = '".$_REQUEST['nomeBannerEdicao']."', link_banner = '".$_REQUEST['linkBannerEdicao']."', target_banner = '".$_REQUEST['targetBannerEdicao']."', posicao_banner = '".$_REQUEST['posicaoBannerEdicao']."', tipo_banner = '".$_REQUEST['tipoBannerEdicao']."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEdicao']."'");
                $artigo = "o";
                break;
            case "newsletter":
            $sql = "UPDATE newsletters SET name = '".($_REQUEST['nomeEdicao'])."', email = '".($_REQUEST['emailEdicao'])."', updated_at = now() WHERE id = '".$_REQUEST['idEdicao']."'";
            $artigo = "a";
            break;
            case "bugTracking":
                $sql = ("SELECT a.*, b.name AS nomeTipoServico , c.name AS nomeTipoVersao , d.name AS nomePrioridade, e.name AS nomeCategoria FROM bug_trackings a INNER JOIN types_services b ON (a.typeService = b.id) INNER JOIN type_versions c ON (a.typeVersion = c.id) INNER JOIN priorities d ON (a.priority = d.id) INNER JOIN categories e ON (a.category = e.id) WHERE a.id = '".$_REQUEST['idEdicao']."'");
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = $vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h";
                if($row['status'] != $_REQUEST['statusEdicao'] && $_REQUEST['statusEdicao'] == 2){
                    $nomelQuem = ($_REQUEST['nomeEdicao']);
                    $emailQuem = ($_REQUEST['emailEdicao']);
                    $assunto = "BH Commerce - Resposta ao bug tracking enviado em nosso site";
                    $corpoEmail = ("<html><head><title>Resposta ao bug tracking enviado em nosso site</title><body><table width='100%' border='0' cellpadding='0' cellspacing='0'><tr><td width='30%' style='text-align:center' valign='top'><img src='".URL."admin/img/logo.png' width='100'></td><td>Olá <b>".$_REQUEST['nomeEdicao']."</b>,<br><br>Este email é pra informar da resposta ao bug tracking enviado em <b>".$row['created_at']."</b>.<br><br><b>Dados do Bug Tracking</b><br><br>Título: <b>".($row['title'])."</b><br>Tipo de Serviço: <b>".($row['nomeTipoServico'])."</b><br>Versão: <b>".($row['nomeTipoVersao'])."</b><br>Prioridade: <b>".($row['nomePrioridade'])."</b><br>Categoria: <b>".($row['nomeCategoria'])."</b><br>Mensagem: <b>".(nl2br($row['message']))."</b><br>Resposta: <b>".(nl2br($_REQUEST['respostaEdicao']))."</b><br><br>Atenciosamente<br><br>Equipe <a href='https://www.bhcommerce.com.br'>BH Commerce</a></td></tr></table></body></head></html>");
                    $cabecalhoEmail = "Content-Type: text/html; charset=iso-8859-1\n";
                    $cabecalhoEmail .= "From: Henrique Marcandier - BH Commerce<henrique@bhcommerce.com.br>\nReply-To: Henrique Marcandier - BH Commerce<henrique@bhcommerce.com.br>";
                    mail($nomelQuem."<".$emailQuem.">", $assunto, $corpoEmail, $cabecalhoEmail);
                }
                $sql = "UPDATE bug_trackings SET name = '".($_REQUEST['nomeEdicao'])."', email = '".($_REQUEST['emailEdicao'])."', title = '".($_REQUEST['tituloEdicao'])."', message = '".($_REQUEST['mensagemEdicao'])."', typeService = '".$_REQUEST['tipoServicoEdicao']."', typeVersion = '".$_REQUEST['typeVersion']."', priority = '".$_REQUEST['priority']."', category = '".$_REQUEST['category']."', status = '".($_REQUEST['statusEdicao'])."', answer = '".($_REQUEST['respostaEdicao'])."', language = '".$row['language']."', updated_at = now() WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                break;
        case "faleConosco":
            $sql = "SELECT a.* FROM messages a WHERE a.id = '".$_REQUEST['idEdicao']."'";
            $query = mysqli_query($con, $sql);
            $row = mysqli_fetch_array($query);
            if($row['status'] != $_REQUEST['statusEdicao'] && $_REQUEST['statusEdicao'] == 2){
                $vetor = explode(' ', $row['created_at']);
                $vetor2 = explode('-', $vetor[0]);
                $row['created_at'] = $vetor2[2]."/".$vetor2[1]."/".$vetor2[0]." às ".$vetor[1]."h";
                $nomeQuem = ($_REQUEST['nomeEdicao']);
                $emailQuem = ($_REQUEST['emailEdicao']);
                $assunto = "BH Commerce - Resposta ao fale Conosco enviado em nosso site";
                $corpoEmail = ("<html><head><title>Resposta ao FALE CONOSCO enviado em nosso site</title><body><table width='100%' border='0' cellpadding='0' cellspacing='0'><tr><td width='30%' style='text-align:center' valign='top'><img src='".URL."admin/img/logo.png' width='100'></td><td>Olá <b>".$_REQUEST['nomeEdicao']."</b>,<br><br>Este email é pra informar da resposta ao fale conosco enviado em <b>".$row['created_at']."</b>.<br><br><b>Dados do Fale Conosco</b><br><br>Assunto: <b>".($row['subject'])."</b><br>Telefone: <b>".($row['phone'])."</b><br></b><br>Mensagem: <b>".(nl2br($row['text']))."</b><br>Resposta: <b>".(nl2br($_REQUEST['respostaEdicao']))."</b><br><br>Atenciosamente<br><br>Equipe <a href='https://www.bhcommerce.com.br'>BH Commerce</a></td></tr></table></body></head></html>");
                $cabecalhoEmail = "Content-Type: text/html; charset=iso-8859-1\n";
                $cabecalhoEmail .= "From: ".$parametrosSite['title']."<".$parametrosSite['email'].">\nReply-To: ".$parametrosSite['title']."<".$parametrosSite['email'].">";
                enviarEmail($parametrosSite['email'], "Contato - ".$parametrosSite['title'], $emailQuem, $nomeQuem, ($assunto), ($corpoEmail));
                //mail($nomelQuem."<".$emailQuem.">", $assunto, $corpoEmail, $cabecalhoEmail);
            }
            $sql = ("UPDATE messages SET name = '".($_REQUEST['nomeEdicao'])."', email = '".($_REQUEST['emailEdicao'])."', subject = '".($_REQUEST['assuntoEdicao'])."', phone = '".$_REQUEST['telefoneEdicao']."', text = '".($_REQUEST['mensagemEdicao'])."', status = '".($_REQUEST['statusEdicao'])."', answer = '".($_REQUEST['respostaEdicao'])."', updated_at = now() WHERE id = '".$_REQUEST['idEdicao']."'");
            $artigo = "o";
            break;
            case "target":
                $sql = "UPDATE targets SET name = '".($_REQUEST['nomeEdicao'])."', status = '".($_REQUEST['statusEdicao'])."' WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                break; 
            case "position":
                $sql = "UPDATE positions SET name = '".($_REQUEST['nomeEdicao'])."', status = '".($_REQUEST['statusEdicao'])."' WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "a";
                break; 
            case "time_banner":
                $sql = "UPDATE time_banners SET name = '".($_REQUEST['nomeEdicao'])."', status = '".($_REQUEST['statusEdicao'])."' WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                break; 
            case "social_networks":
                $sql = "UPDATE social_networks SET name = '".($_REQUEST['nomeEdicao']."', link = '".$_REQUEST['linkEdicao']."', with_image = '".$_REQUEST['comImagemEdicao']."', status = '".$_REQUEST['statusEdicao']."'");
                if(!$_REQUEST['comImagemEdicao']) {
                    $sql .= ", img = '".$_REQUEST['imagemEdicao']."'";
                }
                $sql .= ", updated_at = now() WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "a";
                $qualE = "social_networks";
                if ($_FILES['imagemEdicao'] && $_FILES['imagemEdicao']['error'] == 0){
                    $filesImg = $_FILES['imagemEdicao']['tmp_name'];
                    $nameImg = $_FILES['imagemEdicao']['name'];
                    $qualEdicao = "social_network";
                    $tableEditar = "social_networks";
                }
                break;
            case "statusPedido":
                $sql = "UPDATE requests_statuses SET name = '".($_REQUEST['nomeEdicao'])."', sigla = '".($_REQUEST['siglaEdicao'])."', color = '".$_REQUEST['colorEdicao']."', background = '".$_REQUEST['backgroundEdicao']."', enviarEmail = '".$_REQUEST['enviarEmailEdicao']."', email = '".$_REQUEST['emailEdicao']."', updated_at = now() WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                break;
            case "tiposDocumento":
                $sql = "UPDATE type_documents SET name = '".($_REQUEST['nomeEdicao'])."', status = '".($_REQUEST['statusEdicao'])."', updated_at = now() WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                break;
            case "clientes":
                $sql = "UPDATE clients SET name = '".($_REQUEST['nomeEdicao'])."', email = '".($_REQUEST['emailEdicao'])."', cel = '".$_REQUEST['celEdicao']."', typeDocument = '".$_REQUEST['tipoDocumentoEdicao']."', document = '".$_REQUEST['documentoEdicao']."'";
                if ($_REQUEST['senhaEdicao']){
                    $sql .= ", password = '".md5($_REQUEST['senhaEdicao'])."'";
                }
                $sql .= ", updated_at = now() WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                break;
            case "tiposProduto":
                $sql = "UPDATE types_products SET name = '".($_REQUEST['nomeEdicao'])."', status = '".($_REQUEST['statusEdicao'])."', updated_at = now() WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                break;
            case "produto":
                $sql = "UPDATE products SET name = '".($_REQUEST['nomeEdicao'])."', description = '".($_REQUEST['descricaoEdicao'])."', status = '".($_REQUEST['statusEdicao'])."'";
                $sql .= ", updated_at = now() WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                if ($_FILES['imagemEdicao'] && $_FILES['imagemEdicao']['error'] == 0){
                    $filesImg = $_FILES['imagemEdicao']['tmp_name'];
                    $nameImg = $_FILES['imagemEdicao']['name'];
                    $qualEdicao = "produto";
                    $tableEditar = "products";
                }
                break;
            case "formaPagamento":
                $sql = "UPDATE payment_methods SET name = '".($_REQUEST['nomeEdicao'])."'";
                $sql .= ", updated_at = now() WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                if ($_FILES['imagemEdicao'] && $_FILES['imagemEdicao']['error'] == 0){
                    $filesImg = $_FILES['imagemEdicao']['tmp_name'];
                    $nameImg = $_FILES['imagemEdicao']['name'];
                    $qualEdicao = "formaPagamento";
                    $tableEditar = "payment_methods";
                }
                break;
            case "idiomas":
                $sql = "UPDATE languages SET name = '".($_REQUEST['nomeEdicao'])."', status = '".$_REQUEST['statusEdicao']."'";
                $sql .= ", updated_at = now() WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                if ($_FILES['imagemEdicao'] && $_FILES['imagemEdicao']['error'] == 0){
                    $filesImg = $_FILES['imagemEdicao']['tmp_name'];
                    $nameImg = $_FILES['imagemEdicao']['name'];
                    $qualEdicao = "languages";
                    $tableEditar = "languages";
                }
                break;
            case "coins":
                $_REQUEST['valorRealEdicao'] = str_replace('.', '', $_REQUEST['valorRealEdicao']);
                $_REQUEST['valorRealEdicao'] = str_replace(',', '.', $_REQUEST['valorRealEdicao']);
                $sql = "UPDATE coins SET name = '".($_REQUEST['nomeEdicao'])."', sigla = '".$_REQUEST['siglaEdicao']."', valorReal = '".$_REQUEST['valorRealEdicao']."', status = '".$_REQUEST['statusEdicao']."', url = '".$_REQUEST['urlVaiEdicao']."'";
                $sql .= ", updated_at = now() WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "a";
                break;
            case "banner":
                $sql = ("UPDATE banners SET name = '".$_REQUEST['nomeEdicao']."', description = '".$_REQUEST['descricaoEdicao']."', position = '".$_REQUEST['posicaoEdicao']."', status = '".$_REQUEST['statusEdicao']."', link = '".$_REQUEST['linkEdicao']."', target = '".$_REQUEST['targetEdicao']."', validade = '".$_REQUEST['validadeEdicao']."'");
                $sql .= ", updated_at = now() WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                $qualE = "banners";
                if ($_FILES['imagemEdicao'] && $_FILES['imagemEdicao']['error'] == 0){
                    $filesImg = $_FILES['imagemEdicao']['tmp_name'];
                    $nameImg = $_FILES['imagemEdicao']['name'];
                    $qualEdicao = "banner";
                    $tableEditar = "banners";
                }
                break;
            case "pagina":
                $sql = ("UPDATE pages SET name = '".$_REQUEST['nomeEdicao']."', name_menu = '".$_REQUEST['nomeMenuEdicao']."', subname = '".$_REQUEST['subtituloEdicao']."', appearsMenu = '".$_REQUEST['apareceMenuEdicao']."', appearsSite = '".$_REQUEST['apareceSiteEdicao']."', status = '".$_REQUEST['statusEdicao']."'");
                $sql .= ", updated_at = now() WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "a";
                $sql5 = "DELETE FROM pages_descriptions WHERE page = '".$_REQUEST['idEdicao']."'";
                mysqli_query($con, $sql5);
                for ($i = 1; $i <= $_REQUEST['qtasTemEdicao']; $i++){
					if ($_REQUEST['description'.$i]){
						$sql2 = "SELECT * FROM pages_descriptions WHERE page = '".$_REQUEST['idEdicao']."' AND num = '".$i."'";
						$query = mysqli_query($con, $sql2);
						if (mysqli_num_rows($query)){
							$sql3 = ("UPDATE pages_descriptions SET text = '".$_REQUEST['description'.$i]."', type = '".$_REQUEST['tipoDescription'.$i]."', updated_at = '".date('Y-m-d H:i:s')."' WHERE page = '".$_REQUEST['idEdicao']."' AND num = '".$i."'");
						}
						else{
							$sql3 = ("INSERT INTO pages_descriptions (page, num, text, type, created_at, updated_at) VALUES ('".$_REQUEST['idEdicao']."', '".$i."', '".$_REQUEST['description'.$i]."', '".$_REQUEST['tipoDescription'.$i]."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
						}
						mysqli_query($con, $sql3) or die(mysqli_error($con));
					}
				}
				$i = 1;
				$sql4 = "SELECT * FROM pages_descriptions WHERE page = '".$_REQUEST['idEdicao']."' ORDER BY num ASC";
				$query4 = mysqli_query($con, $sql4);
				if (mysqli_num_rows($query4)){
					while ($row4 = mysqli_fetch_array($query4)){
						$sql = "UPDATE pages_descriptions SET num = '".$i."' WHERE id = '".$row4['id']."'";
						$i++;
						mysqli_query($con, $sql);
					}
				}
                $artigo = "a";
                $qualE = "pages";
                if ($_FILES['imagemEdicao'] && $_FILES['imagemEdicao']['error'] == 0){
                    $filesImg = $_FILES['imagemEdicao']['tmp_name'];
                    $nameImg = $_FILES['imagemEdicao']['name'];
                    $qualEdicao = "pagina";
                    $tableEditar = "pages";
                }
                break;
                case "subitem":
                    $sql = ("UPDATE subitems SET name = '".$_REQUEST['nomeEdicao']."', description = '".$_REQUEST['descricaoEdicao']."', subname = '".$_REQUEST['subtituloEdicao']."', appearsImg = '".$_REQUEST['mostraImagemEdicao']."', page = '".$_REQUEST['paginaEdicao']."', categorie = '".$_REQUEST['categoriaEdicao']."', status = '".$_REQUEST['statusEdicao']."', description2 = '".$_REQUEST['descricao2Edicao']."', description3 = '".$_REQUEST['descricao3Edicao']."'");
                    $sql .= ", updated_at = now() WHERE id = '".$_REQUEST['idEdicao']."'";
                    $artigo = "o";
                    $qualE = "subitems";
                    if ($_FILES['imagemEdicao'] && $_FILES['imagemEdicao']['error'] == 0){
                        $filesImg = $_FILES['imagemEdicao']['tmp_name'];
                        $nameImg = $_FILES['imagemEdicao']['name'];
                        $qualEdicao = "subitem";
                        $tableEditar = "subitems";
                    }
                    break;
                case "redesSociais":
                    $sql = ("UPDATE social_networks SET name = '".$_REQUEST['nomeEdicao']."', status = '".$_REQUEST['statusEdicao']."'");
                    $sql .= ", updated_at = now() WHERE id = '".$_REQUEST['idEdicao']."'";
                    $artigo = "o";
                    $qualE = "social_networks";
                    if ($_FILES['imagemEdicao'] && $_FILES['imagemEdicao']['error'] == 0){
                        $filesImg = $_FILES['imagemEdicao']['tmp_name'];
                        $nameImg = $_FILES['imagemEdicao']['name'];
                        $qualEdicao = "social_network";
                        $tableEditar = "social_networks";
                    }
                    break;
            case "tipoServico":
                $sql = "UPDATE types_services SET name = '".($_REQUEST['nomeEdicao'])."', status = '".($_REQUEST['statusEdicao'])."', updated_at = now() WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                break;
            case "tipoModulo":
                $sql = "UPDATE type_modules SET name = '".($_REQUEST['nomeEdicao'])."', status = '".($_REQUEST['statusEdicao'])."', updated_at = now() WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                break;
            case "modulo":
                $sql = "UPDATE modules SET name = '".($_REQUEST['nomeEdicao'])."', status = '".($_REQUEST['statusEdicao'])."', typeModule = '".$_REQUEST['tipoModuloEdicao']."', slug = '".$_REQUEST['urlAmigavelEdicao']."', updated_at = now() WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                break;
            case "prioridade":
                $sql = "UPDATE priorities SET name = '".($_REQUEST['nomeEdicao'])."', status = '".($_REQUEST['statusEdicao'])."', updated_at = now() WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "a";
                break;
            case "tipoVersao":
                $sql = "UPDATE type_versions SET name = '".($_REQUEST['nomeEdicao'])."', typeService = '".($_REQUEST['tipoServicoEdicao'])."', status = '".($_REQUEST['statusEdicao'])."', updated_at = now() WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                break;
            case "categoria":
                $sql = "UPDATE categories SET name = '".($_REQUEST['nomeEdicao'])."', status = '".($_REQUEST['statusEdicao'])."', updated_at = now() WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "a";
                break;
            case "parametroSite":
                $sql = "UPDATE param_sites SET name = '".($_REQUEST['nomeEdicao'])."', value = '".($_REQUEST['valorEdicao'])."', updated_at = now() WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                break;
            case "parametroAdmin":
                $sql = "UPDATE param_admins SET name = '".($_REQUEST['nomeEdicao'])."', value = '".($_REQUEST['valorEdicao'])."', updated_at = now() WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                break;
            case "versao":
                $sql = "UPDATE versions SET name = '".($_REQUEST['nomeEdicao'])."', description = '".($_REQUEST['descricaoEdicao'])."', date = '".($_REQUEST['dataEdicao'])."'";
                $sql .= ", updated_at = now() WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "a";
                if ($_FILES['imagemEdicao'] && $_FILES['imagemEdicao']['error'] == 0){
                    $filesImg = $_FILES['imagemEdicao']['tmp_name'];
                    $nameImg = $_FILES['imagemEdicao']['name'];
                    $qualEdicao = "versao";
                    $tableEditar = "versions";
                }
                break;
            case "usuario":
                $sql = "UPDATE users SET name = '".($_REQUEST['nomeEdicao'])."', email = '".($_REQUEST['emailEdicao'])."'";
                if ($_REQUEST['senhaEdicao']){
                    $sql .= ", password = '".md5(($_REQUEST['senhaEdicao']))."'";
                }
                $sql .= ", updated_at = now() WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                if ($_FILES['imagemEdicao'] && $_FILES['imagemEdicao']['error'] == 0){
                    $filesImg = $_FILES['imagemEdicao']['tmp_name'];
                    $nameImg = $_FILES['imagemEdicao']['name'];
                    $qualEdicao = "usuarios";
                    $tableEditar = "users";
                }
                break;
            case "usuarioPre":
                $sql = "UPDATE user_pres SET name = '".($_REQUEST['nomeEdicao'])."', email = '".($_REQUEST['emailEdicao'])."'";
                if ($_REQUEST['senhaEdicao']){
                    $sql .= ", password = '".md5($_REQUEST['senhaEdicao'])."'";
                }
                $sql .= ", updated_at = now() WHERE id = '".$_REQUEST['idEdicao']."'";
                $artigo = "o";
                break;
        }
        mysqli_query($con, $sql) or die(mysqli_error($con));
        if ($qualE){
            $sql = "SELECT * FROM ".$qualE." WHERE id = '".$_REQUEST['idEdicao']."'";
            $query = mysqli_query($con, $sql);
            $row = mysqli_fetch_array($query);
            $slug = retirarAcentos($row['name']);
            $sql = "UPDATE ".$qualE." SET slug = '". $slug."' WHERE id = '".$_REQUEST['idEdicao']."'";
            mysqli_query($con, $sql);

        }
        if ($filesImg && $qualEdicao){
            if (preg_match('/.jpg/', $nameImg) || preg_match('/.jpeg/', $nameImg)){
                $arquivo = $qualEdicao.$_REQUEST['idEdicao'].".jpg";
            }
            elseif (preg_match('/.gif/', $nameImg)){
                $arquivo = $qualEdicao.$_REQUEST['idEdicao'].".gif";
            }
            elseif (preg_match('/.png/', $nameImg)){
                $arquivo = $qualEdicao.$_REQUEST['idEdicao'].".png";
            }
            elseif (preg_match('/.bmp/', $nameImg)){
                $arquivo = $qualEdicao.$_REQUEST['idEdicao'].".bmp";
            }
            elseif (preg_match('/.svg/', $nameImg)){
                $arquivo = $qualEdicao.$_REQUEST['idEdicao'].".svg";
            }
            if ($arquivo){
                copy($filesImg, DIRETORIO."assets/img/upload/".$arquivo);
                $sql = "UPDATE ".$tableEditar." SET img = '".$arquivo."' WHERE id = '".$_REQUEST['idEdicao']."'";
                mysqli_query($con, $sql);
                $img = URL."assets/img/upload/".$arquivo;
            }
        }
        $action = "Atualizou ".$artigo." ".$_REQUEST['table']." ".$_REQUEST['idEdicao'];
        $sql = "INSERT INTO logs (action, user, created_at, updated_at) VALUES ('".$action."', '".$_REQUEST['idUserEdicao']."', now(), now())";
        mysqli_query($con, $sql);
        echo "1|-|".$_REQUEST['idUserEdicao']."|-|".$img;
        break;
    case "cadastrar":
        switch ($_REQUEST['table']){
            case "statusPedido":
                $sql = ("INSERT INTO requests_statuses (name, sigla, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['siglaCadastro']."', now(), now())");
                $artigo = "o";
                break;
            case "target":
                $sql = ("INSERT INTO targets (name, status, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['statusCadastro']."', now(), now())");
                $artigo = "a";
                break;
            case "position":
                $sql = ("INSERT INTO positions (name, status, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['statusCadastro']."', now(), now())");
                $artigo = "a";
                break;
            case "time_banner":
                $sql = ("INSERT INTO time_banners (name, status, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['statusCadastro']."', now(), now())");
                $artigo = "o";
                break;
            case "tiposDocumento":
                $sql = ("INSERT INTO type_documents (name, status, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['statusCadastro']."', now(), now())");
                $artigo = "o";
                break;
            case "tiposProduto":
                $sql = ("INSERT INTO types_products (name, status, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['statusCadastro']."', now(), now())");
                $artigo = "o";
                break;
            case "redesSociais":
                $cliques = 0;
                $sql = ("INSERT INTO social_networks (name, with_image, ");
                if ($_REQUEST['comImagemCadastro'] == 0){
                    $sql .= "img, ";
                }
                $sql .= ("link, status, cliques, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['comImagemCadastro']."', ");
                if ($_REQUEST['comImagemCadastro'] == 0){
                    $sql .= "'".$_REQUEST['imagemCadastro']."', ";
                }
                $sql .= ("'".$_REQUEST['linkCadastro']."', '".$_REQUEST['statusCadastro']."', '".$cliques."', now(), now())");
                $artigo = "a";
                $qualE = "rede social";
                if ($_FILES['imagemCadastro'] && $_FILES['imagemCadastro']['error'] == 0){
                    $filesImg = $_FILES['imagemCadastro']['tmp_name'];
                    $nameImg = $_FILES['imagemCadastro']['name'];
                    $qualEdicao = "social_network";
                    $tableEditar = "social_networks";
                }
                break;
            case "produto":
                $sql = ("INSERT INTO products (name, description, status, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['descricaoCadastro']."', '".$_REQUEST['statusCadastro']."', now(), now())");
                $artigo = "o";
                if ($_FILES['imagemCadastro'] && $_FILES['imagemCadastro']['error'] == 0){
                    $filesImg = $_FILES['imagemCadastro']['tmp_name'];
                    $nameImg = $_FILES['imagemCadastro']['name'];
                    $qualEdicao = "produto";
                    $tableEditar = "products";
                }
                break;
            case "formaPagamento":
                $sql = ("INSERT INTO payment_methods (name, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', now(), now())");
                $artigo = "o";
                if ($_FILES['imagemCadastro'] && $_FILES['imagemCadastro']['error'] == 0){
                    $filesImg = $_FILES['imagemCadastro']['tmp_name'];
                    $nameImg = $_FILES['imagemCadastro']['name'];
                    $qualEdicao = "formaPagamento";
                    $tableEditar = "payment_methods";
                }
                break;
            case "languages":
                $sql = ("INSERT INTO languages (name, status, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['statusCadastro']."', now(), now())");
                $artigo = "o";
                if ($_FILES['imagemCadastro'] && $_FILES['imagemCadastro']['error'] == 0){
                    $filesImg = $_FILES['imagemCadastro']['tmp_name'];
                    $nameImg = $_FILES['imagemCadastro']['name'];
                    $qualEdicao = "languages";
                    $tableEditar = "languages";
                }
                break;
            case "coins":
                $_REQUEST['valorRealCadastro'] = str_replace('.', '', $_REQUEST['valorRealCadastro']);
                $_REQUEST['valorRealCadastro'] = str_replace(',', '.', $_REQUEST['valorRealCadastro']);
                $sql = ("INSERT INTO coins (name, sigla, valorReal, status, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['siglaCadastro']."', '".$_REQUEST['valorRealCadastro']."', '".$_REQUEST['statusCadastro']."', now(), now())");
                $artigo = "a";
                break;
            case "banner":
                $sql = ("INSERT INTO banners (name, description, link, position, target, validade, status, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['descricaoCadastro']."', '".$_REQUEST['linkCadastro']."', '".$_REQUEST['posicaoCadastro']."', '".$_REQUEST['targetCadastro']."', '".$_REQUEST['validadeCadastro']."', '".$_REQUEST['statusCadastro']."', now(), now())");
                $artigo = "o";
                $qualE = "banners";
                if ($_FILES['imagemCadastro'] && $_FILES['imagemCadastro']['error'] == 0){
                    $filesImg = $_FILES['imagemCadastro']['tmp_name'];
                    $nameImg = $_FILES['imagemCadastro']['name'];
                    $qualEdicao = "banner";
                    $tableEditar = "banners";
                }
                break;
            case "pagina":
                $sql = ("INSERT INTO pages (name, name_menu, description, subname, appearsMenu, appearsSite, status, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['nomeMenuCadastro']."', '".$_REQUEST['descricaoCadastro']."', '".$_REQUEST['subtituloCadastro']."', '".$_REQUEST['apareceMenuCadastro']."', '".$_REQUEST['apareceSiteCadastro']."', '".$_REQUEST['statusCadastro']."', now(), now())");
                $artigo = "a";
                $qualE = "pages";
                if ($_FILES['imagemCadastro'] && $_FILES['imagemCadastro']['error'] == 0){
                    $filesImg = $_FILES['imagemCadastro']['tmp_name'];
                    $nameImg = $_FILES['imagemCadastro']['name'];
                    $qualEdicao = "pagina";
                    $tableEditar = "pages";
                }
                break;
            case "subitem":
                $sql = ("INSERT INTO subitems (page, categorie, name, description, description2, description3, subname, appearsImg, status, created_at, updated_at) VALUES ('".$_REQUEST['paginaCadastro']."', '".$_REQUEST['categoriaCadastro']."', '".$_REQUEST['nomeCadastro']."', '".$_REQUEST['descricaoCadastro']."', '".$_REQUEST['descricao2Cadastro']."', '".$_REQUEST['descricao3Cadastro']."', '".$_REQUEST['subtituloCadastro']."', '".$_REQUEST['mostraImagemCadastro']."', '".$_REQUEST['statusCadastro']."', now(), now())");
                $artigo = "a";
                $qualE = "subitems";
                if ($_FILES['imagemCadastro'] && $_FILES['imagemCadastro']['error'] == 0){
                    $filesImg = $_FILES['imagemCadastro']['tmp_name'];
                    $nameImg = $_FILES['imagemCadastro']['name'];
                    $qualEdicao = "subitem";
                    $tableEditar = "subitems";
                }
                break;
            case "tipoServico":
                $sql = ("INSERT INTO types_services (name, status, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['statusCadastro']."', now(), now())");
                $artigo = "o";
                break;
            case "prioridade":
                $sql = ("INSERT INTO priorities (name, status, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['statusCadastro']."', now(), now())");
                $artigo = "a";
                break;
            case "tipoVersao":
                $sql = ("INSERT INTO type_versions (name, typeService, status, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['tipoServicoCadastro']."', '".$_REQUEST['statusCadastro']."', now(), now())");
                $artigo = "o";
                break;
            case "categoria":
                $sql = ("INSERT INTO categories (name, status, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['statusCadastro']."', now(), now())");
                $artigo = "a";
                break;
            case "parametroSite":
                $sql = ("INSERT INTO param_sites (name, value, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['valorCadastro']."', now(), now())");
                $artigo = "o";
                break;
            case "parametroAdmin":
                $sql = ("INSERT INTO param_admins (name, value, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['valorCadastro']."', now(), now())");
                $artigo = "o";
                break;
            case "versao":
                $sql = ("INSERT INTO versions (name, description, date, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['descricaoCadastro']."', '".($_REQUEST['dataCadastro'])."', now(), now())");
                $artigo = "a";
                if ($_FILES['imagemCadastro'] && $_FILES['imagemCadastro']['error'] == 0){
                    $filesImg = $_FILES['imagemCadastro']['tmp_name'];
                    $nameImg = $_FILES['imagemCadastro']['name'];
                    $qualEdicao = "versao";
                    $tableEditar = "versions";
                }
                break;
            case "usuarios":
                $sql = ("INSERT INTO users (name, email, password, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['emailCadastro']."', '".md5($_REQUEST['senhaCadastro'])."', now(), now())");
                $artigo = "o";
                if ($_FILES['imagemCadastro'] && $_FILES['imagemCadastro']['error'] == 0){
                    $filesImg = $_FILES['imagemCadastro']['tmp_name'];
                    $nameImg = $_FILES['imagemCadastro']['name'];
                    $qualEdicao = "usuario";
                    $tableEditar = "users";
                }
                break;
            case "tipoModulo":
                $sql = ("INSERT INTO type_modules (name, status, created_at, updated_at) VALUES ('".$_REQUEST['nomeCadastro']."', '".$_REQUEST['statusCadastro']."', now(), now())");
                $artigo = "o";
                break;
            case "modulo":
                $sql = ("INSERT INTO modules (typeModule, name, slug, status, created_at, updated_at) VALUES ('".$_REQUEST['tipoModuloCadastro']."', '".$_REQUEST['nomeCadastro']."', '".$_REQUEST['urlAmigavelCadastro']."', '".$_REQUEST['statusCadastro']."', now(), now())");
                $artigo = "o";
                break;
        }
        mysqli_query($con, $sql) or die(mysqli_error($con));
        $_REQUEST['idCadastro'] = mysqli_insert_id($con);
        if ($qualE){
            $sql = "SELECT * FROM ".$qualE." WHERE id = '".$_REQUEST['idCadastro']."'";
            $query = mysqli_query($con, $sql);
            $row = mysqli_fetch_array($query);
            $slug = retirarAcentos($row['name']);
            $sql = "UPDATE ".$qualE." SET slug = '". $slug."' WHERE id = '".$_REQUEST['idCadastro']."'";
            mysqli_query($con, $sql);
        }
        if ($filesImg && $qualEdicao){
            if (preg_match('/.jpg/', $nameImg) || preg_match('/.jpeg/', $nameImg)){
                $arquivo = $qualEdicao.$_REQUEST['idCadastro'].".jpg";
            }
            elseif (preg_match('/.gif/', $nameImg)){
                $arquivo = $qualEdicao.$_REQUEST['idCadastro'].".gif";
            }
            elseif (preg_match('/.png/', $nameImg)){
                $arquivo = $qualEdicao.$_REQUEST['idCadastro'].".png";
            }
            elseif (preg_match('/.bmp/', $nameImg)){
                $arquivo = $qualEdicao.$_REQUEST['idCadastro'].".bmp";
            }
            elseif (preg_match('/.svg/', $nameImg)){
                $arquivo = $quaclEdicao.$_REQUEST['idCadastro'].".svg";
            }
            if ($arquivo){
                copy($filesImg, DIRETORIO."assets/img/upload/".$arquivo);
                $sql = "UPDATE ".$tableEditar." SET img = '".$arquivo."' WHERE id = '".$_REQUEST['idCadastro']."'";
                mysqli_query($con, $sql);
            }
        }
        $action = "Cadastrou ".$artigo." ".$_REQUEST['table']." ".$_REQUEST['idCadastro'];
        $sql = "INSERT INTO logs (action, user, created_at, updated_at) VALUES ('".$action."', '".$_REQUEST['idUserCadastro']."', now(), now())";
        mysqli_query($con, $sql);
        echo "1";
        break;
    case "visualizar":
        switch ($_REQUEST['table']){
            case "pedido":
                $sql = "SELECT a.*, b.name AS nomeFormaPagamento, c.name AS nomeStatus, c.id AS idStatus, d.name, d.email,d.cel, d.document, e.name AS nomeTipoDocumento,f.cep, f.address AS enderecoCliente, f.number, f.complement, f.neighborhood, f.city, f.state
FROM requests a
INNER JOIN payment_methods b ON (a.paymentMethod = b.id)
INNER JOIN requests_statuses c ON (a.status = c.id)
INNER JOIN clients d ON (a.client = d.id)
INNER JOIN type_documents e ON (e.id = d.typeDocument)
INNER JOIN requests_addresses f ON (f.idRequest = a.id)
WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo ("1|-|<h5>Dados do Pedido ".sprintf("%06s\n", $row[0])."</h5>".("Número do Pedido:")." <b>".sprintf("%06s\n", $row[0])."</b><br>Data do Pedido: <b>".$row['created_at']."</b><br>Status do Pedido: <b>".($row['nomeStatus'])."</b><br>".("Forma de Pagamento").": <b>".($row['nomeFormaPagamento'])."</b>");
                if ($row['status'] <= 3) {
                    echo (" - <a href='".URL."efetuarPagamento?id=".$row[0]."' target='_blank'>Efetuar Pagamento</a>");
                }
                $sql = "SELECT * FROM requests_items WHERE request = '".$row[0]."'";
                $query = mysqli_query($con, $sql);
                $totalItens = mysqli_num_rows($query);
                echo "<h5>Dados do";
                if ($totalItens > 1){
                    echo 's';
                }
                echo " Produto";
                if ($totalItens > 1){
                    echo 's';
                }
                echo "</h5>
                     <table width='100%' cellpadding='0' cellspacing='0' border='0'>
                        <tr>
                            <th width='25%'>Nome do Produto</th>
                            <th width='25%'>Valor do Produto</th>
                            <th width='25%'>Quant.</th>
                            <th width='25%'>Valor Total</th>
                        </tr>
                        ";
                while ($rowItens = mysqli_fetch_array($query)){
                    echo "<tr";
                if ($i % 2 == 0){
                    echo " style='background-color:#F7F7F7'";
                }
                echo ">
                            <td>".($rowItens['name']);
                    if ($rowItens['domine'] != '') {
                        echo ' - <a href="'.$rowItens['domine'].'" target="_blank">' . substr($rowItens['domine'], 0, 15)."...</a>";
                    }
                    echo "</td>
                            <td>R$ ".number_format($rowItens['value'], 2, ',', '.')."</td>
                            <td>".$rowItens['quantity']."</td>
                            <td>R$ ".number_format($rowItens['value'] * $rowItens['quantity'], 2, ',', '.')."</td>
                         </tr>";
                    $i++;
                    $total += $rowItens['value'] * $rowItens['quantity'];
                }
                echo "<tr>
                            <td colspan='4' style='text-align:right'>Sub-Total: <b>R$ ".number_format($total, 2, ',','.')."</b></td>
                      </tr>
                      <tr>
                        <td colspan='4' style='text-align:right";
                if ($row['paymentMethod'] == 2){
                    echo "; display:none";
                }
                echo "'>Desconto à Vista: <b style='color: #003300'>- R$ ".number_format($row['descontoAVista'], 2, ',','.')."</b></td>
                      </tr>
                      <tr>
                            <td colspan='4' style='text-align:right'>Total: <b style='color: #000033'>R$ ".number_format($row['total'], 2, ',','.')."</b></td>
                      </tr></table>
                     <h5>Dados do Cliente</h5>
                Nome do Cliente: <b>".($row['name'])."</b><br>
                Email do Cliente: <b>".($row['email'])."</b><br>
                Telefone do Cliente: <b>".($row['cel'])."</b><br>
                Tipo de Documento do Cliente: <b>".($row['nomeTipoDocumento'])."</b><br>
                Documento do Cliente: <b>".($row['document'])."</b>
                <h5>Dados do Endereço</h5>
                Nome do Endereço: <b>".($row['nomeEndereco'])."</b><br>
                CEP do Endereço: <b>".($row['cep'])."</b><br>
                Logradouro do Endereço: <b>".($row['enderecoCliente'])."</b><br>
                Número do Endereço: <b>".($row['number'])."</b><br>
                Complemento do Endereço: <b>".($row['complement'])."</b><br>
                Bairro do Endereço: <b>".($row['neighborhood'])."</b><br>
                Cidade do Endereço: <b>".($row['city'])."</b><br>
                Estado do Endereço: <b>".($row['state'])."</b>";
                $artigo = "o";
                break;
            case "anuncie":
                $sql = "SELECT a.*, b.name AS nomeTempo FROM anuncie_aqui a INNER JOIN banners_type b ON (a.tipo_banner = b.id) WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                if (file_exists(DIRETORIO."assets/img/upload/anuncieAqui".$row['id'].".jpg")){
                    $img = URL."assets/img/upload/anuncieAqui".$row['id'].".jpg";
                }
                elseif (file_exists(DIRETORIO."assets/img/upload/anuncieAqui".$row['id'].".gif")){
                    $img = URL."assets/img/upload/anuncieAqui".$row['id'].".gif";
                }
                elseif (file_exists(DIRETORIO."assets/img/upload/anuncieAqui".$row['id'].".png")){
                    $img = URL."assets/img/upload/anuncieAqui".$row['id'].".png";
                }
                elseif (file_exists(DIRETORIO."assets/img/upload/anuncieAqui".$row['id'].".bmp")){
                    $img = URL."assets/img/upload/anuncieAqui".$row['id'].".bmp";
                }
                elseif (file_exists(DIRETORIO."assets/img/upload/anuncieAqui".$row['id'].".webp")){
                    $img = URL."assets/img/upload/anuncieAqui".$row['id'].".webp";
                }
                $status = ($row['status'] == 1) ? "<span style='color:#FFFF00'>Enviado</span>" : "<span style='color:#000033'>Respondido</span>";
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo ("1|-|Nome: <b>".$row['name']."</b><br>Email: <b>".$row['email']."</b><br>".("Assunto").": <b>".$row['subject']."</b><br>".("Telefone").": <b>".$row['phone']."</b><br>".("Mensagem").": <b>".nl2br($row['text'])."</b><br>Status: <b>".$status."</b>");
                if ($row['status'] == 2){
                    echo ('<br>Resposta: <b>'.nl2br($row['answer']).'</b>');
                }
                if ($img){
                    echo "<br>Banner: <img src='".$img."' width='100%'>";
                }
                echo ("<br>Nome do Banner: <b>".$row['nome_banner']."</b><br>Link do Banner: <b>".$row['link_banner']."</b><br>Target do Banner: <b>");
                if ($row['target_banner'] == "_parent"){
                    echo "Na mesma página";
                }
                else{
                    echo "Em nova Página";
                }
                echo "</b><br>Posição do Banner: <b>";
                if ($row['posicao_banner'] == "1"){
                    echo "Banner Popup";
                }
                else{
                    echo "Banner Meio Página";
                }
                echo "</b><br>Tempo do Banner: <b>";
                echo ($row['nomeTempo']."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "newsletter":
                $sql = "SELECT * FROM newsletters WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo ("1|-|Nome: <b>".($row['name'])."</b><br>Email: <b>".$row['email']."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "a";
                break;
            case "bugTracking":
                $sql = "SELECT a.*, b.name AS nomeTipoServico , c.name AS nomeTipoVersao , d.name AS nomePrioridade, e.name AS nomeCategoria FROM bug_trackings a INNER JOIN types_services b ON (a.typeService = b.id) INNER JOIN type_versions c ON (a.typeVersion = c.id) INNER JOIN priorities d ON (a.priority = d.id) INNER JOIN categories e ON (a.category = e.id) WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 0) ? "<span style='color:#006600'>Enviado</span>" : "<span style='color:#000033'>Respondido</span>";
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo ("1|-|Nome: <b>".($row['name'])."</b><br>Email: <b>".$row['email']."</b><br>".("Título").": <b>".($row['title'])."</b><br>".("Tipo de Serviço").": <b>".($row['nomeTipoServico'])."</b><br>".("Versão").": <b>".($row['nomeTipoVersao'])."</b><br>".("Prioridade").": <b>".($row['nomePrioridade'])."</b><br>".("Categoria").": <b>".($row['nomeCategoria'])."</b><br>".("Mensagem").": <b>".(nl2br($row['message']))."</b><br>Status: <b>".$status."</b>");
                if ($row['status'] == 2){
                    echo ('<br>Resposta: <b>'.nl2br($row['answer']).'</b>');
                }
                echo ("<br>Data de Cadastro: <b>".$row['created_at']."</b><br>".("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "faleConosco":
                $sql = "SELECT a.* FROM messages a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#FFFF00'>Enviado</span>" : "<span style='color:#000033'>Respondido</span>";
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo ("1|-|Nome: <b>".$row['name']."</b><br>Email: <b>".$row['email']."</b><br>".("Assunto").": <b>".$row['subject']."</b><br>".("Telefone").": <b>".$row['phone']."</b><br>".("Mensagem").": <b>".nl2br($row['text'])."</b><br>Status: <b>".$status."</b>");
                if ($row['status'] == 2){
                    echo ('<br>Resposta: <b>'.nl2br($row['answer']).'</b>');
                }
                echo ("<br>Data de Cadastro: <b>".$row['created_at']."</b><br>".("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "target":
                $sql = "SELECT a.* FROM targets a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>";
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo ("1|-|Nome: <b>".$row['name']."</b><br>Status: <b>".$status."</b>");
                echo ("<br>Data de Cadastro: <b>".$row['created_at']."</b><br>".("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;            
            case "position":
                $sql = "SELECT a.* FROM positions a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>";
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo ("1|-|Nome: <b>".$row['name']."</b><br>Status: <b>".$status."</b>");
                echo ("<br>Data de Cadastro: <b>".$row['created_at']."</b><br>".("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;           
            case "time_banner":
                $sql = "SELECT a.* FROM time_banners a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>";
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo ("1|-|Nome: <b>".$row['name']."</b><br>Status: <b>".$status."</b>");
                echo ("<br>Data de Cadastro: <b>".$row['created_at']."</b><br>".("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "statusPedido":
                $sql = "SELECT a.* FROM requests_statuses a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>";
                $enviarEmail = ($row['enviarEmail']) ? "Sim" : "Não";
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo ("1|-|Nome: <b>".$row['name']."</b><br>Sigla: <b>".$row['sigla']."</b><br>Cor da Fonte: <b>".$row['color']."</b><br>Background: <b>".$row['background']."</b><br>Enviar Email: <b>".$enviarEmail."</b><br>Email: <b>".$row['email']."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "tiposDocumento":
                $sql = "SELECT a.* FROM type_documents a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>" ;
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo ("1|-|Nome: <b>".$row['name']."</b><br>Status: <b>".$status."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "social_networks":
                $sql = "SELECT a.* FROM social_networks a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>" ;
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                if (!file_exists(DIRETORIO."assets/img/upload/".$row['img']) || !$row['img']){
                    $row['img'] = URL."img/noFoto1.gif";
                    $excluirImg = 0;
                }
                else{
                    $row['img'] = URL."assets/img/upload/".$row['img'];
                    $excluirImg = 1;
                }
                echo ("1|-|Nome: <b>".$row['name']."</b><br>Link: <b>".$row['link']."</b><br>");
                if ($excluirImg) {
                    echo "Imagem: <img src='" . $row['img'] . "' width='150'><input type='button' value='Excluir Imagem' class='btn btn-danger' onclick=excluirImg('social_network','" . $row['id'] . "','" . URL . "','" . $_REQUEST['idUser'] . "','a')><br>";
                }
                echo ("Cliques: <b>" . $row['cliques'] . "</b><br>Status: <b>".$status."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "formasPagamento":
                $sql = "SELECT a.* FROM payment_methods a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>" ;
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                if (!file_exists(DIRETORIO."assets/img/upload/".$row['img']) || !$row['img']){
                    $row['img'] = URL."img/noFoto1.gif";
                    $excluirImg = 0;
                }
                else{
                    $row['img'] = URL."assets/img/upload/".$row['img'];
                    $excluirImg = 1;
                }
                echo ("1|-|Nome: <b>".$row['name']."</b><br>");
                if ($excluirImg) {
                    echo "Imagem: <img src='" . $row['img'] . "' width='150'><input type='button' value='Excluir Imagem' class='btn btn-danger' onclick=excluirImg('social_network','" . $row['id'] . "','" . URL . "','" . $_REQUEST['idUser'] . "','a')><br>";
                }
                echo ("Data de Cadastro: <b>".$row['created_at']."</b><br>".("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "clientes":
                $sql = "SELECT a.*, b.name AS nomeTipoDocumento FROM clients a INNER JOIN type_documents b ON (a.typeDocument = b.id) WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo ("1|-|Nome: <b>".$row['name']."</b><br>Email: <b>".$row['email']."</b><br>Celular: <b>".$row['cel']."</b><br>Tipo de Documento: <b>".$row['nomeTipoDocumento']."</b><br>Documento: <b>".$row['document']."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "tiposProduto":
                $sql = "SELECT a.* FROM types_products a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>" ;
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo ("1|-|Nome: <b>".$row['name']."</b><br>Status: <b>".$status."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "produto":
                $sql = "SELECT a.* FROM products a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>" ;
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                if (!file_exists(DIRETORIO."assets/img/upload/".$row['img']) || !$row['img']){
                    $row['img'] = URL."img/noFoto1.gif";
                    $excluirImg = 0;
                }
                else{
                    $row['img'] = URL."assets/img/upload/".$row['img'];
                    $excluirImg = 1;
                }
                echo ("1|-|Nome: <b>".$row['name']."</b><br>".("Descrição").": <b>".$row['description']."</b><br>");
                if ($excluirImg) {
                    echo "Imagem: <img src='" . $row['img'] . "' width='150'><input type='button' value='Excluir Imagem' class='btn btn-danger' onclick=excluirImg('produto','" . $row['id'] . "','" . URL . "','" . $_REQUEST['idUser'] . "','o')><br>";
                }
                echo ("Status: <b>".$status."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "idioma":
                $sql = "SELECT a.* FROM languages a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>" ;
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                if (!file_exists(DIRETORIO."assets/img/upload/".$row['img']) || !$row['img']){
                    $row['img'] = URL."img/noFoto1.gif";
                    $excluirImg = 0;
                }
                else{
                    $row['img'] = URL."assets/img/upload/".$row['img'];
                    $excluirImg = 1;
                }
                echo ("1|-|Nome: <b>".$row['name']."</b><br>Status: <b>".$status."</b><br>");
                if ($excluirImg) {
                    echo "Imagem: <img src='" . $row['img'] . "' width='150'><input type='button' value='Excluir Imagem' class='btn btn-danger' onclick=excluirImg('languages','" . $row['id'] . "','" . URL . "','" . $_REQUEST['idUser'] . "','o')><br>";
                }
                echo ("Data de Cadastro: <b>".$row['created_at']."</b><br>".("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "a";
                break;
            case "coins":
                $sql = "SELECT a.* FROM coins a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>" ;
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo ("1|-|Nome: <b>".$row['name']."</b><br>Sigla: <b>".$row['sigla']."</b><br>Valor Real: <b>R$ ".number_format($row['valorReal'], 2, ',', '.')."</b><br>Status: <b>".$status."</b><br>");
                echo ("Data de Cadastro: <b>".$row['created_at']."</b><br>".("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "a";
                break;
            case "formaPagamento":
                $sql = "SELECT a.* FROM payment_methods a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>" ;
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                if (!file_exists(DIRETORIO."assets/img/upload/".$row['img']) || !$row['img']){
                    $row['img'] = URL."img/noFoto1.gif";
                    $excluirImg = 0;
                }
                else{
                    $row['img'] = URL."assets/img/upload/".$row['img'];
                    $excluirImg = 1;
                }
                echo ("1|-|Nome: <b>".$row['name']."</b><br>");
                if ($excluirImg) {
                    echo "Imagem: <img src='" . $row['img'] . "' width='150'><input type='button' value='Excluir Imagem' class='btn btn-danger' onclick=excluirImg('formaPagamento','" . $row['id'] . "','" . URL . "','" . $_REQUEST['idUser'] . "','a')><br>";
                }
                echo ("Data de Cadastro: <b>".$row['created_at']."</b><br>".("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "a";
                break;
            case "banner":
                $sql = "SELECT a.* FROM banners a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>" ;
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                if (!file_exists(DIRETORIO."assets/img/upload/".$row['img']) || !$row['img']){
                    $row['img'] = URL."img/noFoto1.gif";
                    $excluirImg = 0;
                }
                else{
                    $row['img'] = URL."assets/img/upload/".$row['img'];
                    $excluirImg = 1;
                }
                if ($row['position'] == 1){
                    $row['position'] = "Banner Popup";
                }
                elseif ($row['position'] == 2){
                    $row['position'] = ("Banner Meio Página");
                }
                if ($row['target'] == '_blank'){
                    $row['target'] = ("Nova Página");
                }
                elseif ($row['target'] == '_parent'){
                    $row['target'] = ("Mesma Página");
                }
                echo ("1|-|Nome: <b>".$row['name']."</b><br>".("Descrição").": <b>".$row['description']."</b><br>".('Posição: ')."<b>".$row['position']."</b><br>Abertura do Link: <b>".$row['target']."</b><br>Link: <b>".$row['link']."</b><br>");
                if ($excluirImg) {
                    echo "Imagem: <img src='" . $row['img'] . "' width='150'><input type='button' value='Excluir Imagem' class='btn btn-danger' onclick=excluirImg('banner','" . $row['id'] . "','" . URL . "','" . $_REQUEST['idUser'] . "','o')><br>";
                }
                echo ("Status: <b>".$status."</b><br>".("Exibições").": <b>".$row['exibitions']."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "pagina":
                $sql = "SELECT a.* FROM pages a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $apareceMenu = ($row['appearsMenu'] == 1) ? "<span style='color:#000033'>Sim</span>" : "<span style='color:#FF0000'>Não</span>" ;
                $apareceSite = ($row['appearsSite'] == 1) ? "<span style='color:#000033'>Sim</span>" : "<span style='color:#FF0000'>Não</span>" ;
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>" ;
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                if (!file_exists(DIRETORIO."assets/img/upload/".$row['img']) || !$row['img']){
                    $row['img'] = URL."img/noFoto1.gif";
                    $excluirImg = 0;
                }
                else{
                    $row['img'] = URL."assets/img/upload/".$row['img'];
                    $excluirImg = 1;
                }
                if ($row['position'] == 1){
                    $row['position'] = "Banner Popup";
                }
                elseif ($row['position'] == 2){
                    $row['position'] = "Banner meio Página";
                }
                if ($row['target'] == '_blank'){
                    $row['target'] = "Nova página";
                }
                elseif ($row['target'] == '_parent'){
                    $row['target'] = "Mesma página";
                }
                echo ("1|-|Nome: <b>".$row['name']."</b><br>".("Subtítulo").": <b>".$row['subname']."</b><br>");
                if ($excluirImg) {
                    echo "Imagem: <img src='" . $row['img'] . "' width='150'><input type='button' value='Excluir Imagem' class='btn btn-danger' onclick=excluirImg('pagina','" . $row['id'] . "','" . URL . "','" . $_REQUEST['idUser'] . "','a')><br>";
                }
                echo ("Aparece no Menu: <b>".($apareceMenu)."</b><br>Aparece no Site: <b>".($apareceSite)."</b><br>Status: <b>".$status."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "a";
                break;
            case "subitem":
                $sql = "SELECT a.*, b.name AS nomePagina FROM subitems a INNER JOIN pages b ON (a.page = b.id) WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $apareceImagem = ($row['appearsImg'] == 1) ? "<span style='color:#000033'>Sim</span>" : "<span style='color:#FF0000'>Não</span>";
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>" ;
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                if (!file_exists(DIRETORIO."assets/img/upload/".$row['img']) || !$row['img']){
                    $row['img'] = URL."img/noFoto1.gif";
                    $excluirImg = 0;
                }
                else{
                    $row['img'] = URL."assets/img/upload/".$row['img'];
                    $excluirImg = 1;
                }
                if ($row['position'] == 1){
                    $row['position'] = "Banner Topo";
                }
                echo ("1|-|".("Página").": <b>".($row['nomePagina'])."</b><br>Nome: <b>".($row['name'])."</b><br>".("Subtítulo").": <b>".($row['subname'])."</b><br>".("Descrição").": <b>".($row['description'])."</b><br>".("Descrição 2").": <b>".($row['description2'])."</b><br>".("Descrição 3").": <b>".($row['description3'])."</b><br>");
                if ($excluirImg) {
                    echo "Imagem: <img src='" . $row['img'] . "' width='150'><input type='button' value='Excluir Imagem' class='btn btn-danger' onclick=excluirImg('subitem','" . $row['id'] . "','" . URL . "','" . $_REQUEST['idUser'] . "','o')><br>";
                }
                echo ("Aparece Imagem no ".("Subítem").": <b>".($apareceImagem)."</b><br>Status: <b>".$status."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "tipoServico":
                $sql = "SELECT a.* FROM types_services a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>" ;
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo ("1|-|Nome: <b>".$row['name']."</b><br>Status: <b>".$status."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "tipoModulo":
                $sql = "SELECT a.* FROM type_modules a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>" ;
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo ("1|-|Nome: <b>".$row['name']."</b><br>Status: <b>".$status."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "modulo":
                $sql = "SELECT a.*, b.name AS nomeTipoModulo FROM modules a INNER JOIN type_modules b ON (a.typeModule = b.id) WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>" ;
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo ("1|-|".("Nome do Tipo Módulo").": <b>".$row['nomeTipoModulo']."</b><br>Nome: <b>".$row['name']."</b><br>".("Url Amigável").": <b>".$row['slug']."</b><br>Status: <b>".$status."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "prioridade":
                $sql = "SELECT a.* FROM priorities a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>" ;
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo ("1|-|Nome: <b>".$row['name']."</b><br>Status: <b>".$status."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "a";
                break;
            case "tipoVersao":
                $sql = "SELECT a.*, b.name AS nomeTipoServico FROM type_versions a INNER JOIN types_services b ON (a.typeService = b.id) WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>";
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo ("1|-|".("Nome do Tipo de Serviço").": <b>".($row['nomeTipoServico'])."</b><br>Nome: <b>".$row['name']."</b><br>Status: <b>".$status."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "categorias":
                $sql = "SELECT a.*, b.name AS nomeTipoServico FROM categories a INNER JOIN types_services b ON (a.typeService = b.id) WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>";
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo ("1|-|".("Nome do Tipo de Serviço").": <b>".$row['nomeTipoServico']."</b><br>Nome: <b>".$row['name']."</b><br>Status: <b>".$status."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "a";
                break;
            case "parametroSite":
                $sql = "SELECT a.* FROM param_sites a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>";
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo ("1|-|Nome: <b>".$row['name']."</b><br>Valor: <b>".$row['value']."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "parametroAdmin":
                $sql = "SELECT a.* FROM param_admins a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $status = ($row['status'] == 1) ? "<span style='color:#000033'>Ativo</span>" : "<span style='color:#FF0000'>Inativo</span>";
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo ("1|-|Nome: <b>".$row['name']."</b><br>Valor: <b>".$row['value']."</b><br>Data de Cadastro: <b>".$row['created_at']."</b><br>".("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "versao":
                $sql = "SELECT a.* FROM versions a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                if (!file_exists(DIRETORIO."assets/img/upload/".$row['img'])){
                    $row['img'] = URL."img/noFotoUsuario.png";
                    $excluirImg = 0;
                }
                else{
                    $row['img'] = URL."assets/img/upload/".$row['img'];
                    $excluirImg = 1;
                }
                $row['updated_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode('-', $row['date']);
                $row['data'] = $vet[2]."/".$vet[1]."/".$vet[0];
                echo ("1|-|Nome: <b>".$row['name']."</b><br>".("Descrição")." <b>".$row['description']."</b><br>Data: <b>".$row['data']."</b><br>");
                if ($excluirImg) {
                    echo "Imagem: <img src='" . $row['img'] . "' width='150'><input type='button' value='Excluir Imagem' class='btn btn-danger' onclick=excluirImg('versao','" . $row['id'] . "','" . URL . "','" . $_REQUEST['idUser'] . "','a')><br>";
                }
                echo ("Data de Cadastro: <b>".$row['created_at']."</b><br>".("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "usuarios":
                $sql = "SELECT a.* FROM users a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                if (!file_exists(DIRETORIO."assets/img/upload/".$row['img'])){
                    $row['img'] = URL."img/user-avatar.svg";
                    $excluirImg = 0;
                }
                else{
                    $row['img'] = URL."assets/img/upload/".$row['img'];
                    $excluirImg = 1;
                }
                echo ("1|-|Nome: <b>".$row['name']."</b><br>Email: <b>".$row['email']."</b><br>Foto: <img src='");
                if ($excluirImg){
                    echo $row['img'];
                    echo "' width='100'> <a class='btn btn-primary' style='color:#FFFFFF' onclick=excluirImg('usuarios','".$row['id']."','".URL."','".$_SESSION['user']['id']."','a');>Excluir Foto</a><br>";
                }
                else{
                    echo URL."img/noFotoUsuario.png' width='100'><br>";
                }
                echo ("Data de Cadastro: <b>".$row['created_at']."</b><br>".("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
            case "usuariosPre":
                $sql = "SELECT a.* FROM user_pres a WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo ("1|-|Nome: <b>".$row['name']."</b><br>Email: <b>".$row['email']."</b><br>");
                echo ("Data de Cadastro: <b>".$row['created_at']."</b><br>".("Data de Atualização").": <b>".$row['updated_at']."</b>");
                $artigo = "o";
                break;
        }
        $action = "Visualizou ".$artigo." ".$_REQUEST['table']." ".$_REQUEST['id'];
        $sql = "INSERT INTO logs (action, user, created_at, updated_at) VALUES ('".$action."', '".$_REQUEST['idUser']."', now(), now())";
        mysqli_query($con, $sql);
        break;
     case 'excluirImg':
        unlink(DIRETORIO."assets/img/upload/".$_REQUEST['table'].$_REQUEST['id'].".jpg");
        unlink(DIRETORIO."assets/img/upload/".$_REQUEST['table'].$_REQUEST['id'].".gif");
        unlink(DIRETORIO."assets/img/upload/".$_REQUEST['table'].$_REQUEST['id'].".png");
        unlink(DIRETORIO."assets/img/upload/".$_REQUEST['table'].$_REQUEST['id'].".bmp");
        unlink(DIRETORIO."assets/img/upload/".$_REQUEST['table'].$_REQUEST['id'].".svg");
        if ($_REQUEST['table'] == 'usuarios'){
            $table = "usuario";
        }
        elseif ($_REQUEST['table'] == 'produto'){
            $table = "produto";
        }
        elseif ($_REQUEST['table'] == 'formaPagamento'){
            $table = "forma de pagamento";
        }
        elseif ($_REQUEST['table'] == 'banner'){
            $table = "banner";
        }
        elseif ($_REQUEST['table'] == 'pagina'){
            $table = "página";
        }
        elseif ($_REQUEST['table'] == 'subitem'){
            $table = "subitem";
        }
        elseif ($_REQUEST['table'] == 'versao'){
            $table = "versao";
        }
        elseif ($_REQUEST['table'] == 'usuario'){
            $table = "usuario";
        }
        $action = "Excluiu a imagem d".$_REQUEST['artigo']." ".$table." ".$_REQUEST['id'];
        $sql = "INSERT INTO logs (action, user, created_at, updated_at) VALUES ('".$action."', '".$_REQUEST['idUser']."', now(), now())";
        mysqli_query($con, $sql);
        echo "1|-|".$_SESSION['user']['id']."|-|".URL."admin/img/user-avatar.svg";
        break;
    case "selecionaCliente":
        $sql = "SELECT a.*, b.name AS nomeTipoDocumento FROM clients a INNER JOIN type_documents b ON (a.typeDocument = b.id) WHERE a.id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        $html = "Nome do Cliente: <b>".($row['name'])."</b><br>
                Email do Cliente: <b>".($row['email'])."</b><br>
                Telefone do Cliente: <b>".($row['cel'])."</b><br>
                Tipo de Documento do Cliente: <b>".($row['nomeTipoDocumento'])."</b><br>
                Documento do Cliente: <b>".($row['document'])."</b> ";
        $sql = "SELECT * FROM addresses WHERE idClient = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        $html2 = "<select name='enderecoEditar' id='enderecoEditar' class='form-control' onchange='selecionaEndereco(this.value,\"".URL."\")'><option value=''>Selecione o endereço abaixo corretamente...</option>";
        if (mysqli_num_rows($query)){
            while ($row = mysqli_fetch_array($query)){
                $html2 .= "<option value='".$row['id']."'>".($row['name'])."</option>";
            }
        }
        $html2 .= "</select><span id='dadosEndereco'>Selecione o endereco acima corretamente!</span>";
        echo "1|-|".($html)."|-|".$html2;
        break;
    case "selecionaEndereco":
        if ($_REQUEST['id'] == 'new'){
            $html = '<label for="cepCadEndereco2">CEP do Endereço:</label>
            <input class="form-control" value="" placeholder="Informe o cep do endereço corretamente..." id="cepCadEndereco2" required="" name="cepCadEndereco2" maxlength="9" onkeyup=mascara(this,"#####-###",event);verificaCepCadEndereco2(this.value)>
            <label for="logradouroCadEndereco2">Logradouro:</label>
                <input class="form-control" value="" placeholder="Informe o logradouro do endereço corretamente..." id="logradouroCadEndereco2" required="" name="logradouroCadEndereco2">
                <label for="numeroCadEndereco2">Número:</label>
                <input class="form-control" value="" placeholder="Informe o número do endereço corretamente..." id="numeroCadEndereco2" required="" name="numeroCadEndereco2">
                <label for="complementoCadEndereco2">Complemento:</label>
                <input class="form-control" value="" placeholder="Informe o complemento do endereço corretamente..." id="complementoCadEndereco2" name="complementoCadEndereco2">
                <label for="bairroCadEndereco2">Bairro:</label>
                <input class="form-control" value="" placeholder="Informe o bairro do endereço corretamente..." id="bairroCadEndereco2" required="" name="bairroCadEndereco2">
                <label for="cidadeCadEndereco2">Cidade:</label>
                <input class="form-control" value="" placeholder="Informe a cidade do endereço corretamente..." id="cidadeCadEndereco2" required="" name="cidadeCadEndereco2">
                <label for="estadoCadEndereco2">Estado:</label>
                <select class="form-control" id="estadoCadEndereco2" required="" name="estadoCadEndereco2">
                    <option value="">Selecione o estado do endereço abaixo corretamente...</option>';
            $sql = "SELECT * FROM states";
            $query = mysqli_query($con, $sql);
            if (mysqli_num_rows($query)) {
                while ($row = mysqli_fetch_array($query)) {
                    $html .= '
                        <option value="'.$row['sigla'].'">'.$row['nome'].'</option>';
                }
            }
            $html .= '</select>
            <label for="referenciaCadEndereco2">Ponto de Referência:</label>
            <input class="form-control" value="" placeholder="Informe o ponto de referência do endereço corretamente..." id="referenciaCadEndereco2" name="referenciaCadEndereco2">
            <input type="button" class="btn btn-primary" value="Cadastrar" onclick=validaCadastrarEndereco("'.$_REQUEST['idPedido'].'","'.URL.'")>';
        }
        else {
            if ($_REQUEST['id']) {
                $sql = "SELECT * FROM addresses WHERE id = '" . $_REQUEST['id'] . "'";
            }
            else{
                $sql = "SELECT * FROM requests_addresses WHERE idRequest = '".$_REQUEST['idPedido']."'";
            }
            $query = mysqli_query($con, $sql);
            $row = mysqli_fetch_array($query);
            $html = "CEP do Endereço: <b>" . ($row['cep']) . "</b><br>
                Logradouro do Endereço: <b>" . ($row['address']) . "</b><br>
                Número do Endereço: <b>" . ($row['number']) . "</b><br>
                Complemento do Endereço: <b>" . ($row['complement']) . "</b><br>
                Bairro do Endereço: <b>" . ($row['neighborhood']) . "</b><br>
                Cidade do Endereço: <b>" . ($row['city']) . "</b><br>
                Estado do Endereço: <b>" . ($row['state']) . "</b>";
            if ($row['referencia']){
                $html .= "<br>Ponto de Referência: <b>".($row['referencia'])."</b>";
            }
        }
        echo "1|-|".($html);
        break;
    case "cadastrarEnderecoClientePedido":
        $sql = "SELECT * FROM requests WHERE id = '".$_REQUEST['idPedido']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        $sql = "INSERT INTO addresses (idClient, cep, address, number, complement, neighborhood, city, state, referencia) VALUES ('".$row['client']."', '".$_REQUEST['cep']."', '".$_REQUEST['address']."', '".$_REQUEST['number']."', '".$_REQUEST['complement']."', '".$_REQUEST['neighborhood']."', '".$_REQUEST['city']."', '".$_REQUEST['state']."', '".$_REQUEST['referencia']."')";
        mysqli_query($con, $sql);
        $idAddress = mysqli_insert_id($con);
        $sql = "SELECT * FROM addresses WHERE idClient = '".$row['client']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $html = "<select name='enderecoEditar' id='enderecoEditar' class='form-control' onchange='selecionaEndereco(this.value,\"".$_REQUEST['iPedido']."\",\"".URL."\")'><option value=''>Selecione o endereço corretamente...</option><option value='new'>Cadastrar Novo Endereço</option>";
            while ($row = mysqli_fetch_array($query)){
                $html .= "<option value='".$row['id']."' ";
                if ($idAddress == $row['id']){
                    $html .= "selected";
                }
                $html .= ">".($row['address']." - ".$row['number']);
                if ($row['complement']) {
                    $html .= " - " . ($row['complement']);
                }
                $html .= " - ".($row['neighborhood']." - ".$row['city']." - ".$row['state']." - CEP: ".$row['cep']);
                if ($row['referencia']) {
                    $html .= " - " . ($row['referencia']);
                }
                $html .= "</option>";
            }
            $html .= "</select>
            <div id='dadosEndereco'>CEP do Endereço: <b>".($_REQUEST['cep'])."</b><br>
                Logradouro do Endereço: <b>".($_REQUEST['address'])."</b><br>
                Número do Endereço: <b>".($_REQUEST['number'])."</b>";
            if ($_REQUEST['complement']){
                $html .= "<br>
                Complemento do Endereço: <b>".($_REQUEST['complement'])."</b>";
            }
            $html .= "<br>
                Bairro do Endereço: <b>".($_REQUEST['neighborhood'])."</b><br>
                Cidade do Endereço: <b>".($_REQUEST['city'])."</b><br>
                Estado do Endereço: <b>".($_REQUEST['state'])."</b>";
            if ($_REQUEST['referencia']) {
                $html .= "<br>
                Ponto de Referência: <b>" . ($_REQUEST['referencia']) . "</b>";
            }
            $html .= "</div>";
        }
        echo "1|-|".$html;
        break;
        case "proximaDescricaoPaginaEdicao":
            $i = $_REQUEST['qualVai'];
            $htmlDescription = "<label for='tipoDescription".$i."'>Tipo de Descrição ".$i."</label>
            <select name='tipoDescription".$i."' id='tipoDescription".$i."' class='form-control'>
            <option value='h1' ";
            if ($row2['type'] == 'h1'){
                $htmlDescription .= 'selected';
            }
            $htmlDescription .= ">Título 1</option><option value='h2' ";
            if ($row2['type'] == 'h2'){
                $htmlDescription .= 'selected';
            }
            $htmlDescription .= ">Título 2</option><option value='h3' ";
            if ($row2['type'] == 'h3'){
                $htmlDescription .= 'selected';
            }
            $htmlDescription .= ">Título 3</option><option value='h4' ";
            if ($row2['type'] == 'h4'){
                $htmlDescription .= 'selected';
            }
            $htmlDescription .= ">Título 4</option><option value='h5' ";
            if ($row2['type'] == 'h5'){
                $htmlDescription .= 'selected';
            }
            $htmlDescription .= ">Título 5</option><option value='p' ";
            if ($row2['type'] == 'p'){
                $htmlDescription .= 'selected';
            }
            $htmlDescription .= ">Parágrafo</option>
            </select>
            <label for='description".$i."'>Descrição ".$i."</label>
            <textarea name='description".$i."' id='description".$i."' class='form-control'>".($row2['text'])."</textarea></div>";
            $j = $i;
            $i++;
            $htmlDescription .= "<div id='proximaDescricaoEdicao".$i."'><img src='".URL."admin/img/excluir.svg' width='25' style='cursor:pointer' onclick=excluirDescricaoPaginaEdicao('".$j."','".URL."')>";
            $htmlDescription .= "<div style='cursor:pointer;' onClick=vaiProximaDescricaoPaginaEdicao('".URL."')><img src='".URL."admin/img/mais.png' style='height: 35px'> Adicionar Nova Descrição</div></div></div></div>";
            echo "1|-|".$htmlDescription."|-|".$i;
            break;
        case "excluirDescricaoPaginaEdicao":
            $i = $_REQUEST['qual'];
            if ($i > 0){
                $htmlDescription = "<label for='tipoDescription".$i."'>Tipo de Descrição ".$i."</label>
                <select name='tipoDescription".$i."' id='tipoDescription".$i."' class='form-control'>
                <option value='h1' ";
                if ($row2['type'] == 'h1'){
                    $htmlDescription .= 'selected';
                }
                $htmlDescription .= ">Título 1</option><option value='h2' ";
                if ($row2['type'] == 'h2'){
                    $htmlDescription .= 'selected';
                }
                $htmlDescription .= ">Título 2</option><option value='h3' ";
                if ($row2['type'] == 'h3'){
                    $htmlDescription .= 'selected';
                }
                $htmlDescription .= ">Título 3</option><option value='h4' ";
                if ($row2['type'] == 'h4'){
                    $htmlDescription .= 'selected';
                }
                $htmlDescription .= ">Título 4</option><option value='h5' ";
                if ($row2['type'] == 'h5'){
                    $htmlDescription .= 'selected';
                }
                $htmlDescription .= ">Título 5</option><option value='p' ";
                if ($row2['type'] == 'p'){
                    $htmlDescription .= 'selected';
                }
                $htmlDescription .= ">Parágrafo</option>
                </select>
                <label for='description".$i."'>Descrição ".$i."</label>
                <textarea name='description".$i."' id='description".$i."' class='form-control'>".($row2['text'])."</textarea></div>";
                $j = $i;
                $i++;
                $htmlDescription .= "<div id='proximaDescricaoEdicao".$i."'><img src='".URL."admin/img/excluir.svg' width='25' style='cursor:pointer' onclick=excluirDescricaoPaginaEdicao('".$j."','".URL."')>";
            }
            else{                
                $j = $i;
                $i++;
                $htmlDescription .= "<div id='proximaDescricaoEdicao".$i."'>";
            }
            $htmlDescription .= "<div style='cursor:pointer;' onClick=vaiProximaDescricaoPaginaEdicao('".URL."')><img src='".URL."admin/img/mais.png' style='height: 35px'> Adicionar Nova Descrição</div></div></div></div>";
            echo "1|-|".$htmlDescription."|-|".$i;
            break;
    case "pegaDados":
        switch ($_REQUEST['table']){
            case 'pedido':
                $sql = "SELECT a.*, b.name AS nomeFormaPagamento, c.name AS nomeStatus, c.id AS idStatus, d.name, d.email,d.cel, d.document, e.name AS nomeTipoDocumento, f.cep, f.address AS enderecoCliente, f.number, f.complement, f.neighborhood, f.city, f.state, f.referencia
FROM requests a
INNER JOIN payment_methods b ON (a.paymentMethod = b.id)
INNER JOIN requests_statuses c ON (a.status = c.id)
INNER JOIN clients d ON (a.client = d.id)
INNER JOIN type_documents e ON (e.id = d.typeDocument)
INNER JOIN requests_addresses f ON (f.idRequest = a.id)
WHERE a.id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
                $row['created_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                $vet = explode(' ', $row['updated_at']);
                $vet2 = explode('-', $vet[0]);
                $row['updated_at'] = ($vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h");
                echo ("1|-|<input type='hidden' name='idEdicao' id='idEdicao' value='".$row['id']."'><input type='hidden' value='".$row['status']."' id='statusGrava' name='statusGrava'><input type='hidden' name='idUserEdicao' id='idUserEdicao' value='".$_REQUEST['idUser']."'><h5>Dados do Pedido ".sprintf("%06s\n", $row[0])."</h5>".("Número do Pedido:")." <b>".sprintf("%06s\n", $row[0])."</b><br>Data do Pedido: <b>".$row['created_at']."</b><br>Status do Pedido: <b><select name='statusEditar' id='statusEditar' class='form-control'");
                if ($row['status'] >= '5'){
                    echo "disabled='true' ";
                }
                echo ("><option value=''>Selecione o status do pedido corretamente...</option>");
                $sql = "SELECT * FROM requests_statuses";
                $query2 = mysqli_query($con, $sql);
                if (mysqli_num_rows($query2)){
                    while ($row2 = mysqli_fetch_array($query2)){
                        echo "<option value='".$row2['id']."'";
                        if ($row2['id'] == $row['status']){
                            echo " selected";
                        }
                        echo ">".($row2['name'])."</option>";
                    }
                }
                echo ("</select></b><br>".("Forma de Pagamento").": <b><input type='hidden' value='".$row['paymentMethod']."' id='formaPagamentoGrava' name='formaPagamentoGrava'><select name='formaPagamentoEditar' id='formaPagamentoEditar' ");
                if ($row['status'] >= '4'){
                    echo "disabled='true' ";
                }
                echo ("class='form-control' onchange=selecionaFormaPagamentoPedido(this.value,'".$_REQUEST['id']."','".URL."')><option value=''>Selecione a forma de pagamento corretamente...</option>");
                $sql = "SELECT * FROM payment_methods";
                $query2 = mysqli_query($con, $sql);
                if (mysqli_num_rows($query2)){
                    while ($row2 = mysqli_fetch_array($query2)){
                        echo "<option value='".$row2['id']."'";
                        if ($row2['id'] == $row['paymentMethod']){
                            echo " selected";
                        }
                        echo ">".($row2['name'])."</option>";
                    }
                }
                echo ("</select></b>");
                $sql = "SELECT * FROM requests_items WHERE request = '".$row[0]."'";
                $query = mysqli_query($con, $sql);
                $totalItens = mysqli_num_rows($query);
                echo "<h5>Dados do";
                if ($totalItens > 1){
                    echo 's';
                }
                echo " Produto";
                if ($totalItens > 1){
                    echo 's';
                }
                if ($row['status'] < 4){
                echo (" <img src='".URL."admin/img/mais.png' width='25' style='cursor:pointer' onclick=addProdutoPedido('".$row['id']."','".URL."','".$_REQUEST['idUser']."')><div style='border:1px solid #CCCCCC; width:100%; display:none; position:absolute; background-color: #FFFFFF' id='addProdutoPedido'><div style='position:absolute; float:left; left:95%'><img src='".URL."admin/img/close.png' style='cursor:pointer' onclick=fecha('addProdutoPedido')></div><h5>Adicionar Produto ao Pedido</h5><div id='adicionaProdutoPedido'></div></div>");
                }
                echo ("</h5>
                     <table width='100%' cellpadding='0' cellspacing='0' border='0'>
                        <tr>
                            <th width='23%'>Nome do Produto</th>
                            <th width='23%'>Valor do Produto</th>
                            <th width='23%'>Quant.</th>
                            <th width='23%'>Valor Total</th>
                            <th width='8%'></th>
                        </tr>
                        ");
                while ($rowItens = mysqli_fetch_array($query)){
                    echo "<tr";
                    if ($i % 2 == 0){
                        echo " style='background-color:#F7F7F7'";
                    }
                    echo ">
                            <td>".($rowItens['name']);
                    if ($rowItens['domine'] != '') {
                        echo ' - <a href="'.$rowItens['domine'].'" target="_blank">' . substr($rowItens['domine'], 0, 15)."...</a>";
                    }
                    if ($rowItens['cashier_system']){
                        $sql = "SELECT * FROM cashier_system WHERE id = '".$rowItens['cashier_system']."'";
                        $query3 = mysqli_query($con, $sql);
                        $rowCashierSystem = mysqli_fetch_array($query3);
                        echo " <a onclick=abreFecha('informacoesSistema".$rowItens['id']."');><span id='imgProdutoPedido".$rowItens['id']."'><img src='".URL."admin/img/plus.png' width='20' style='cursor:pointer' title='Informações do Sistema de Caixa' onclick=mudaImgProdutoPedido('close','".$rowItens['id']."','".URL."','Sistema de Caixa')></span></a><div id='informacoesSistema".$rowItens['id']."' style='position:absolute; width:97%; border:1px solid #e7e7e7; display:none; text-align:center; background-color:#FFFFFF'><div style='position:absolute; float:left; left: 93%'><img src='".URL."admin/img/close.png' width='20' style='cursor: pointer' onclick=abreFecha('informacoesSistema".$rowItens['id']."'); title='Fechar'></div><h5>Informações do Sistema de Caixa</h5>Razão Social: <b>".$rowCashierSystem['razao_social']."</b><br>Nome Fantasia: <b>".$rowCashierSystem['nome_fantasia']."</b><br>Email: <b>".$rowCashierSystem['email']."</b><br>CNPJ: <b>".$rowCashierSystem['cnpj']."</b><br>CEP: <b>".$rowCashierSystem['cep']."</b><br>Logradouro: <b>".$rowCashierSystem['logradouro']."</b><br>Número: <b>".$rowCashierSystem['numero']."</b>";
                        if ($rowCashierSystem['complemento']) {
                            echo " Complemento: <b>" . $rowCashierSystem['complemento'] . "</b>";
                        }
                        echo "<br>Bairro: <b>".$rowCashierSystem['bairro']."</b><br>Cidade: <b>".$rowCashierSystem['cidade']."</b> Estado: <b>".$rowCashierSystem['estado']."</b><br>Tipo do Estabelecimento: <b>";
                        if ($rowCashierSystem['tipoEstabelecimento'] == 1){
                            echo "Mesas";
                        }
                        else{
                            echo "Caixas";
                        }
                        echo "</b>";
                        if ($rowCashierSystem['tipoEstabelecimento'] == 1){
                            echo "<br>Quantidade de Mesas: <b>".$rowCashierSystem['quantidade']."</b><br>Número de Pessoas Por Mesa: <b>".$rowCashierSystem['numeroPessoasPorMesa']."</b><br>Percentual do Garçom: <b>".$rowCashierSystem['percentual']."%</b>";
                        }
                        else{
                            echo "<br>Quantidade de Caixas: <b>".$rowCashierSystem['quantidade']."<b>";
                        }
                        echo "</div>";
                    }
                    if ($rowItens['school_system']){
                        $sql = "SELECT * FROM school_system WHERE id = '".$rowItens['school_system']."'";
                        $query3 = mysqli_query($con, $sql);
                        $rowSchoolSystem = mysqli_fetch_array($query3);
                        echo " <a onclick=abreFecha('informacoesSistema".$rowItens['id']."');><span id='imgProdutoPedido".$rowItens['id']."'><img src='".URL."admin/img/plus.png' width='20' style='cursor:pointer' title='Informações do Sistema Escolar' onclick=mudaImgProdutoPedido('close','".$rowItens['id']."','".URL."','Sistema_Escolar')></span></a><div id='informacoesSistema".$rowItens['id']."' style='position:absolute; width:97%; border:1px solid #e7e7e7; display:none; text-align:center; background-color:#FFFFFF'><div style='position:absolute; float:left; left: 93%'><img src='".URL."admin/img/close.png' width='20' style='cursor: pointer' onclick=abreFecha('informacoesSistema".$rowItens['id']."');mudaImgProdutoPedido('mais','".$rowItens['id']."','".URL."','Sistema_Escolar'); title='Fechar'></div><h5>Informações do Sistema Escolar</h5>Nome da Escola <b>".$rowSchoolSystem['nome']."</b><br>Email: <b>".$rowSchoolSystem['email']."</b><br>CEP: <b>".$rowSchoolSystem['cep']."</b><br>Logradouro: <b>".$rowSchoolSystem['logradouro']."</b><br>Número: <b>".$rowSchoolSystem['numero']."</b>";
                        if ($rowSchoolSystem['complemento']) {
                            echo " Complemento: <b>" . $rowSchoolSystem['complemento'] . "</b>";
                        }
                        echo "<br>Bairro: <b>".$rowSchoolSystem['bairro']."</b><br>Cidade: <b>".$rowSchoolSystem['cidade']."</b> Estado: <b>".$rowSchoolSystem['stado']."</b><br>Tipo de Nota: <b>";
                        if ($rowSchoolSystem['tipoNota'] == 1){
                            echo "Bimestral";
                        }
                        elseif ($rowSchoolSystem['tipoNota'] == 2){
                            echo "Trimestral";
                        }
                        elseif ($rowSchoolSystem['tipoNota'] == 3){
                            echo "Semestral";
                        }
                        elseif ($rowSchoolSystem['tipoNota'] == 4){
                            echo "Anual";
                        }
                        echo "</b><br>";
						$sql = "SELECT * FROM school_system_notas WHERE idSchool = '".$rowSchoolSystem['id']."'";
						$query4 = mysqli_query($con, $sql);
						if (mysqli_num_rows($query4)){
							while ($row4 = mysqli_fetch_array($query4)){
							echo $row4['etapa']."ª Etapa: <b>".$row4['ptsDistribuidos']."</b><br>";
							}
						}
						echo "Turno da Escola: <b>";
                        if ($rowSchoolSystem['turno'] == 1){
                            echo "Manhã";
                        }
                        if ($rowSchoolSystem['turno'] == 2){
                            echo "Tarde";
                        }
                        if ($rowSchoolSystem['turno'] == 3){
                            echo "Noite";
                        }
                        elseif ($rowSchoolSystem['turno'] == 4){
                            echo "Manhã e Tarde";
                        }
                        elseif ($rowSchoolSystem['turno'] == 5){
                            echo "Manhã e Noite";
                        }
                        elseif ($rowSchoolSystem['turno'] == 6){
                            echo "Tarde e Noite";
                        }
                        elseif ($rowSchoolSystem['turno'] == 7){
                            echo "Todos";
                        }
                        elseif ($rowSchoolSystem['turno'] == 8){
                            echo "Único";
                        }
                        echo "</b><br>Até que letra vai as turmas da Esola: <b>";
                        if ($rowSchoolSystem['letra'] == "Un"){
                            echo "Única";
                        }
                        else {
                            echo $rowSchoolSystem['letra'];
                        }
                        echo "</b>";
                        echo "</div>";
                    }
                    echo "</td>
                            <td>R$ ".number_format($rowItens['value'], 2, ',', '.')."</td>
                            <td>".$rowItens['quantity']."</td>
                            <td>R$ ".number_format($rowItens['value'] * $rowItens['quantity'], 2, ',', '.')."</td>
                            <td>";
                    if ($row['status'] < 4){
                            echo "<img src='".URL."admin/img/excluir.png' width='20' title='Excluir Produto' style='cursor:pointer' onclick=excluirProdutoPedido('".$rowItens['id']."','".URL."','".$_REQUEST['idUser']."','".$_REQUEST['id']."')>";
                    }
                    else{
                        echo "&nbsp;";
                    }
                    echo "</td>
                         </tr>";
                    $i++;
                    $total += $rowItens['value'] * $rowItens['quantity'];
                }
                echo "<tr>
                            <td colspan='4' style='text-align:right'>Sub-Total: <b>R$ ".number_format($total, 2, ',','.')."</b></td>
                      </tr>
		      <tr>
                            <td colspan='4' style='text-align:right;";
                if (!$row['descontoAVista'] || $row['descontoAVista'] == 0){
                    echo " display:none";
                }
                echo "' id='descontoAVistaPedido'>Desconto à Vista: <b style='color:#003300'>- R$ " . number_format($row['descontoAVista'], 2, ',', '.') . "</b></td>
                      </tr>
		      <tr>
                            <td colspan='4' style='text-align:right' id='totalPedido'>Total: <b style='color:#000033'>R$ " . number_format($row['total'], 2, ',', '.') . "</b></td>
                      </tr></table>
                     <h5>Dados do Cliente</h5>
                     <input type='hidden' value='".$row['client']."' id='clienteGrava' name='clienteGrava'>
                     <select name='clienteEditar' id='clienteEditar' class='form-control' onchange='selecionaCliente(this.value,\"".URL."\")'";    
                    if ($row['status'] >= '4'){
                        echo "disabled='true' ";
                    }
                     echo "><option value=''>Selecione o cliente corretamente...</option>";
                $sql = "SELECT * FROM clients";
                $query2 = mysqli_query($con, $sql);
                if (mysqli_num_rows($query2)){
                    while ($row2 = mysqli_fetch_array($query2)){
                        echo "<option value='".$row2['id']."'";
                        if ($row2['id'] == $row['client']){
                            echo " selected";
                        }
                        echo '>'.($row2['name'])."</option>";
                    }
                }
                echo "</select>
               <span id='dadosCliente'>
                Nome do Cliente: <b>".($row['name'])."</b><br>
                Email do Cliente: <b>".($row['email'])."</b><br>
                Telefone do Cliente: <b>".($row['cel'])."</b><br>
                Tipo de Documento do Cliente: <b>".($row['nomeTipoDocumento'])."</b><br>
                Documento do Cliente: <b>".($row['document'])."</b>
                </span>
                <h5>Dados do Endereço</h5>
                <span id='enderecos'>
                <input type='hidden' value='".$row['address']."' id='enderecoGrava' name='enderecoGrava'>
                <select name='enderecoEditar' id='enderecoEditar' class='form-control' onchange='selecionaEndereco(this.value,\"".$_REQUEST['id']."\",\"".URL."\")'";  
                if ($row['status'] >= '4'){
                    echo "disabled='true' ";
                }
                echo "><option value=''>Selecione o endereço corretamente...</option><option value='new'>Cadastrar Novo Endereço</option>";
                $sql = "SELECT * FROM addresses WHERE idClient = '".$row['client']."'";
                $query2 = mysqli_query($con, $sql);
                if (mysqli_num_rows($query2)){
                    while ($row2 = mysqli_fetch_array($query2)){
                        echo "<option value='".$row2['id']."'";
                        if ($row2['id'] == $row['address']){
                            echo " selected";
                        }
                        echo '>'.($row2['address']." - ".$row2['number']." - ".$row2['complement']." - ".$row2['neighborhood']." - ".$row2['city']." - ".$row2['state']." - CEP: ".$row2['cep']." - ".$row2['referencia'])."</option>";
                    }
                }
                echo "</select>
                <span id='dadosEndereco'>
                CEP do Endereço: <b>".($row['cep'])."</b><br>
                Logradouro do Endereço: <b>".($row['enderecoCliente'])."</b><br>
                Número do Endereço: <b>".($row['number'])."</b><br>
                Complemento do Endereço: <b>".($row['complement'])."</b><br>
                Bairro do Endereço: <b>".($row['neighborhood'])."</b><br>
                Cidade do Endereço: <b>".($row['city'])."</b><br>
                Estado do Endereço: <b>".($row['state'])."</b>";
                if ($row['referencia']){
                    echo "<br>Ponto de Referência: <b>".($row['referencia'])."</b>";
                }
                echo "
                </span></span>
                <h5>Mensagens do Pedido <IMG SRC='".URL."admin/img/refresh.png' height='25' style='cursor:pointer' onclick=pegarPedidoMensagens('".$row['id']."','".URL."');></h5>
                <input type='button' class='btn btn-primary' value='Adicionar Nova Mensagem' onclick=location.href='#';addMsgPedido('".$row['id']."','".URL."','1','1','".$row['client']."') data-toggle='modal' data-target='#addMsgPedido'><br>
                <div id='adicionaMensagemAoPedido' style='display:none; position:absolute; background-color:#FFFFFF; border:1px solid #e7e7e7; padding:10px'></div>
                <div id='mensagensPedido'></div>
                <br><input type='button' class='btn btn-primary' value='Adicionar Nova Mensagem' onclick=location.href='#';addMsgPedido('".$row['id']."','".URL."','1','".$row['client']."') data-toggle='modal' data-target='#addMsgPedido'>";
                $artigo = "o";
                break;
            case 'target':
                $sql = "SELECT * FROM targets WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo ("1|-|".$row['id']."|-|".$row['name']."|-|".$row['status']);
                break;
            case 'position':
                $sql = "SELECT * FROM positions WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo ("1|-|".$row['id']."|-|".$row['name']."|-|".$row['status']);
                break;
            case 'time_banner':
                $sql = "SELECT * FROM time_banners WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo ("1|-|".$row['id']."|-|".$row['name']."|-|".$row['status']);
                break;
            case 'anuncie':
                $sql = "SELECT * FROM anuncie_aqui WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo ("1|-|".$row['id']."|-|".$row['name']."|-|".$row['email']."|-|".$row['status']."|-|".$row['subject']."|-|".$row['phone']."|-|".$row['text']."|-|".$row['answer']."|-|".$row['nome_banner']."|-|".$row['link_banner']."|-|".$row['target_banner']."|-|".$row['posicao_banner']."|-|".$row['tipo_banner']);
                break;
            case 'redesSociais':
                $sql = "SELECT * FROM social_networks WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo ("1|-|".$row['id']."|-|".$row['name']."|-|".$row['status']."|-|".$row['description']."|-|".$row['link']."|-|".$row['cliques']);
                break;
            case 'newsletter':
                $sql = "SELECT * FROM newsletters WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo ("1|-|".$row['id']."|-|".$row['name']."|-|".$row['email']."|-|".$row['status']);
                break;
            case 'bugTracking':
                $sql = "SELECT * FROM bug_trackings WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo ("1|-|".$row['id']."|-|".$row['name']."|-|".$row['email']."|-|".$row['status']."|-|".$row['title']."|-|".$row['typeService']."|-|".$row['typeVersion']."|-|".$row['priority']."|-|".$row['category']."|-|".$row['message']."|-|".$row['answer']);
                break;
            case 'faleConosco':
                $sql = "SELECT * FROM messages WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo ("1|-|".$row['id']."|-|".$row['name']."|-|".$row['email']."|-|".$row['status']."|-|".$row['subject']."|-|".$row['phone']."|-|".$row['text']."|-|".$row['answer']);
                break;
            case 'statusPedido':
                $sql = "SELECT * FROM requests_statuses WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo ("1|-|".$row['id']."|-|".$row['sigla']."|-|".$row['name']."|-|".$row['color']."|-|".$row['background']."|-|".$row['enviarEmail']."|-|".$row['email']);
                break;
            case 'tipoDocumento':
                $sql = "SELECT * FROM type_documents WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo ("1|-|".$row['id']."|-|".$row['name']."|-|".$row['status']);
                break;
            case 'clientes':
                $sql = "SELECT * FROM clients WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo ("1|-|".$row['id']."|-|".$row['name']."|-|".$row['email']."|-|".$row['cel']."|-|".$row['typeDocument']."|-|".$row['document']);
                break;
            case 'tiposProduto':
                $sql = "SELECT * FROM types_products WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo ("1|-|".$row['id']."|-|".$row['name']."|-|".$row['status']);
                break;
            case 'produto':
                $sql = "SELECT * FROM products WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo ("1|-|".$row['id']."|-|".$row['name']."|-|".$row['status']."|-|".$row['description'])."|-|".URL."admin/paginas/itensVendaProduto.php?idProduto=".$_REQUEST['id'];
                break;
            case 'formaPagamento':
                $sql = "SELECT * FROM payment_methods WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo ("1|-|".$row['id']."|-|".$row['name']);
                break;
            case 'banner':
                $sql = "SELECT * FROM banners WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo ("1|-|".$row['id']."|-|".$row['name']."|-|".$row['status']."|-|".$row['description']."|-|".$row['position']."|-|".$row['link']."|-|".$row['target']."|-|".$row['validade']);
                break;
            case 'languages':
                $sql = "SELECT * FROM languages WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $i = 1;
                echo "1|-|".$row['id']."|-|".$row['name']."|-|".$row['status']."|-|".$row['description']."|-|".$row['subname']."|-|".$row['appearsMenu']."|-|".$row['appearsSite']."|-|".$row['name_menu']."|-|".$htmlDescription;
                break;
            case 'coins':
                $sql = "SELECT * FROM coins WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $i = 1;
                echo "1|-|".$row['id']."|-|".$row['name']."|-|".$row['sigla']."|-|".number_format($row['valorReal'], 2, ',', '.')."|-|".$row['status']."|-|".$row['url'];
                break;
            case 'pagina':
                $sql = "SELECT * FROM pages WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $sql = "SELECT * FROM pages_descriptions WHERE page = '".$_REQUEST['id']."' ORDER BY num ASC";
                $query2 = mysqli_query($con, $sql);
                $i = 1;
                $htmlDescription = "<input type='hidden' name='qtasTemEdicao' id='qtasTemEdicao' value='".mysqli_num_rows($query2)."'>
                <div id='proximaDescricaoEdicao0'>";
                if (mysqli_num_rows($query2)){
                    while ($row2 = mysqli_fetch_array($query2)){
                        $htmlDescription .= "<div id='proximaDescricaoEdicao".$i."'><label for='tipoDescription".$i."'>Tipo de Descrição ".$i."</label>
                        <select name='tipoDescription".$i."' id='tipoDescription".$i."' class='form-control'>
                        <option value='h1' ";
                        if ($row2['type'] == 'h1'){
                            $htmlDescription .= 'selected';
                        }
                        $htmlDescription .= ">Título 1</option><option value='h2' ";
                        if ($row2['type'] == 'h2'){
                            $htmlDescription .= 'selected';
                        }
                        $htmlDescription .= ">Título 2</option><option value='h3' ";
                        if ($row2['type'] == 'h3'){
                            $htmlDescription .= 'selected';
                        }
                        $htmlDescription .= ">Título 3</option><option value='h4' ";
                        if ($row2['type'] == 'h4'){
                            $htmlDescription .= 'selected';
                        }
                        $htmlDescription .= ">Título 4</option><option value='h5' ";
                        if ($row2['type'] == 'h5'){
                            $htmlDescription .= 'selected';
                        }
                        $htmlDescription .= ">Título 5</option><option value='p' ";
                        if ($row2['type'] == 'p'){
                            $htmlDescription .= 'selected';
                        }
                        $htmlDescription .= ">Parágrafo</option>
                        </select>
                        <label for='description".$i."'>Descrição ".$i."</label>
                        <textarea name='description".$i."' id='description".$i."' class='form-control'>".($row2['text'])."</textarea></div>";
                        $i++;
                    }
                    $htmlDescription .= "<div id='proximaDescricaoEdicao".$i."'><img src='".URL."admin/img/excluir.svg' width='25' style='cursor:pointer' onclick=excluirDescricaoPaginaEdicao('".mysqli_num_rows($query2)."','".URL."')>";
                }
                else{
                    $htmlDescription .= "<div id='proximaDescricaoEdicao".$i."'>";
                }
                $htmlDescription .= "<div style='cursor:pointer;' onClick=vaiProximaDescricaoPaginaEdicao('".URL."')><img src='".URL."admin/img/mais.png' style='height: 35px'> Adicionar Nova Descrição</div></div></div></div>";
                echo "1|-|".$row['id']."|-|".$row['name']."|-|".$row['status']."|-|".$row['description']."|-|".$row['subname']."|-|".$row['appearsMenu']."|-|".$row['appearsSite']."|-|".$row['name_menu']."|-|".$htmlDescription;
                break;
            case 'subitem':
                $sql = "SELECT * FROM subitems WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo ("1|-|".$row['id']."|-|".$row['name']."|-|".$row['status']."|-|".$row['description']."|-|".$row['subname']."|-|".$row['appearsImg']."|-|".$row['page']."|-|".$row['descriptionVejaUmExemplo']."|-|".$row['description2']."|-|".$row['description3']."|-|".$row['categorie']);
                break;
            case 'tipoServico':
                $sql = "SELECT * FROM types_services WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo "1|-|".$row['id']."|-|".($row['name'])."|-|".$row['status'];
                break;
            case 'prioridade':
                $sql = "SELECT * FROM priorities WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo ("1|-|".$row['id']."|-|".$row['name']."|-|".$row['status']);
                break;
            case 'tipoVersao':
                $sql = "SELECT * FROM type_versions WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo ("1|-|".$row['id']."|-|".$row['typeService']."|-|".$row['name']."|-|".$row['status']);
                break;
            case 'categorias':
                $sql = "SELECT * FROM categories WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo ("1|-|".$row['id']."|-|".$row['typeService']."|-|".$row['name']."|-|".$row['status']);
                break;
            case 'parametroAdmin':
                $sql = "SELECT * FROM param_admins WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo ("1|-|".$row['id']."|-|".$row['name']."|-|".$row['value']."|-|".$row['status']);
                break;
            case 'parametroSite':
                $sql = "SELECT * FROM param_sites WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo ("1|-|".$row['id']."|-|".$row['name']."|-|".$row['value']."|-|".$row['status']);
                break;
            case 'versao':
                $sql = "SELECT * FROM versions WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo ("1|-|".$row['id']."|-|".$row['name']."|-|".$row['description']."|-|".$row['date']);
                break;
            case 'tipoModulo':
                $sql = "SELECT * FROM type_modules WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo ("1|-|".$row['id']."|-|".$row['name']."|-|".$row['status']);
                break;
            case 'modulo':
                $sql = "SELECT * FROM modules WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo ("1|-|".$row['id']."|-|".$row['name']."|-|".$row['status']."|-|".$row['typeModule']."|-|".$row['slug']);
                break;
            case 'usuarios':
                $sql = "SELECT * FROM users WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo ("1|-|".$row['id']."|-|".$row['name']."|-|".$row['email']);
                break;
            case 'usuariosPre':
                $sql = "SELECT * FROM user_pres WHERE id = '".$_REQUEST['id']."'";
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                echo ("1|-|".$row['id']."|-|".$row['name']."|-|".$row['email']);
                break;
        }
        break;
    case "excluir":
        $sql = "DELETE FROM ".$_REQUEST['table']." WHERE id = '".$_REQUEST['id']."'";
        mysqli_query($con, $sql) or die(mysqli_error($con));
        $acao = "Excluiu ".$_REQUEST['artigo']." ".$_REQUEST['tabela']." ".$_REQUEST['id'];
        $sql = "INSERT INTO logs (action, user, created_at, updated_at) VALUES ('".$acao."', '".$_REQUEST['idUser']."', now(), now())";
        mysqli_query($con, $sql) or die(mysqli_error($con));
        echo "1";
        break;  
    case 'verRegistrosExcluidos':
        $sql = "SELECT * FROM ".$_REQUEST['table']."";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $html .= '<h3 style="text-align:center">'.$_REQUEST['nome'].'</h3>
            <div style="width:100%; border:1px solid #e6e6e6; padding:5px;" id="mostraBotoesRegistroExcluido"><button class="btn btn-success" onclick=voltarTodosSelecionados("'.$_REQUEST['table'].'","'.$_REQUEST['nome'].'","'.URL.'")>Voltar Todos os Selecionados</button> <button class="btn btn-primary" onclick=excluirTodosSelecionados("'.$_REQUEST['table'].'","'.$_REQUEST['nome'].'","'.URL.'")>Excluir Todos os Selecionados</button></div>
            <table id="example2" class="table table-bordered table-hover" style="padding:15px">
            <tr>
            <th id="selDescTodas"><a style="cursor:pointer;" onclick=selecionarTodas("'.mysqli_num_rows($query).'","'.$_REQUEST['table'].'","'.$_REQUEST['nome'].'",false)>Desmarcar</a></th>
            <th>Nome</th>
            <th>Data da Exclusão</th>
            <th>Ações</th>
            </tr>
            ';
            $i = 1;
            $html .= '<input type="hidden" name="totalRegistrosExcluidos" id="totalRegistrosExcluidos" value="'.mysqli_num_rows($query).'">';
            while ($row = mysqli_fetch_array($query)){
                $vet = explode(' ', $row['deleted_at']);
                $vet2 = explode('-', $vet[0]);
                $row['deleted_at'] = $vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h";
                $html .= '<tr>
                    <td style="text-align:center"><input type="checkbox" name="selItem'.$i.'" id="selItem'.$i.'" checked onchange=selItemRegExcluidos("'.$row['id'].'","'.$i.'","'.URL.'","'.$_REQUEST['table'].'","'.$_REQUEST['nome'].'")></td>
                    <td>'.$row['name'].'</td>
                    <td>'.$row['deleted_at'].'</td>
                    <td><img src="'.URL.'admin/img//voltar.png" width="20" style="cursor:pointer" onclick=voltarRegistroExcluido("'.$row['id'].'","'.$_REQUEST['table'].'","'.$_REQUEST['nome'].'","'.URL.'")> <img src="'.URL.'admin/img//excluir.png" width="20" style="cursor:pointer" onclick=excluirRegistroExcluido("'.$row['id'].'","'.$_REQUEST['table'].'","'.$_REQUEST['nome'].'","'.URL.'")></td>
                </tr>';
                $i++;
            }
            $html .= '</table>';
        }
        echo "1|-|".$html;
        break;
    case 'voltarRegistroExcluidos':
        $sql = "UPDATE ".$_REQUEST['table']." SET deleted_at = NULL WHERE id = '".$_REQUEST['id']."'";
        mysqli_query($con, $sql);
        echo "1";
        break;
    case 'excluirRegistroExcluidos':
        $sql = "DELETE FROM ".$_REQUEST['table']." WHERE id = '".$_REQUEST['id']."'";
        mysqli_query($con, $sql);
        echo "1";
        break;
    case "voltarTodosSelecionados":
        $vet2 = explode('|-|', $_REQUEST['checkadas']);
        $sql = "SELECT * FROM ".$_REQUEST['table']."";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $i = 1;
            while ($row = mysqli_fetch_array($query)){
                foreach ($vet2 as $key => $value){
                    if ($value == $i){
                        $sql =  "UPDATE ".$_REQUEST['table']." SET deleted_at = NULL WHERE id = '".$row['id']."'";
                        mysqli_query($con, $sql);
                    }
                }
                $i++;
            }
        }
            echo "1";
        break;
    case "excluirTodosSelecionados":
        $vet2 = explode('|-|', $_REQUEST['checkadas']);
        $sql = "SELECT * FROM ".$_REQUEST['table']."";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $i = 1;
            while ($row = mysqli_fetch_array($query)){
                foreach ($vet2 as $key => $value){
                    if ($value == $i){
                        $sql =  "DELETE FROM ".$_REQUEST['table']." WHERE id = '".$row['id']."'";
                        mysqli_query($con, $sql);
                    }
                }
                $i++;
            }
        }
            echo "1";
        break;
    case "voltarTodosExcluidos":
        $sql = "UPDATE ".$_REQUEST['table']." SET deleted_at = NULL";
        mysqli_query($con, $sql) or die(mysqli_error($con));
        echo "1";
        break;
    case "excluirTodosExcluidos":
        $sql = "DELETE FROM ".$_REQUEST['table']."";
        mysqli_query($con, $sql) or die(mysqli_error($con));
        echo "1";
        break;
    case 'verificaNovamente':
        switch ($_REQUEST['tela']) {
            case 'index':
                $sql = "SELECT * FROM messages WHERE status = '1'";
                $query = mysqli_query($con, $sql);
                $messages = mysqli_num_rows($query);
                $sql = "SELECT * FROM counters WHERE created_at LIKE '".date('Y-m')."%' ORDER BY data DESC";
                $query = mysqli_query($con, $sql);
                $html = '
                    <!-- ./col -->
                    <div class="col-lg-3 col-6">
                        <!-- small box -->
                        <div class="small-box bg-primary">
                            <div class="inner">
                                <h3>'.$messages.'</h3>

                                <p>Fale Conosco à Responder</p>
                            </div>
                            <div class="icon">
                                <i class="ion ion-pie-graph"></i>
                            </div>
                            <a href="'.URL.'admin/faleConosco" class="small-box-footer">Maiores Informações <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>|-|
                        <table id="example2" class="table table-bordered table-hover">
                            <thead>
                            <tr>

                <th>Data de Acesso</th>

                <th>Quantidade de Acessos</th>

            </tr>
            </thead>
            <tbody>';
                while ($value = mysqli_fetch_object($query)) {
                    $vet = explode('-', $value->data);
                    $value->data = $vet[2]."/".$vet[1]."/".$vet[0];
                    $html .= '
                            <tr>
                            <td>'.$value->data.'</td>
                                <td>'.$value->acessos.'</td>
                            </tr>   ';
                }
                $html .= '
                            </tbody>
                        </table>';
                break;
            case 'itensExcluidos':
                $sql = "SELECT * FROM modules WHERE status = '1' ORDER BY typeModule ASC, created_at ASC";
                $query = mysqli_query($con, $sql);
                $modules = mysqli_num_rows($query);
                if ($modules){
                    $i = 0;
                    $j = 0;
                    while ($row = mysqli_fetch_array($query)){
                        if ($i >= 6 && $i != 10 && $i != 14 && $i != 15 && $i != 33 && $i != 34 && $i != 38){
                            if ($row['slug'] == 'newsletter'){
                                $table = 'newsletters';
                                $artigo = "o";
                            }
                            if ($row['slug'] == 'idiomas'){
                                $table = 'languages';
                                $artigo = "o";
                            }
                            if ($row['slug'] == 'listarPedidos'){
                                $table = 'requests';
                                $artigo = "o";
                            }
                            if ($row['slug'] == 'target'){
                                $table = 'targets';
                                $artigo = "o";
                            }
                            if ($row['slug'] == 'position'){
                                $table = 'positions';
                                $artigo = "a";
                            }
                            if ($row['slug'] == 'time_banner'){
                                $table = 'time_banners';
                                $artigo = "o";
                            }
                            if ($row['slug'] == 'bugTracking'){
                                $table = 'bug_trackings';
                                $artigo = "o";
                            }
                            if ($row['slug'] == 'type_documents'){
                                $table = 'type_documents';
                                $artigo = "o";
                            }
                            elseif ($row['slug'] == 'anuncie'){
                                $table = 'anuncie_aqui';
                                $artigo = "o";
                            }
                            elseif ($row['slug'] == 'faleConosco'){
                                $table = 'messages';                                
                                $artigo = "o";
                            }
                            elseif ($row['slug'] == 'comentariosProduto'){
                                $table = 'products_reviews';
                                $artigo = "o";
                            }
                            elseif ($row['slug'] == 'solicitacaoComentario'){
                                $table = 'products_reviews_solicitas';
                                $artigo = "a";
                            }
                            elseif ($row['slug'] == 'clientes'){
                                $table = 'clients';
                                $artigo = "o";
                            }
                            elseif ($row['slug'] == 'status'){
                                $table = 'requests_statuses';
                                $artigo = "o";
                            }
                            elseif ($row['slug'] == 'bairrosEntrega'){
                                $table = 'bairros_entrega';
                                $artigo = "o";
                            }
                            elseif ($row['slug'] == 'formas-pagamento'){
                                $table = 'payment_methods';
                                $artigo = "a";
                            }
                            elseif ($row['slug'] == 'banner'){
                                $table = 'banners';
                                $artigo = "o";
                            }
                            elseif ($row['slug'] == 'pagina'){
                                $table = 'pages';
                                $artigo = "a";
                            }
                            elseif ($row['slug'] == 'subitems'){
                                $table = 'subitems';
                                $artigo = "o";
                            }
                            elseif ($row['slug'] == 'atributos'){
                                $table = 'attributes';
                                $artigo = "o";
                            }
                            elseif ($row['slug'] == 'departamentos'){
                                $table = 'departaments';
                                $artigo = "o";
                            }
                            elseif ($row['slug'] == 'selos'){
                                $table = 'stamps';
                                $artigo = "o";
                            }
                            elseif ($row['slug'] == 'sugestoes'){
                                $table = 'suggestions';
                                $artigo = "a";
                            }
                            elseif ($row['slug'] == 'relacionamentos'){
                                $table = 'relationships';
                                $artigo = "o";
                            }
                            elseif ($row['slug'] == 'produto'){
                                $table = 'products';
                                $artigo = "o";
                            }
                            elseif ($row['slug'] == 'tiposProduto'){
                                $table = 'types_products';
                                $artigo = "o";
                            }
                            elseif ($row['slug'] == 'cupomDesconto'){
                                $table = 'coupon_discounts';
                                $artigo = "o";
                            }
                            elseif ($row['slug'] == 'paramSite'){
                                $table = 'param_sites';
                                $artigo = "o";
                            }
                            elseif ($row['slug'] == 'paramAdmin'){
                                $table = 'param_admins';
                                $artigo = "o";
                            }
                            elseif ($row['slug'] == 'versao'){
                                $table = 'versions';
                                $artigo = "a";
                            }
                            elseif ($row['slug'] == 'parceiros'){
                                $table = 'partners';
                                $artigo = "o";
                            }
                            elseif ($row['slug'] == 'nacionalidade'){
                                $table = 'nationalities';
                                $artigo = "a";
                            }
                            elseif ($row['slug'] == 'pais'){
                                $table = 'countries';
                                $artigo = "o";
                            }
                            elseif ($row['slug'] == 'redesSociais'){
                                $table = 'social_networks';
                                $artigo = "a";
                            }
                            elseif ($row['slug'] == 'types_services'){
                                $table = 'types_services';
                                $artigo = "a";
                            }
                            elseif ($row['slug'] == 'usuarios'){
                                $table = 'users';
                                $artigo = "o";
                            }
                            elseif ($row['slug'] == 'tiposModulo'){
                                $table = 'type_modules';
                                $artigo = "o";
                            }
                            elseif ($row['slug'] == 'modulos'){
                                $table = 'modules';
                                $artigo = "o";
                            }
                            elseif ($row['slug'] == 'formasPagamento'){
                                $table = 'payment_methods';
                                $artigo = "a";
                            }
                            elseif ($row['slug'] == 'usuarios-pre'){
                                $table = 'user_pres';
                                $artigo = "o";
                            }
                            elseif ($row['slug'] == 'types_versions'){
                                $table = 'type_versions';
                                $artigo = "o";
                            }
                            elseif ($row['slug'] == 'categories'){
                                $table = 'categories';
                                $artigo = "a";
                            }
                            elseif ($row['slug'] == 'priorities'){
                                $table = 'priorities';
                                $artigo = "a";
                            }
                            elseif ($row['slug'] == 'coins'){
                                $table = 'coins';
                                $artigo = "a";
                            }
                            $sql = "SELECT * FROM ".$table."";
                            $query2 = mysqli_query($con, $sql);
                            $rows = mysqli_num_rows($query2);
                        $html .= '
                        <div class="col-lg-3 col-3">
                            <!-- small box -->
                            <div class="small-box bg-';
                            if ($j % 4 == 0){
                                $html .= 'info';
                            }
                            elseif ($j % 4 == 1){
                                $html .= 'success';
                            }
                            elseif ($j % 4 == 2){
                                $html .= 'warning';
                            }
                            elseif ($j % 4 == 3){
                                $html .= 'danger';
                            }
                            $html .= '">
                                <div class="inner">
                                    <h3>';
                                    $html .= $rows;
                            $html .= '</h3>
    
                                    <p>'.($row['name']).' excluíd'.$artigo.'s até o momento</p>
                                </div>
                                <div class="icon">
                                    <i class="ion ion-edit"></i>
                                </div>
                                <a href="'.URL.'admin/'.$row['slug'].'" class="small-box-footer">Ver as Informações de Cadastrados <i class="fas fa-arrow-circle-right"></i></a>
                                ';
                                if ($rows){
                                    $html .= '<a onclick=verificaTodosExcluidos("'.$table.'","'.str_replace(" ", "_", $row['name']).'","'.URL.'")  data-toggle="modal" data-target="#modalVerTodosExcluidos" style="cursor:pointer" class="small-box-footer">Ver Todos os Excluídos <i class="fas fa-arrow-circle-right"></i></a>';
                                    $html .= '<a onclick=voltarTodosExcluidos("'.$table.'","'.str_replace(" ", "_", $row['name']).'","'.URL.'") style="cursor:pointer" class="small-box-footer">Voltar Todos os Excluídos <i class="fas fa-arrow-circle-right"></i></a>';
                                    $html .= '<a onclick=excluirTodosExcluidos("'.$table.'","'.str_replace(" ", "_", $row['name']).'","'.URL.'") style="cursor:pointer" class="small-box-footer">Excluir Todos os Excluídos <i class="fas fa-arrow-circle-right"></i></a>';
                                }
                                $html .= '
                                </div>
                        </div>
                        ';
                        $j++;
                        }
                        $i++;
                    }
                }
                $sql = "SELECT * FROM addresses";
                $query = mysqli_query($con, $sql);
                $rows = mysqli_num_rows($query);
                $row['name'] = "Endereços do Cliente";
                $row['slug'] = "cliente";
                $table = "addresses";
                $artigo = "o";
                $html .= '
                <div class="col-lg-3 col-3">
                    <!-- small box -->
                    <div class="small-box bg-danger';
                    $html .= '">
                        <div class="inner">
                            <h3>';
                            $html .= $rows;
                    $html .= '</h3>

                            <p>'.$row['name'].' excluíd'.$artigo.'s até o momento</p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-edit"></i>
                        </div>
                        <a href="'.URL.'admin/'.$row['slug'].'" class="small-box-footer">Ver as Informações de Cadastrados <i class="fas fa-arrow-circle-right"></i></a>
                        ';
                        if ($rows > 0){
                            $html .= '
                            <a onclick=verificaTodosExcluidos("'.$table.'","'.str_replace(" ", "_", $row['name']).'","'.URL.'")  data-toggle="modal" data-target="#modalVerTodosExcluidos" style="cursor:pointer" class="small-box-footer">Ver Todos os Excluídos <i class="fas fa-arrow-circle-right"></i></a>';
                            $html .= '<a onclick=voltarTodosExcluidos("'.$table.'","'.str_replace(" ", "_", $row['name']).'","'.URL.'") style="cursor:pointer" class="small-box-footer">Voltar Todos os Excluídos <i class="fas fa-arrow-circle-right"></i></a>';
                            $html .= '<a onclick=excluirTodosExcluidos("'.$table.'","'.str_replace(" ", "_", $row['name']).'","'.URL.'") style="cursor:pointer" class="small-box-footer">Excluir Todos os Excluídos <i class="fas fa-arrow-circle-right"></i></a>';
                        }
                        $html .= '
                    </div>
                </div>
                ';
                break;
            case 'contador':
                $sql = "SELECT * FROM counters ";
                if ($_REQUEST['dataFiltro'] && $_REQUEST['dataFimFiltro']) {
                    $sql .= "WHERE data >= '" . $_REQUEST['dataFiltro'] . "' AND data <= '".$_REQUEST['dataFimFiltro']."'";
                }
                $sql .= "ORDER BY data DESC ";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html = '
                        <table id="example2" class="table table-bordered table-hover">
                            <thead>
                            <tr>

                <th>Data de Acesso</th>

                <th>Quantidade de Acessos</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($counter = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td>' . date('d/m/Y', strtotime($counter->data)) . '</td>

                    <td>' . $counter->acessos . '</td>

                </tr>';
                        $key++;
                    }
                    $html .= '
            <//tbody>
        </table>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'contadorPagina':
                $sql = "SELECT a.*, b.name AS nomePagina FROM counters_pages a INNER JOIN pages b ON (a.page = b.id) ";
                if ($_REQUEST['dataFiltro'] && $_REQUEST['dataFimFiltro']) {
                    $sql .= "WHERE a.data >= '" . $_REQUEST['dataFiltro'] . "' && a.data <= '".$_REQUEST['dataFimFiltro']."' ";
                    $where = 1;
                }
                if ($_REQUEST['paginaFiltro']) {
                    if ($where) {
                        $sql .= "AND ";
                    } else {
                        $sql .= "WHERE ";
                    }
                    $sql .= "a.page = '" . $_REQUEST['paginaFiltro'] . "' ";
                }
                $sql .= "ORDER BY a.data DESC ";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html = '<table id="example2" class="table table-bordered table-hover">
                            <thead>
                            <tr>

                <th>Data de Acesso</th>
                <th>Nome da Página</th>

                <th>Quantidade de Acessos</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($counter = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . date('d/m/Y', strtotime($counter->data)) . '</td>

                    <td style="padding:5px">' . ($counter->nomePagina) . '</td>

                    <td style="padding:5px">' . $counter->acessos . '</td>

                </tr>';
                        $key++;
                    }
                    $html .= '
            </tbody>
        </table>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'contadorSubitem':
                $sql = "SELECT a.*, b.name AS nomeSubitem FROM counters_subitems a INNER JOIN subitems b ON (a.subitem = b.id) ";
                if ($_REQUEST['dataFiltro'] && $_REQUEST['dataFimFiltro']) {
                    $sql .= "WHERE a.data >= '" . $_REQUEST['dataFiltro'] . "' && a.data <= '".$_REQUEST['dataFimFiltro']."' ";
                    $where = 1;
                }
                if ($_REQUEST['subitemFiltro']) {
                    if ($where) {
                        $sql .= "AND ";
                    } else {
                        $sql .= "WHERE ";
                    }
                    $sql .= "a.subitem = '" . $_REQUEST['subitemFiltro'] . "' ";
                }
                $sql .= "ORDER BY a.data DESC ";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html = '<table id="example2" class="table table-bordered table-hover">
                            <thead>
                            <tr>

                <th>Data de Acesso</th>

                <th>Nome do Subítem</th>

                <th>Quantidade de Acessos</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($counter = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . date('d/m/Y', strtotime($counter->data)) . '</td>

                    <td style="padding:5px">' . ($counter->nomeSubitem) . '</td>

                    <td style="padding:5px">' . $counter->acessos . '</td>

                </tr>';
                        $key++;
                    }
                    $html .= '
                </tbody>
        </table>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'contadorBanner':
                $sql = "SELECT a.*, b.name AS nomeBanner FROM counters_banners a INNER JOIN banners b ON (a.banner = b.id) ";
                if ($_REQUEST['dataFiltro'] && $_REQUEST['dataFimFiltro']) {
                    $sql .= "WHERE a.data >= '" . $_REQUEST['dataFiltro'] . "' && a.data <= '".$_REQUEST['dataFimFiltro']."' ";
                    $where = 1;
                }
                if ($_REQUEST['bannerFiltro']) {
                    if ($where) {
                        $sql .= "AND ";
                    } else {
                        $sql .= "WHERE ";
                    }
                    $sql .= "a.banner = '" . $_REQUEST['bannerFiltro'] . "' ";
                }
                $sql .= "ORDER BY a.data DESC ";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html = '
                            <table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>
                                    <th>Data do Acesso</th>
                                    <th>Nome do Banner</th>
                                    <th>Quantidade de Acessos</th>
                                </tr>
                                </thead>
                                <tbody>';
                    $key = 0;
                    while ($counter = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . date('d/m/Y', strtotime($counter->data)) . '</td>

                    <td style="padding:5px">' . ($counter->nomeBanner." - ".$counter->banner) . '</td>

                    <td style="padding:5px">' . $counter->acessos . '</td>

                </tr>';
                        $key++;
                    }
                    $html .= '
</tbody>
        </table>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
                case 'contadorRedeSocial':
                    $sql = "SELECT a.*, b.name AS nomeRedeSocial FROM counters_social_network a INNER JOIN social_networks b ON (a.social_network = b.id) ";
                    if ($_REQUEST['dataFiltro'] && $_REQUEST['dataFimFiltro']) {
                        $sql .= "WHERE a.data >= '" . $_REQUEST['dataFiltro'] . "' && a.data <= '".$_REQUEST['dataFimFiltro']."' ";
                        $where = 1;
                    }
                    if ($_REQUEST['redeSocialFiltro']) {
                        if ($where) {
                            $sql .= "AND ";
                        } else {
                            $sql .= "WHERE ";
                        }
                        $sql .= "a.social_network = '" . $_REQUEST['redeSocialFiltro'] . "' ";
                    }
                    $sql .= "ORDER BY a.data DESC ";
                    $query = mysqli_query($con, $sql);
                    if (mysqli_num_rows($query)) {
                        $html = '
                                <table id="example2" class="table table-bordered table-hover">
                                    <thead>
                                    <tr>
                                        <th>Data do Acesso</th>
                                        <th>Nome da Rede Social</th>
                                        <th>Quantidade de Acessos</th>
                                    </tr>
                                    </thead>
                                    <tbody>';
                        $key = 0;
                        while ($counter = mysqli_fetch_object($query)) {
                            $html .= '<tr>
    
                        <td style="padding:5px">' . date('d/m/Y', strtotime($counter->data)) . '</td>
    
                        <td style="padding:5px">' . ($counter->nomeRedeSocial) . '</td>
    
                        <td style="padding:5px">' . $counter->acessos . '</td>
    
                    </tr>';
                            $key++;
                        }
                        $html .= '
    </tbody>
            </table>';
                    } else {
                        $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                    }
                    break;
            case 'newsletter':
                $sql = "SELECT a.* FROM newsletters a ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                if ($_REQUEST['emailFiltro']) {
                    $sql .= "AND ";
                    $sql .= "a.email LIKE '%" . $_REQUEST['emailFiltro'] . "%' ";
                    $where = 1;
                }
                if ($_REQUEST['dataFiltro']) {
                    $sql .= "AND ";
                    $sql .= "a.created_at LIKE '" . $_REQUEST['dataFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.created_at DESC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '
                            <table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>
                                    <th>Data</th>
                                    <th>Nome</th>
                                    <th>Email</th>
                                    <th>Ações</th>
                                </tr>
                                </thead>
                                <tbody>';
                    $key = 0;
                    while ($newsletter = mysqli_fetch_object($query)) {
                        $vet = explode(' ', $newsletter->created_at);
                        $vet2 = explode('-', $vet[0]);
                        $newsletter->created_at = $vet2[2] . "/" . $vet2[1] . "/" . $vet2[0];
                        $html .= '<tr>

                    <td style="padding:5px">' . $newsletter->created_at . '</td>

                    <td style="padding:5px">' . ($newsletter->name) . '</td>

                    <td style="padding:5px">' . ($newsletter->email) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarNewsletter("' . $newsletter->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarNewsletter("' . $newsletter->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/editar.png" width="20"></a>
                        <a style="cursor:pointer" onclick=excluirNewsletter("' . $newsletter->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","a","newsletter")><img src="' . URL.'admin/img/excluir.png" width="20"></a>
                    </td>

                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</table>
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("newsletter","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("newsletter","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("newsletter","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("newsletter","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("newsletter","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("newsletter","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("newsletter","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("newsletter","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("newsletter","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'redesSociais':
                $sql = "SELECT a.* FROM social_networks a ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($banners = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $banners->id . '</td>

                    <td style="padding:5px">' . ($banners->name) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarRedeSocial("' . $banners->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarRedeSocial("' . $banners->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/editar.png" width="20"></a>
                         <a style="cursor:pointer" onclick=excluirRedeSocial("' . $banners->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","banner")><img src="' . URL.'admin/img/excluir.png" width="20"></a>
                    </td>
                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("redesSociais","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("redesSociais","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("redesSociais","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("redesSociais","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("redesSociais","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("redesSociais","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("redesSociais","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("redesSociais","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("redesSociais","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'bugTracking':
                $sql = "SELECT a.* FROM bug_trackings a ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                if ($_REQUEST['emailFiltro']) {
                    $sql .= "AND ";
                    $sql .= "a.email LIKE '%" . $_REQUEST['emailFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.created_at DESC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '
                            <table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">Data</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Email</th>

                <th style="padding:5px">Status</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($bugTracking = mysqli_fetch_object($query)) {
                        $vet = explode(' ', $bugTracking->created_at);
                        $vet2 = explode('-', $vet[0]);
                        $bugTracking->created_at = $vet2[2] . "/" . $vet2[1] . "/" . $vet2[0];
                        $status = ($bugTracking->status == 1) ? "<div style='background-color: #000033; color: #FFFFFF; float:left; padding:5px'>Respondido</div>" : "<div style='background-color: #006600; color: #FFFFFF;  float:left; padding:5px'>Enviado</div>";
                        $html .= '<tr>

                    <td style="padding:5px">' . $bugTracking->created_at . '</td>

                    <td style="padding:5px">' . ($bugTracking->name) . '</td>

                    <td style="padding:5px">' . ($bugTracking->email) . '</td>

                    <td style="padding:5px">' . ($status) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarBugTracking("' . $bugTracking->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarBugTracking("' . $bugTracking->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/editar.png" width="20"></a>
                        <a style="cursor:pointer" onclick=excluirBugTracking("' . $bugTracking->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","bugTacking")><img src="' . URL.'admin/img/excluir.png" width="20"></a>
                    </td>

                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card">
              <div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("bugTracking","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("bugTracking","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("bugTracking","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("bugTracking","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("bugTracking","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("bugTracking","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("bugTracking","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("bugTracking","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("bugTracking","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'faleConosco':
                $sql = "SELECT a.* FROM messages a ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "WHERE a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                if ($_REQUEST['emailFiltro']) {
                    if ($where){
                        $sql .= "AND ";
                    }
                    else{
                        $sql .= "WHERE ";
                    }
                    $sql .= "a.email LIKE '%" . $_REQUEST['emailFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.created_at DESC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '
                            <table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">Data</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Email</th>

                <th style="padding:5px">Status</th>

                <th style="padding:5px">Ações</th>
            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($faleConosco = mysqli_fetch_object($query)) {
                        $vet = explode(' ', $faleConosco->created_at);
                        $vet2 = explode('-', $vet[0]);
                        $faleConosco->created_at = $vet2[2] . "/" . $vet2[1] . "/" . $vet2[0];
                        $status = ($faleConosco->status == 1) ? "<div style='background-color: #FFFF00; color: #000000; float:left; padding:5px'>Enviado</div>" : "<div style='background-color: #000033; color: #FFFFFF;  float:left; padding:5px'>Respondido</div>";
                        $html .= '<tr>

                    <td style="padding:5px">' . $faleConosco->created_at . '</td>

                    <td style="padding:5px">' . ($faleConosco->name) . '</td>

                    <td style="padding:5px">' . ($faleConosco->email) . '</td>

                    <td style="padding:5px">' . ($status) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarFaleConosco("' . $faleConosco->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarFaleConosco("' . $faleConosco->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/editar.png" width="20"></a>
                        <a style="cursor:pointer" onclick=excluirFaleConosco("' . $faleConosco->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","FaleConosco")><img src="' . URL.'admin/img/excluir.png" width="20"></a>
                    </td>

                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card">
              <div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("faleConosco","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("faleConosco","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("faleConosco","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("faleConosco","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("faleConosco","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("faleConosco","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("faleConosco","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("faleConosco","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("faleConosco","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'anuncie':
                $sql = "SELECT a.* FROM anuncie_aqui a ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                if ($_REQUEST['emailFiltro']) {
                    $sql .= "AND ";
                    $sql .= "a.email LIKE '%" . $_REQUEST['emailFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.created_at DESC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">Data</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Email</th>

                <th style="padding:5px">Status</th>

                <th style="padding:5px">Ações</th>
            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($faleConosco = mysqli_fetch_object($query)) {
                        $vet = explode(' ', $faleConosco->created_at);
                        $vet2 = explode('-', $vet[0]);
                        $faleConosco->created_at = $vet2[2] . "/" . $vet2[1] . "/" . $vet2[0];
                        $status = ($faleConosco->status == 1) ? "<div style='background-color: #FFFF00; color: #000000; float:left; padding:5px'>Enviado</div>" : "<div style='background-color: #000033; color: #FFFFFF;  float:left; padding:5px'>Respondido</div>";
                        $html .= '<tr>

                    <td style="padding:5px">' . $faleConosco->created_at . '</td>

                    <td style="padding:5px">' . ($faleConosco->name) . '</td>

                    <td style="padding:5px">' . ($faleConosco->email) . '</td>

                    <td style="padding:5px">' . ($status) . '</td>

                    <td style="padding:5px">';
                    if (!$faleConosco->aprovado){
                        $html .= '<a href="#" onclick=aprovarAnuncie("' . $faleConosco->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/sucesso.png" width="20"></a>';
                    }
                    $html .= '<a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarAnuncie("' . $faleConosco->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/visualizar.svg" width="20"></a>
                        <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarAnuncie("' . $faleConosco->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/editar.png" width="20"></a>
                        <a style="cursor:pointer" onclick=excluirAnuncie("' . $faleConosco->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","anuncie_aqui")><img src="' . URL.'admin/img/excluir.png" width="20"></a>
                    </td>

                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card">
                <div class="card-header">
                <h3 class="card-title">
                    <i class="ion pagination mr-1"></i>
                    Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("anuncie","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("anuncie","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("anuncie","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("anuncie","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                    ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("anuncie","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("anuncie","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("anuncie","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                    ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("anuncie","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("anuncie","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                    </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'pedido':
                $sql = "SELECT DISTINCT a.id, a.*, b.name AS nomeStatus, b.sigla, c.name AS nomeCliente
                        FROM requests a
                        INNER JOIN requests_statuses b ON (a.status = b.id)
                        INNER JOIN clients c ON (a.client = c.id)
                        LEFT JOIN requests_items d ON (a.id = d.request) 
                        ";
                if ($_REQUEST['idFiltro']) {
                    $sql .= "AND a.id LIKE '%" . $_REQUEST['idFiltro'] . "%' ";
                    $where = 1;
                }
                if ($_REQUEST['dataFiltro']) {
                    $sql .= "AND ";
                    $sql .= "a.created_at LIKE '%" . $_REQUEST['dataFiltro'] . "%' ";
                    $where = 1;
                }
                if ($_REQUEST['formaPagamentoFiltro'] && $_REQUEST['formaPagamentoFiltro'] != 'undefined') {
                    $sql .= "AND ";
                    $sql .= "a.paymentMethod = '" . $_REQUEST['formaPagamentoFiltro'] . "' ";
                    $where = 1;
                }
                if ($_REQUEST['statusFiltro']) {
                    $sql .= "AND ";
                    $sql .= "a.status = '" . $_REQUEST['statusFiltro'] . "' ";
                    $where = 1;
                }
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND ";
                    $sql .= "c.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                if ($_REQUEST['emailFiltro']) {
                    $sql .= "AND ";
                    $sql .= "c.email LIKE '%" . $_REQUEST['emailFiltro'] . "%' ";
                    $where = 1;
                }
                if ($_REQUEST['nomeProdutoFiltro']) {
                    $sql .= "AND ";
                    $sql .= "d.name LIKE '%" . $_REQUEST['nomeProdutoFiltro'] . "%' ";
                    $where = 1;
                }
                if ($_REQUEST['idProdutoFiltro']) {
                    $sql .= "AND ";
                    $sql .= "d.id = '" . $_REQUEST['idProdutoFiltro'] . "' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id DESC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '
                            <table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Data / Hora</th>

                <th style="padding:5px">Status do Pedido</th>

                <th style="padding:5px">Nome do Cliente</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($pedido = mysqli_fetch_object($query)) {
                        $vet = explode(' ', $pedido->created_at);
                        $vet2 = explode('-', $vet[0]);
                        $pedido->created_at = $vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h";
                        $html .= '<tr>

                    <td style="padding:5px">' . sprintf("%06s\n", $pedido->id) . '</td>

                    <td style="padding:5px">' . $pedido->created_at . '</td>

                    <td style="padding:5px"><span style="background-color:';
                        if ($pedido->status == 1){
                            $html .= '#003300';
                        }
                        elseif ($pedido->status == 2){
                            $html .= '#999900';
                        }
                        elseif ($pedido->status == 3){
                            $html .= '#F0AD4E';
                        }
                        elseif ($pedido->status == 4) {
                            $html .= '#009900';
                        }
                        elseif ($pedido->status == 5){
                            $html .= '#000099';
                        }
                        elseif ($pedido->status == 6) {
                            $html .= '#FF0000';
                        }
                        $html .= '; color:#FFFFFF; padding: 7px" title="'.($pedido->nomeStatus).'">' . $pedido->sigla . '</span></td>

                    <td style="padding:5px">' . ($pedido->nomeCliente) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarPedido("' . $pedido->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarPedido("' . $pedido->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/editar.png" width="20"></a>
                    </td>

                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card">
              <div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("pedido","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("pedido","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("pedido","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("pedido","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("pedido","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("pedido","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("pedido","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("pedido","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("pedido","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'statusPedido':
                $sql = "SELECT a.* FROM requests_statuses a ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '
                            <table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($statusPedido = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $statusPedido->id . '</td>

                    <td style="padding:5px">' . ($statusPedido->name) . '</td>

                    <td style="padding:5px">
                        <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarStatusPedido("' . $statusPedido->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/visualizar.svg" width="20"></a>
                        <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarStatusPedido("' . $statusPedido->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/editar.png" width="20"></a>
                        <a style="cursor:pointer" onclick="excluirStatusPedido(\'' . $statusPedido->id . '\',\'' . URL . '\',\'' . $_REQUEST['idUser'] . '\',\'a\',\'status_do_pedido\')"><img src="' . URL.'admin/img/excluir.png" width="20"></a>
                    </td>

                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                    <i class="ion pagination mr-1"></i>
                    Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("statusPedido","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("statusPedido","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("statusPedido","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("statusPedido","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                    ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("statusPedido","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("statusPedido","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("statusPedido","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                    ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("statusPedido","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("statusPedido","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                    </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'target':
                $sql = "SELECT a.* FROM targets a ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '
                            <table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($statusPedido = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $statusPedido->id . '</td>

                    <td style="padding:5px">' . ($statusPedido->name) . '</td>

                    <td style="padding:5px">
                            <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarTarget("' . $statusPedido->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/visualizar.svg" width="20"></a>
                            <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarTarget("' . $statusPedido->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/editar.png" width="20"></a>
                            <a style="cursor:pointer" onclick="excluirTarget(\'' . $statusPedido->id . '\',\'' . URL . '\',\'' . $_REQUEST['idUser'] . '\',\'a\',\'target\')"><img src="' . URL.'admin/img/excluir.png" width="20"></a>
                    </td>

                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                    <i class="ion pagination mr-1"></i>
                    Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("target","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("target","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("target","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("target","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                    ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("target","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("target","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("target","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                    ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("target","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("target","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                    </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;            
            case 'position':
                $sql = "SELECT a.* FROM positions a ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '
                            <table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($statusPedido = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $statusPedido->id . '</td>

                    <td style="padding:5px">' . ($statusPedido->name) . '</td>

                    <td style="padding:5px">
                            <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarPosition("' . $statusPedido->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/visualizar.svg" width="20"></a>
                            <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarPosition("' . $statusPedido->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/editar.png" width="20"></a>
                            <a style="cursor:pointer" onclick="excluirPosition(\'' . $statusPedido->id . '\',\'' . URL . '\',\'' . $_REQUEST['idUser'] . '\',\'a\',\'posição_do_banner\')"><img src="' . URL.'admin/img/excluir.png" width="20"></a>
                    </td>

                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                    <i class="ion pagination mr-1"></i>
                    Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("position","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("position","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("position","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("position","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                    ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("position","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("position","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("position","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                    ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("position","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("position","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                    </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;      
            case 'time_banner':
                $sql = "SELECT a.* FROM time_banners a ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '
                            <table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($statusPedido = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $statusPedido->id . '</td>

                    <td style="padding:5px">' . ($statusPedido->name) . '</td>

                    <td style="padding:5px">
                            <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarTimeBanner("' . $statusPedido->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/visualizar.svg" width="20"></a>
                            <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarTimeBanner("' . $statusPedido->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/editar.png" width="20"></a>
                            <a style="cursor:pointer" onclick="excluirTimeBanner(\'' . $statusPedido->id . '\',\'' . URL . '\',\'' . $_REQUEST['idUser'] . '\',\'o\',\'tempo_do_banner\')"><img src="' . URL.'admin/img/excluir.png" width="20"></a>
                    </td>

                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                    <i class="ion pagination mr-1"></i>
                    Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("position","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("position","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("position","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("position","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                    ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("position","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("position","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("position","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                    ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("position","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("position","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                    </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'type_documents':
                $sql = "SELECT a.* FROM type_documents a ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '
                            <table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($statusPedido = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $statusPedido->id . '</td>

                    <td style="padding:5px">' . ($statusPedido->name) . '</td>

                    <td style="padding:5px">
                            <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarTipoDocumento("' . $statusPedido->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/visualizar.svg" width="20"></a>
                            <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarTipoDocumento("' . $statusPedido->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/editar.png" width="20"></a>
                            <a style="cursor:pointer" onclick="excluirTipoDocumento(\'' . $statusPedido->id . '\',\'' . URL . '\',\'' . $_REQUEST['idUser'] . '\',\'o\',\'tipo_de_documento\')"><img src="' . URL.'admin/img/excluir.png" width="20"></a>
                    </td>

                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                    <i class="ion pagination mr-1"></i>
                    Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("type_documents","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("type_documents","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("type_documents","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("type_documents","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                    ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("type_documents","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("type_documents","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("type_documents","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                    ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("type_documents","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("type_documents","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                    </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'tiposDocumento':
                $sql = "SELECT a.* FROM type_documents a ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '
                            <table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($tiposDocumento = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $tiposDocumento->id . '</td>

                    <td style="padding:5px">' . ($tiposDocumento->name) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarTipoDocumento("' . $tiposDocumento->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarTipoDocumento("' . $tiposDocumento->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/editar.png" width="20"></a>
                         <a style="cursor:pointer" onclick=excluirTipoDocumento("' . $tiposDocumento->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","tipo_de_documento")><img src="' . URL.'admin/img/excluir.png" width="20"></a>
                    </td>

                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tiposDocumento","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tiposDocumento","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("tiposDocumento","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tiposDocumento","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("tiposDocumento","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tiposDocumento","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("tiposDocumento","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tiposDocumento","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tiposDocumento","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'clientes':
                $sql = "SELECT a.* FROM clients a  ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "WHERE a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                if ($_REQUEST['emailFiltro']) {
                    if ($where) {
                        $sql .= "AND ";
                    } else {
                        $sql .= "WHERE ";
                    }
                    $sql .= "a.email LIKE '%" . $_REQUEST['emailFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '
                            <table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Email</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($clientes = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $clientes->id . '</td>

                    <td style="padding:5px">' . ($clientes->name) . '</td>

                    <td style="padding:5px">' . ($clientes->email) . '</td>

                    <td style="padding:5px">
                        <a href="#" onclick="visualizaEndereco(\'' . $clientes->id . '\', \'' . URL . '\', \'' . $_REQUEST['idUser'] . '\')" data-toggle="modal" data-target="#modalEndereco' . $clientes->id . '"><img src="' . URL.'admin/img/endereco.png" style="cursor:pointer" title="Visualizar Endereços do Cliente ' . $clientes->id . '" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarClientes("' . $clientes->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarClientes("' . $clientes->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/editar.png" width="20"></a>
                    </td>

                </tr>

                <div class="modal fade" id="modalEndereco' . $clientes->id . '" tabindex="-1" role="dialog" aria-labelledby="modalEndereco' . $clientes->id . '" aria-hidden="true">

                    <div class="modal-dialog" role="document">

                        <div class="modal-content">

                            <div class="modal-header">

                                <h5 class="modal-title" id="exampleModalLabel">Visualização de Endereços</h5>

                                <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">

                                    <span aria-hidden="true">&times;</span>

                                </button>

                            </div>

                            <div class="modal-body" id="htmlVisualizaEnderecos' . $clientes->id . '">...

                            </div>

                            <div class="modal-footer">

                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>

                            </div>

                        </div>

                    </div>

                </div>
';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("clientes","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("clientes","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("clientes","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("clientes","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("clientes","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("clientes","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("clientes","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("clientes","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("clientes","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
                case 'tiposProduto':
                    $sql = "SELECT a.* FROM types_products a ";
                    if ($_REQUEST['nomeFiltro']) {
                        $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                        $where = 1;
                    }
                    $sql .= "ORDER BY a.id ASC";
                    $query = mysqli_query($con, $sql);
                    $total = mysqli_num_rows($query);
                    $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                    $totalPaginacao = ceil($total / 15);
                    if ($totalPaginacao == $_REQUEST['pagina']) {
                        $paginacaoProxima = $_REQUEST['pagina'];
                    } elseif ($totalPaginacao > 1) {
                        $paginacaoProxima = $_REQUEST['pagina'] + 1;
                    } else {
                        $paginacaoAnterior = 1;
                    }
                    if ($_REQUEST['pagina'] <= 10) {
                        $inicial = 1;
                    } else {
                        $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                    }
                    $final = $inicial + 10;
                    $sql .= " LIMIT " . $offSet . ", 15";
                    $query = mysqli_query($con, $sql);
                    if (mysqli_num_rows($query)) {
                        $html .= '<table id="example2" class="table table-bordered table-hover">
                                    <thead>
                                    <tr>
    
                    <th style="padding:5px">ID</th>
    
                    <th style="padding:5px">Nome</th>
    
                    <th style="padding:5px">Ações</th>
    
                </tr>
                </thead>
                <tbody>';
                        $key = 0;
                        while ($tiposProduto = mysqli_fetch_object($query)) {
                            $html .= '<tr>
    
                        <td style="padding:5px">' . $tiposProduto->id . '</td>
    
                        <td style="padding:5px">' . ($tiposProduto->name) . '</td>
    
                        <td style="padding:5px">
                             <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarTiposProduto("' . $tiposProduto->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/visualizar.svg" width="20"></a>
                             <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarTiposProduto("' . $tiposProduto->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/editar.png" width="20"></a>
                             <a style="cursor:pointer" onclick=excluirTiposProduto("'.$tiposProduto->id.'","'.URL.'","'.$_REQUEST['idUser'].'","o","tipo_de_produto")><img src="' . URL.'admin/img/excluir.png" width="20"></a>
                        </td>
                    </tr>';
                            $key++;
                        }
                        $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                        $html .= '</tbody></table>|-|<div class="card-header">
                    <h3 class="card-title">
                      <i class="ion pagination mr-1"></i>
                      Paginação
                    </h3>
    
                    <div class="card-tools">
                        <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                            <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tiposProduto","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                            <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tiposProduto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                            ';
                        $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("tiposProduto","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                        if ($_REQUEST['pagina'] >= 11) {
                            $proxima2 = $inicial - 1;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tiposProduto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                       ';
                        }
                        for ($j = $inicial; $j < $final; $j++) {
                            if ($j < $totalPaginacao && $j > 1) {
                                $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                                $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("tiposProduto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                            ';
                            }
                        }
                        if ($totalPaginacao > 11) {
                            $vaiAte = (floor($totalPaginacao / 10)) * 10;
                            if ($vaiAte >= $_REQUEST['pagina']) {
                                $proxima2 = $final;
                                $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tiposProduto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                            }
                        }
                        if ($totalPaginacao > 1) {
                            $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("tiposProduto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                       ';
                            $proxima = $_REQUEST['pagina'] + 1;
                            if ($proxima > $totalPaginacao) {
                                $proxima = $totalPginacao;
                            }
                        } else {
                            $proxima = 2;
                            if ($proxima > $totalPaginacao) {
                                $proxima = $totalPginacao;
                            }
                        }
                        $html .= '
                            <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tiposProduto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                            <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tiposProduto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                       </ul></div>
                        </div>
                        </div>';
                    } else {
                        $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                    }
                    break;
                case 'tiposServico':
                    $sql = "SELECT a.* FROM types_services a ";
                    if ($_REQUEST['nomeFiltro']) {
                        $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                        $where = 1;
                    }
                    $sql .= "ORDER BY a.id ASC";
                    $query = mysqli_query($con, $sql);
                    $total = mysqli_num_rows($query);
                    $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                    $totalPaginacao = ceil($total / 15);
                    if ($totalPaginacao == $_REQUEST['pagina']) {
                        $paginacaoProxima = $_REQUEST['pagina'];
                    } elseif ($totalPaginacao > 1) {
                        $paginacaoProxima = $_REQUEST['pagina'] + 1;
                    } else {
                        $paginacaoAnterior = 1;
                    }
                    if ($_REQUEST['pagina'] <= 10) {
                        $inicial = 1;
                    } else {
                        $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                    }
                    $final = $inicial + 10;
                    $sql .= " LIMIT " . $offSet . ", 15";
                    $query = mysqli_query($con, $sql);
                    if (mysqli_num_rows($query)) {
                        $html .= '<table id="example2" class="table table-bordered table-hover">
                                    <thead>
                                    <tr>
    
                    <th style="padding:5px">ID</th>
    
                    <th style="padding:5px">Nome</th>
    
                    <th style="padding:5px">Ações</th>
    
                </tr>
                </thead>
                <tbody>';
                        $key = 0;
                        while ($tiposProduto = mysqli_fetch_object($query)) {
                            $html .= '<tr>
    
                        <td style="padding:5px">' . $tiposProduto->id . '</td>
    
                        <td style="padding:5px">' . ($tiposProduto->name) . '</td>
    
                        <td style="padding:5px">
                                <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarTipoServico("' . $tiposProduto->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/visualizar.svg" width="20"></a>
                                <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarTipoServico("' . $tiposProduto->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/editar.png" width="20"></a>
                                <a style="cursor:pointer" onclick=excluirTipoServico("' . $tiposProduto->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","tipo_de_servico")><img src="' . URL.'admin/img/excluir.png" width="20"></a>
                        </td>
                    </tr>';
                            $key++;
                        }
                        $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                        $html .= '</tbody></table>|-|<div class="card-header">
                    <h3 class="card-title">
                        <i class="ion pagination mr-1"></i>
                        Paginação
                    </h3>
    
                    <div class="card-tools">
                        <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                            <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tiposServico","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                            <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tiposServico","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                            ';
                        $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("tiposServico","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                        if ($_REQUEST['pagina'] >= 11) {
                            $proxima2 = $inicial - 1;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tiposServico","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                        ';
                        }
                        for ($j = $inicial; $j < $final; $j++) {
                            if ($j < $totalPaginacao && $j > 1) {
                                $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                                $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("tiposServico","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                            ';
                            }
                        }
                        if ($totalPaginacao > 11) {
                            $vaiAte = (floor($totalPaginacao / 10)) * 10;
                            if ($vaiAte >= $_REQUEST['pagina']) {
                                $proxima2 = $final;
                                $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tiposServico","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                            }
                        }
                        if ($totalPaginacao > 1) {
                            $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("tiposServico","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                        ';
                            $proxima = $_REQUEST['pagina'] + 1;
                            if ($proxima > $totalPaginacao) {
                                $proxima = $totalPginacao;
                            }
                        } else {
                            $proxima = 2;
                            if ($proxima > $totalPaginacao) {
                                $proxima = $totalPginacao;
                            }
                        }
                        $html .= '
                            <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tiposServico","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                            <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tiposServico","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                        </ul></div>
                        </div>
                        </div>';
                    } else {
                        $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                    }
                    break;   
                case 'tiposVersoes':
                    $sql = "SELECT a.*, b.name AS nomeTipoServico FROM type_versions a INNER JOIN types_services b ON (a.typeService = b.id) ";
                    if ($_REQUEST['nomeFiltro']) {
                        $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                        $where = 1;
                    }
                    if ($_REQUEST['tipoServicoFiltro']) {
                        $sql .= "AND a.typeService = '" . $_REQUEST['tipoServicoFiltro'] . "' ";
                        $where = 1;
                    }
                    $sql .= "ORDER BY a.id ASC";
                    $query = mysqli_query($con, $sql);
                    $total = mysqli_num_rows($query);
                    $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                    $totalPaginacao = ceil($total / 15);
                    if ($totalPaginacao == $_REQUEST['pagina']) {
                        $paginacaoProxima = $_REQUEST['pagina'];
                    } elseif ($totalPaginacao > 1) {
                        $paginacaoProxima = $_REQUEST['pagina'] + 1;
                    } else {
                        $paginacaoAnterior = 1;
                    }
                    if ($_REQUEST['pagina'] <= 10) {
                        $inicial = 1;
                    } else {
                        $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                    }
                    $final = $inicial + 10;
                    $sql .= " LIMIT " . $offSet . ", 15";
                    $query = mysqli_query($con, $sql);
                    if (mysqli_num_rows($query)) {
                        $html .= '<table id="example2" class="table table-bordered table-hover">
                                    <thead>
                                    <tr>
    
                    <th style="padding:5px">ID</th>
    
                    <th style="padding:5px">Tipo de Serviço</th>
    
                    <th style="padding:5px">Nome</th>
    
                    <th style="padding:5px">Ações</th>
    
                </tr>
                </thead>
                <tbody>';
                        $key = 0;
                        while ($tiposProduto = mysqli_fetch_object($query)) {
                            $html .= '<tr>
    
                        <td style="padding:5px">' . $tiposProduto->id . '</td>
    
                        <td style="padding:5px">' . ($tiposProduto->nomeTipoServico) . '</td>
    
                        <td style="padding:5px">' . ($tiposProduto->name) . '</td>
    
                        <td style="padding:5px">
                                <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarTipoVersao("' . $tiposProduto->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/visualizar.svg" width="20"></a>
                                <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarTipoVersao("' . $tiposProduto->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/editar.png" width="20"></a>
                                <a style="cursor:pointer" onclick=excluirTipoVersao("' . $tiposProduto->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","tipo_de_versao")><img src="' . URL.'admin/img/excluir.png" width="20"></a>
                        </td>
                    </tr>';
                            $key++;
                        }
                        $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                        $html .= '</tbody></table>|-|<div class="card-header">
                    <h3 class="card-title">
                        <i class="ion pagination mr-1"></i>
                        Paginação
                    </h3>
    
                    <div class="card-tools">
                        <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                            <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tiposVersoes","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                            <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tiposVersoes","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                            ';
                        $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("tiposVersoes","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                        if ($_REQUEST['pagina'] >= 11) {
                            $proxima2 = $inicial - 1;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tiposVersoes","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                        ';
                        }
                        for ($j = $inicial; $j < $final; $j++) {
                            if ($j < $totalPaginacao && $j > 1) {
                                $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                                $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("tiposVersoes","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                            ';
                            }
                        }
                        if ($totalPaginacao > 11) {
                            $vaiAte = (floor($totalPaginacao / 10)) * 10;
                            if ($vaiAte >= $_REQUEST['pagina']) {
                                $proxima2 = $final;
                                $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tiposVersoes","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                            }
                        }
                        if ($totalPaginacao > 1) {
                            $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("tiposVersoes","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                        ';
                            $proxima = $_REQUEST['pagina'] + 1;
                            if ($proxima > $totalPaginacao) {
                                $proxima = $totalPginacao;
                            }
                        } else {
                            $proxima = 2;
                            if ($proxima > $totalPaginacao) {
                                $proxima = $totalPginacao;
                            }
                        }
                        $html .= '
                            <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tiposVersoes","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                            <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tiposVersoes","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                        </ul></div>
                        </div>
                        </div>';
                    } else {
                        $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                    }
                    break;
            case 'produto':
                $sql = "SELECT a.* FROM products a ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($produto = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $produto->id . '</td>

                    <td style="padding:5px">' . ($produto->name) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarProdutos("' . $produto->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarProdutos("' . $produto->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/editar.png" width="20"></a>
                         <a style="cursor:pointer" onclick=excluirProdutos("' . $produto->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","produto")><img src="' . URL.'admin/img/excluir.png" width="20"></a>
                    </td>
                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("produto","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("produto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("produto","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("produto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("produto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("produto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("produto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("produto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("produto","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'formasPagamento':
                $sql = "SELECT a.* FROM payment_methods a ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "WHERE a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($formasPagamento = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $formasPagamento->id . '</td>

                    <td style="padding:5px">' . ($formasPagamento->name) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarFormaPagamento("' . $formasPagamento->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarFormaPagamento("' . $formasPagamento->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/editar.png" width="20"></a>
                         <a style="cursor:pointer" onclick=excluirFormaPagamento("' . $formasPagamento->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","a","forma_de_pagamento")><img src="' . URL.'admin/img/excluir.png" width="20"></a>
                    </td>
                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("formasPagamento","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("formasPagamento","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("formasPagamento","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("formasPagamento","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("formasPagamento","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("formasPagamento","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("formasPagamento","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("formasPagamento","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("formasPagamento","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'banners':
                $sql = "SELECT a.* FROM banners a ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($banners = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $banners->id . '</td>

                    <td style="padding:5px">' . ($banners->name) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarBanner("' . $banners->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarBanner("' . $banners->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/editar.png" width="20"></a>
                         <a style="cursor:pointer" onclick=excluirBanner("' . $banners->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","banner")><img src="' . URL.'admin/img/excluir.png" width="20"></a>
                    </td>
                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("banners","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("banners","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("banners","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("banners","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("banners","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("banners","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("banners","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("banners","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("banners","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'pagina':
                $sql = "SELECT a.* FROM pages a ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($pagina = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $pagina->id . '</td>

                    <td style="padding:5px">' . ($pagina->name) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarPagina("' . $pagina->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarPagina("' . $pagina->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/editar.png" width="20"></a>
                         <a style="cursor:pointer" onclick=excluirPagina("' . $pagina->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","a","pagina")><img src="' . URL.'admin/img/excluir.png" width="20"></a>
                    </td>
                </tr>';
                        $key++;
                    }
                    $paginacaoAntaerior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("pagina","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("pagina","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("pagina","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("pagina","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("pagina","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("pagina","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("pagina","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("pagina","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("pagina","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'subitem':
                $sql = "SELECT a.*, b.name AS nomePagina FROM subitems a INNER JOIN pages b ON (b.id = a.page) ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                if ($_REQUEST['paginaFiltro']) {
                    $sql .= "AND a.page = '" . $_REQUEST['paginaFiltro'] . "' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.page ASC, a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Página</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($subitem = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $subitem->id . '</td>

                    <td style="padding:5px">' . ($subitem->nomePagina) . '</td>

                    <td style="padding:5px">' . ($subitem->name) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarSubitem("' . $subitem->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarSubitem("' . $subitem->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/editar.png" width="20"></a>
                         <a style="cursor:pointer" onclick=excluirSubitem("' . $subitem->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","subitem")><img src="' . URL.'admin/img/excluir.png" width="20"></a>
                    </td>
                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("subitem","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("subitem","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("subitem","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("subitem","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("subitem","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("subitem","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("subitem","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("subitem","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("subitem","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'priorities':
                $sql = "SELECT a.* FROM priorities a ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>
                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($prioridade = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $prioridade->id . '</td>

                    <td style="padding:5px">' . ($prioridade->name) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarPrioridade("' . $prioridade->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarPrioridade("' . $prioridade->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/editar.png" width="20"></a>
                        <a style="cursor:pointer" onclick=excluirPrioridade("' . $prioridade->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","a","prioridade")><img src="' . URL.'admin/img/excluir.png" width="20"></a>
                    </td>

                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("prioridade","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("prioridade","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("prioridade","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("prioridade","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("prioridade","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("prioridade","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("prioridade","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("prioridade","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("prioridade","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'tipoVersao':
                $sql = "SELECT a.*, b.name AS nomeTipoServico FROM type_versions a INNER JOIN types_services b ON (a.typeService = b.id) ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "WHERE a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                if ($_REQUEST['tipoServicoFiltro']) {
                    if ($where) {
                        $sql .= "AND ";
                    } else {
                        $sql .= "WHERE ";
                    }
                    $sql .= "a.typeService = '" . $_REQUEST['tipoServicoFiltro'] . "' ";
                    $where = 1;
                }
                $sql .= "ORDER BY b.id ASC, a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>
                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome do Tipo de Serviço</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($statusPedido = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $statusPedido->id . '</td>

                    <td style="padding:5px">' . ($statusPedido->nomeTipoServico) . '</td>

                    <td style="padding:5px">' . ($statusPedido->name) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarTipoVersao("' . $statusPedido->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarTipoVersao("' . $statusPedido->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/editar.png" width="20"></a>
                        <a style="cursor:pointer" onclick=excluirTipoVersao("' . $statusPedido->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","tipo_de_versao")><img src="' . URL.'admin/img/excluir.png" width="20"></a>
                    </td>

                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tipoVersao","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tipoVersao","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("tipoVersao","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tipoVersao","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("tipoVersao","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tipoVersao","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("tipoVersao","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tipoVersao","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tipoVersao","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'categorias':
                $sql = "SELECT a.* FROM categories a ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "WHERE a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            </tbody>';
                    $key = 0;
                    while ($statusPedido = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $statusPedido->id . '</td>

                    <td style="padding:5px">' . ($statusPedido->name) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarCategoria("' . $statusPedido->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarCategoria("' . $statusPedido->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/editar.png" width="20"></a>
                        <a style="cursor:pointer" onclick=excluirCategoria("' . $statusPedido->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","a","categoria")><img src="' . URL.'admin/img/excluir.png" width="20"></a>
                    </td>

                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("categorias","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("categorias","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("categorias","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("categorias","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("categorias","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("categorias","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("categorias","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("categorias","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("categorias","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'paramSite':
                $sql = "SELECT a.* FROM param_sites a ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "WHERE a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id DESC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>
                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($parametroSite = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $parametroSite->id . '</td>

                    <td style="padding:5px">' . ($parametroSite->name) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarParametroSite("' . $parametroSite->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarParametroSite("' . $parametroSite->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/editar.png" width="20"></a>
                        <a style="cursor:pointer" onclick=excluirParametroSite("' . $parametroSite->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","parametro_do_site")><img src="' . URL.'admin/img/excluir.png" width="20"></a>
                    </td>

                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("paramSite","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("paramSite","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("paramSite","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("paramSite","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("paramSite","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("paramSite","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("paramSite","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("paramSite","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("paramSite","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'paramAdmin':
                $sql = "SELECT a.* FROM param_admins a ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>';
                    $key = 0;
                    while ($parametroAdmin = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $parametroAdmin->id . '</td>

                    <td style="padding:5px">' . ($parametroAdmin->name) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarParametroAdmin("' . $parametroAdmin->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarParametroAdmin("' . $parametroAdmin->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/editar.png" width="20"></a>
                        <a style="cursor:pointer" onclick=excluirParametroAdmin("' . $parametroAdmin->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","parametro_do_administrativo")><img src="' . URL.'admin/img/excluir.png" width="20"></a>
                    </td>
                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("paramAdmin","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("paramAdmin","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("paramAdmin","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("paramAdmin","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("paramAdmin","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("paramAdmin","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("paramAdmin","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("paramAdmin","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("paramAdmin","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'versao':
                $sql = "SELECT a.* FROM versions a ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "WHERE a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>';
                    $key = 0;
                    while ($parametroAdmin = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $parametroAdmin->id . '</td>

                    <td style="padding:5px">' . ($parametroAdmin->name) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarVersao("' . $parametroAdmin->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarVersao("' . $parametroAdmin->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/editar.png" width="20"></a>
                        <a style="cursor:pointer" onclick=excluirVersao("' . $parametroAdmin->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","a","versao")><img src="' . URL.'admin/img/excluir.png" width="20"></a>
                    </td>
                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("versao","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("versao","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("versao","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("versao","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("versao","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("versao","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("versao","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("versao","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("versao","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'usuarios':
                $sql = "SELECT a.* FROM users a ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "WHERE a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                if ($_REQUEST['emailFiltro']) {
                    if ($where){
                        $sql .= "AND ";
                    }
                    else{
                        $sql .= "WHERE ";
                    }
                    $sql .= "a.email = '" . $_REQUEST['emailFiltro'] . "' ";
                    $where = 1;
                }
                if ($_REQUEST['idUser'] != 1) {
                    if ($where){
                        $sql .= "AND ";
                    }
                    else{
                        $sql .= "WHERE ";
                    }
                    $sql .= "a.id = '" . $_REQUEST['idUser'] . "' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Email</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($usuarios = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $usuarios->id . '</td>

                    <td style="padding:5px">' . ($usuarios->name) . '</td>

                    <td style="padding:5px">' . ($usuarios->email) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarUsuarios("' . $usuarios->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarUsuarios("' . $usuarios->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/editar.png" width="20"></a>
                        <a style="cursor:pointer" onclick=excluirUsuarios("' . $usuarios->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","usuário")><img src="' . URL.'admin/img/excluir.png" width="20"></a>
                    </td>

                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("usuarios","\'' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("usuarios","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("usuarios","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("usuarios","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("usuarios","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("usuarios","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("usuarios","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("usuarios","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("usuarios","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'usuarios-pre':
                $sql = "SELECT a.* FROM user_pres a ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "WHERE a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                if ($_REQUEST['emailFiltro']) {
                    if ($where) {
                        $sql .= "AND ";
                    } else {
                        $sql .= "WHERE ";
                    }
                    $sql .= "a.email = '" . $_REQUEST['emailFiltro'] . "' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Email</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($usuarios = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $usuarios->id . '</td>

                    <td style="padding:5px">' . ($usuarios->name) . '</td>

                    <td style="padding:5px">' . ($usuarios->email) . '</td>

                    <td style="padding:5px">
                         <a href="#" onclick=aprovaUsuario("'.$usuarios->id.'","'.URL.'","'.$_SESSION['user']['id'].'")><img src="' . URL.'admin/img/sucesso.png" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarUsuariosPre("' . $usuarios->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarUsuariosPre("' . $usuarios->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/editar.png" width="20"></a>
                        <a style="cursor:pointer" onclick=excluirUsuariosPre("' . $usuarios->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","usuário_pre")><img src="' . URL.'admin/img/excluir.png" width="20"></a>
                    </td>

                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("usuarios-pre","\'' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("usuarios-pre","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("usuarios-pre","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("usuarios-pre","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("usuarios-pre","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("usuarios-pre","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("usuarios-pre","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("usuarios-pre","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("usuarios-pre","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'idiomas':
                $sql = "SELECT a.* FROM languages a ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>
                <th style="padding:5px">ID</th>

                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    $key = 0;
                    while ($idioma = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $idioma->id . '</td>

                    <td style="padding:5px">' . ($idioma->name) . '</td>

                    <td style="padding:5px">
                            <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarIdioma("' . $idioma->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/visualizar.svg" width="20"></a>
                            <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarIdioma("' . $idioma->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/editar.png" width="20"></a>
                        <a style="cursor:pointer" onclick=excluirIdioma("' . $idioma->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","idioma")><img src="' . URL.'admin/img/excluir.png" width="20"></a>
                    </td>
                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</tbbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                    <i class="ion pagination mr-1"></i>
                    Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("idiomas","\'' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("idiomas","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("idiomas","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("idiomas","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                    ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("idiomas","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("idiomas","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("idiomas","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                    ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("idiomas","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("idiomas","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                    </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
        case 'coins':
            $sql = "SELECT a.* FROM coins a ";
            if ($_REQUEST['nomeFiltro']) {
                $sql .= "AND a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                $where = 1;
            }
            $sql .= "ORDER BY a.id ASC";
            $query = mysqli_query($con, $sql);
            $total = mysqli_num_rows($query);
            $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
            $totalPaginacao = ceil($total / 15);
            if ($totalPaginacao == $_REQUEST['pagina']) {
                $paginacaoProxima = $_REQUEST['pagina'];
            } elseif ($totalPaginacao > 1) {
                $paginacaoProxima = $_REQUEST['pagina'] + 1;
            } else {
                $paginacaoAnterior = 1;
            }
            if ($_REQUEST['pagina'] <= 10) {
                $inicial = 1;
            } else {
                $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
            }
            $final = $inicial + 10;
            $sql .= " LIMIT " . $offSet . ", 15";
            $query = mysqli_query($con, $sql);
            if (mysqli_num_rows($query)) {
                $html .= '<table id="example2" class="table table-bordered table-hover">
                            <thead>
                            <tr>
            <th style="padding:5px">ID</th>

            <th style="padding:5px">Nome</th>

            <th style="padding:5px">Ações</th>

        </tr>
        </thead>
        <tbody>';
                $key = 0;
                while ($idioma = mysqli_fetch_object($query)) {
                    $html .= '<tr>

                <td style="padding:5px">' . $idioma->id . '</td>

                <td style="padding:5px">' . ($idioma->name) . '</td>

                <td style="padding:5px">
                        <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarMoeda("' . $idioma->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/visualizar.svg" width="20"></a>
                        <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarMoeda("' . $idioma->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/editar.png" width="20"></a>
                    <a style="cursor:pointer" onclick=excluirMoeda("' . $idioma->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","idioma")><img src="' . URL.'admin/img/excluir.png" width="20"></a>
                </td>
            </tr>';
                    $key++;
                }
                $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                $html .= '</tbbody></table>|-|<div class="card-header">
            <h3 class="card-title">
                <i class="ion pagination mr-1"></i>
                Paginação
            </h3>

            <div class="card-tools">
                <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                    <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("idiomas","\'' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                    <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("idiomas","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                    ';
                $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("idiomas","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                if ($_REQUEST['pagina'] >= 11) {
                    $proxima2 = $inicial - 1;
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("idiomas","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                ';
                }
                for ($j = $inicial; $j < $final; $j++) {
                    if ($j < $totalPaginacao && $j > 1) {
                        $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("idiomas","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                    ';
                    }
                }
                if ($totalPaginacao > 11) {
                    $vaiAte = (floor($totalPaginacao / 10)) * 10;
                    if ($vaiAte >= $_REQUEST['pagina']) {
                        $proxima2 = $final;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("idiomas","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                    }
                }
                if ($totalPaginacao > 1) {
                    $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("idiomas","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                ';
                    $proxima = $_REQUEST['pagina'] + 1;
                    if ($proxima > $totalPaginacao) {
                        $proxima = $totalPginacao;
                    }
                } else {
                    $proxima = 2;
                    if ($proxima > $totalPaginacao) {
                        $proxima = $totalPginacao;
                    }
                }
                $html .= '
                    <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("idiomas","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                    <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("idiomas","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                </ul></div>
                </div>
                </div>';
            } else {
                $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
            }
            break;
        case 'tipoModulo':
            $sql = "SELECT a.* FROM type_modules a ";
            if ($_REQUEST['nomeFiltro']) {
                $sql .= "WHERE a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                $where = 1;
            }
            $sql .= "ORDER BY a.id ASC";
            $query = mysqli_query($con, $sql);
            $total = mysqli_num_rows($query);
            $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
            $totalPaginacao = ceil($total / 15);
            if ($totalPaginacao == $_REQUEST['pagina']) {
                $paginacaoProxima = $_REQUEST['pagina'];
            } elseif ($totalPaginacao > 1) {
                $paginacaoProxima = $_REQUEST['pagina'] + 1;
            } else {
                $paginacaoAnterior = 1;
            }
            if ($_REQUEST['pagina'] <= 10) {
                $inicial = 1;
            } else {
                $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
            }
            $final = $inicial + 10;
            $sql .= " LIMIT " . $offSet . ", 15";
            $query = mysqli_query($con, $sql);
            if (mysqli_num_rows($query)) {
                $html .= '<table id="example2" class="table table-bordered table-hover">
                            <thead>
                            <tr>
            <th style="padding:5px">ID</th>

            <th style="padding:5px">Nome</th>

            <th style="padding:5px">Ações</th>

        </tr>
        </thead>
        <tbody>';
                $key = 0;
                while ($tipoModulo = mysqli_fetch_object($query)) {
                    $html .= '<tr>

                <td style="padding:5px">' . $tipoModulo->id . '</td>

                <td style="padding:5px">' . ($tipoModulo->name) . '</td>

                <td style="padding:5px">
                        <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarTipoModulo("' . $tipoModulo->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL . 'admin/img/visualizar.svg" width="20"></a>
                        <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarTipoModulo("' . $tipoModulo->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/editar.png" width="20"></a>
                    <a style="cursor:pointer" onclick=excluirTipoModulo("' . $tipoModulo->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","tipoModulo")><img src="' . URL.'admin/img/excluir.png" width="20"></a>
                </td>
            </tr>';
                    $key++;
                }
                $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                $html .= '</tbbody></table>|-|<div class="card-header">
            <h3 class="card-title">
                <i class="ion pagination mr-1"></i>
                Paginação
            </h3>

            <div class="card-tools">
                <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                    <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tipoModulo","\'' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                    <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tipoModulo","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                    ';
                $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("tipoModulo","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                if ($_REQUEST['pagina'] >= 11) {
                    $proxima2 = $inicial - 1;
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tipoModulo","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                ';
                }
                for ($j = $inicial; $j < $final; $j++) {
                    if ($j < $totalPaginacao && $j > 1) {
                        $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("tipoModulo","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                    ';
                    }
                }
                if ($totalPaginacao > 11) {
                    $vaiAte = (floor($totalPaginacao / 10)) * 10;
                    if ($vaiAte >= $_REQUEST['pagina']) {
                        $proxima2 = $final;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tipoModulo","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                    }
                }
                if ($totalPaginacao > 1) {
                    $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("tipoModulo","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                ';
                    $proxima = $_REQUEST['pagina'] + 1;
                    if ($proxima > $totalPaginacao) {
                        $proxima = $totalPginacao;
                    }
                } else {
                    $proxima = 2;
                    if ($proxima > $totalPaginacao) {
                        $proxima = $totalPginacao;
                    }
                }
                $html .= '
                    <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tipoModulo","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                    <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("tipoModulo","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                </ul></div>
                </div>
                </div>';
            } else {
                $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
            }
            break;
            case 'modulo':
                $sql = "SELECT a.*, b.name AS nomeTipoModulo FROM modules a INNER JOIN type_modules b ON (a.typeModule = b.id) ";
                if ($_REQUEST['nomeFiltro']) {
                    $sql .= "WHERE a.name LIKE '%" . $_REQUEST['nomeFiltro'] . "%' ";
                    $where = 1;
                }
                if ($_REQUEST['tipoModuloFiltro']) {
                    if ($where){
                        $sql .= "AND";
                    }
                    else{
                        $sql .= "WHERE";
                    }
                    $sql .= " a.typeModule = '" . $_REQUEST['tipoModuloFiltro'] . "' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.typeModule ASC, a.id ASC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                        $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>

                <th style="padding:5px">ID</th>

                <th style="padding:5px">Tipo de Módulo</th>
                <th style="padding:5px">Nome</th>

                <th style="padding:5px">Ações</th>

            </tr>
            </thead>
            <tbody>';
                    ;$key = 0;
                    while ($modulo = mysqli_fetch_object($query)) {
                        $html .= '<tr>

                    <td style="padding:5px">' . $modulo->id . '</td>

                    <td style="padding:5px">' . ($modulo->nomeTipoModulo) . '</td>

                    <td style="padding:5px">' . ($modulo->name) . '</td>

                    <td style="padding:5px">
                         <a href="#" data-toggle="modal" data-target="#modalVisualizacao" onclick=visualizarModulo("' . $modulo->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/visualizar.svg" width="20"></a>
                         <a href="#" data-toggle="modal" data-target="#modalEdicao" onclick=editarModulo("' . $modulo->id . '","' . URL . '","' . $_REQUEST['idUser'] . '")><img src="' . URL.'admin/img/editar.png" width="20"></a>
                        <a style="cursor:pointer" onclick=excluirModulo("' . $modulo->id . '","' . URL . '","' . $_REQUEST['idUser'] . '","o","modulo")><img src="' . URL.'admin/img/excluir.png" width="20"></a>
                    </td>
                </tr>';
                        $key++;
                    }
                    $html .= '</tbbody></table>|-|<div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("modulo","\'' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("modulo","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                        $background = ($_REQUEST['pagina'] == 1) ? "#cccccc" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("modulo","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                        if ($_REQUEST['pagina'] >= 11) {
                            $proxima2 = $inicial - 1;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("modulo","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                        }
                        for ($j = $inicial; $j < $final; $j++) {
                            if ($j < $totalPaginacao && $j > 1) {
                                $background = ($_REQUEST['pagina'] == $j) ? "#cccccc" : "";
                                $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("modulo","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                            }
                        }
                        if ($totalPaginacao > 11) {
                            $vaiAte = (floor($totalPaginacao / 10)) * 10;
                            if ($vaiAte >= $_REQUEST['pagina']) {
                                $proxima2 = $final;
                                $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("modulo","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                            }
                        }
                        if ($totalPaginacao > 1) {
                            $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#cccccc" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("modulo","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                            $proxima = $_REQUEST['pagina'] + 1;
                            if ($proxima > $totalPaginacao) {
                                $proxima = $totalPginacao;
                            }
                        } else {
                            $proxima = 2;
                            if ($proxima > $totalPaginacao) {
                                $proxima = $totalPginacao;
                            }
                        }
                        $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("modulo","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("modulo","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
            case 'logs':
                $sql = "SELECT a.*, b.name AS nomeUsuario FROM logs a INNER JOIN users b ON (a.user = b.id) ";
                if ($_REQUEST['usuarioFiltro']) {
                    $sql .= "WHERE a.user = '" . $_REQUEST['usuarioFiltro'] . "' ";
                    $where = 1;
                }
                if ($_REQUEST['acaoFiltro']) {
                    if ($where) {
                        $sql .= "AND ";
                    } else {
                        $sql .= "WHERE ";
                    }
                    $sql .= "a.action LIKE '%" . $_REQUEST['acaoFiltro'] . "%' ";
                    $where = 1;
                }
                if ($_REQUEST['idUser'] != 1) {
                    if ($where) {
                        $sql .= "AND ";
                    } else {
                        $sql .= "WHERE ";
                    }
                    $sql .= "a.user = '" . $_REQUEST['idUser'] . "' ";
                    $where = 1;
                }
                $sql .= "ORDER BY a.id DESC";
                $query = mysqli_query($con, $sql);
                $total = mysqli_num_rows($query);
                $offSet = $_REQUEST['pagina'] < 1 ? 0 : ((15 * ($_REQUEST['pagina'] - 1) > $total) ? $total - ($total % 15) : 15 * ($_REQUEST['pagina'] - 1));
                $totalPaginacao = ceil($total / 15);
                if ($totalPaginacao == $_REQUEST['pagina']) {
                    $paginacaoProxima = $_REQUEST['pagina'];
                } elseif ($totalPaginacao > 1) {
                    $paginacaoProxima = $_REQUEST['pagina'] + 1;
                } else {
                    $paginacaoAnterior = 1;
                }
                if ($_REQUEST['pagina'] <= 10) {
                    $inicial = 1;
                } else {
                    $inicial = ((ceil($_REQUEST['pagina'] / 10) - 1) * 10) + 1;
                }
                $final = $inicial + 10;
                $sql .= " LIMIT " . $offSet . ", 15";
                $query = mysqli_query($con, $sql);
                if (mysqli_num_rows($query)) {
                    $html .= '<table id="example2" class="table table-bordered table-hover">
                                <thead>
                                <tr>
                                    <th>Nome do Usuário</th>
                                    <th>Ação</th>
                                    <th>Data / Hora</th>
                                </tr>
                                </thead>
                                <tbody>';
                    $key = 0;
                    while ($usuarios = mysqli_fetch_object($query)) {
                        $vet = explode(' ', $usuarios->created_at);
                        $vet2 = explode('-', $vet[0]);
                        $usuarios->created_at = $vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h";
                        $html .= '<tr>

                    <td style="padding:5px">' . ($usuarios->nomeUsuario) . '</td>

                    <td style="padding:5px">' . ($usuarios->action) . '</td>

                    <td style="padding:5px">' . ($usuarios->created_at) . '</td>

                </tr>';
                        $key++;
                    }
                    $paginacaoAnterior = ($_REQUEST['pagina'] == 1) ? 1 : $_REQUEST['pagina'] - 1;
                    $html .= '</table>
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">
                  <i class="ion pagination mr-1"></i>
                  Paginação
                </h3>

                <div class="card-tools">
                    <ul class="pagination pagination-sm" style="width:100%; text-align:center">
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("logs","' . URL . '","' . $_REQUEST['idUser'] . '","1")>&laquo;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("logs","' . URL . '","' . $_REQUEST['idUser'] . '","' . $paginacaoAnterior . '")>&leftarrow;</a></li>
                        ';
                    $background = ($_REQUEST['pagina'] == 1) ? "#CCCCCC" : "";
                    $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("logs","' . URL . '","' . $_REQUEST['idUser'] . '","1")>1</a></li>';
                    if ($_REQUEST['pagina'] >= 11) {
                        $proxima2 = $inicial - 1;
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("logs","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>
                   ';
                    }
                    for ($j = $inicial; $j < $final; $j++) {
                        if ($j < $totalPaginacao && $j > 1) {
                            $background = ($_REQUEST['pagina'] == $j) ? "#CCCCCC" : "";
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("logs","' . URL . '","' . $_REQUEST['idUser'] . '","' . $j . '")>' . $j . '</a></li>
                        ';
                        }
                    }
                    if ($totalPaginacao > 11) {
                        $vaiAte = (floor($totalPaginacao / 10)) * 10;
                        if ($vaiAte >= $_REQUEST['pagina']) {
                            $proxima2 = $final;
                            $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("logs","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima2 . '")>...</a></li>';
                        }
                    }
                    if ($totalPaginacao > 1) {
                        $background = ($_REQUEST['pagina'] == $totalPaginacao) ? "#CCCCCC" : "";
                        $html .= '<li class="page-item"><a class="page-link" style="cursor:pointer; background-color: '.$background.'" onClick=verificaNovamente("logs","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>' . $totalPaginacao . '</a></li>
                   ';
                        $proxima = $_REQUEST['pagina'] + 1;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    } else {
                        $proxima = 2;
                        if ($proxima > $totalPaginacao) {
                            $proxima = $totalPginacao;
                        }
                    }
                    $html .= '
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("logs","' . URL . '","' . $_REQUEST['idUser'] . '","' . $proxima . '")>&rightarrow;</a></li>
                        <li class="page-item"><a class="page-link" style="cursor:pointer" onClick=verificaNovamente("logs","' . URL . '","' . $_REQUEST['idUser'] . '","' . $totalPaginacao . '")>&raquo;</a></li>
                   </ul></div>
                    </div>
                    </div>';
                } else {
                    $html = '<div style="text-align:center; background-color:#FF0000; color:#FFFFFF; padding:5px; width:100%">Sem nenhum registro encontrado!</div>';
                }
                break;
        }
        echo "1|-|".$html;
        break;
    case "editaProdutoPedido":
        $sql = "SELECT * FROM requests_items WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        echo "1|-|".$row['product']."|-|".$row['product_item']."|-|".$row['id'];
        break;
    case "excluirItemPedido":
        $sql = "DELETE FROM requests_items WHERE id = '".$_REQUEST['id']."'";
        mysqli_query($con, $sql);
        echo "1";
        break;
    case "incluirItemPedido":
        $sql = "SELECT * FROM products_items WHERE id = '".$_REQUEST['product_item']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        $valor = ($row['promotion'] && $row['validity_promotion'] > date('Y-m-d')) ? $row['promotion'] : $row['value'];
        $sql = "INSERT INTO requests_items (request, product, product_item, name, domine, quantity, value, created_at, updated_at) VALUES ('".$_REQUEST['request']."', '".$_REQUEST['product']."', '".$_REQUEST['product_item']."', '".$row['name']."', '".$_REQUEST['domine']."', '1', '".$valor."', now(), now())";
        mysqli_query($con, $sql);
        $idRequestItem = mysqli_insert_id($con);
        if ($_REQUEST['product'] == 3){
            $sql = "INSERT INTO cashier_system (razao_social, nome_fantasia, email, cnpj, cep, logradouro, numero, complemento, bairro, cidade, estado, tipoEstabelecimento, quantidade, numeroPessoasPorMesa, percentual) VALUES ('".$_REQUEST['razaoSocial']."', '".$_REQUEST['nomeFantasia']."', '".$_REQUEST['email']."', '".$_REQUEST['cnpj']."', '".$_REQUEST['cep']."', '".$_REQUEST['logradouro']."', '".$_REQUEST['numero']."', '".$_REQUEST['complemento']."', '".$_REQUEST['bairro']."', '".$_REQUEST['cidade']."', '".$_REQUEST['estado']."', '".$_REQUEST['tipoEstabelecimento']."', '".$_REQUEST['quantidade']."', '".$_REQUEST['numPessoas']."', '".$_REQUEST['perGarcom']."')";
            mysqli_query($con, $sql);
            $idSistemaCaixa = mysqli_insert_id($con);
            $sql = "UPDATE requests_items SET cashier_system = '".$idSistemaCaixa."' WHERE id = '".$idRequestItem."'";
            mysqli_query($con, $sql);
        }
        if ($_REQUEST['product'] == 4){
            $sql = "INSERT INTO school_system (nome, email, cep, logradouro, numero, complemento, bairro, cidade, estado, tipoNota, turno, letra) VALUES ('".$_REQUEST['nome']."', '".$_REQUEST['email']."', '".$_REQUEST['cep']."', '".$_REQUEST['logradouro']."', '".$_REQUEST['numero']."', '".$_REQUEST['complemento']."', '".$_REQUEST['bairro']."', '".$_REQUEST['cidade']."', '".$_REQUEST['estado']."', '".$_REQUEST['tipoNota']."', '".$_REQUEST['turno']."', '".$_REQUEST['letra']."')";
            mysqli_query($con, $sql);
            $idSistemaEscola = mysqli_insert_id($con);
            $sql = "UPDATE requests_items SET school_system = '".$idSistemaEscola."' WHERE id = '".$idRequestItem."'";
            mysqli_query($con, $sql);
        }
        echo "1";
        break;
    case "editarItemPedido":
        $sql = "SELECT * FROM products_items WHERE id = '".$_REQUEST['product_item']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        $valor = ($row['promotion'] && $row['validity_promotion'] > date('Y-m-d')) ? $row['promotion'] : $row['value'];
        $sql = "UPDATE requests_items SET product = '".$_REQUEST['product']."', product_item = '".$_REQUEST['product_item']."', name = '".$row['name']."', domine = '".$_REQUEST['domine']."', quantity = '1', value = '".$valor."', updated_at = now() WHERE id = '".$_REQUEST['id']."'";
        mysqli_query($con, $sql);
        echo "1";
        break;
    case "productItemCadastro":
        $sql = "SELECT * FROM products_items WHERE id = '".$_REQUEST['id']."' ";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        if ($row['product'] != 3 && $row['product'] != 4) {
            $html .= "<label for='domineCadastro'>Domínio:</label><input type='text' name='domineCadastro' id='domineCadastro' required class='form-control'>";
        }
        elseif ($row['product'] == 3){
            $html .= "
            <label for='razaoSocialCaixa'>Razão Social:</label>
            <input type='text' name='razaoSocialCaixa' id='razaoSocialCaixa' required class='form-control'>
            <label for='nomeFantasiaCaixa'>Nome Fantasia:</label>
            <input type='text' name='nomeFantasiaCaixa' id='nomeFantasiaCaixa' required class='form-control'>
            <label for='emailCaixa'>Email:</label>
            <input type='email' name='emailCaixa' id='emailCaixa' required class='form-control'>
            <label for='cnpjCaixa'>CNPJ:</label>
            <input type='text' name='cnpjCaixa' id='cnpjCaixa' required class='form-control' onkeypress=\"return mascara(this, '00.000.000/0000-00', event)\">
            <label for='cepCaixa'>CEP:</label>
            <input type='text' name='cepCaixa' id='cepCaixa' required class='form-control' onkeypress=\"return mascara(this, '00000-000', event)\" onkeyup=\"verificacepcaixa(this.value)\">
            <label for='logradouroCaixa'>Logradouro:</label>
            <input type='text' name='logradouroCaixa' id='logradouroCaixa' required class='form-control'>
            <label for='numeroCaixa'>Numero:</label>
            <input type='text' name='numeroCaixa' id='numeroCaixa' required class='form-control'>
            <label for='complementoCaixa'>Complemento:</label>
            <input type='text' name='complementoCaixa' id='complementoCaixa' class='form-control'>
            <label for='bairroCaixa'>Bairro:</label>
            <input type='text' name='bairroCaixa' id='bairroCaixa' required class='form-control'>
            <label for='cidadeCaixa'>Cidade:</label>
            <input type='text' name='cidadeCaixa' id='cidadeCaixa' required class='form-control'>
            <label for='estadoCaixa'>Estado:</label>
            <select name='estadoCaixa' id='estadoCaixa' required class='form-control'>
                <option value=''>Selecione o estado corretamente...</option>";
            $sql = "SELECT * FROM states ORDER BY sigla ASC";
            $query = mysqli_query($con, $sql);
            if (mysqli_num_rows($query)){
                while ($row = mysqli_fetch_array($query)){
                    $html .= "<option value='".$row['sigla']."'>".$row['sigla']."</option>";
                }
            }
            $html .="
            </select>
            <label for='tipoEstabelecimentoCaixa'>Tipo do Estabelecimento:</label>
            <select name='tipoEstabelecimentoCaixa' id='tipoEstabelecimentoCaixa' required class='form-control' onchange='selecionaTipoEstabelecimento(this.value)'>
                <option value=''>Selecione o tipo do estabelecimento corretamente...</option>
                <option value='1'>Mesas</option>
                <option value='2'>Caixas</option>
            </select>
            <div id='tiposEstabelecimentoRealizarPedido'></div>";
        }
        elseif ($row['product'] == 4){
            $html .= "
            <label for='nomeEscola'>Nome da Escola:</label>
            <input type='text' name='nomeEscola' id='nomeEscola' required class='form-control'>
            <label for='emailEscola'>Email da Escola:</label>
            <input type='text' name='emailEscola' id='emailEscola' required class='form-control'>
            <label for='cepEscola'>CEP:</label>
            <input type='text' name='cepEscola' id='cepEscola' required class='form-control' onkeypress=\"return mascara(this, '00000-000', event)\" onkeyup=\"verificacepescolar(this.value)\">
            <label for='logradouroEscola'>Logradouro:</label>
            <input type='text' name='logradouroEscola' id='logradouroEscola' required class='form-control'>
            <label for='numeroEscola'>Numero:</label>
            <input type='text' name='numeroEscola' id='numeroEscola' required class='form-control'>
            <label for='complementoEscola'>Complemento:</label>
            <input type='text' name='complementoEscola' id='complementoEscola' class='form-control'>
            <label for='bairroEscola'>Bairro:</label>
            <input type='text' name='bairroEscola' id='bairroEscola' required class='form-control'>
            <label for='cidadeEscola'>Cidade:</label>
            <input type='text' name='cidadeEscola' id='cidadeEscola' required class='form-control'>
            <label for='estadoEscola'>Estado:</label>
            <select name='estadoEscola' id='estadoEscola' required class='form-control'>
                <option value=''>Selecione o estado corretamente...</option>";
            $sql = "SELECT * FROM states ORDER BY sigla ASC";
            $query = mysqli_query($con, $sql);
            if (mysqli_num_rows($query)){
                while ($row = mysqli_fetch_array($query)){
                    $html .= "<option value='".$row['sigla']."'>".$row['sigla']."</option>";
                }
            }
            $html .="
            </select>
            <label for='tipoNotaEscola'>Tipo de Nota:</label>
            <select name='tipoNotaEscola' id='tipoNotaEscola' required class='form-control'>
                <option value=''>Selecione o tipo de nota corretamente...</option>
                <option value='1'>Bimestral</option>
                <option value='2'>Trimestral</option>
                <option value='3'>Semestral</option>
                <option value='4'>Anual</option>
            </select>
            <label for='turnoEscola'>Turno da Escola:</label>
            <select name='turnoEscola' id='turnoEscola' required class='form-control'>
                <option value=''>Selecione o turno da escola corretamente...</option>
                <option value='1'>Manhã</option>
                <option value='2'>Tarde</option>
                <option value='3'>Noite</option>
                <option value='4'>Único</option>
                <option value='5'>Todos</option>
            </select>
                <label for='letraEscola'>Letra da Escola:</label>
                     <select name='letraEscola' id='letraEscola' required class='form-control'>
                     <option value=''>Selecione até que letra a escola vai abaixo...</option>";
                     for($i = 0; $i <= 26; $i++) {
                         switch ($i){
                             case 0:
                                 $letra = "Única";
                                 $l = "Un";
                                 break;
                             case 1:
                                 $letra = "A";
                                 break;
                             case 2:
                                 $letra = "B";
                                 break;
                             case 3:
                                 $letra = "C";
                                 break;
                             case 4:
                                 $letra = "D";
                                 break;
                             case 5:
                                 $letra = "E";
                                 break;
                             case 6:
                                 $letra = "F";
                                 break;
                             case 7:
                                 $letra = "G";
                                 break;
                             case 8:
                                 $letra = "H";
                                 break;
                             case 9:
                                 $letra = "I";
                                 break;
                             case 10:
                                 $letra = "J";
                                 break;
                             case 11:
                                 $letra = "K";
                                 break;
                             case 12:
                                 $letra = "L";
                                 break;
                             case 13:
                                 $letra = "M";
                                 break;
                             case 14:
                                 $letra = "N";
                                 break;
                             case 15:
                                 $letra = "O";
                                 break;
                             case 16:
                                 $letra = "P";
                                 break;
                             case 17:
                                 $letra = "Q";
                                 break;
                             case 18:
                                 $letra = "R";
                                 break;
                             case 19:
                                 $letra = "S";
                                 break;
                             case 20:
                                 $letra = "T";
                                 break;
                             case 21:
                                 $letra = "U";
                                 break;
                             case 22:
                                 $letra = "V";
                                 break;
                             case 23:
                                 $letra = "W";
                                 break;
                             case 24:
                                 $letra = "X";
                                 break;
                             case 25:
                                 $letra = "Y";
                                 break;
                             case 26:
                                 $letra = "Z";
                                 break;
                         }
                         if ($i > 0){
                             $l = $letra;
                         }
                         $html .= "<option value='".$l."'>".$letra."</option>";
                     }
                     $html .= "
                     </select>";
        }
        $html .= "<br>
                            <button type=\"button\" onclick=\"incluirItem('".URL."')\"class=\"btn btn-primary\">Gravar</button>";
        echo "1|-|".$html;
        break;
    case "productItemEdita":
        $sql = "SELECT * FROM requests_items WHERE product_item = '".$_REQUEST['id']."' AND request = '".$_REQUEST['request']."' AND product = '".$_REQUEST['product']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        if ($row['product'] != 3 && $row['product'] != 4) {
            $html .= "<label for='domineEdita'>Domínio:</label><input type='text' name='domineEdita' id='domineEdita' required class='form-control' value='".$row['domine']."'>";
        }
        $html .= "<br>
                            <button type=\"button\" onclick=\"atualizarItem('".URL."')\"class=\"btn btn-primary\">Gravar</button>";
        echo "1|-|".$html;
        break;
    case "selecionaProdutoCadastro":
        $html = "<label for='productItemCadastro'>Item do Produto</label>
                 <select name='productItemCadastro' id='productItemCadastro' required class='form-control' onchange=selectProductItemCadastro(this.value,'".URL."')>
                    <option value=''>Selecione o item do produto abaixo...</option>";
        $sql = "SELECT * FROM products_items WHERE product = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            while ($row = mysqli_fetch_array($query)){
                $valor = ($row['promotion'] && $row['validity_promotion'] >= date('Y-m-d')) ? $row['promotion'] : $row['value'];
                $html .= "<option value='".$row['id']."'>".($row['name'])." - R$ ".number_format($valor, 2, ',', '.')."</option>";
            }
        }
        $html .= "</select><div id='productsItemCadastro'></div>";
        echo "1|-|".$html;
        break;
    case "selecionaEnderecoPedido":
        $sql = "SELECT * FROM addresses WHERE id = '" . $_REQUEST['id'] . "'";
        $query = mysqli_query($con, $sql);
        $endereco = mysqli_fetch_object($query);
        $html = "<b>Nome do Endereço:</b> " . ($endereco->name) . "<br>
                                          <b>CEP do Endereço:</b> " . ($endereco->cep) . "<br>
                                          <b>Logradouro do Endereço:</b> " . ($endereco->address) . "<br>
                                          <b>Número do Endereço:</b> " . ($endereco->number);
        if ($endereco->complement) {
            $html .= "<br>
                                          <b>Complemento do Endereço:</b> " . ($endereco->complement);
        }
        $html .= "<br>
                                          <b>Bairro do Endereço:</b> " . ($endereco->neighborhood);
        $html .= "<br>
                                          <b>Cidade do Endereço:</b> " . ($endereco->city);
        $html .= "<br>
                                          <b>Estado do Endereço:</b> " . ($endereco->state);
        echo "1|-|" . $html;
        break;
    case "abreEnderecosCliente":
        $sql = "SELECT * FROM addresses WHERE idClient = '" . $_SESSION['cliente']['id'] . "'";
        $query = mysqli_query($con, $sql);
        $html = "<div style='text-align:center'><input type='button' class='btn btn-primary' value='Cadastrar Novo' onclick=abre('cadastrarEndereco')></div>";
        if (mysqli_num_rows($query)) {
            while ($value = mysqli_fetch_object($query)) {
                $background = ($i % 2 == 0) ? "#F7F7F7" : "#FFFFFF";
                $html .= ("<div style='padding:5px; background-color: ".$background."'>".$value->address . ", ".$value->number);
                if ($value->complement){
                    $html .= ", ".($value->complement);
                }
                $html .= (" - ".$value->neighborhood.' - ' . $value->city . " - " . $value->state." - CEP: ".$value->cep);
                if ($value->referencia){
                    $html .= " - ".($value->referencia);
                }
                $html .= (" <img src='".URL_SITE."img/editar.svg' width='25' style='cursor:pointer' onclick=editarEnderecoCliente('".$value->id."','".URL_SITE."')> <img src='".URL_SITE."img/excluir.svg' width='25' style='cursor:pointer' onclick=excluirEnderecoCliente('".$value->id."','".URL_SITE."')></div>");
                $i++;
            }
        }
        else{
            $html .= "<button class='btn btn-danger' onclick=abre('cadastrarEndereco')>Nenhum endereço encontrado! Cadastre um novo agora!</button><br>";
        }
        $html .= "<input type='button' class='btn btn-primary' value='Cadastrar Novo' onclick=abre('cadastrarEndereco')>";
        echo "1|-|".$html;
        break;
    case "pegaEnderecosCliente":
        $sql = "SELECT * FROM addresses WHERE idClient = '" . $_REQUEST['idCliente'] . "'";
        $query = mysqli_query($con, $sql);
        $html = "<label for='enderecoPedido'>Endereço do Cliente:</label><select name='enderecoPedido' id='enderecoPedido' class='form-control' required onchange=selecionaEnderecoPedido(this.value,'" . URL . "')><option value=''>Selecione o endereço abaixo corretamente...</option>";
        while ($value = mysqli_fetch_object($query)) {
            $html .= "<option value='$value->id'";
            if ($_REQUEST['idEndereco'] == $value->id) {
                $endereco = $value;
                $html .= " selected";
            }
            $html .= ">" . ($value->name . " - " . $value->address . " ... " . $value->city . " - " . $value->state) . "</option>";
        }
        $html .= "</select>";
        if (count($endereco)) {
            $html2 = "<b>Nome do Endereço:</b> " . ($endereco->name) . "<br>
                                          <b>CEP do Endereço:</b> " . ($endereco->cep) . "<br>
                                          <b>Logradouro do Endereço:</b> " . ($endereco->address) . "<br>
                                          <b>Número do Endereço:</b> " . ($endereco->number);
            if ($endereco->complement) {
                $html2 .= "<br>
                                          <b>Complemento do Endereço:</b> " . ($endereco->complement);
            }
            $html2 .= "<br>
                                          <b>Bairro do Endereço:</b> " . ($endereco->neighborhood);
            $html2 .= "<br>
                                          <b>Cidade do Endereço:</b> " . ($endereco->city);
            $html2 .= "<br>
                                          <b>Estado do Endereço:</b> " . ($endereco->state);
        }
        echo "1|-|$html|-|".$html2;
        break;
    case "selecionaClientePedido":
        $sql = "SELECT a.*, b.name AS nameTypeDocument FROM clients a INNER JOIN type_documents b ON (a.typeDocument = b.id)  WHERE a.id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        $cliente = mysqli_fetch_object($query);
        $html = "
                            <div class=\"media text-muted pt-3\">
                                <p><b>Nome do Cliente: </b>".($cliente->name)."</p>
                            </div>
                            <div class=\"media text-muted pt-3\">
                                <p><b>Email do Cliente: </b>".$cliente->email."</p>
                            </div>
                            <div class=\"media text-muted pt-3\">
                                <p><b>Celular do Cliente: </b>$cliente->cel</p>
                            </div>
                            <div class=\"media text-muted pt-3\">
                                <p><b>Tipo de Documento do Cliente: </b>$cliente->nameTypeDocument</p>
                            </div>
                            <div class=\"media text-muted pt-3\">
                                <p><b>Documento do Cliente: </b>$cliente->document</p>
                            </div>";
        echo "1|-|".$html;
        break;
    case "pegaItensPedido":
        $sql = "SELECT * FROM products WHERE status = '1'";
        $query = mysqli_query($con, $sql);
        while ($row = mysqli_fetch_array($query)){
            $products[] = $row;
        }
        $sql = "SELECT * FROM requests_items WHERE request = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $html .= '<table border="0" width="100%" cellpadding="0" cellspacing="0">';
            if ($_REQUEST['cadastrar']){
                $html .= "<tr><td colspan='6'><button class='btn btn-primary' onClick='abre(\"cadastrarItem\")'>Cadastrar Item</button><div id='cadastrarItem' style='position: absolute; display:none; float: left; width:70%; padding:10px; background-color:#FFFFFF; border:1px solid #e7e7e7'><div style='position:absolute; float:left; left:95%; cursor:pointer' onclick=fecha('cadastrarItem')>&times;</div><input type='hidden' value='".$_REQUEST['id']."' name='requestCadastro' id='requestCadastro'><h3>Cadastro de Item</h3><label for='productCadastro'>Produto: </label><select class='form-control' name='productCadastro' id='productCadastro' onchange=selectProductCadastro(this.value,'".URL."')><option value=''>Selecione o produto...</option>";
                foreach($products as $key => $value){
                    $html .= "<option value='".$value['id']."'>".($value['name'])."</option>";
                }
                $html .= "</select><div id='selecionadoProdutoCadastro'></div></td></tr>";
            }
            $html .= "<div id='atualizarItem' style='position: absolute; display:none; float: left; width:70%; padding:10px; background-color:#FFFFFF; border:1px solid #e7e7e7'><div style='position:absolute; float:left; left:95%; cursor:pointer' onclick=fecha('atualizarItem')>&times;</div><input type='hidden' value='' name='idEdita' id='idEdita'><input type='hidden' value='".$_REQUEST['id']."' name='requestEdita' id='requestEdita'><h3>Edição de Item</h3><label for='productEdita'>Produto: </label><select class='form-control' name='productEdita' id='productEdita' onchange=selecionaProdutoEdita(this.value,'".$_REQUEST['id']."','".$_REQUEST['product']."','','".URL."')><option value=''>Selecione o produto...</option>";
                foreach($products as $key => $value){
                    $html .= "<option value='".$value['id']."'>".($value['name'])."</option>";
                }
                $html .= "</select><div id='selecionadoProdutoEdita'></div>
                        <tr>
                            <th style='text-align: center'>ID do Produto</th>
                            <th style='text-align: center'>Nome do Produto</th>
                            <th style='text-align: center'>Valor Unitário do Produto</th>
                            <th style='text-align: center'>Quantidade</th>
                            <th style='text-align: center'>Valor Total</th>";
            if ($_REQUEST['editar'] == 1 || $_REQUEST['excluir'] == 1){
                $html .= '<th style="text-align: center">Ações</th>';
            }
            $HTML .= '
                        </tr>';
            while ($row = mysqli_fetch_array($query)){
                $background = ($i % 2 == 0) ? "#e7e7e7" : "#ffffff";
                $html .= '<tr>
                            <td style="text-align:center; padding:5px; background-color: '.$background.'">'.$row['product'].'</td>
                            <td style="text-align:center; padding:5px; background-color: '.$background.'">'.($row['name']);
                if ($row['cashier_system']){
                    $sql = "SELECT * FROM cashier_system WHERE id = '".$row['cashier_system']."'";
                    $query2 = mysqli_query($con, $sql);
                    $row2 = mysqli_fetch_array($query2);
                    $html .= ' - <a onclick=verInformacoesCaixa("'.$row['cashier_system'].'") style="cursor:pointer">Ver informações do sistema</a>
                             <div id="informacoesCaixa" style="display:none; position:absolute; width:50%; background-color: #FFFFFF; border:1px solid #e7e7e7">
                                <div style="position:absolute; float::left; left: 95%; cursor: pointer" onclick=fecha("informacoesCaixa")>&times;</div>
                                <h3>Informações do Sistema de Caixa</h3>
                                Razão Social: <b>'.$row2['razao_social'].'</b><br>
                                Nome Fantasia: <b>'.$row2['nome_fantasia'].'</b><br>
                                E-mail: <b>'.$row2['email'].'</b><br>
                                CNPJ: <b>'.$row2['cnpj'].'</b><br>
                                CEP: <b>'.$row2['cep'].'</b><br>
                                Logradouro: <b>'.$row2['logradouro'].'</b><br>
                                Número: <b>'.$row2['numero'].'</b><br>';
                    if ($row2['complemento']){
                        $html .= "Complemento: <b>".$row2['complemento']."</b><br>";
                    }
                    $html .= '  Bairro: <b>'.$row2['bairro'].'</b><br>
                                Cidade: <b>'.$row2['cidade'].'</b><br>
                                Estado: <b>'.$row2['estado'].'</b><br>
                                Tipo do Estabelecimento: <b>';
                    if ($row2['tipoEstabelecimento'] == 1){
                        $tipoEstabelecimento = "Mesas";
                    }
                    else{
                        $tipoEstabelecimento = "Caixas";
                    }
                    $html .= $tipoEstabelecimento;
                    $html .= '</b><br>
                                Quantidade de '.$tipoEstabelecimento.': <b>'.$row2['quantidade'].'</b>';
                    if ($row2['tipoEstabelecimento'] == 1){
                        $html .= '<br>Número de Pessoas Por Mesa: <b>'.$row2['numeroPessoasPorMesa'].'</b>
                                    <br>Gorjeta do Garçom: <b>'.$row2['percentual'].'%</b>';
                    }
                   $html .= '</div>';
                }
                if ($row['school_system']){
                    $sql = "SELECT * FROM school_system WHERE id = '".$row['school_system']."'";
                    $query2 = mysqli_query($con, $sql);
                    $row2 = mysqli_fetch_array($query2);
                    $html .= ' - <a onclick=verInformacoesEscolar("'.$row['school_system'].'") style="cursor:pointer">Ver informações do sistema</a>
                             <div id="informacoesEscolar" style="display:none; position:absolute; width:50%; background-color: #FFFFFF; border:1px solid #e7e7e7">
                                <div style="position:absolute; float::left; left: 95%; cursor: pointer" onclick=fecha("informacoesEscolar")>&times;</div>
                                <h3>Informações do Sistema Escolar</h3>
                                Nome: <b>'.$row2['nome'].'</b><br>
                                E-mail: <b>'.$row2['email'].'</b><br>
                                CEP: <b>'.$row2['cep'].'</b><br>
                                Logradouro: <b>'.$row2['logradouro'].'</b><br>
                                Número: <b>'.$row2['numero'].'</b><br>';
                    if ($row2['complemento']){
                        $html .= "Complemento: <b>".$row2['complemento']."</b><br>";
                    }
                    $html .= '  Bairro: <b>'.$row2['bairro'].'</b><br>
                                Cidade: <b>'.$row2['cidade'].'</b><br>
                                Estado: <b>'.$row2['estado'].'</b><br>
                                Tipo de Nota: <b>';
                    if ($row2['tipoNota'] == 1){
                        $html .= 'Bimestral';
                    }
                    elseif ($row2['tipoNota'] == 2){
                        $html .= 'Trimestral';
                    }
                    elseif ($row2['tipoNota'] == 3){
                        $html .= 'Semestral';
                    }
                    elseif ($row2['tipoNota'] == 4){
                        $html .= 'Anual';
                    }
                    $html .= '</b><br>Turno: <b>';
                    if ($row2['turno'] == 1){
                        $html .= 'Manhã';
                    }
                    elseif ($row2['turno'] == 2){
                        $html .= 'Tarde';
                    }
                    elseif ($row2['turno'] == 3){
                        $html .= 'Noite';
                    }
                    elseif ($row2['turno'] == 4){
                        $html .= 'Único';
                    }
                    elseif ($row2['turno'] == 5){
                        $html .= 'Todos';
                    }
                    $html .= '</b><br>Letra: <b>';
                    if ($row2['letra'] == 'Un'){
                        $html .= "Única";
                    }
                    else{
                        $html .= $row2['letra'];
                    }
                    $html .= '</b></div>';
                }
                if ($row['domine']){
                    $html .= ' - <a href="'.$row['domine'].'" target="_blank" title="'.$row['domine'].'">'.substr($row['domine'], 0, 15)."...</a>";
                }
                $html .= '</td>
                            <td style="text-align:center; padding:5px; background-color: '.$background.'">R$'.number_format($row['value'], 2, ',', '.').'</td>
                            <td style="text-align:center; padding:5px; background-color: '.$background.'">'.$row['quantity'].'</td>
                            <td style="text-align:center; padding:5px; background-color: '.$background.'">R$'.number_format($row['value'] * $row['quantity'], 2, ',', '.').'</td>';
                if ($_REQUEST['editar'] == 1 || $_REQUEST['excluir'] == 1){
                    $html .= '<td style="text-align: center; padding:5px; background-color: '.$background.'">';
                    /*if ($_REQUEST['editar'] == 1){
                        $html .= '<img src="'.URL.'admin/img//editar.png" style="cursor:pointer" onclick=editaProdutoPedido("'.$row['id'].'","'.$_REQUEST['id'].'","'.URL.'") width="15">';
                    }*/
                    if ($_REQUEST['excluir'] == 1){
                        $html .= '<img src="'.URL.'admin/img//excluir.png" style="cursor:pointer" onclick=excluirItemPedido("'.$row['id'].'","'.$_REQUEST['id'].'","'.URL.'") width="15">';
                    }
                    $html .= '</td>';
                }

                $html .= '
                        </tr>';
                $i++;
                $valorTotal += $row['value'] * $row['quantity'];
            }
            $html .= '<tr>
                            <td style="padding:5px; text-align:center; width: 100%; background-color:#0069D9; color:#FFFFFF" colspan="6">Valor Total do Pedido: R$ '.number_format($valorTotal, 2, ',','.').'</td>
                        </tr></table>';
        }
        else{
            $html = "<div style='padding:5px; text-align:center; width: 100%; color:#FFFFFF; background-color: #FF0000'>Sem nenhum item encontrado!</div>";
        }
        echo "1|-|".$html;
        break;
    case "addPermissao":
        if ($_REQUEST['field'] == 'view'){
            $permissao = "view";
            $naoCadastra='register';
            $naoCadastra2 = "`delete`";
        }
        elseif ($_REQUEST['field'] == 'register'){
            $permissao = "register";
            $naoCadastra='view';
            $naoCadastra2 = "delete";
        }
        elseif ($_REQUEST['field'] == 'delete'){
            $permissao = "delete";
            $naoCadastra='view';
            $naoCadastra2 = "register";
        }
        $sql = "INSERT INTO logs (user, action, created_at, updated_at) VALUES ('".$_REQUEST['userLog']."', '".("Adicionou a permissão de ".$permissao." o módulo ".$_REQUEST['module']."  do usuário  ").$_REQUEST['user']."', now(), now())";
        mysqli_query($con, $sql);
        $sql = "SELECT * FROM permissions WHERE module = '".$_REQUEST['module']."' AND user = '".$_REQUEST['user']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $row = mysqli_fetch_array($query);
            $sql = "UPDATE permissions SET `".$_REQUEST['field']."` = '1' WHERE id = '".$row['id']."'";
        }
        else{
            $sql = "INSERT INTO permissions (module, user, ".$_REQUEST['field'].", ".$naoCadastra.", ".$naoCadastra2.", created_at, updated_at) VALUES ('".$_REQUEST['module']."', '".$_REQUEST['user']."', '1', '0', '0', now(), now())";
        }
        mysqli_query($con, $sql) or die(mysqli_error($con));
        echo "1";
        break;
    case "removePermissao":
        if ($_REQUEST['field'] == 'view'){
            $permissao = "visualizar";
        }
        elseif ($_REQUEST['field'] == 'register'){
            $permissao = "cadastrar";
        }
        elseif ($_REQUEST['field'] == 'delete'){
            $permissao = "excluir";
        }
        $sql = "INSERT INTO logs (user, action, created_at, updated_at) VALUES ('".$_REQUEST['userLog']."', '".("Removeu a permissão de ".$permissao." o módulo ".$_REQUEST['module']."  do usuário  ").$_REQUEST['user']."', now(), now())";
        mysqli_query($con, $sql);
        $sql = "SELECT * FROM permissions WHERE module = '".$_REQUEST['module']."' AND user = '".$_REQUEST['user']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $row = mysqli_fetch_array($query);
            $sql = "UPDATE permissions SET `".$_REQUEST['field']."` = '0' WHERE id = '".$row['id']."'";
        }
        else{
            $sql = "INSERT INTO permissions (module, user, `".$_REQUEST['field']."`, created_at, updated_at) VALUES ('".$_REQUEST['module']."', '".$_REQUEST['user']."', '0', now(), now())";
        }
        mysqli_query($con, $sql) or die(mysqli_error($con));
        echo "1";
        break;
    case "pegaPermissaoUsuario":
        echo "1|-|";
        $sql = "INSERT INTO logs (user, action, created_at, updated_at) VALUES ('".$_REQUEST['user']."', '".("Visualizou as permissões do usuário  ").$_REQUEST['id']."', now(), now())";
        mysqli_query($con, $sql);
        $sql = "SELECT a.*, b.name AS nameTypeModule FROM modules a INNER JOIN type_modules b ON (a.typeModule = b.id) ORDER BY a.typeModule ASC, a.id ASC";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            echo '
          <div style="float:left; width:25%">Módulo</div>
          <div style="float:left; width:25%">Visualiar</div>
          <div style="float:left; width:25%">Cadastrar</div>
          <div style="float:left; width:25%">Excluir</div> <br>
    ';
            while($row = mysqli_fetch_array($query)){
                $sql = "SELECT * FROM permissions WHERE user = '".$_REQUEST['id']."' AND module = '".$row['id']."'";
                $query2 = mysqli_query($con, $sql);
                $row2 = mysqli_fetch_array($query2);
                echo '<div style="float: left; width:25%; height:50px;';
                if ($i % 2 == 0){
                    echo 'background-color: #e7e7e7';
                }
                echo '">'.($row['nameTypeModule'].' => '.$row['name']).'</div>
    <div style="float: left; width:25%; height:50px; ';
                if ($i % 2 == 0){
                    echo 'background-color: #e7e7e7';
                }
                echo '" id="view'.$row['id'].$_REQUEST['id'].'">';
                if ($row2['view']){
                    echo '<img src="'.URL.'admin/img//sucesso.png" width="20" style="cursor:pointer" onclick=removePermissao("'.$_REQUEST['id'].'","'.$row['id'].'","view","'.URL.'","'.$_REQUEST['user'].'")>';
                }
                else{
                    echo '<img src="'.URL.'admin/img//erro.ico" width="20" style="cursor:pointer" onclick=adicionaPermissao("'.$_REQUEST['id'].'","'.$row['id'].'","view","'.URL.'","'.$_REQUEST['user'].'")>';
                }
                echo '</div>
    <div style="float: left; width:25%; height:50px; ';
                if ($i % 2 == 0){
                    echo 'background-color: #e7e7e7';
                }
                echo '" id="register'.$row['id'].$_REQUEST['id'].'">';
                if ($row2['register']){
                    echo '<img src="'.URL.'admin/img//sucesso.png" width="20" style="cursor:pointer" onclick=removePermissao("'.$_REQUEST['id'].'","'.$row['id'].'","register","'.URL.'","'.$_REQUEST['user'].'")>';
                }
                else{
                    echo '<img src="'.URL.'admin/img//erro.ico" width="20" style="cursor:pointer" onclick=adicionaPermissao("'.$_REQUEST['id'].'","'.$row['id'].'","register","'.URL.'","'.$_REQUEST['user'].'")>';
                }
                echo '</div>
    <div style="float: left; width:25%; height:50px; ';
                if ($i % 2 == 0){
                echo 'background-color: #e7e7e7';
                }
                echo '" id="delete'.$row['id'].$_REQUEST['id'].'">';
                if ($row2['delete']){
                    echo '<img src="'.URL.'admin/img//sucesso.png" width="20" style="cursor:pointer" onclick=removePermissao("'.$_REQUEST['id'].'","'.$row['id'].'","delete","'.URL.'","'.$_REQUEST['user'].'")>';
                }
                else{
                    echo '<img src="'.URL.'admin/img//erro.ico" width="20" style="cursor:pointer" onclick=adicionaPermissao("'.$_REQUEST['id'].'","'.$row['id'].'","delete","'.URL.'","'.$_REQUEST['user'].'")>';
                }
                echo '</div><br>
';
                $i++;
            }
        }
        else{
            echo '<div style="text-align:center; padding:10px; color:#FFFFFF; background-color: #FF0000">Sem nenhum módulo encontrado!</div>';
        }
        break;
    case "contaAcessoBanner":
        $sql = "SELECT * FROM counters_banners WHERE data = '".date('Y-m-d')."' AND banner = '".$_GET['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $row = mysqli_fetch_array($query);
            $acessos = $row['acessos'] + 1;
            $sql = "UPDATE counters_banners SET acessos = '".$acessos."', updated_at = now() WHERE id = '".$row['id']."'";
            mysqli_query($con, $sql);
        }
        else{
            $sql = "INSERT INTO counters_banners (banner, data, acessos, created_at, updated_at) VALUES ('".$_GET['id']."', '".date('Y-m-d')."', '1', now(), now())";
            mysqli_query($con, $sql);
        }
        echo "1";
        break;
    case "contaAcessoSubitem":
        $sql = "SELECT * FROM counters_subitems WHERE data = '".date('Y-m-d')."' AND subitem = '".$_GET['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $row = mysqli_fetch_array($query);
            $acessos = $row['acessos'] + 1;
            $sql = "UPDATE counters_subitems SET acessos = '".$acessos."', updated_at = now() WHERE id = '".$row['id']."'";
            mysqli_query($con, $sql);
        }
        else{
            $sql = "INSERT INTO counters_subitems (subitem, data, acessos, created_at, updated_at) VALUES ('".$_GET['id']."', '".date('Y-m-d')."', '1', now(), now())";
            mysqli_query($con, $sql);
        }
        echo "1";
        break;
    case "contaAcessoRedeSocial":
        $sql = "SELECT * FROM counters_social_network WHERE data = '".date('Y-m-d')."' AND social_network = '".$_GET['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $row = mysqli_fetch_array($query);
            $acessos = $row['acessos'] + 1;
            $sql = "UPDATE counters_social_network SET acessos = '".$acessos."', updated_at = now() WHERE id = '".$row['id']."'";
            mysqli_query($con, $sql);
        }
        else{
            $sql = "INSERT INTO counters_social_network (social_network, data, acessos, created_at, updated_at) VALUES ('".$_GET['id']."', '".date('Y-m-d')."', '1', now(), now())";
            mysqli_query($con, $sql);
        }
        echo "1";
        break;
    case "contaAcessoPagina":
        $sql = "SELECT * FROM counters_pages WHERE data = '".date('Y-m-d')."' AND page = '".$_GET['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $row = mysqli_fetch_array($query);
            $acessos = $row['acessos'] + 1;
            $sql = "UPDATE counters_pages SET acessos = '".$acessos."', updated_at = now() WHERE id = '".$row['id']."'";
            mysqli_query($con, $sql);
        }
        else{
            $sql = "INSERT INTO counters_pages (page, data, acessos, created_at, updated_at) VALUES ('".$_GET['id']."', '".date('Y-m-d')."', '1', now(), now())";
            mysqli_query($con, $sql);
        }
        echo "1";
        break;
    case "contaAcesso":
        if (!$_SESSION['entrouContador']){
            $sql = "SELECT * FROM counters WHERE data = '".date('Y-m-d')."'";
            echo $sql;
            $query = mysqli_query($con, $sql);
            if (mysqli_num_rows($query)){
                $row = mysqli_fetch_array($query);
                $acessos = $row['acessos'] + 1;
                $sql = "UPDATE counters SET acessos = '".$acessos."', updated_at = now() WHERE id = '".$row['id']."'";
                mysqli_query($con, $sql);
            }
            else{
                $sql = "INSERT INTO counters (data, acessos, created_at, updated_at) VALUES ('".date('Y-m-d')."', '1', now(), now())";
                mysqli_query($con, $sql);
            }
            $_SESSION['entrouContador'] = 1;
        }
        if (!$_GET['url']){
            $page = 1;
        }
        else{
            $sql = "SELECT * FROM pages WHERE slug = '".$_GET['url']."'";
            $query = mysqli_query($con, $sql);
            $row = mysqli_fetch_array($query);
            $page = $row['id'];
        }
        $sql = "SELECT * FROM counters_pages WHERE data = '".date('Y-m-d')."' AND page = '".$page."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $row = mysqli_fetch_array($query);
            $acessos = $row['acessos'] + 1;
            $sql = "UPDATE counters_pages SET acessos = '".$acessos."', updated_at = now() WHERE id = '".$row['id']."'";
            mysqli_query($con, $sql);
        }
        else {
            $sql = "INSERT INTO counters_pages (page, data, acessos, created_at, updated_at) VALUES ('" . $page . "', '" . date('Y-m-d') . "', '1', now(), now())";
            mysqli_query($con, $sql);
        }
        echo "1";
        break;
    case "abreSubitem":
        $sql = "SELECT a.*, b.name AS nomePagina FROM subitems a INNER JOIN pages b ON (a.page = b.id) WHERE a.id = '".$_GET['id']."' OR a.slug = '".$_GET['id']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        $sql = "SELECT * FROM counters_subitems WHERE data = '".date('Y-m-d')."' AND subitem = '".$row['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $row2 = mysqli_fetch_array($query);
            $acessos = $row['acessos'] + 1;
            $sql = "UPDATE counters_subitems SET acessos = '".$acessos."', updated_at = now() WHERE id = '".$row2['id']."'";
            mysqli_query($con, $sql);
        }
        else{
            $sql = "INSERT INTO counters_subitems (subitem, data, acessos, created_at, updated_at) VALUES ('".$row['id']."', '".date('Y-m-d')."', '1', now(), now())";
            mysqli_query($con, $sql);
        }
        $sql = "SELECT * FROM products_items WHERE product = '7' AND status = '1'";
        $query2 = mysqli_query($con, $sql);
        if (mysqli_num_rows($query2)){
            while ($row2 = mysqli_fetch_object($query2)){
                if (preg_match('/Básico/', ($row2->name))) {
                    $hospedagemBasico[] = $row2;
                }
                if (preg_match('/Intermediário/', ($row2->name))) {
                    $hospedagemIntermediario[] = $row2;
                }
                if (preg_match('/Avançado/', ($row2->name))) {
                    $hospedagemAvancado[] = $row2;
                }
            }
        }
        $planosHospedagem = "<div style='float:left; width:300px; height:1100px; background-color:#330000; color:#FFFFFF; padding:5px; margin:5px;'>
            <h3 style='color:#FFFFFF'>Plano Básico</h3>
            <p style='height:160px;'>Conheça o Plano Básico, o plano ideal para empresas que não requerem muito tráfego mensal. Possui 5 caixas de email, 1 subdomínio e até 2 banco de dados.</p>";
        foreach($hospedagemBasico as $key => $value){
            if ($value->promotion && $value->validity_promotion >= date('Y-m-d')){
                $valor = $value->promotion;
            }
            else{
                $valor = $value->value;
            }
            $planosHospedagem .= "<p>".($value->name)." - R$".number_format($valor, 2, ',', '.').'<br><input type="button" onclick=abreComprar("' . $row['id'] . '","' . URL_SITE . '","'.$value->id.'") class="btn btn-primary btn-outline" value="Comprar Esta"></p>';
        }
        $planosHospedagem .= "</div><div style='float:left; width:300px; height:1100px; background-color:#003300; color:#FFFFFF; padding:5px; margin:5px;'>
            <h3 style='color:#FFFFFF'>Plano Intermediário</h3>
            <p style='height:160px;'>Conheça o Plano Intermediário, o plano ideal para empresas que possuem um tráfego mensal intermediário. Possui até 10 caixas de emails, até 10 subdomínios e até 10 banco de dados!</p>";
        foreach($hospedagemIntermediario as $key => $value){
            if ($value->promotion && $value->validity_promotion >= date('Y-m-d')){
                $valor = $value->promotion;
            }
            else{
                $valor = $value->value;
            }
            $planosHospedagem .= "<p>".($value->name)." - R$".number_format($valor, 2, ',', '.').'<br><input type="button" onclick=abreComprar("' . $row['id'] . '","' . URL_SITE . '","'.$value->id.'") class="btn btn-primary btn-outline" value="Comprar Esta"></p>';
        }
        $planosHospedagem .= "</div><div style='float:left; width:300px; height:1100px; background-color:#000033; color:#FFFFFF; padding:5px; margin:5px;'>
            <h3 style='color:#FFFFFF'>Plano Avançado</h3>
            <p style='height:160px;'>Conheça o Plano Avançado, o plano ideal para empresas que possuem um tráfego mensal alto. Esse plano é todo ilimitado!</p>";
        foreach($hospedagemAvancado as $key => $value){
            if ($value->promotion && $value->validity_promotion >= date('Y-m-d')){
                $valor = $value->promotion;
            }
            else{
                $valor = $value->value;
            }
            $planosHospedagem .= "<p>".($value->name)." - R$".number_format($valor, 2, ',', '.').'<br><input type="button" onclick=abreComprar("' . $row['id'] . '","' . URL_SITE . '","'.$value->id.'") class="btn btn-primary btn-outline" value="Comprar Esta"></p>';
        }
        $planosHospedagem .= "</div>";
        $sql = "SELECT * FROM products_items WHERE product = '8' AND status = '1'";
        $query3 = mysqli_query($con, $sql);
        if (mysqli_num_rows($query3)) {
            while ($row2 = mysqli_fetch_array($query3)) {
                if ($row2['promotion'] && $row2['validity_promotion'] >= date('Y-m-d')){
                    $valor = $row2['promotion'];
                }
                else{
                    $valor = $row2['value'];
                }
                $planosRegistro .= '<div style="">'.$row2['name'].' - R$'.number_format($valor, 2, ',', '.').' - <input type="button" onclick=abreComprar("' . $row['id'] . '","' . URL_SITE . '","'.$row2['id'].'") class="btn btn-primary btn-outline" value="Comprar"></div>';
            }
        }
        $sql = "SELECT * FROM products_items WHERE name LIKE '%".$row['name']."%' AND product = '9'";
        $query3 = mysqli_query($con, $sql);
        $row3 = mysqli_fetch_array($query3);
        $btnVejaOSite = '<input type="button" onclick=window.open("'.URL_SITE.'cliente/'.$row['slug'].'") class="btn btn-primary btn-md" value="Veja o Site Deles">';
        $btnVejaOSiteModelo = '<input type="button" onclick=window.open("'.URL_SITE.'modelo/'.$row['slug'].'") class="btn btn-primary btn-md" value="Veja o Site">';
        if($_SESSION['cliente']['id']){
            $btnSoliciteASua = '<input type="button" onclick=abreComprar("'.$row['id'].'","'.URL_SITE.'") class="btn btn-primary btn-outline" value="Solicite a Sua Agora">';
            $btnSoliciteOSeu = '<input type="button" onclick=abreComprar("'.$row['id'].'","'.URL_SITE.'") class="btn btn-primary btn-outline" value="Solicite o Seu Agora">';
            $btnCompreEsseModelo = '<input type="button" onclick=abreComprar("9","'.URL_SITE.'","'.$row3['id'].'") class="btn btn-primary btn-outline" value="Compre o Seu Agora">';
        }
        else{
            $btnSoliciteASua = '<input type="button" onclick=abre("login");$("#emailLogin").focus(); class="btn btn-primary btn-outline" value="'.("Faça o seu login para comprar").'">';
            $btnSoliciteOSeu = '<input type="button" onclick=abre("login");$("#emailLogin").focus(); class="btn btn-primary btn-outline" value="'.("Faça o seu login para comprar").'">';
            $btnCompreEsseModelo = '<input type="button" onclick=abre("login");$("#emailLogin").focus(); class="btn btn-primary btn-outline" value="'.("Faça o seu login para comprar").'">';
        }
        echo "1|-|".$parametrosSite['title'].' &raquo; '.($row['nomePagina'].' &raquo; '.$row['name']."|-|<img src='".URL_SITE."img/upload/".$row['img']."' style='width:100%'><br>".nl2br(str_replace("##btnConfiraONossoSite##", '<input type="button" onclick=window.open("'.URL_SITE.'cliente/'.$row['slug'].'") class="btn btn-primary btn-outline" value="Veja esse site">', str_replace("##btnSoliciteASua##", $btnSoliciteASua, str_replace("##soliciteOSeu##", $btnSoliciteOSeu, str_replace("##nome##", $row['name'], str_replace('##btnVejaUmExemplo##', '<input type="button" onclick=vejaUmExemplo("'.$row['id'].'","'.URL_SITE.'") class="btn btn-primary btn-md" value="Veja um exemplo">', str_replace('##btnVejaOSite##', $btnVejaOSite, str_replace('##btnVejaOSiteModelo##', $btnVejaOSiteModelo, str_replace('##btnCompreEsseModelo##', $btnCompreEsseModelo, str_replace('##planosHospedagem##', ($planosHospedagem), str_replace("##planosRegistro##", $planosRegistro, str_replace("##subtitulo##", URL."cliente/".$row['slug'], $row['description'])))))))))))));
        break;
    case "abreProdutosItens":
        if ($_REQUEST['product']) {
            $sql = "SELECT * FROM products_items WHERE product = '" . $_REQUEST['product'] . "'";
            $query = mysqli_query($con, $sql);
            $html = '<label for="idProdutoItemComprar'.$_REQUEST['slug'].'"><span class="required">*</span> Item:</label>
                    <select name="idProdutoItemComprar'.$_REQUEST['slug'].'" id="idProdutoItemComprar'.$_REQUEST['slug'].'" class="form-control" style="width:100%" required onchange=selecionaProdutoItem("'.$_REQUEST['product'].'",this.value,"'.URL_SITE.'","'.$_REQUEST['slug'].'")>
                        <option value="">Selecione o item do produto abaixo...</option>';
            if (mysqli_num_rows($query)) {
                while ($row = mysqli_fetch_array($query)) {
                    if ($row['promotion'] && $row['validity_promotion'] >= date('Y-m-d')) {
                        $valor = $row['promotion'];
                    } else {
                        $valor = $row['value'];
                    }
                    $html .= '<option value="' . $row['id'] . '"';
                    if ($_REQUEST['item'] == $row['id']) {
                        $html .= ' selected';
                    }
                    $html .= '>' . ($row['name']) . ' - R$' . number_format($valor, 2, ',', '.') . '</option>';
                }
            }
            $html .= '</select><div id="dadosItem'.$_REQUEST['slug'].'"></div>';
            $html .= '<div class="content">
                <div style="text-align: center" id="btnComprar">
                    <input class="btn btn-primary btn-outline" value="Comprar" onclick=comprar(\''.$_REQUEST['product'].'\',$(\'#idProdutoItemComprar'.$_REQUEST['slug'].'\').val(),\''.URL.'\',\''.$_REQUEST['slug'].'\');> <input type="button" class="btn btn-danger btn-outline" onClick=fecha("solicite'.$_REQUEST['slug'].'") value="Fechar">
                </div>
            </div>';
        }
        echo "1|-|".$html;
        break;
    case "selecionaProdutoItem":
        if ($_REQUEST['product'] == 4){
            $html = "<label for='nomeEscolaComprar".$_REQUEST['slug']."'><span class='required'>*</span> Nome da Escola:</label>
                <input type='text' name='nomeEscolaComprar".$_REQUEST['slug']."' id='nomeEscolaComprar".$_REQUEST['slug']."' class='form-control' style='width:100%' required placeholder='Informe o nome da escola corretamente...'>
                <label for='emailEscolaComprar".$_REQUEST['slug']."'><span class='required'>*</span> Email da Escola:</label>
                <input type='email' name='emailEscolaComprar".$_REQUEST['slug']."' id='emailEscolaComprar".$_REQUEST['slug']."' class='form-control' style='width:100%' required placeholder='Informe o email da escola corretamente...'>
                <label for='cepEscolaComprar".$_REQUEST['slug']."'><span class='required'>*</span> CEP da Escola:</label>
                <input type='text' name='cepEscolaComprar".$_REQUEST['slug']."' id='cepEscolaComprar".$_REQUEST['slug']."' class='form-control' style='width:100%' maxlength='9' placeholder='Informe o cep da escola corretamente...' onkeyup=mascara(this,'#####-###',event);pesquisacep(this.value,'EscolaComprar".$_REQUEST['slug']."') required>
                <label for='logradouroEscolaComprar".$_REQUEST['slug']."'><span class='required'>*</span> Logradouro da Escola:</label>
                <input type='text' name='logradouroEscolaComprar".$_REQUEST['slug']."' id='logradouroEscolaComprar".$_REQUEST['slug']."' class='form-control' style='width:100%' required placeholder='Informe o logradouro da escola corretamente...'>
                <label for='numeroEscolaComprar".$_REQUEST['slug']."'><span class='required'>*</span> Número da Escola:</label>
                <input type='text' name='numeroEscolaComprar".$_REQUEST['slug']."' id='numeroEscolaComprar".$_REQUEST['slug']."' class='form-control' style='width:100%' required placeholder='Informe o número do endereço da escola corretamente...'>
                <label for='complementoEscolaComprar".$_REQUEST['slug']."'>Complemento da Escola:</label>
                <input type='text' name='complementoEscolaComprar".$_REQUEST['slug']."' id='complementoEscolaComprar".$_REQUEST['slug']."' class='form-control' style='width:100%' placeholder='Informe o complemento do endereço da escola corretamente...'>
                <label for='bairroEscolaComprar".$_REQUEST['slug']."'><span class='required'>*</span> Bairro da Escola:</label>
                <input type='text' name='bairroEscolaComprar".$_REQUEST['slug']."' id='bairroEscolaComprar".$_REQUEST['slug']."' class='form-control' required style='width:100%' placeholder='Informe o bairro da escola corretamente...'>
                <label for='cidadeEscolaComprar".$_REQUEST['slug']."'><span class='required'>*</span> Cidade da Escola:</label>
                <input type='text' name='cidadeEscolaComprar".$_REQUEST['slug']."' id='cidadeEscolaComprar".$_REQUEST['slug']."' class='form-control' required style='width:100%' placeholder='Informe a cidade da escola corretamente...'>
                <label for='estadoEscolaComprar".$_REQUEST['slug']."'><span class='required'>*</span> Estado da Escola:</label>
                <select name='estadoEscolaComprar".$_REQUEST['slug']."' id='estadoEscolaComprar".$_REQUEST['slug']."' class='form-control' style='width:100%' required>
                    <option value=''>Selecione o estado abaixo...</option>";
            $sql = "SELECT * FROM states";
            $query = mysqli_query($con, $sql);
            if (mysqli_num_rows($query)){
                while ($row = mysqli_fetch_array($query)){
                    $html .= "<option value='".$row['sigla']."'>".$row['sigla']."</option>";
                }
            }
            $html .= "
                </select>
                <label for='tipoNotaEscolaComprar".$_REQUEST['slug']."'><span class='required'>*</span> Tipo de Notas da Escola:</label>
                <select name='tipoNotaEscolaComprar".$_REQUEST['slug']."' id='tipoNotaEscolaComprar".$_REQUEST['slug']."' class='form-control' style='width:100%' required onchange=selecionaTipoNotaEscola(this.value,'".URL_SITE."')>
                    <option value=''>Selecione o tipo de notas da escola corretamente...</option>";
            $sql = "SELECT * FROM tipo_notas WHERE deleted_at IS NULL";
            $query = mysqli_query($con, $sql);
            if (mysqli_num_rows($query)){
                while ($row = mysqli_fetch_array($query)){
                    $html .= "<option value='".$row['id']."'>".$row['nome']."</option>";
                }
            }
            $html .= "
                </select>
                <div id='tipoNotasEscola'></div>
                <label for='turnoEscolaComprar".$_REQUEST['slug']."'><span class='required'>*</span> Turno da Escola:</label>
                <select name='turnoEscolaComprar".$_REQUEST['slug']."' id='turnoEscolaComprar".$_REQUEST['slug']."' class='form-control' style='width:100%' required>
                    <option value=''>Selecione o turno em que a escola funciona corretamente...</option>";
                    $sql = "SELECT * FROM turnos WHERE deleted_at IS NULL";
                    $query = mysqli_query($con, $sql);
                    if (mysqli_num_rows($query)){
                        while ($row = mysqli_fetch_array($query)){
                            $html .= "<option value='".$row['id']."'>".$row['name']."</option>";
                        }
                    }
                    $html .= "
                </select>
                <label for='letraEscolaComprar".$_REQUEST['slug']."'><span class='required'>*</span> Até que letra vai as turmas da Escola:</label>
                <select name='letraEscolaComprar".$_REQUEST['slug']."' id='letraEscolaComprar".$_REQUEST['slug']."' class='form-control' style='width:100%' required>
                    <option value=''>Selecione até que letra vai as turmas da escola corretamente...</option>";
                    $sql = "SELECT * FROM letras WHERE deleted_at IS NULL";
                    $query = mysqli_query($con, $sql);
                    if (mysqli_num_rows($query)){
                        while ($row = mysqli_fetch_array($query)){
                            $html .= "<option value='".$row['sigla']."'>".$row['name']."</option>";
                        }
                    }
                    $html .= "
                </select>
                ";
        }
        elseif ($_REQUEST['product'] == 5){
            $html = "<label for='razaoSocialEstabelecimentoComprar".$_REQUEST['slug']."'><span class='required'>*</span> Razão Social do Estabelecimento:</label>
                <input type='text' name='razaoSocialEstabelecimentoComprar".$_REQUEST['slug']."' id='razaoSocialEstabelecimentoComprar".$_REQUEST['slug']."' placeholder='Informe a razão social do estabelecimento aqui..' class='form-control' style='width:100%' required>
                <label for='nomeFantasiaEstabelecimentoComprar".$_REQUEST['slug']."'><span class='required'>*</span> Nome Fantasia do Estabelecimento:</label>
                <input type='text' name='nomeFantasiaEstabelecimentoComprar".$_REQUEST['slug']."' id='nomeFantasiaEstabelecimentoComprar".$_REQUEST['slug']."' placeholder='Informe o nome fantasia do estabelecimento aqui..' class='form-control' style='width:100%' required>
                <label for='cnpjEstabelecimentoComprar".$_REQUEST['slug']."'><span class='required'>*</span> CNPJ do Estabelecimento:</label>
                <input type='text' name='cnpjEstabelecimentoComprar".$_REQUEST['slug']."' id='cnpjEstabelecimentoComprar".$_REQUEST['slug']."' maxlength='18' placeholder='Informe o cnpj do estabelecimento (só números) aqui..' class='form-control' style='width:100%' onkeyup=mascara(this,'##.###.###/####-##',event); required>
                <label for='contatoEstabelecimentoComprar".$_REQUEST['slug']."'><span class='required'>*</span> Nome do Contato do Estabelecimento:</label>
                <input type='text' name='contatoEstabelecimentoComprar".$_REQUEST['slug']."' id='contatoEstabelecimentoComprar".$_REQUEST['slug']."' placeholder='Informe o nome do contato do estabelecimento aqui..' class='form-control' style='width:100%' required>
                <label for='emailEstabelecimentoComprar".$_REQUEST['slug']."'><span class='required'>*</span> Email do Estabelecimento:</label>
                <input type='email' name='emailEstabelecimentoComprar".$_REQUEST['slug']."' id='emailEstabelecimentoComprar".$_REQUEST['slug']."' placeholder='Informe o email do estabelecimento aqui..' class='form-control' style='width:100%' required>
                <label for='cepEstabelecimentoComprar".$_REQUEST['slug']."'><span class='required'>*</span> CEP do Estabelecimento:</label>
                <input type='text' name='cepEstabelecimentoComprar".$_REQUEST['slug']."' id='cepEstabelecimentoComprar".$_REQUEST['slug']."' class='form-control' maxlength='9' placeholder='Informe o cep do estabelecimento corretamente...' style='width:100%' onkeyup=mascara(this,'#####-###',event);pesquisacepestabelecimento(this.value,'EstabelecimentoComprar".$_REQUEST['slug']."') required>
                <label for='logradouroEstabelecimentoComprar".$_REQUEST['slug']."'><span class='required'>*</span> Logradouro do Estabelecimento:</label>
                <input type='text' name='logradouroEstabelecimentoComprar".$_REQUEST['slug']."' id='logradouroEstabelecimentoComprar".$_REQUEST['slug']."' class='form-control' required style='width:100%' placeholder='Informe o logradouro do estabelecimento corretamente...'>
                <label for='numeroEstabelecimentoComprar".$_REQUEST['slug']."'><span class='required'>*</span> Número do Estabelecimento:</label>
                <input type='text' name='numeroEstabelecimentoComprar".$_REQUEST['slug']."' id='numeroEstabelecimentoComprar".$_REQUEST['slug']."' class='form-control' required style='width:100%' placeholder='Informe o número do endereço do estabelecimento corretamente...'>
                <label for='complementoEstabelecimentoComprar".$_REQUEST['slug']."'>Complemento do Estabelecimento:</label>
                <input type='text' name='complementoEstabelecimentoComprar".$_REQUEST['slug']."' id='complementoEstabelecimentoComprar".$_REQUEST['slug']."' class='form-control' style='width:100%' placeholder='Informe o complemento do endereço do estabelecimento corretamente...'>
                <label for='bairroEstabelecimentoComprar".$_REQUEST['slug']."'><span class='required'>*</span> Bairro do Estabelecimento:</label>
                <input type='text' name='bairroEstabelecimentoComprar".$_REQUEST['slug']."' id='bairroEstabelecimentoComprar".$_REQUEST['slug']."' class='form-control' required style='width:100%' placeholder='Informe o bairro do estabelecimento corretamente...'>
                <label for='cidadeEstabelecimentoComprar".$_REQUEST['slug']."'><span class='required'>*</span> Cidade do Estabelecimento:</label>
                <input type='text' name='cidadeEstabelecimentoComprar".$_REQUEST['slug']."' id='cidadeEstabelecimentoComprar".$_REQUEST['slug']."' class='form-control' required style='width:100%' placeholder='Informe a cidade do estabelecimento corretamente...'>
                <label for='estadoEstabelecimentoComprar".$_REQUEST['slug']."'><span class='required'>*</span> Estado do Estabelecimento:</label>
                <select name='estadoEstabelecimentoComprar".$_REQUEST['slug']."' id='estadoEstabelecimentoComprar".$_REQUEST['slug']."' class='form-control' style='width:100%' required>
                    <option value=''>Selecione o estado abaixo...</option>";
            $sql = "SELECT * FROM states";
            $query = mysqli_query($con, $sql);
            if (mysqli_num_rows($query)){
                while ($row = mysqli_fetch_array($query)){
                    $html .= "<option value='".$row['sigla']."'>".$row['nome']."</option>";
                }
            }
            $html .= "
                </select>
                <label for='tipoEstabelecimentoComprar".$_REQUEST['slug']."'><span class='required'>*</span> Tipo do Estabelecimento:</label>
                <select name='tipoEstabelecimentoComprar".$_REQUEST['slug']."' id='tipoEstabelecimentoComprar".$_REQUEST['slug']."' class='form-control' style='width:100%' onchange=selecionaTipoEstabelecimento(this.value,'".URL_SITE."') required>
                    <option value=''>Selecione o tipo do estabelecimento abaixo...</option>";
                    $sql = "SELECT * FROM tipo_estabelecimentos WHERE deleted_at IS NULL";
                    $query = mysqli_query($con, $sql);
                    if (mysqli_num_rows($query)){
                        while ($row = mysqli_fetch_array($query)){
                            $html .= "<option value='".$row['id']."'>".$row['name']."</option>";
                        }
                    }
                    $html .= "
                </select>
                <div id='tipoEstabelecimento'></div>";
        }
        else{
            if ($_REQUEST['product'] != 9) {
                $html = "<label for='dominioComprar".$_REQUEST['slug']."'><span class='required'>*</span> Domínio:</label>
                <input type='text' name='dominioComprar".$_REQUEST['slug']."' id='dominioComprar".$_REQUEST['slug']."' placeholder='Informe o domínio aqui..' class='form-control' style='width:100%' required>";
                if ($_REQUEST['product'] != 8) {
                    $html .= "<label for='compraDominioComprar".$_REQUEST['slug']."'>Comprar o domínio também:</label>
                <select name='compraDominioComprar".$_REQUEST['slug']."' id='compraDominioComprar".$_REQUEST['slug']."' class='form-control' style='width:100%' onchange=selecionaComprar".$_REQUEST['slug']."Dominio(this.value,'" . URL . "')>
                    <option value='0'>Não</option>
                    <option value='1' selected>Sim</option>
                </select>
                <div id='ComprarDominio".$_REQUEST['slug']."'>
                    <label for='periodicidadeCobrancaDominioComprar".$_REQUEST['slug']."'><span class='required'>*</span> Periodicidade da Cobrança do Domínio:</label>
                    <select name='periodicidadeCobrancaDominioComprar".$_REQUEST['slug']."' id='periodicidadeCobrancaDominioComprar".$_REQUEST['slug']."' class='form-control' style='width:100%' required>
                    <option value=''>Selecione a periodicidade de cobrança do domínio corretamente...</option>";
                    $sql = "SELECT * FROM products_items WHERE product = '8' AND status = '1'";
                    $query2 = mysqli_query($con, $sql);
                    if (mysqli_num_rows($query2)) {
                        while ($row2 = mysqli_fetch_array($query2)) {
                            $html .= "
                        <option value='" . $row2['id'] . "'>" . ($row2['name']) . " - ";
                            if ($row2['promotion'] && $row2['validity_promotion'] >= date('Y-m-d')) {
                                $html .= "R$ " . number_format($row2['promotion'], 2, ',', '.');
                            } else {
                                $html .= "R$ " . number_format($row2['value'], '2', ',', '.');
                            }
                            $html .= "</option>";
                        }
                    }
                    $html .= "
                    </select>
                </div>";
                    if ($_REQUEST['product'] != 7) {
                        $html .= "<label for='compraHospedagemComprar".$_REQUEST['slug']."'>Comprar a hospedagem do site também:</label>
                <select name='compraHospedagemComprar".$_REQUEST['slug']."' id='compraHospedagemComprar".$_REQUEST['slug']."' class='form-control' style='width:100%' onchange=selecionaComprar".$_REQUEST['slug']."Hospedagem(this.value,'" . URL . "')>
                    <option value='0'>Não</option>
                    <option value='1' selected>Sim</option>
                </select>
                <div id='Comprar".$_REQUEST['slug']."Hospedagem'>
                    <label for='itemVendaHospedagemComprar".$_REQUEST['slug']."'><span class='required'>*</span> Item de Venda da Hospedagem:</label>
                    <select name='itemVendaHospedagemComprar".$_REQUEST['slug']."' id='itemVendaHospedagemComprar".$_REQUEST['slug']."' class='form-control' style='width:100%' required>
                    <option value=''>Selecione o item de venda da hospedagem corretamente...</option>";
                        $sql = "SELECT * FROM products_items WHERE product = '7' AND status = '1'";
                        $query2 = mysqli_query($con, $sql);
                        if (mysqli_num_rows($query2)) {
                            while ($row2 = mysqli_fetch_array($query2)) {
                                $html .= "
                        <option value='" . $row2['id'] . "'>" . ($row2['name']) . " - ";
                                if ($row2['promotion'] && $row2['validity_promotion'] >= date('Y-m-d')) {
                                    $html .= "R$ " . number_format($row2['promotion'], 2, ',', '.');
                                } else {
                                    $html .= "R$ " . number_format($row2['value'], '2', ',', '.');
                                }
                                $html .= "</option>";
                            }
                        }
                    $html .= "
                    </select>
                </div>";
                    $html .= "<label for='compraModeloComprar".$_REQUEST['slug']."'>Comprar o modelo do site também:</label>
                <select name='compraModeloComprar".$_REQUEST['slug']."' id='compraModeloComprar".$_REQUEST['slug']."' class='form-control' style='width:100%' onchange=selecionaComprar".$_REQUEST['slug']."Modelo(this.value,'" . URL . "')>
                    <option value='0'>Não</option>
                    <option value='1' selected>Sim</option>
                </select>
                <div id='Comprar".$_REQUEST['slug']."Modelo'>
                    <label for='modeloComprar".$_REQUEST['slug']."'><span class='required'>*</span> Modelo de Site:</label>
                    <select name='modeloComprar".$_REQUEST['slug']."' id='modeloComprar".$_REQUEST['slug']."' class='form-control' style='width:100%' required>
                    <option value=''>Selecione o modelo de site corretamente...</option>";
                        $sql = "SELECT * FROM products_items WHERE product = '9' AND status = '1'";
                        $query2 = mysqli_query($con, $sql);
                        if (mysqli_num_rows($query2)) {
                            while ($row2 = mysqli_fetch_array($query2)) {
                                $html .= "
                        <option value='" . $row2['id'] . "'>" . ($row2['name']) . " - ";
                                if ($row2['promotion'] && $row2['validity_promotion'] >= date('Y-m-d')) {
                                    $html .= "R$ " . number_format($row2['promotion'], 2, ',', '.');
                                } else {
                                    $html .= "R$ " . number_format($row2['value'], '2', ',', '.');
                                }
                                $html .= "</option>";
                            }
                        }
                        $html .= "
                    </select>
                </div>";
                }
            }
            }
        }
        $html2 = '';
        echo "1|-|".$html;
        break;
    case "selecionaTipoEstabelecimento":
        if ($_REQUEST['qual'] == '1'){
            $quantidade = ($_REQUEST['quantidade']) ? $_REQUEST['quantidade'] : "12";
            $numeroPessoasEstabelecimento = ($_REQUEST['numeroPessoasEstabelecimento']) ? $_REQUEST['numeroPessoasEstabelecimento'] : 4;
            $percentual = ($_REQUEST['percentual']) ? $_REQUEST['percentual'] : 10;
            $_REQUEST['id'] = ($_REQUEST['id']) ? $_REQUEST['id'] : "EstabelecimentoComprar";
            $html = "
                <label for='quantidade".$_REQUEST['id']."'><span class='required'>*</span> Número de Mesas do Estabelecimento:</label>
                <input type='number' name='quantidade".$_REQUEST['id']."' id='quantidade".$_REQUEST['id']."' value='".$quantidade."' class='form-control' style='width:100%' min='1' required placeholder='Informe o número de mesas do estabelecimento corretamente...'>
                <label for='numeroPessoas".$_REQUEST['id']."'><span class='required'>*</span> Número de Pessoas por Mesa do Estabelecimento:</label>
                <input type='number' name='numeroPessoas".$_REQUEST['id']."' id='numeroPessoas".$_REQUEST['id']."' value='".$numeroPessoasEstabelecimento."' class='form-control' style='width:100%' min='1' required placeholder='Informe o número de pessoas por mesa do estabelecimento corretamente...'>
                <label for='percentualGarcom".$_REQUEST['id']."'><span class='required'>*</span> Percentual do Garçom do Estabelecimento:</label>
                <input type='number' name='percentualGarcom".$_REQUEST['id']."' id='percentualGarcom".$_REQUEST['id']."' value='".$percentual."' class='form-control' style='width:100%' min='1' required placeholder='Informe o percentual do garçom do estabelecimento corretamente...'>
                ";
        }
        elseif($_REQUEST['qual'] == '2'){
            $html = "
                <label for='quantidade".$_REQUEST['id']."'><span class='required'>*</span> Número de Caixas do Estabelecimento:</label>
                <input type='number' name='quantidade".$_REQUEST['id']."' id='quantidade".$_REQUEST['id']."' value='12' class='form-control' style='width:100%' min='1' required placeholder='Informe o número de caixas do estabelecimento corretamente...'>
               ";
        }
        echo "1|-|".$html;
        break;
    case "selecionaTipoNotaEscola":
        if ($_REQUEST['qual'] == 1){
            $numero = 4;
            $simbolo = "º";
            $nome = "Bimestre";
        }
        elseif ($_REQUEST['qual'] == 2){
            $numero = 3;
            $simbolo = "º";
            $nome = "Trimestre";
        }
        elseif ($_REQUEST['qual'] == 3){
            $numero = 2;
            $simbolo = "º";
            $nome = "Semestre";
        }
        elseif ($_REQUEST['qual'] == 4){
            $numero = 1;
            $simbolo = "º";
            $nome = "ano";
        }
        for($i = 1; $i <= $numero; $i++){
            $ptsDistribuidos = 100 / $numero;
            $html .= "<div style='float:left; width:".$ptsDistribuidos."%'><b>".$i.$simbolo." ".$nome."</b><input type='text' name='ptsDistribuidos".$i."' id='ptsDistribuidos".$i."' class='form-control' value='".number_format($ptsDistribuidos, 2)."' required></div>";
        }
        echo "1|-|".$html;
        break;
    case "editarSistemaEscolar":
        $sql = "UPDATE school_system SET nome = '".$_REQUEST['nomeEscola']."', email = '".$_REQUEST['emailEscola']."', cep = '".$_REQUEST['cepEscola']."', logradouro = '".$_REQUEST['logradouroEscola']."', numero = '".$_REQUEST['numeroEscola']."', complemento = '".$_REQUEST['complementoEscola']."', bairro = '".$_REQUEST['bairroEscola']."', cidade = '".$_REQUEST['cidadeEscola']."', estado = '".$_REQUEST['estadoEscola']."',  tipoNota = '".$_REQUEST['tipoNotaEscola']."', turno = '".$_REQUEST['turnoEscola']."', letra = '".$_REQUEST['letraEscola']."' WHERE id = '".$_REQUEST['idEscola']."'";
        mysqli_query($con, $sql) or die(mysqli_error($con));
        $sql = "DELETE FROM school_system_notas WHERE idSchool = '".$_REQUEST['idEscola']."'";
        $query = mysqli_query($con, $sql);
        if ($_REQUEST['tipoNotaEscola'] == 1){
            $numero = 4;
        }
        elseif ($_REQUEST['tipoNotaEscola'] == 2){
            $numero = 3;
        }
        elseif ($_REQUEST['tipoNotaEscola'] == 3){
            $numero = 2;
        }
        elseif ($_REQUEST['tipoNotaEscola'] == 4){
            $numero = 1;
        }
        for ($i = 1; $i <= $numero; $i++){
            $sql = "INSERT INTO school_system_notas (idSchool, etapa, ptsDistribuidos, created_at, updated_at) VALUES ('".$_REQUEST['idEscola']."', '".$i."', '".$_REQUEST['ptsDistribuidos'.$i]."', now(), now())";
            mysqli_query($con, $sql) or die(mysqli_error($con));
        }
        echo "1";
        break;
    case "editarSistemaCaixa":
        $sql = "UPDATE cashier_system SET razao_social = '".$_REQUEST['razaoSocialEstabelecimento']."', nome_fantasia = '".$_REQUEST['nomeFantasiaEstabelecimento']."', cnpj = '".$_REQUEST['cnpjEstabelecimento']."', contato = '".$_REQUEST['contatoEstabelecimento']."', email = '".$_REQUEST['emailEstabelecimento']."', cep = '".$_REQUEST['cepEstabelecimento']."', logradouro = '".$_REQUEST['logradouroEstabelecimento']."', numero = '".$_REQUEST['numeroEstabelecimento']."', complemento = '".$_REQUEST['complementoEstabelecimento']."', bairro = '".$_REQUEST['bairroEstabelecimento']."', cidade = '".$_REQUEST['cidadeEstabelecimento']."', estado = '".$_REQUEST['estadoEstabelecimento']."',  tipoEstabelecimento = '".$_REQUEST['tipoEstabelecimento']."', quantidade = '".$_REQUEST['quantidadeEstabelecimento']."', numeroPessoasPorMesa = '".$_REQUEST['numeroPessoasEstabelecimento']."', percentual = '".$_REQUEST['percentualGarcomEstabelecimento']."' WHERE id = '".$_REQUEST['idCaixa']."'";
        mysqli_query($con, $sql) or die(mysqli_error($con));
        echo "1";
        break;
    case "";
    case "abreCarrinho":
        $sql = "SELECT * FROM cart WHERE session_id = '".session_id()."'";
        $query = mysqli_query($con, $sql);
        $totCarrinho = mysqli_num_rows($query);
        if (mysqli_num_rows($query)){
            $html = "<table width='100%' cellpadding='0' cellspacing='0' border='0'><tr><th>Nome do Produto</th><th>Valor Unitário</th><th>Quantidade</th><th>Valor Total</th><th>Excluir</th></tr>";
            while ($row = mysqli_fetch_array($query)){
                $background = ($i % 2 == 0) ? "#F7F7F7" : "";
                $html .= ("<tr style='background-color: ".$background."'>
                               <td>".($row['name'])." - ");
                               if ($row['product'] != 5 && $row['product'] != 4){
                                   $html .= "<a href='".$row['domine']."' target='_blank'>".$row['domine']."</a>";
                               }
                               if ($row['school_system']){
                                   $html .= "<a onclick=verInformacoesSistemaEscolar('".$row['school_system']."','".URL."') style='cursor:pointer'>Editar Sistema Escolar</a><div id='verInformacoesSistemaEscolar".$row['school_system']."' style='display:none; position:absolute; padding:10px; border:1px solid #000000; width:100%; background-color:#FFFFFF'></div>";
                               }
                               if ($row['cashier_system']){
                                   $html .= "<a onclick=verInformacoesSistemaDeCaixa('".$row['cashier_system']."','".URL."') style='cursor:pointer'>Editar Sistema De Caixa</a><div id='verInformacoesSistemaDeCaixa".$row['cashier_system']."' style='display:none; position:absolute; padding:10px; border:1px solid #000000; width:100%; background-color:#FFFFFF'></div>";
                               }
                               $html .= ("</td>
                               <td>R$".number_format($row['value'], 2, ',', '.')."</td>
                               <td>".$row['quantity']."</td>
                               <td>R$".number_format($row['value'] * $row['quantity'], 2, ',', '.')."</td>
                               <td><img src='".URL_SITE."img/excluir.png' height='25' style='cursor:pointer' onclick=excluirCarrinho('".$row['id']."','".URL_SITE."')></td>
                          </tr>");
                $i++;
            }
            $html .= "</table>";
        }
        else{
            $html = "<div style='color:#FFFFFF; background-color:#FF0000; border-radius:25px; padding:15px; text-align:center; font-size:20px; font-weight:bold'>Nenhum produto encontrado!</div>";
        }
        echo "1|-|".$html."|-|".$totCarrinho;
        break;
    case "verInformacoesSistemaEscolar":
        $sql = "SELECT * FROM school_system WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $row = mysqli_fetch_array($query);
            $html = "<div style='position:absolute; float:left; left:95%'><img src='".URL."assets/img/close-icon.svg' width='30' style='cursor:pointer' onclick=fecha('verInformacoesSistemaEscolar".$_REQUEST['id']."')></div>
                    <h3>Editar Informações do Sistema Escolar</h3>
                    <input type='hidden' id='idEscolaComprar".$_REQUEST['id']."' name='idEscolaComprar".$_REQUEST['id']."' value='".$row['id']."'>
                    <label for='nomeEscolaComprar".$_REQUEST['id']."'><span class='required'>*</span> Nome da Escola:</label>
                    <input type='text' name='nomeEscolaComprar".$_REQUEST['id']."' id='nomeEscolaComprar".$_REQUEST['id']."' class='form-control' required placeholder='Informe o nome da escola corretamente...' value='".$row['nome']."'>
                    <label for='emailEscolaComprar".$_REQUEST['id']."'><span class='required'>*</span> Email da Escola:</label>
                    <input type='email' name='emailEscolaComprar".$_REQUEST['id']."' id='emailEscolaComprar".$_REQUEST['id']."' class='form-control' style='width:100%' required placeholder='Informe o email da escola corretamente...' value='".$row['email']."'>
                    <label for='cepEscolaComprar".$_REQUEST['id']."'><span class='required'>*</span> CEP da Escola:</label>
                    <input type='text' name='cepEscolaComprar".$_REQUEST['id']."' id='cepEscolaComprar".$_REQUEST['id']."' class='form-control' style='width:100%' maxlength='9' placeholder='Informe o cep da escola corretamente...' value='".$row['cep']."' onkeyup=mascara(this,'#####-###',event);pesquisacepescolaenderecocarrinho(this.value,'EscolaComprar".$_REQUEST['id']."') required>
                    <label for='logradouroEscolaComprar".$_REQUEST['id']."'><span class='required'>*</span> Logradouro da Escola:</label>
                    <input type='text' name='logradouroEscolaComprar".$_REQUEST['id']."' id='logradouroEscolaComprar".$_REQUEST['id']."' class='form-control' style='width:100%' required placeholder='Informe o logradouro da escola corretamente...' value='".$row['logradouro']."'>
                    <label for='numeroEscolaComprar".$_REQUEST['id']."'><span class='required'>*</span> Número da Escola:</label>
                    <input type='text' name='numeroEscolaComprar".$_REQUEST['id']."' id='numeroEscolaComprar".$_REQUEST['id']."' class='form-control' style='width:100%' required placeholder='Informe o número do endereço da escola corretamente...' value='".$row['numero']."'>
                    <label for='complementoEscolaComprar".$_REQUEST['id']."'>Complemento da Escola:</label>
                    <input type='text' name='complementoEscolaComprar".$_REQUEST['id']."' id='complementoEscolaComprar".$_REQUEST['id']."' class='form-control' style='width:100%' placeholder='Informe o complemento do endereço da escola corretamente...' value='".$row['complemento']."'>
                    <label for='bairroEscolaComprar".$_REQUEST['id']."'><span class='required'>*</span> Bairro da Escola:</label>
                    <input type='text' name='bairroEscolaComprar".$_REQUEST['id']."' id='bairroEscolaComprar".$_REQUEST['id']."' class='form-control' required style='width:100%' placeholder='Informe o bairro da escola corretamente...' value='".$row['bairro']."'>
                    <label for='cidadeEscolaComprar".$_REQUEST['id']."'><span class='required'>*</span> Cidade da Escola:</label>
                    <input type='text' name='cidadeEscolaComprar".$_REQUEST['id']."' id='cidadeEscolaComprar".$_REQUEST['id']."' class='form-control' required style='width:100%' placeholder='Informe a cidade da escola corretamente...' value='".$row['cidade']."'>
                    <label for='estadoEscolaComprar".$_REQUEST['id']."'><span class='required'>*</span> Estado da Escola:</label>
                    <select name='estadoEscolaComprar".$_REQUEST['id']."' id='estadoEscolaComprar".$_REQUEST['id']."' class='form-control' style='width:100%' required>
                        <option value=''>Selecione o estado abaixo...</option>";
                $sql = "SELECT * FROM states";
                $query2 = mysqli_query($con, $sql);
                if (mysqli_num_rows($query2)){
                    while ($row2 = mysqli_fetch_array($query2)){
                        $html .= "<option value='".$row2['sigla']."'";
                        if ($row2['sigla'] == $row['estado']){
                            $html .= " selected";
                        }
                        $html .= ">".$row2['sigla']."</option>";
                    }
                }
                $html .= "
                    </select>
                    <label for='tipoNotaEscolaComprar".$_REQUEST['id']."'><span class='required'>*</span> Tipo de Notas da Escola:</label>
                    <select name='tipoNotaEscolaComprar".$_REQUEST['id']."' id='tipoNotaEscolaComprar".$_REQUEST['id']."' class='form-control' style='width:100%' required onchange=selecionaTipoNotaEscola(this.value,'".URL_SITE."')>
                        <option value=''>Selecione o tipo de notas da escola corretamente...</option>";
                $sql = "SELECT * FROM tipo_notas WHERE deleted_at IS NULL";
                $query2 = mysqli_query($con, $sql);
                if (mysqli_num_rows($query2)){
                    while ($row2 = mysqli_fetch_array($query2)){
                        $html .= "<option value='".$row2['id']."'";
                        if ($row2['id'] == $row['tipoNota']){
                            $html .= " selected";
                        }
                        $html .= ">".$row2['nome']."</option>";
                    }
                }
                $html .= "
                    </select>
                    <div id='tipoNotasEscola'></div>
                    <label for='turnoEscolaComprar".$_REQUEST['id']."'><span class='required'>*</span> Turno da Escola:</label>
                    <select name='turnoEscolaComprar".$_REQUEST['id']."' id='turnoEscolaComprar".$_REQUEST['id']."' class='form-control' style='width:100%' required>
                        <option value=''>Selecione o turno em que a escola funciona corretamente...</option>";
                        $sql = "SELECT * FROM turnos WHERE deleted_at IS NULL";
                        $query2 = mysqli_query($con, $sql);
                        if (mysqli_num_rows($query2)){
                            while ($row2 = mysqli_fetch_array($query2)){
                                $html .= "<option value='".$row2['id']."'";
                                if ($row2['id'] == $row['turno']){
                                    $html .= " selected";
                                }
                                $html .= ">".$row2['name']."</option>";
                            }
                        }
                        $html .= "
                    </select>
                    <label for='letraEscolaComprar".$_REQUEST['id']."'><span class='required'>*</span> Até que letra vai as turmas da Escola:</label>
                    <select name='letraEscolaComprar".$_REQUEST['id']."' id='letraEscolaComprar".$_REQUEST['id']."' class='form-control' style='width:100%' required>
                        <option value=''>Selecione até que letra vai as turmas da escola corretamente...</option>";
                        $sql = "SELECT * FROM letras WHERE deleted_at IS NULL";
                        $query2 = mysqli_query($con, $sql);
                        if (mysqli_num_rows($query2)){
                            while ($row2 = mysqli_fetch_array($query2)){
                                $html .= "<option value='".$row2['sigla']."'";
                                if ($row2['sigla'] == $row['letra']){
                                    $html .= " selected";
                                }
                                $html .= ">".$row2['name']."</option>";
                            }
                        }
                        $html .= "
                    </select>
                    <input type='button' class='btn btn-primary' value='Gravar' onclick=gravaSistemaEscolar('".$row['id']."','".URL."')> <input type='button' class='btn btn-danger' value='Fechar' onclick=fecha('verInformacoesSistemaEscolar".$_REQUEST['id']."')> 
                    ";
                    echo "1|-|".$html;
                }
                else{
                    echo "0|-|Não foi encontrado o id pesquisado!";
                }
        break;
    case "verInformacoesSistemaDeCaixa":
        $sql = "SELECT * FROM cashier_system WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){            
            $row = mysqli_fetch_array($query);
            $html = "<div style='position:absolute; float:left; left:95%'><img src='".URL."assets/img/close-icon.svg' width='30' style='cursor:pointer' onclick=fecha('verInformacoesSistemaDeCaixa".$_REQUEST['id']."')></div>
                <h3>Editar Informações do Sistema De Caixa</h3>
                <label for='razaoSocialEstabelecimentoComprar".$_REQUEST['id']."'><span class='required' style='color:#990000'>*</span> Razão Social do Estabelecimento:</label>
                <input type='text' name='razaoSocialEstabelecimentoComprar".$_REQUEST['id']."' value='".$row['razao_social']."' id='razaoSocialEstabelecimentoComprar".$_REQUEST['id']."' placeholder='Informe a razão social do estabelecimento aqui..' class='form-control' style='width:100%' required>
                <label for='nomeFantasiaEstabelecimentoComprar".$_REQUEST['id']."'><span class='required'>*</span> Nome Fantasia do Estabelecimento:</label>
                <input type='text' name='nomeFantasiaEstabelecimentoComprar".$_REQUEST['id']."' value='".$row['nome_fantasia']."' id='nomeFantasiaEstabelecimentoComprar".$_REQUEST['id']."' placeholder='Informe o nome fantasia do estabelecimento aqui..' class='form-control' style='width:100%' required>
                <label for='cnpjEstabelecimentoComprar".$_REQUEST['id']."'><span class='required'>*</span> CNPJ do Estabelecimento:</label>
                <input type='text' name='cnpjEstabelecimentoComprar".$_REQUEST['id']."' value='".$row['cnpj']."' id='cnpjEstabelecimentoComprar".$_REQUEST['id']."' maxlength='18' placeholder='Informe o cnpj do estabelecimento (só números) aqui..' class='form-control' style='width:100%' onkeyup=mascara(this,'##.###.###/####-##',event); required>
                <label for='contatoEstabelecimentoComprar".$_REQUEST['id']."'><span class='required'>*</span> Nome do Contato do Estabelecimento:</label>
                <input type='text' name='contatoEstabelecimentoComprar".$_REQUEST['id']."' value='".$row['contato']."' id='contatoEstabelecimentoComprar".$_REQUEST['id']."' placeholder='Informe o nome do contato do estabelecimento aqui..' class='form-control' style='width:100%' required>
                <label for='emailEstabelecimentoComprar".$_REQUEST['id']."'><span class='required'>*</span> Email do Estabelecimento:</label>
                <input type='email' name='emailEstabelecimentoComprar".$_REQUEST['id']."' value='".$row['email']."' id='emailEstabelecimentoComprar".$_REQUEST['id']."' placeholder='Informe o email do estabelecimento aqui..' class='form-control' style='width:100%' required>
                <label for='cepEstabelecimentoComprar".$_REQUEST['id']."'><span class='required'>*</span> CEP do Estabelecimento:</label>
                <input type='text' name='cepEstabelecimentoComprar".$_REQUEST['id']."' value='".$row['cep']."' id='cepEstabelecimentoComprar".$_REQUEST['id']."' class='form-control' maxlength='9' placeholder='Informe o cep do estabelecimento corretamente...' style='width:100%' onkeyup=mascara(this,'#####-###',event);pesquisacepestabelecimentocomprar(this.value,'EstabelecimentoComprar".$_REQUEST['id']."') required>
                <label for='logradouroEstabelecimentoComprar".$_REQUEST['id']."'><span class='required'>*</span> Logradouro do Estabelecimento:</label>
                <input type='text' name='logradouroEstabelecimentoComprar".$_REQUEST['id']."' value='".$row['logradouro']."' id='logradouroEstabelecimentoComprar".$_REQUEST['id']."' class='form-control' required style='width:100%' placeholder='Informe o logradouro do estabelecimento corretamente...'>
                <label for='numeroEstabelecimentoComprar".$_REQUEST['id']."'><span class='required'>*</span> Número do Estabelecimento:</label>
                <input type='text' name='numeroEstabelecimentoComprar".$_REQUEST['id']."' value='".$row['numero']."' id='numeroEstabelecimentoComprar".$_REQUEST['id']."' class='form-control' required style='width:100%' placeholder='Informe o número do endereço do estabelecimento corretamente...'>
                <label for='complementoEstabelecimentoComprar".$_REQUEST['id']."'>Complemento do Estabelecimento:</label>
                <input type='text' name='complementoEstabelecimentoComprar".$_REQUEST['id']."' value='".$row['complemento']."' id='complementoEstabelecimentoComprar".$_REQUEST['id']."' class='form-control' style='width:100%' placeholder='Informe o complemento do endereço do estabelecimento corretamente...'>
                <label for='bairroEstabelecimentoComprar".$_REQUEST['id']."'><span class='required'>*</span> Bairro do Estabelecimento:</label>
                <input type='text' name='bairroEstabelecimentoComprar".$_REQUEST['id']."' value='".$row['bairro']."' id='bairroEstabelecimentoComprar".$_REQUEST['id']."' class='form-control' required style='width:100%' placeholder='Informe o bairro do estabelecimento corretamente...'>
                <label for='cidadeEstabelecimentoComprar".$_REQUEST['id']."'><span class='required'>*</span> Cidade do Estabelecimento:</label>
                <input type='text' name='cidadeEstabelecimentoComprar".$_REQUEST['id']."' value='".$row['cidade']."' id='cidadeEstabelecimentoComprar".$_REQUEST['id']."' class='form-control' required style='width:100%' placeholder='Informe a cidade do estabelecimento corretamente...'>
                <label for='estadoEstabelecimentoComprar".$_REQUEST['id']."'><span class='required'>*</span> Estado do Estabelecimento:</label>
                <select name='estadoEstabelecimentoComprar".$_REQUEST['id']."' id='estadoEstabelecimentoComprar".$_REQUEST['id']."' class='form-control' style='width:100%' required>
                    <option value=''>Selecione o estado abaixo...</option>";
            $sql = "SELECT * FROM states";
            $query2 = mysqli_query($con, $sql);
            if (mysqli_num_rows($query2)){
                while ($row2 = mysqli_fetch_array($query2)){
                    $html .= "<option value='".$row2['sigla']."'";
                    if ($row2['sigla'] == $row['estado']){
                        $html .= " selected";
                    }
                    $html .= ">".$row2['nome']."</option>";
                }
            }
            $html .= "
                </select>
                <label for='tipoEstabelecimentoComprar".$_REQUEST['id']."'><span class='required'>*</span> Tipo do Estabelecimento:</label>
                <select name='tipoEstabelecimentoComprar".$_REQUEST['id']."' id='tipoEstabelecimentoComprar".$_REQUEST['id']."' class='form-control' style='width:100%' onchange=selecionaTipoEstabelecimentoComprar(this.value,'".URL_SITE."','".$row['id']."') required>
                    <option value=''>Selecione o tipo do estabelecimento abaixo...</option>";
                    $sql = "SELECT * FROM tipo_estabelecimentos WHERE deleted_at IS NULL";
                    $query2 = mysqli_query($con, $sql);
                    if (mysqli_num_rows($query2)){
                        while ($row2 = mysqli_fetch_array($query2)){
                            $html .= "<option value='".$row2['id']."'";
                            if ($row2['id'] == $row['tipoEstabelecimento']){
                                $html .= " selected";
                            }
                            $html .= ">".$row2['name']."</option>";
                        }
                    }
                    $html .= "
                </select>
                <div id='tipoEstabelecimento".$row['id']."'>
                ";
                if ($row['tipoEstabelecimento'] == 1){
                    $html .= '<label for="quantidade'.$row['id'].'"><span class="required">*</span> Número de Mesas do Estabelecimento:</label>
                    <input type="number" name="quantidade'.$row['id'].'" id="quantidade'.$row['id'].'" value="'.$row['quantidade'].'" class="form-control" style="width:100%" min="1" required="" placeholder="Informe o número de mesas do estabelecimento corretamente...">
                    <label for="numeroPessoas'.$row['id'].'"><span class="required">*</span> Número de Pessoas por Mesa do Estabelecimento:</label>
                    <input type="number" name="numeroPessoas'.$row['id'].'" id="numeroPessoas'.$row['id'].'" value="'.$row['numeroPessoasPorMesa'].'" class="form-control" style="width:100%" min="1" required="" placeholder="Informe o número de pessoas por mesa do estabelecimento corretamente...">
                    <label for="percentualGarcom'.$row['id'].'"><span class="required">*</span> Percentual do Garçom do Estabelecimento:</label>
                    <input type="number" name="percentualGarcom'.$row['id'].'" id="percentualGarcom'.$row['id'].'" value="'.$row['percentual'].'" class="form-control" style="width:100%" min="1" required="" placeholder="Informe o percentual do garçom do estabelecimento corretamente...">';
                }
                elseif ($row['tipoEstabelecimento'] == 2){
                    $html .= '<label for="quantidade'.$row['id'].'"><span class="required">*</span> Número de Caixas do Estabelecimento:</label>
                    <input type="number" name="quantidade'.$row['id'].'" id="quantidade'.$row['id'].'" value="'.$row['quantidade'].'" class="form-control" style="width:100%" min="1" required="" placeholder="Informe o número de mesas do estabelecimento corretamente...">';
                }
                $html .= "</div>
                <input type='button' class='btn btn-primary' value='Gravar' onclick=gravaSistemaDeCaixa('".$row['id']."','".URL."')> <input type='button' class='btn btn-danger' value='Fechar' onclick=fecha('verInformacoesSistemaDeCaixa".$_REQUEST['id']."')> 
                ";
                    echo "1|-|".$html;
                }
                else{
                    echo "0|-|Não foi encontrado o id pesquisado!";
                }
        break;
    case "pegaNumCarrinho":
        $sql = "SELECT * FROM cart WHERE session_id = '".session_id()."'";
        $query = mysqli_query($con, $sql);
        $tot = mysqli_num_rows($query);
        echo "1|-|".$tot;
        break;
    case "selecionaItemsDominio":
        $html = "<label for='periodicidadeCobrancaDominioComprar'><span class='required'>*</span> Periodicidade da Cobrança do Domínio:</label>
                    <select name='periodicidadeCobrancaDominioComprar' id='periodicidadeCobrancaDominioComprar' class='form-control' required>
                    <option value=''>Selecione a periodicidade de cobrança do domínio corretamente...</option>";
        $sql = "SELECT * FROM products_items WHERE product = '8' AND status = '1'";
        $query2 = mysqli_query($con, $sql);
        if (mysqli_num_rows($query2)){
            while ($row2 = mysqli_fetch_array($query2)){
                $html .= "
                        <option value='".$row2['id']."'>".$row2['name']." - ";
                if ($row2['promotion'] && $row2['validity_promotion'] >= date('Y-m-d')){
                    $html .= "R$ ".number_format($row2['promotion'], 2, ',', '.');
                }
                else{
                    $html .= "R$ ".number_format($row2['value'], '2',',','.');
                }
                $html .= "</option>";
            }
        }
        $html .= "
                    </select>";
        echo "1|-|".$html;
        break;
    case "selecionaItemsHospedagem":
        $html = "<label for='itemVendaHospedagemComprar'><span class='required'>*</span> Item de Venda da Hospedagem do Domínio:</label>
                    <select name='itemVendaHospedagemComprar' id='itemVendaHospedagemComprar' class='form-control' required>
                    <option value=''>Selecione o Item de Venda do Hospedagem do Domínio corretamente...</option>";
        $sql = "SELECT * FROM products_items WHERE product = '7' AND status = '1'";
        $query2 = mysqli_query($con, $sql);
        if (mysqli_num_rows($query2)){
            while ($row2 = mysqli_fetch_array($query2)){
                $html .= "
                        <option value='".$row2['id']."'>".$row2['name']." - ";
                if ($row2['promotion'] && $row2['validity_promotion'] >= date('Y-m-d')){
                    $html .= "R$ ".number_format($row2['promotion'], 2, ',', '.');
                }
                else{
                    $html .= "R$ ".number_format($row2['value'], '2',',','.');
                }
                $html .= "</option>";
            }
        }
        $html .= "
                    </select>";
        echo "1|-|".$html;
        break;
    case "selecionaItemsModelo":
        $html = "<label for='modeloComprar'><span class='required'>*</span> Modelo de Site:</label>
                    <select name='modeloComprar' id='modeloComprar' class='form-control' required>
                    <option value=''>Selecione o o modelo de corretamente...</option>";
        $sql = "SELECT * FROM products_items WHERE product = '9' AND status = '1'";
        $query2 = mysqli_query($con, $sql);
        if (mysqli_num_rows($query2)){
            while ($row2 = mysqli_fetch_array($query2)){
                $html .= "
                        <option value='".$row2['id']."'>".($row2['name'])." - ";
                if ($row2['promotion'] && $row2['validity_promotion'] >= date('Y-m-d')){
                    $html .= "R$ ".number_format($row2['promotion'], 2, ',', '.');
                }
                else{
                    $html .= "R$ ".number_format($row2['value'], '2',',','.');
                }
                $html .= "</option>";
            }
        }
        $html .= "
                    </select>";
        echo "1|-|".$html;
        break;
    case "selecionaTipoServico":
        $html = "<select name='tipoVersaoBugTracking' id='tipoVersaoBugTracking' class='form-control' style='padding:20px' required>
                    <option value=''>Selecione a versão corretamente...</option>";
        $sql = "SELECT * FROM type_versions WHERE typeService = '".$_REQUEST['id']."' AND status = '1'";
        $query2 = mysqli_query($con, $sql);
        if (mysqli_num_rows($query2)){
            while ($row2 = mysqli_fetch_array($query2)){
                $html .= "
                        <option value='".$row2['id']."'>".($row2['name']);
                $html .= "</option>";
            }
        }
        $html .= "
                    </select>|-|";
        $html .= "<select name='prioridadeBugTracking' id='prioridadeBugTracking' class='form-control' style='padding:20px' required>
                    <option value=''>Selecione a prioridade corretamente...</option>";
        $sql = "SELECT * FROM priorities WHERE status = '1'";
        $query2 = mysqli_query($con, $sql);
        if (mysqli_num_rows($query2)){
            while ($row2 = mysqli_fetch_array($query2)){
                $html .= "
                        <option value='".$row2['id']."'>".($row2['name']);
                $html .= "</option>";
            }
        }
        $html .= "
                    </select>|-|";
        $html .= "<select name='categoriaBugTracking' id='categoriaBugTracking' class='form-control' style='padding:20px' required>
                    <option value=''>Selecione a categoria corretamente...</option>";
    $sql = "SELECT * FROM categories WHERE typeService = '".$_REQUEST['id']."' AND status = '1'";
        $query2 = mysqli_query($con, $sql);
        if (mysqli_num_rows($query2)){
            while ($row2 = mysqli_fetch_array($query2)){
                $html .= "
                        <option value='".$row2['id']."'>".($row2['name']);
                $html .= "</option>";
            }
        }
        $html .= "
                    </select>";
        echo "1|-|".$html;
        break;
    case "editaItensVenda":
        $sql = "SELECT * FROM products_items WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        echo ("1|-|".$row['id']."|-|".$row['product_type']."|-|".$row['code']."|-|".$row['name']."|-|".number_format($row['value'], 2, ',', '.')."|-|".number_format($row['promotion'], 2, ',', '.')."|-|".$row['validity_promotion']."|-|".$row['status']);
        break;
    case "listarItensVenda":
        $sql = "SELECT * FROM products_items WHERE product = '".$_REQUEST['id']."'";
        echo $sql;
        $query = mysqli_query($con, $sql);
        echo "1|-|";
        if (mysqli_num_rows($query)){
            while ($row = mysqli_fetch_array($query)){
                ?><div style="width:100%; padding:10px"id="itemVenda<?php echo $row['id']?>" onmouseover="this.style.backgroundColor='#F7F7F7'" onmouseout="this.style.backgroundColor='#FFFFFF'"><?php echo ($row['name'])?> <img src="<?php echo URL?>img/editar.png" width="20" style="cursor:pointer" onclick="editaItemVenda('<?php echo $row['id']?>', '<?=URL?>', '<?=$_REQUEST['id']?>')"> <img src="<?php echo URL?>img/excluir.png" width="20" style="cursor:pointer" onclick="excluirItemVenda('<?=$row['id']?>', '<?=URL?>', '<?=$roe['product']?>')"></div><?php
            }
        }
        break;
    case "excluirItemVenda":
        $sql = "DELETE FROM products_items WHERE id = '".$_REQUEST['id']."'";
        mysqli_query($con, $sql);
        echo "1|-|";
        break;
    case "cadastrarItemVenda":
        $_REQUEST['value'] = str_replace('.', '', $_REQUEST['value']);
        $_REQUEST['value'] = str_replace(',', '.', $_REQUEST['value']);
        $_REQUEST['promotion'] = str_replace('.', '', $_REQUEST['promotion']);
        $_REQUEST['promotion'] = str_replace(',', '.', $_REQUEST['promotion']);
        $sql = ("INSERT INTO products_items (product, product_type, code, name, value, promotion, validity_promotion, status, created_at, updated_at) VALUES ('".$_REQUEST['product']."', '".$_REQUEST['product_type']."', '".$_REQUEST['code']."', '".$_REQUEST['name']."', '".$_REQUEST['value']."', '".$_REQUEST['promotion']."', '".$_REQUEST['validity_promotion']."', '".$_REQUEST['status']."', now(), now())");
        mysqli_query($con, $sql);
        echo "1|-|";
        break;
    case "editarItemVenda":
        $_REQUEST['value'] = str_replace('.', '', $_REQUEST['value']);
        $_REQUEST['value'] = str_replace(',', '.', $_REQUEST['value']);
        $_REQUEST['promotion'] = str_replace('.', '', $_REQUEST['promotion']);
        $_REQUEST['promotion'] = str_replace(',', '.', $_REQUEST['promotion']);
        $sql = ("UPDATE products_items SET product_type = '".$_REQUEST['product_type']."', code = '".$_REQUEST['code']."', name = '".$_REQUEST['name']."', value = '".$_REQUEST['value']."', promotion = '".$_REQUEST['promotion']."', validity_promotion = '".$_REQUEST['validity_promotion']."', status = '".$_REQUEST['status']."', updated_at = now() WHERE id = '".$_REQUEST['id']."'");
        echo $sql;
        mysqli_query($con, $sql);
        echo "1|-|";
        break;
    case "excluirItensVenda":
        $sql = "UPDATE products_items SET deleted_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['id']."'";
        mysqli_query($con, $sql);
        echo "1|-|";
        break;
    case "mostra_comprovante":
        echo "1|-|";
        $_REQUEST['id'] = $_REQUEST['request_id'];
        require_once('enviaComprovante.php');
        break;
    case "comprar":
        $sql = "SELECT * FROM cart WHERE session_id = '".session_id()."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)) {
            while ($row = mysqli_fetch_array($query)) {
                $subtotal += $row['value'] * $row['quantity'];
            }
        }
        $subtotal = str_replace(',', '.', $subtotal);
        if ($_REQUEST['idFormaPagamentoComprar'] == 1 && $parametrosSite['descontoAVista']){
            $descontoAVista = $subtotal * $parametrosSite['descontoAVista'];
        }
        $descontoAVista = str_replace(',', '.', $descontoAVista);
        $total = $subtotal - $descontoAVista;
        $total = str_replace(',', '.', $total);
        $sql = "INSERT INTO requests (client, paymentMethod, address, subtotal, descontoAVista, total, status, created_at, updated_at) VALUES ('".$_SESSION['cliente']['id']."', '".$_REQUEST['idFormaPagamentoComprar']."', '".$_REQUEST['enderecoCompra']."', '".$subtotal."', '".$descontoAVista."', '".$total."', '3', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        $query = mysqli_query($con, $sql) or die(mysqli_error($con));
        $idPedido = mysqli_insert_id($con);
        $sql = "SELECT * FROM cart WHERE session_id = '".session_id()."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            while ($row = mysqli_fetch_array($query)){
                $row['school_system'] = ($row['school_system']) ? $row['school_system'] : "0";
                $row['cashier_system'] = ($row['cashier_system']) ? $row['cashier_system'] : "0";
                $sql = "INSERT INTO requests_items (request, product, product_item, school_system, cashier_system, name, domine, quantity, value, created_at, updated_at) VALUES ('".$idPedido."', '".$row['product']."', '".$row['product_item']."', '".$row['school_system']."', '".$row['cashier_system']."', '".$row['name']."', '".$row['domine']."', '".$row['quantity']."', '".$row['value']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
                $query2 = mysqli_query($con, $sql);
            }
        }
        $sql = "SELECT * FROM addresses WHERE id = '".$_REQUEST['enderecoCompra']."'";
        $query = mysqli_query($con, $sql) or die(mysqli_error($con));
        $row = mysqli_fetch_array($query);
        $sql = "INSERT INTO requests_addresses (idRequest, cep, address, number, complement, neighborhood, city, state, referencia, created_at, updated_at) VALUES ('" . $idPedido . "', '".$row['cep']."', '".$row['address']."', '".$row['number']."', '".$row['complement']."', '".$row['neighborhood']."', '".$row['city']."', '".$row['state']."', '".$row['referencia']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        mysqli_query($con, $sql) or die(mysqli_error($con));
        $sql = "DELETE FROM cart WHERE session_id = '".session_id()."'";
        $query = mysqli_query($con, $sql);
        echo '1|-|<img src="'.URL.'admin/img//loader.gif" width="20"> Aguarde... Carregando Comprovante...|-|'.$idPedido;
        break;
    case "enderecosCompra":
        $sql = "SELECT * FROM payment_methods WHERE id = '".$_REQUEST['id']."' ";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        echo "1|-|<div style='position:absolute; float:left; left:95%'><img src='".URL."assets/img/close-icon.svg' width='25' onclick=$('#finalizacaoDeCompra').hide('fast') style='cursor:pointer' title='Fechar'></div>Forma de Pagamento escolhida: <b>".($row['name'])."</b><input type='hidden' name='formaPagamentoCompra' id='formaPagamentoCompra' value='".$row['id']."'><br>                  <label for='enderecoCompra'>Endereço:</label> ";
        $sql = "SELECT * FROM addresses WHERE idClient = '".$_SESSION['cliente']['id']."' ";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            echo "<select name='enderecoCompra' id='enderecoCompra' class='form-control' required onchange='selecionaEnderecoCompra(this.value)'>
            <option value=''>Seleione o endereço corretamente...</option>
            <option value='novo'>Cadastrar Novo</option>";
            while ($row = mysqli_fetch_array($query)){
                echo "<option value='".$row['id']."'>".($row['address'].", ".$row['number']);
                if ($row['complement']){
                    echo (", ".$row['complement']);
                }
                echo (" - B. ".$row['neighborhood']." - ".$row['city']." - ".$row['state']." - CEP: ".$row['cep']);
                if ($row['referencia']){
                    echo (" - ".$row['referencia']);
                }
                echo ("</option>");
            }
            echo '</select>
            <br>
            <button type="button" class="btn btn-danger" onClick="fecha(\'finalizacaoDeCompra\')">Fechar</button>
            <button type="button" class="btn btn-primary" onclick="realizarCompra(\''.URL.'\')">Realizar Compra</button>';
            mysqli_num_rows($query);
        }
        else{
            echo "Sem endereço encontrado para o cliente! <a onclick=abreFecha('cadastroEndereco') style='cursor:pointer'>Cadastre um novo agora!</a>";
        }
        echo '<div id="cadastroEndereco" style="display:none">
                    <form name="cadastrarEndereco" id="cadastrarEndereco">
                    <h3>Cadastro de Endereço</h3>
                    <input type="hidden" value="'.URL_SITE.'" name="urlCadastrarEnderecoCompra" id="urlCadastrarEnderecoCompra">
                    <label for=\'cepCadastroCompra\'>CEP:</label>
                    <input class="form-control" value="" placeholder="Informe o cep do endereço corretamente..." id="cepCadastroCompra" required name="cepCadastroCompra" maxlength="9" onkeyup=mascara(this,"#####-###",event);verificaCepCadastroCompra(this.value)>
                    <label for=\'logradouroCadastroCompra\'>Logradouro:</label>
                    <input class="form-control" value="" placeholder="Informe o logradouro do endereço corretamente..." id="logradouroCadastroCompra" required name="logradouroCadastroCompra">
                    <label for=\'numeroCadastroCompra\'>Número:</label>
                    <input class="form-control" value="" placeholder="Informe o número do endereço corretamente..." id="numeroCadastroCompra" required name="numeroCadastroCompra">
                    <label for=\'complementoCadastroCompra\'>Complemento:</label>
                    <input class="form-control" value="" placeholder="Informe o complemento do endereço corretamente..." id="complementoCadastroCompra" name="complementoCadastroCompra">
                    <label for=\'bairroCadastroCompra\'>Bairro:</label>
                    <input class="form-control" value="" placeholder="Informe o bairro do endereço corretamente..." id="bairroCadastroCompra" required name="bairroCadastroCompra">
                    <label for=\'cidadeCadastroCompra\'>Cidade:</label>
                    <input class="form-control" value="" placeholder="Informe a cidade do endereço corretamente..." id="cidadeCadastroCompra" required name="cidadeCadastroCompra">
                    <label for=\'estadoCadastroCompra\'>Estado:</label>
                    <select class="form-control" id="estadoCadastroCompra" required name="estadoCadastroCompra">
                        <option value="">Selecione o estado do endereço abaixo corretamente...</option>
                        ';
                    $sql = "SELECT * FROM states";
                    $query = mysqli_query($con, $sql);
                    while ($row = mysqli_fetch_array($query)){
                        echo '<option value="'.$row['sigla'].'">'.$row['sigla'].'</option>';
                    }
                    echo '
                    </select>
                    <label for=\'referenciaCadastroCompra\'>Ponto de Referência:</label>
                    <input class="form-control" value=""" placeholder="Informe um ponto de referência do endereço se quiser..." id="referenciaCadastroCompra" name="referenciaCadastroCompra">
                    <br>
            <button type="button" class="btn btn-secondary" onClick="fecha(\'cadastroEndereco\')">Fechar</button>
            <button type="submit" class="btn btn-primary">Cadastrar</button>
            </div>';
        break;
    case "cadastrarEnderecoCompra":
        $sql = ("INSERT INTO addresses (idClient, cep, address, number, complement, neighborhood, city, state, referencia, created_at, updated_at) VALUES ('".$_SESSION['cliente']['id']."', '".$_REQUEST['cepCadastroCompra']."', '".$_REQUEST['logradouroCadastroCompra']."', '".$_REQUEST['numeroCadastroCompra']."', '".$_REQUEST['complementoCadastroCompra']."', '".$_REQUEST['bairroCadastroCompra']."', '".$_REQUEST['cidadeCadastroCompra']."', '".$_REQUEST['estadoCadastroCompra']."', '".$_REQUEST['referenciaCadastroCompra']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
        mysqli_query($con, $sql) or die(mysqli_error($con));
        echo "1|-|".$_REQUEST['idFormaPagamentoComprar'];
        break;
    case "cadEndereco":
        $sql = ("INSERT INTO addresses (idClient, cep, address, number, complement, neighborhood, city, state, referencia, created_at, updated_at) VALUES ('".$_SESSION['cliente']['id']."', '".$_REQUEST['cepAdicionarEndereco']."', '".$_REQUEST['logradouroAdicionarEndereco']."', '".$_REQUEST['numeroAdicionarEndereco']."', '".$_REQUEST['complementoAdicionarEndereco']."', '".$_REQUEST['bairroAdicionarEndereco']."', '".$_REQUEST['cidadeAdicionarEndereco']."', '".$_REQUEST['estadoAdicionarEndereco']."', '".$_REQUEST['referenciaAdicionarEndereco']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
        mysqli_query($con, $sql) or die(mysqli_error($con));
        echo "1|-|".$_REQUEST['idFormaPagamentoComprar'];
        break;
    case "editEndereco":
        $sql = "SELECT * FROM addresses WHERE id = '".$_REQUEST['idEditEndereco']."' AND idClient = '".$_SESSION['cliente']['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)) {
            $sql = ("UPDATE addresses SET cep = '" . $_REQUEST['cepEditEndereco'] . "', address = '" . $_REQUEST['logradouroEditEndereco'] . "', number = '" . $_REQUEST['numeroEditEndereco'] . "', complement = '" . $_REQUEST['complementoEditEndereco'] . "', neighborhood = '" . $_REQUEST['bairroEditEndereco'] . "', city = '" . $_REQUEST['cidadeEditEndereco'] . "', state = '" . $_REQUEST['estadoEditEndereco'] . "', referencia = '".$_REQUEST['referenciaEditEndereco']."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEditEndereco']."'");            mysqli_query($con, $sql) or die(mysqli_error($con));
            echo "1|-|" . $_REQUEST['idFormaPagamentoComprar'];
        }
        else{
            echo "0|-|Esse endereço não é seu, portanto você não pode alterá-lo!";
        }
        break;
    case "finalizarPedido":
        echo '1|-|<div style="position:absolute; float:left; left:95%"><img src="'.URL.'assets/img/close-icon.svg" width="25" onclick=$("#finalizacaoDeCompra").hide("fast") style="cursor:pointer" title="Fechar"></div>Escolha a forma de pagamento abaixo:<br><br>
            ';
            $sql = "SELECT * FROM payment_methods ORDER BY name DESC";
            $query = mysqli_query($con, $sql);
            if (mysqli_num_rows($query)){
                while ($row = mysqli_fetch_array($query)){
                    echo '<div style="width: 50%; float:left; text-align: center; cursor:pointer" onclick="selecionaFormaPagamento(\''.$row['id'].'\', \''.URL.'\', this)" id="formaPagamento'.$row['id'].'">
                    <img src="'.URL.'admin/img//upload/'.$row['img'].'" width="200">
                    '.($row['name']).'
                    </div>';
                }
            }
        echo '<br><br><br><br><div id="aVistaOuParcelado"></div>';
        break;
    case "abreAVistaOuParcelado":
        $sql = "SELECT * FROM cart WHERE session_id = '".session_id()."'";
        $query = mysqli_query($con, $sql);
        while ($row = mysqli_fetch_array($query)){
            $subtotal += $row['value'] * $row['quantity'];
        }
        $html = '<div style="float:left; width:60%; text-align:right">Subtotal: </div><div style="float:left; width:35%; text-align:left; font-weight:bold">R$'.number_format($subtotal, 2, ',', '.').'</div>';
        if ($parametrosSite['descontoAVista'] && $_REQUEST['id'] == 1){
            $descontoAVista = $subtotal * $parametrosSite['descontoAVista'];
            $html .= '<div style="float:left; width:60%; text-align:right">Desconto à vista: </div><div style="float:left; width:35%; text-align:left; font-weight:bold">R$'.number_format($descontoAVista, 2, ',', '.').'</div>';
        }
        $html .= '<div style="float:left; width:60%; text-align:right">Total: </div><div style="float:left; width:35%; text-align:left; font-weight:bold">R$'.number_format($subtotal - $descontoAVista, 2, ',', '.').'</div><br><br>
            <br>
            <button type="button" class="btn btn-secondary" onClick="fecha(\'finalizarPedido\')">Fechar</button>
            <button type="button" class="btn btn-primary" onclick="selecionarEndereco(\''.$_REQUEST['id'].'\', \''.URL.'\')">Selecionar Endereço</button><br>';
        echo '1|-|'.$html;
        break;
    case "limparCarrinho":
        $sql = "DELETE FROM cart WHERE session_id = '".session_id()."'";
        mysqli_query($con, $sql);
        $sql = "SELECT * FROM cart WHERE session_id = '".session_id()."'";
        $query = mysqli_query($con, $sql);
        $tot = mysqli_num_rows($query);
        echo "1|-|".$tot;
        break;
    case "excluirCarrinho":
        $sql = "DELETE FROM cart WHERE id = '".$_REQUEST['id']."'";
        mysqli_query($con, $sql);
        $sql = "SELECT * FROM cart WHERE session_id = '".session_id()."'";
        $query = mysqli_query($con, $sql);
        $tot = mysqli_num_rows($query);
        echo "1|-|".$tot;
        break;
    case "mostraCarrinhoDeCompras":
        echo '1|-|';
        $sql = "SELECT a.* FROM cart a WHERE a.session_id = '".session_id()."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            echo '<table width="100%" border="0" cellpadding="0" cellspacing="0">
                      <tr>
                           <th>Nome do Produto</th>
                           <th>Valor do Produto</th>
                           <th>Quantidade</th>
                           <th>Valor Total</th>
                           <th>Excluir</th>
                      </tr>';
            $i = 0;
            while ($row = mysqli_fetch_array($query)){
                $backgroundColor = ($i % 2 == 1) ? "#E7E7E7" : "";
                echo ('<tr style="background-color:'.$backgroundColor.'">
                    <td style="text-align: left">'.$row['name']);
                if($row['domine']) {
                    echo (' - <a href="' . $row['domine'] . '" target="_blank">' . $row['domine'] . '</a>');
                }
                if ($row['school_system']){
                    $sql = "SELECT * FROM school_system WHERE id = '".$row['school_system']."'";
                    $query2 = mysqli_query($con, $sql);
                    $rowSistemaEscolar = mysqli_fetch_array($query2);
                    if ($rowSistemaEscolar['tipoNota'] == 1){
                        $rowSistemaEscolar['tipoNota'] = "Bimestral";
                    }
                    elseif ($rowSistemaEscolar['tipoNota'] == 2){
                        $rowSistemaEscolar['tipoNota'] = "Trimestral";
                    }
                    elseif ($rowSistemaEscolar['tipoNota'] == 3){
                        $rowSistemaEscolar['tipoNota'] = "Semestral";
                    }
                    elseif ($rowSistemaEscolar['tipoNota'] == 4){
                        $rowSistemaEscolar['tipoNota'] = "Anual";
                    }
                    if ($rowSistemaEscolar['turno'] == 1){
                        $rowSistemaEscolar['turno'] = "Manhã";
                    }
                    elseif ($rowSistemaEscolar['turno'] == 2){
                        $rowSistemaEscolar['turno'] = "Tarde";
                    }
                    elseif ($rowSistemaEscolar['turno'] == 3){
                        $rowSistemaEscolar['turno'] = "Noite";
                    }
                    elseif ($rowSistemaEscolar['turno'] == 4){
                        $rowSistemaEscolar['turno'] = "Único";
                    }
                    elseif ($rowSistemaEscolar['turno'] == 5){
                        $rowSistemaEscolar['turno'] = "Todos";
                    }
                    if ($rowSistemaEscolar['letra'] == "Un"){
                        $rowSistemaEscolar['letra'] = "Única";
                    }
                    echo ' - <a onclick="verInformacoesSistemaEscolar(\''.$row['school_system'].'\', \''.URL_SITE.'\')" style="color: #0077A4; cursor: pointer" title="Ver informações do sistema">Ver Informações do Sistema</a>
                            <div id="verInformacoesSistemaEscolar'.$row['school_system'].'" style="display: none; position:absolute; width:92%; background-color:#FFFFFF">
                                <button type"button" class="close" onClick=fecha("informacoesSistemaEscolar'.$row['school_system'].'")><span aria-hidden="true">&times;</span></button>
                                <h3>Informações do Sistema Escolar</h3>
                                <b>Nome da Escola:</b> '.$rowSistemaEscolar['nome'].'<br>
                                <b>Email da Escola:</b> '.$rowSistemaEscolar['email'].'<br>
                                <b>CEP da Escola:</b> '.$rowSistemaEscolar['cep'].'<br>
                                <b>Logradouro da Escola:</b> '.$rowSistemaEscolar['logradouro'].'<br>
                                <b>Número da Escola:</b> '.$rowSistemaEscolar['numero'].'<br>';
                    if ($rowSistemaEscolar['complemento']){
                        echo '<b>Complemento:</b> '.$rowSistemaEscolar['complemento'].'<br>';
                    }
                    echo '<b>Bairro da Escola:</b> '.$rowSistemaEscolar['bairro'].'<br>
                                <b>Cidade da Escola:</b> '.$rowSistemaEscolar['cidade'].'<br>
                                <b>Estado da Escola:</b> '.$rowSistemaEscolar['estado'].'<br>
                                <b>Tipo de Nota da Escola:</b> '.$rowSistemaEscolar['tipoNota'].'<br>
                                <b>Turno da Escola:</b> '.$rowSistemaEscolar['turno'].'<br>
                                <b>Letra da Escola:</b> '.$rowSistemaEscolar['letra'].'
                            </div>';
                }
                if ($row['cashier_system']) {
                    $sql = "SELECT * FROM cashier_system WHERE id = '" . $row['cashier_system'] . "'";
                    $query2 = mysqli_query($con, $sql);
                    $rowSistemaCaixa = mysqli_fetch_array($query2);
                    echo ' - <a onclick=verInformacoesSistemaCaixa(' . $row['cashier_system'] . ',"'.URL_SITE.'") style="color: #0077A4; cursor: pointer" title="Ver informações do sistema">Ver Informações do Sistema</a>
                    <div id="verInformacoesSistemaCaixa' . $row['cashier_system'] . '" style="display: none; position:absolute; width:92%; background-color:#FFFFFF">
                                <button type"button" class="close" onClick=fecha("informacoesSistemaCaixa' . $row['cashier_system'] . '")><span aria-hidden="true">&times;</span></button>
                                <h3>Informações do Sistema de Caixa</h3>
                                <b>Razão Social:</b> ' . $rowSistemaCaixa['razao_social'] . '<br>
                                <b>Nome Fantasia:</b> ' . $rowSistemaCaixa['nome_fantasia'] . '<br>
                                <b>Email:</b> ' . $rowSistemaCaixa['email'] . '<br>
                                <b>CNPJ:</b> ' . $rowSistemaCaixa['cnpj'] . '<br>
                                <b>CEP:</b> ' . $rowSistemaCaixa['cep'] . '<br>
                                <b>Logradouro:</b> ' . $rowSistemaCaixa['logradouro'] . '<br>
                                <b>Número:</b> ' . $rowSistemaCaixa['numero'] . '<br>';
                    if ($rowSistemaCaixa['complemento']) {
                        echo '<b>Complemento:</b> ' . $rowSistemaCaixa['complemento'] . '<br>';
                    }
                    echo '<b>Bairro:</b> ' . $rowSistemaCaixa['bairro'] . '<br>
                                <b>Cidade:</b> ' . $rowSistemaCaixa['cidade'] . '<br>
                                <b>Estado:</b> ' . $rowSistemaCaixa['estado'] . '<br>
                                <b>Tipo de Estabelecimento:</b> ';
                    if ($rowSistemaCaixa['tipoEstabelecimento'] == 1) {
                        echo 'Mesa';
                    } else {
                        echo 'Caixa';
                    }
                    echo '<br>
                                <b>Quantidade de ';
                    if ($rowSistemaCaixa['tipoEstabelecimento'] == 1) {
                        echo 'Mesas';
                    } else {
                        echo 'Caixas';
                    }
                    echo ':</b> ' . $rowSistemaCaixa['quantidade'];
                    if ($rowSistemaCaixa['tipoEstabelecimento'] == 1) {
                        echo '<br>
                                <b>Número Pessoas Por Mesa:</b> ' . $rowSistemaCaixa['numeroPessoasPorMesa'] . '<br>
                                <b>Gorjeta do Garçom:</b> ' . $rowSistemaCaixa['percentual'] . '%
                            </div>';
                    }
                }
                    echo ('</td>
                    <td style="text-align: center">R$'.number_format($row['value'], 2, ',', '.').'</td>
                    <td style="text-align: center">'.$row['quantity'].'</td>
                    <td style="text-align: center">R$'.number_format($row['value'] * $row['quantity'], 2, ',', '.').'</td>
                    <td style="text-align: center"><img src="'.URL.'admin/img//excluir.png" width="20" style="cursor:pointer;" onclick=excluirCarrinho("'.$row['id'].'","'.URL.'")></td>
                </tr>');
                $i++;
            }
            echo '</table>
<input type="button" onclick="fecha(\'carrinho\')" class="btn btn-primary btn-md" value="Fechar e Continuar Comprando"> <input type="button" onclick="limparCarrinho(\''.URL_SITE.'\')" class="btn btn-primary btn-md" value="Limpar Carrinho"> <input type="button" onclick="finalizarPedido(\''.URL_SITE.'\')" class="btn btn-primary btn-outline" value="Finalizar Pedido">';
        }
        else {
            echo '<button class="btn btn-danger" onclick=fecha("carrinho")>Sem nenhum produto no carrinho no momento!</button>';
        }
        echo  '<input type="hidden" id="numProdutosCarrinho" name="numProdutosCarrinho" value="0">|-|'.mysqli_num_rows($query);
        break;
        case "salvarCarrinho":
            $_REQUEST['dominioComprar'] = str_replace('|', '/', $_REQUEST['dominioComprar']);
            $sql = 'SELECT * FROM products_items WHERE id = "'.$_REQUEST['item'].'"';
            $query = mysqli_query($con, $sql);
            $row = mysqli_fetch_array($query);
            $valor = ($row['promotion'] && $row['validity_promotion'] >= date('Y-m-d')) ? $row['promotion'] : $row['value'];
            $sql = "INSERT INTO cart (product, product_item, session_id, domine, name, quantity, value, created_at, updated_at) VALUES ('".$_REQUEST['product']."', '".$_REQUEST['item']."', '".session_id()."', '".$_REQUEST['dominioComprar']."', '".$row['name']."', '1', '".$valor."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
            mysqli_query($con, $sql);
            $idCarrinho = mysqli_insert_id($con);
            if ($_REQUEST['compraHospedagemComprar']){
                $sql = 'SELECT * FROM products_items WHERE id = "'.$_REQUEST['itemVendaHospedagemComprar'].'"';
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $valor = ($row['promotion'] && $row['validity_promotion'] >= date('Y-m-d')) ? $row['promotion'] : $row['value'];
                $sql = "INSERT INTO cart (product, product_item, session_id, domine, name, quantity, value, created_at, updated_at) VALUES ('".$row['product']."', '".$_REQUEST['itemVendaHospedagemComprar']."', '".session_id()."', '".$_REQUEST['dominioComprar']."', '".$row['name']."', '1', '".$valor."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
                mysqli_query($con, $sql);
            }
            if ($_REQUEST['compraDominioComprar']){
                $sql = 'SELECT * FROM products_items WHERE id = "'.$_REQUEST['periodicidadeCobrancaDominioComprar'].'"';
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $valor = ($row['promotion'] && $row['validity_promotion'] >= date('Y-m-d')) ? $row['promotion'] : $row['value'];
                $sql = "INSERT INTO cart (product, product_item, session_id, domine, name, quantity, value, created_at, updated_at) VALUES ('".$row['product']."', '".$_REQUEST['periodicidadeCobrancaDominioComprar']."', '".session_id()."', '".$_REQUEST['dominioComprar']."', '".$row['name']."', '1', '".$valor."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
                mysqli_query($con, $sql);
            }
            if ($_REQUEST['compraModeloComprar']){
                $sql = 'SELECT * FROM products_items WHERE id = "'.$_REQUEST['modeloComprar'].'"';
                $query = mysqli_query($con, $sql);
                $row = mysqli_fetch_array($query);
                $valor = ($row['promotion'] && $row['validity_promotion'] >= date('Y-m-d')) ? $row['promotion'] : $row['value'];

                $sql = "INSERT INTO cart (product, product_item, session_id, domine, name, quantity, value, created_at, updated_at) VALUES ('".$row['product']."', '".$_REQUEST['modeloComprar']."', '".session_id()."', '".$_REQUEST['dominioComprar']."', '".$row['name']."', '1', '".$valor."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
                mysqli_query($con, $sql);
            }
            if ($_REQUEST['product'] == 5) {
                $sql = "INSERT INTO cashier_system (razao_social, nome_fantasia, cnpj, contato, email, cep, logradouro, numero, complemento, bairro, cidade, estado, tipoEstabelecimento, quantidade, numeroPessoasPorMesa, percentual, created_at, updated_at) VALUES ('" . $_REQUEST['razaoSocialEstabelecimentoComprar'] . "', '" . $_REQUEST['nomeFantasiaEstabelecimentoComprar'] . "', '" . $_REQUEST['cnpjEstabelecimentoComprar'] . "', '".$_REQUEST['contatoEstabelecimentoComprar']."', '".$_REQUEST['emailEstabelecimentoComprar']."', '" . $_REQUEST['cepEstabelecimentoComprar'] . "', '" . $_REQUEST['logradouroEstabelecimentoComprar'] . "', '" . $_REQUEST['numeroEstabelecimentoComprar'] . "', '" . $_REQUEST['complementoEstabelecimentoComprar'] . "', '" . $_REQUEST['bairroEstabelecimentoComprar'] . "', '" . $_REQUEST['cidadeEstabelecimentoComprar'] . "', '" . $_REQUEST['estadoEstabelecimentoComprar'] . "', '" . $_REQUEST['tipoEstabelecimentoComprar'] . "', '" . $_REQUEST['quantidadeEstabelecimentoComprar'] . "', '" . $_REQUEST['numeroPessoasEstabelecimentoComprar'] . "', '" . $_REQUEST['percentualGarcomEstabelecimentoComprar'] . "', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
                mysqli_query($con, $sql) or die(mysqli_error($con));
                $cashier_system = mysqli_insert_id($con);
                $sql = "UPDATE cart SET cashier_system = '".$cashier_system."' WHERE id = '".$idCarrinho."'";
                mysqli_query($con, $sql) or die(mysqli_error($con));
            }
            if ($_REQUEST['product'] == 4) {
                $sql = "INSERT INTO school_system (nome, email, cep, logradouro, numero, complemento, bairro, cidade, estado, tipoNota, turno, letra, created_at, updated_at) VALUES ('" . $_REQUEST['nomeEscolaComprar'] . "', '" . $_REQUEST['emailEscolaComprar'] . "', '" . $_REQUEST['cepEscolaComprar'] . "', '" . $_REQUEST['logradouroEscolaComprar'] . "', '" . $_REQUEST['numeroEscolaComprar'] . "', '" . $_REQUEST['complementoEscolaComprar'] . "', '" . $_REQUEST['bairroEscolaComprar'] . "', '" . $_REQUEST['cidadeEscolaComprar'] . "', '" . $_REQUEST['estadoEscolaComprar'] . "', '" . $_REQUEST['tipoNotaEscolaComprar'] . "', '" . $_REQUEST['turnoEscolaComprar'] . "', '" . $_REQUEST['letraEscolaComprar'] . "', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
                mysqli_query($con, $sql) or die(mysqli_error($con));
                $school_system = mysqli_insert_id($con);
                if ($_REQUEST['tipoNotaEscolaComprar'] == 1){
                    $numero = 4;
                }
                elseif ($_REQUEST['tipoNotaEscolaComprar'] == 2){
                    $numero = 3;
                }
                elseif ($_REQUEST['tipoNotaEscolaComprar'] == 3){
                    $numero = 2;
                }
                elseif ($_REQUEST['tipoNotaEscolaComprar'] == 4){
                    $numero = 1;
                }
                for ($i = 1; $i <= $numero; $i++){
                    $sql = "INSERT INTO school_system_notas (idSchool, etapa, ptsDistribuidos, created_at, updated_at) VALUES ('".$school_system."', '".$i."', '".$_REQUEST['ptsDistribuidos'.$i]."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
                    mysqli_query($con, $sql);
                }
                $sql = "UPDATE cart SET school_system = '".$school_system."' WHERE id = '".$idCarrinho."'";
                mysqli_query($con, $sql) or die(mysqli_error($con));
            }
            echo "1";
            break;
    case "abreSistemaEscolar":
        $sql = "SELECT * FROM school_system WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        if ($_REQUEST['soVer']){
            $html = "Nome da Escola: <b>".$row['nome']."</b><br>
                    Email da Escola: <b>".$row['email']."</b><br>
                    CEP da Escola: <b>".$row['cep']."</b><br>
                    Logradouro da Escola: <b>".$row['logradouro']."</b><br>
                    Número da Escola: <b>".$row['numero']."</b><br>";
            if ($row['complemento']){
                $html .= "Complemento da Escola: <b>".$row['complemento']."</b><br>";
            }
            $html .= "
                    Bairro da Escola: <b>".$row['bairro']."</b><br>
                    Cidade da Escola: <b>".$row['cidade']."</b><br>
                    Estado da Escola: <b>".$row['estado']."</b><br>
                    Tipo de Nota da Escola: <b>";
            if ($row['tipoNota'] == 1){
                $html .= "Bimestral";
                $etapa = "Bimestre";
                $artigo = "o";
                $simbolo = "º";
            }
            elseif ($row['tipoNota'] == 2){
                $html .= "Trimestral";
                $etapa = "Trimestre";
                $artigo = "o";
                $simbolo = "º";
            }
            elseif ($row['tipoNota'] == 3){
                $html .= "Semestral";
                $etapa = "Semestre";
                $artigo = "o";
                $simbolo = "º";
            }
            elseif ($row['tipoNota'] == 4){
                $html .= "Anual";
                $etapa = "Etapa";
                $artigo = "a";
                $simbolo = "ª";
            }
            $html .= "</b><br>Pontos Distribuidos nas Etapas<br>";
            $sql = "SELECT * FROM school_system_notas WHERE idSchool = '".$row['id']."'";
            $query2 = mysqli_query($con, $sql);
            if (mysqli_num_rows($query2)){
                while ($row2 = mysqli_fetch_array($query2)){
                    $html .= "Pontos Distribuidos n".$artigo." ".$row2['etapa'].$simbolo." ".$etapa.": <b>".$row2['ptsDistribuidos']." pts</b><br>";
                }
            }
            $html .= "Turno da Escola: <b>";
            if ($row['turno'] == 'Un') {
                $html .= "Único";
            }
            elseif ($row['turno'] == 1) {
                $html .= "Manhã";
            }
            elseif ($row['turno'] == 2) {
                $html .= "Tarde";
            }
            elseif ($row['turno'] == 3) {
                $html .= "Noite";
            }
            elseif ($row['turno'] == 4) {
                $html .= "Manhã e Tarde";
            }
            elseif ($row['turno'] == 5) {
                $html .= "Manhã e Noite";
            }
            elseif ($row['turno'] == 6) {
                $html .= "Tarde e Noite";
            }
            elseif ($row['turno'] == 7) {
                $html .= "Manhã, Tarde e Noite";
            }
            $html .= "</b><br>
                    Letra da Escola: <b>";
            if ($row['letra'] == 'Un') {
                $html .= "Única";
            }
            else{
                $html .= $row['letra'];
            }
            $html .= "</b><br>";
        }
        else{
            $html = "<input type='hidden' name='idEscola' id='idEscola' value='".$row['id']."'>
            <label for='nomeEscola'>Nome da Escola: </label>
            <input type='text' name='nomeEscola' id='nomeEscola' value='".$row['nome']."' class='form-control'>
            <label for='emailEscola'>Email da Escola: </label>
            <input type='email' name='emailEscola' id='emailEscola' value='".$row['email']."' class='form-control'>
            <label for='cepEscola'>CEP da Escola: </label>
            <input type='text' name='cepEscola' id='cepEscola' class='form-control' maxlength='9' placeholder='Informe o cep da escola corretamente...' onkeyup=mascara(this,'#####-###',event);pesquisacepescola(this.value,'Escola') value='".$row['cep']."' required>
            <label for='logradouroEscola'>Logradouro da Escola: </label>
            <input type='text' name='logradouroEscola' id='logradouroEscola' value='".$row['logradouro']."' class='form-control' required>
            <label for='numeroEscola'>Número da Escola: </label>
            <input type='text' name='numeroEscola' id='numeroEscola' value='".$row['numero']."' class='form-control' required>
            <label for='complementoEscola'>Complemento da Escola: </label>
            <input type='text' name='complementoEscola' id='complementoEscola' value='".$row['complemento']."' class='form-control'>
            <label for='bairroEscola'>Bairro da Escola: </label>
            <input type='text' name='bairroEscola' id='bairroEscola' value='".$row['bairro']."' class='form-control' required>
            <label for='cidadeEscola'>Cidade da Escola: </label>
            <input type='text' name='cidadeEscola' id='cidadeEscola' value='".$row['cidade']."' class='form-control' required>
            <label for='estadoEscola'>Estado da Escola: </label>
            <select name='estadoEscola' id='estadoEscola' class='form-control' required>
                        <option value=''>Selecione o estado abaixo...</option>";
            $sql = "SELECT * FROM states";
            $query = mysqli_query($con, $sql);
            if (mysqli_num_rows($query)){
                while ($row3 = mysqli_fetch_array($query)){
                    $html .= "<option value='".$row3['sigla']."'";
                    if ($row3['sigla'] == $row['estado']){
                        $html .= ' selected';
                    }
                    $html .= ">".$row3['nome']."</option>";
                }
            }
            $html .= "
                    </select><label for='tipoNotaEscola'>Tipo de Nota da Escola: </label>
                    <select name='tipoNotaEscola' id='tipoNotaEscola' class='form-control' required onchange=selecionaTipoNota(this.value,'".URL_SITE."')>
                        <option value=''>Selecione o tipo de notas da escola corretamente...</option>
                        <option value='1'";
            if ($row['tipoNota'] == 1){
                $html .= " selected";
            }
            $html .= ">Bimestral</option>
                        <option value='2'";
            if ($row['tipoNota'] == 2){
                $html .= " selected";
            }
            $html .= ">Trimestral</option>
                        <option value='3'";
            if ($row['tipoNota'] == 3){
                $html .= " selected";
            }
            $html .= ">Semestral</option>
                        <option value='4'";
            if ($row['tipoNota'] == 4){
                $html .= " selected";
            }
            $html .= ">Anual</option>
                    </select><div id='tiposNotasEscolaComprar'>";
            if ($row['tipoNota'] == 1){
                $simbolo = "º";
                $nome = "Bimestre";
                $artigo = "o";
                $numero = "4";
            }
            elseif ($row['tipoNota'] == 2){
                $simbolo = "º";
                $nome = "Trimestre";
                $artigo = "o";
                $numero = "3";
            }
            elseif ($row['tipoNota'] == 3){
                $simbolo = "º";
                $nome = "Semestre";
                $artigo = "o";
                $numero = "2";
            }
            elseif ($row['tipoNota'] == 4){
                $simbolo = "º";
                $nome = "Ano";
                $artigo = "o";
                $numero = "1";
            }
            $sql = "SELECT * FROM school_system_notas WHERE idSchool = '".$_REQUEST['id']."'";
            $query2 = mysqli_query($con, $sql);
            $total = mysqli_num_rows($query2);
            $i = 1;
            while ($row2 = mysqli_fetch_array($query2)){
                $width = 100 / $numero;
                $html .= '<div style="float:left; width:'.$width.'%"><label for="ptsDistribuidos'.$i.'"><b>'.$row2['etapa'].'º '.$nome.'</b></label><input type="text" name="ptsDistribuidos'.$i.'" id="ptsDistribuidos'.$i.'" class="form-control" value="'.number_format($width, 2).'" required=""></div>';
                $i++;
            }
            $html .= "</div><br><br><br><label for='turnoEscola'>Turno da Escola: </label>
                      <select name='turnoEscola' id='turnoEscola' class='form-control' required>
                        <option value=''>Selecione o turno em que a escola funciona corretamente...</option>
                        <option value='1'";
            if ($row['turno'] == 1){
                $html .= " selected";
            }
            $html .= ">Manhã</option>
                        <option value='2'";
            if ($row['turno'] == 2){
                $html .= " selected";
            }
            $html .= ">Tarde</option>
                        <option value='3'";
            if ($row['turno'] == 3){
                $html .= " selected";
            }
            $html .= ">Noite</option>
                        <option value='4'";
            if ($row['turno'] == 4){
                $html .= " selected";
            }
            $html .= ">Manhã e Tarde</option>
                        <option value='5'";
            if ($row['turno'] == 5){
                $html .= " selected";
            }
            $html .= ">Manhã e Noite</option>
                        <option value='6'";
            if ($row['turno'] == 6){
                $html .= " selected";
            }
            $html .= ">Tarde e Noite</option>
                        <option value='7'";
            if ($row['turno'] == 7){
                $html .= " selected";
            }
            $html .= ">Manhã, Tarde e Noite</option>
                      </select>";
            $html .= "<label for='letraEscola'>Até que letra vai as turmas da Escola: </label>
                      <select name='letraEscola' id='letraEscola' class='form-control' required>
                        <option value=''>Selecione até que letra vai as turmas da escola corretamente...</option>
                        <option value='Un'";
            if ($row['letra'] == 'Un'){
                $html .= " selected";
            }
            $html .= ">Única</option>
                        <option value='A'";
            if ($row['letra'] == 'A'){
                $html .= " selected";
            }
            $html .= ">A</option>
                        <option value='B'";
            if ($row['letra'] == 'B'){
                $html .= " selected";
            }
            $html .= ">B</option>
                        <option value='C'";
            if ($row['letra'] == 'C'){
                $html .= " selected";
            }
            $html .= ">C</option>
                        <option value='D'";
            if ($row['letra'] == 'D'){
                $html .= " selected";
            }
            $html .= ">D</option>
                        <option value='E'";
            if ($row['letra'] == 'E'){
                $html .= " selected";
            }
            $html .= ">E</option>
                        <option value='F'";
            if ($row['letra'] == 'F'){
                $html .= " selected";
            }
            $html .= ">F</option>
                        <option value='G'";
            if ($row['letra'] == 'G'){
                $html .= " selected";
            }
            $html .= ">G</option>
                        <option value='H'";
            if ($row['letra'] == 'H'){
                $html .= " selected";
            }
            $html .= ">H</option>
                        <option value='I'";
            if ($row['letra'] == 'I'){
                $html .= " selected";
            }
            $html .= ">I</option>
                        <option value='J'";
            if ($row['letra'] == 'J'){
                $html .= " selected";
            }
            $html .= ">J</option>
                        <option value='K'";
            if ($row['letra'] == 'K'){
                $html .= " selected";
            }
            $html .= ">K</option>
                        <option value='L'";
            if ($row['letra'] == 'L'){
                $html .= " selected";
            }
            $html .= ">L</option>
                        <option value='M'";
            if ($row['letra'] == 'M'){
                $html .= " selected";
            }
            $html .= ">M</option>
                        <option value='N'";
            if ($row['letra'] == 'N'){
                $html .= " selected";
            }
            $html .= ">N</option>
                        <option value='O'";
            if ($row['letra'] == 'O'){
                $html .= " selected";
            }
            $html .= ">O</option>
                        <option value='P'";
            if ($row['letra'] == 'P'){
                $html .= " selected";
            }
            $html .= ">P</option>
                        <option value='Q'";
            if ($row['letra'] == 'Q'){
                $html .= " selected";
            }
            $html .= ">Q</option>
                        <option value='R'";
            if ($row['letra'] == 'R'){
                $html .= " selected";
            }
            $html .= ">R</option>
                        <option value='S'";
            if ($row['letra'] == 'S'){
                $html .= " selected";
            }
            $html .= ">S</option>
                        <option value='T'";
            if ($row['letra'] == 'T'){
                $html .= " selected";
            }
            $html .= ">T</option>
                        <option value='U'";
            if ($row['letra'] == 'U'){
                $html .= " selected";
            }
            $html .= ">U</option>
                        <option value='V'";
            if ($row['letra'] == 'V'){
                $html .= " selected";
            }
            $html .= ">V</option>
                        <option value='W'";
            if ($row['letra'] == 'W'){
                $html .= " selected";
            }
            $html .= ">W</option>
                        <option value='X'";
            if ($row['letra'] == 'X'){
                $html .= " selected";
            }
            $html .= ">X</option>
                        <option value='Y'";
            if ($row['letra'] == 'Y'){
                $html .= " selected";
            }
            $html .= ">Y</option>
                        <option value='Z'";
            if ($row['letra'] == 'Z'){
                $html .= " selected";
            }
            $html .= ">Z</option>
                      </select>
                      <input type='hidden' name='urlSistemaEscolar' id='urlSistemaEscolar' value='".URL_SITE."'>
                      <input type='submit' class='btn btn-primary btn-outline' value='Editar'>";
        }
        $html .= "
                  <input type='button' class='btn btn-danger btn-outline' onclick='$(\"#sistemaEscolar\").hide(\"fast\")' value='Fechar'>";
        echo "1|-|Sistema Escolar ".$_REQUEST['id']."|-|".$html;
        break;
    case "abreSistemaCaixa":
        $sql = "SELECT * FROM cashier_system WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        if ($_REQUEST['soVer']){
            $html = "Razão Social do Estabelecimento: <b>".$row['razao_social']."</b><br>
            Nome Fantasia do Estabelecimento: <b>".$row['nome_fantasia']."</b><br>
            CNPJ do Estabelecimento: <b>".$row['cnpj']."</b><br>
            Nome do Contato do Estabelecimento: <b>".$row['contato']."</b><br>
            Email do Estabelecimento: <b>".$row['email']."</b><br>
            CEP do Estabelecimento: <b>".$row['cep']."</b><br>
            Logradouro do Estabelecimento: <b>".$row['logradouro']."</b><br>
            Número do Estabelecimento: <b>".$row['numero']."</b><br>";
            if ($row['complemento']){
                $html .= "Complemento do Estabelecimento: <b>".$row['complemento']."</b><br>";
            }
            $html .= "Bairro do Estabelecimento: <b>".$row['bairro']."</b><br>
            Cidade do Estabelecimento: <b>".$row['cidade']."</b><br>
            Estado do Estabelecimento: <b>".$row['estado']."</b><br>
            Tipo do Estabelecimento: <b>";
            if ($row['tipoEstabelecimento'] == 1){
                $html .= "Mesas";
            }
            else{
                $html .= "Caixas";
            }
            $html .= "</b><br>";

            if ($row['tipoEstabelecimento'] == 1){
                $html .= "Quantidade de Mesas do Estabelecimento: <b>".$row['quantidade']."</b><br>
                Número de Pessoas por Mesa do Estabelecimento: <b>".$row['numeroPessoasPorMesa']."</b><br>
                Percentual do Garçom do Estabelecimento: <b>".$row['percentual']."%</b><br>";
            }
            else{
                $html .= "Quantidade de Caixas do Estabelecimento: <b>".$row['quantidade']."</b><br>";
            }
        }
        else {
            $html = "<input type='hidden' name='idCaixa' id='idCaixa' value='" . $row['id'] . "'>
        <label for='razaoSocialEstabelecimento'>Razão Social do Estabelecimento: </label>
        <input type='text' name='razaoSocialEstabelecimento' id='razaoSocialEstabelecimento' value='" . $row['razao_social'] . "' class='form-control'>
        <label for='nomeFantasiaEstabelecimento'>Nome Fantasia do Estabelecimento: </label>
        <input type='text' name='nomeFantasiaEstabelecimento' id='nomeFantasiaEstabelecimento' value='" . $row['nome_fantasia'] . "' class='form-control'>
        <label for='cnpjEstabelecimento'>CNPJ do Estabelecimento: </label>
        <input type='text' name='cnpjEstabelecimento' id='cnpjEstabelecimento' maxlength='18' placeholder='Informe o cnpj do estabelecimento (só números) aqui..' class='form-control' onkeypress=mascara(this,'##.###.###/####-##',event); value='" . $row['cnpj'] . "' required=''>
        <label for='contatoEstabelecimento'>Contato do Estabelecimento: </label>
        <input type='text' name='contatoEstabelecimento' id='contatoEstabelecimento' value='" . $row['contato'] . "' class='form-control'>
        <label for='emailEstabelecimento'>Email do Estabelecimento: </label>
        <input type='email' name='emailEstabelecimento' id='emailEstabelecimento' value='" . $row['email'] . "' class='form-control'>
        <label for='cepEstabelecimento'>CEP da Estabelecimento: </label>
        <input type='text' name='cepEstabelecimento' id='cepEstabelecimento' class='form-control' maxlength='9' placeholder='Informe o cep do Estabelecimento corretamente...' onkeypress=mascara(this,'#####-###',event); onkeyup=pesquisacepestabelecimento(this.value,'Estabelecimento') placeholder='Informe o cep do estabelecimento aqui...' value='" . $row['cep'] . "' required>
        <label for='logradouroEstabelecimento'>Logradouro da Estabelecimento: </label>
        <input type='text' name='logradouroEstabelecimento' id='logradouroEstabelecimento' value='" . $row['logradouro'] . "' class='form-control' required>
        <label for='numeroEstabelecimento'>Número da Estabelecimento: </label>
        <input type='text' name='numeroEstabelecimento' id='numeroEstabelecimento' value='" . $row['numero'] . "' class='form-control' required>
        <label for='complementoEstabelecimento'>Complemento da Estabelecimento: </label>
        <input type='text' name='complementoEstabelecimento' id='complementoEstabelecimento' value='" . $row['complemento'] . "' class='form-control'>
        <label for='bairroEstabelecimento'>Bairro da Estabelecimento: </label>
        <input type='text' name='bairroEstabelecimento' id='bairroEstabelecimento' value='" . $row['bairro'] . "' class='form-control' required>
        <label for='cidadeEstabelecimento'>Cidade da Estabelecimento: </label>
        <input type='text' name='cidadeEstabelecimento' id='cidadeEstabelecimento' value='" . $row['cidade'] . "' class='form-control' required>
        <label for='estadoEstabelecimento'>Estado do Estabelecimento: </label>
        <select name='estadoEstabelecimento' id='estadoEstabelecimento' class='form-control' required>
                    <option value=''>Selecione o estado abaixo...</option>";
            $sql = "SELECT * FROM states";
            $query = mysqli_query($con, $sql);
            if (mysqli_num_rows($query)) {
                while ($row3 = mysqli_fetch_array($query)) {
                    $html .= "<option value='" . $row3['sigla'] . "'";
                    if ($row3['sigla'] == $row['estado']) {
                        $html .= ' selected';
                    }
                    $html .= ">" . $row3['nome'] . "</option>";
                }
            }
            $html .= "
                </select>
                <label for='tipoEstabelecimento'>Tipo do Estabelecimento: </label>
                <select name='tipoEstabelecimento' id='tipoEstabelecimento' class='form-control' required  onchange=selecionaTipoEstabelecimento2(this.value,'" . URL_SITE . "')>
                    <option value=''>Selecione o tipo do estabelecimento abaixo...</option>
                    <option value='1'";
            if ($row['tipoEstabelecimento'] == 1) {
                $html .= " selected";
            }
            $html .= ">Mesas</option>
                    <option value='2'";
            if ($row['tipoEstabelecimento'] == 2) {
                $html .= " selected";
            }
            $html .= ">Caixas</option>
                </select>
                <div id='infsTipo'></div>
                  <input type='hidden' name='urlSistemaCaixa' id='urlSistemaCaixa' value='" . URL_SITE . "'>
                  <input type='submit' class='btn btn-primary btn-outline' value='Editar'>";
        }
        $html .= "
                  <input type='button' class='btn btn-danger btn-outline' onclick='$(\"#sistemaCaixa\").hide(\"fast\")' value='Fechar'>";
        echo "1|-|Sistema de Caixa ".$_REQUEST['id']."|-|".$html."|-|".$_REQUEST['id']."|-|".$row['tipoEstabelecimento']."|-|".$row['quantidade']."|-|".$row['numeroPessoasPorMesa']."|-|".$row['percentual'];
        break;
    case "selecionaPasso03":
        if ($_REQUEST['product'] != 3 && $_REQUEST['product'] != 4) {
            $html = '<label for="domineRealizarPedido">Domínio:</label>
                     <input type="text" name="domineRealizarPedido" id="domineRealizarPedido" required class="form-control" placeholder="Informe aqui o domínio que você comprou ou ainda vai comprar...">';
            if ($_REQUEST['product'] <= 5) {
                $html .= '
                     <label for="hostingRealizarPedido">Hospedagem:</label>
                     <select name="hostingRealizarPedido" id="hostingRealizarPedido" class="form-control">
                        <option value="">Selecione uma hospedagem para o seu site, ou deixe assim se já possuir a hospedagem...</option>
                        ';
                $sql = "SELECT * FROM products_items WHERE product = '6' AND status = '1'";
                $query = mysqli_query($con, $sql);
                while ($row = mysqli_fetch_array($query)) {
                    $valor = ($row['promotion'] && $row['validity_promotion'] && $row['validity_promotion'] >= date('Y-m-d')) ? $row['promotion'] : $row['value'];
                    $html .= '<option value="' . $row['id'] . '">' . ($row['name']) . ' - R$' . number_format($valor, 2, ',', '.') . '</option>';
                }
                $html .= '</select>
                     ';
            }
            if ($_REQUEST['product'] <= 6) {
                $html .= '<label for="registroRealizarPedido">Registro do Domínio:</label>
                     <select name="registroRealizarPedido" id="registroRealizarPedido" class="form-control">
                        <option value="">Selecione um registro para o seu site, ou deixe assim se já possuir o domínio...</option>
                        ';
                $sql = "SELECT * FROM products_items WHERE product = '7' AND status = '1'";
                $query = mysqli_query($con, $sql);
                while ($row = mysqli_fetch_array($query)) {
                    $valor = ($row['promotion'] && $row['validity_promotion'] && $row['validity_promotion'] >= date('Y-m-d')) ? $row['promotion'] : $row['value'];
                    $html .= '<option value="' . $row['id'] . '">' . ($row['name']) . ' - R$' . number_format($valor, 2, ',', '.') . '</option>';
                }
                $html .= '</select>';
            }
            if ($_REQUEST['product'] <= 5) {
                $html .= '<label for="modelSiteRealizarPedido">Modelo de Site:</label>
                     <select name="modelSiteRealizarPedido" id="modelSiteRealizarPedido" class="form-control">
                        <option value="">Selecione um modelo de site, ou deixe assim se já possuir um modelo...</option>
                        ';
                $sql = "SELECT * FROM subitems WHERE page = '5' AND status = '1'";
                $query = mysqli_query($con, $sql);
                while ($row = mysqli_fetch_array($query)) {
                    $sql = "SELECT * FROM products_items WHERE product = '8' AND status = '1'";
                    $query2 = mysqli_query($con, $sql);
                    $rowProductItem = mysqli_fetch_array($query2);
                    $valor = ($rowProductItem['promotion'] && $rowProductItem['validity_promotion'] && $rowProductItem['validity_promotion'] >= date('Y-m-d')) ? $rowProductItem['promotion'] : $rowProductItem['value'];
                    $html .= '<option value="' . $row['id'] . '">' . ($row['name']) . ' - R$' . number_format($valor, 2, ',', '.') . '</option>';
                }
                $html .= '</select>';
            }
        }
        if ($_REQUEST['product'] == 3){
            $html = '<label for="razaoSocialRealizarPedido">Razão Social:</label>
                     <input type="text" name="razaoSocialRealizarPedido" id="razaoSocialRealizarPedido" required class="form-control" placeholder="Informe aqui a razão social da empresa...">
                     <label for="nomeFantasiaRealizarPedido">Nome Fantasia:</label>
                     <input type="text" name="nomeFantasiaRealizarPedido" id="nomeFantasiaRealizarPedido" required class="form-control" placeholder="Informe aqui o nome fantasia da empresa...">
                     <label for="emailEmpresaRealizarPedido">Email:</label>
                     <input type="email" name="emailEmpresaRealizarPedido" id="emailEmpresaRealizarPedido" required class="form-control" placeholder="Informe aqui o email da empresa...">
                     <label for="cnpjEmpresaRealizarPedido">CNPJ:</label>
                     <input type="text" name="cnpjEmpresaRealizarPedido" id="cnpjEmpresaRealizarPedido" onkeypress="return mascara(this, \'00.000.000/0000-00\', event)" required class="form-control" placeholder="Informe aqui o cnpj da empresa... Somente Números...">
                     <label for="cepRealizarPedido">CEP:</label>
                     <input type="text" name="cepRealizarPedido" id="cepRealizarPedido" onkeyup="pesquisacepRealizarPedido(this.value)" onkeypress="return mascara(this, \'00000-000\', event)" required class="form-control" placeholder="Informe aqui o cep da empresa... Somente Números...">
                     <label for="logadouroRealizarPedido">Logradouro:</label>
                     <input type="text" name="logadouroRealizarPedido" id="logadouroRealizarPedido" required class="form-control" placeholder="Informe aqui o logradouro da empresa...">
                     <label for="numeroRealizarPedido">Número:</label>
                     <input type="text" name="numeroRealizarPedido" id="numeroRealizarPedido" required class="form-control" placeholder="Informe aqui o número da empresa...">
                     <label for="complementoRealizarPedido">Complemento:</label>
                     <input type="text" name="complementoRealizarPedido" id="complementoRealizarPedido" class="form-control" placeholder="Informe aqui o complemento da empresa...">
                     <label for="bairroRealizarPedido">Bairro:</label>
                     <input type="text" name="bairroRealizarPedido" id="bairroRealizarPedido" required class="form-control" placeholder="Informe aqui o bairro da empresa..">
                     <label for="cidadeRealizarPedido">Cidade:</label>
                     <input type="text" name="cidadeRealizarPedido" id="cidadeRealizarPedido" required class="form-control" placeholder="Informe aqui a cidade da empresa..">
                     <label for="estadoRealizarPedido">Estado:</label>
                     <select name="estadoRealizarPedido" id="estadoRealizarPedido" required class="form-control">
                     <option value="">UF</option>
                    ';
        $sql = "SELECT * FROM states ORDER BY sigla ASC";
        $query2 = mysqli_query($con, $sql);
        while ($row2 = mysqli_fetch_array($query2)) {
            $html .= '<option value="'.$row2['sigla'].'">'.$row2['sigla'].'</option>';
        }
                $html .= '
                </select>
                <label for="tipoEstabelecimentoRealizarPedido">Tipo do Estabelecimento:</label>
                     <select name="tipoEstabelecimentoRealizarPedido" id="tipoEstabelecimentoRealizarPedido" required class="form-control" onchange="selecionaTipoEstabelecimento(this.value)">
                     <option value="">Selecione o tipo do estabelecimento abaixo...</option>
                     <option value="1">Mesas</option>
                     <option value="2">Caixa</option>
                     </select>
                     <span id="tiposEstabelecimentoRealizarPedido">Selecione o tipo do estabelecimento acima...</span>';
        }
        if ($_REQUEST['product'] == 4){
            $html = '<label for="nomeEscolaRealizarPedido">Nome da Escola:</label>
                     <input type="text" name="nomeEscolaRealizarPedido" id="nomeEscolaRealizarPedido" required class="form-control" placeholder="Informe aqui o nome da escola..">
                     <label for="emailEscolaRealizarPedido">Email da Escola:</label>
                     <input type="text" name="emailEscolaRealizarPedido" id="emailEscolaRealizarPedido" required class="form-control" placeholder="Informe aqui o email da escola..">
                     <label for="cepEscolaRealizarPedido">CEP:</label>
                     <input type="text" name="cepEscolaRealizarPedido" id="cepEscolaRealizarPedido" onkeyup="pesquisacepEscolaRealizarPedido(this.value)" onkeypress="return mascara(this, \'00000-000\', event)" required class="form-control" placeholder="Informe aqui o cep da escola... Somente Números...">
                     <label for="logadouroEscolaRealizarPedido">Logradouro:</label>
                     <input type="text" name="logadouroEscolaRealizarPedido" id="logadouroEscolaRealizarPedido" required class="form-control" placeholder="Informe aqui o logradouro da escola...">
                     <label for="numeroEscolaRealizarPedido">Número:</label>
                     <input type="text" name="numeroEscolaRealizarPedido" id="numeroEscolaRealizarPedido" required class="form-control" placeholder="Informe aqui o número da escola...">
                     <label for="complementoEscolaRealizarPedido">Complemento:</label>
                     <input type="text" name="complementoEscolaRealizarPedido" id="complementoEscolaRealizarPedido" class="form-control" placeholder="Informe aqui o complemento da escola...">
                     <label for="bairroEscolaRealizarPedido">Bairro:</label>
                     <input type="text" name="bairroEscolaRealizarPedido" id="bairroEscolaRealizarPedido" required class="form-control" placeholder="Informe aqui o bairro da escola..">
                     <label for="cidadeEscolaRealizarPedido">Cidade:</label>
                     <input type="text" name="cidadeEscolaRealizarPedido" id="cidadeEscolaRealizarPedido" required class="form-control" placeholder="Informe aqui a cidade da escola..">
                     <label for="estadoEscolaRealizarPedido">Estado:</label>
                     <select name="estadoEscolaRealizarPedido" id="estadoEscolaRealizarPedido" required class="form-control">
                     <option value="">UF</option>
                    ';
        $sql = "SELECT * FROM states ORDER BY sigla ASC";
        $query2 = mysqli_query($con, $sql);
        while ($row2 = mysqli_fetch_array($query2)) {
            $html .= '<option value="'.$row2['sigla'].'">'.$row2['sigla'].'</option>';
        }
                $html .= '
                </select>
                <label for="tipoNotaRealizarPedido">Tipo de Nota:</label>
                     <select name="tipoNotaRealizarPedido" id="tipoNotaRealizarPedido" required class="form-control">
                     <option value="">Selecione o tipo de nota abaixo...</option>
                     <option value="1">Bimestral</option>
                     <option value="2">Trimestral</option>
                     <option value="3">Semestral</option>
                     <option value="4">Anual</option>
                     </select>
                <label for="turnoEscolaRealizarPedido">Turno da Escola:</label>
                     <select name="turnoEscolaRealizarPedido" id="turnoEscolaRealizarPedido" required class="form-control">
                     <option value="">Selecione o turno da escola abaixo...</option>
                     <option value="1">Manhã</option>
                     <option value="2">Tarde</option>
                     <option value="3">Noite</option>
                     <option value="4">Único</option>
                     <option value="5">Todos</option>
                     </select>
                <label for="letraEscolaRealizarPedido">Letra da Escola:</label>
                     <select name="letraEscolaRealizarPedido" id="letraEscolaRealizarPedido" required class="form-control">
                     <option value="">Selecione até que letra a escola vai abaixo...</option>';
                     for($i = 0; $i <= 26; $i++) {
                         switch ($i){
                             case 0:
                                 $letra = "Única";
                                 $l = "Un";
                                 break;
                             case 1:
                                 $letra = "A";
                                 break;
                             case 2:
                                 $letra = "B";
                                 break;
                             case 3:
                                 $letra = "C";
                                 break;
                             case 4:
                                 $letra = "D";
                                 break;
                             case 5:
                                 $letra = "E";
                                 break;
                             case 6:
                                 $letra = "F";
                                 break;
                             case 7:
                                 $letra = "G";
                                 break;
                             case 8:
                                 $letra = "H";
                                 break;
                             case 9:
                                 $letra = "I";
                                 break;
                             case 10:
                                 $letra = "J";
                                 break;
                             case 11:
                                 $letra = "K";
                                 break;
                             case 12:
                                 $letra = "L";
                                 break;
                             case 13:
                                 $letra = "M";
                                 break;
                             case 14:
                                 $letra = "N";
                                 break;
                             case 15:
                                 $letra = "O";
                                 break;
                             case 16:
                                 $letra = "P";
                                 break;
                             case 17:
                                 $letra = "Q";
                                 break;
                             case 18:
                                 $letra = "R";
                                 break;
                             case 19:
                                 $letra = "S";
                                 break;
                             case 20:
                                 $letra = "T";
                                 break;
                             case 21:
                                 $letra = "U";
                                 break;
                             case 22:
                                 $letra = "V";
                                 break;
                             case 23:
                                 $letra = "W";
                                 break;
                             case 24:
                                 $letra = "X";
                                 break;
                             case 25:
                                 $letra = "Y";
                                 break;
                             case 26:
                                 $letra = "Z";
                                 break;
                         }
                         if ($i > 0){
                             $l = $letra;
                         }
                         $html .= '<option value="'.$l.'">'.$letra.'</option>';
                     }
                     $html .= '
                     </select>';
        }
        echo "1|-|".$html;
        break;
    case "selecionaProduto":
        $sql = "SELECT * FROM products_items WHERE product = '".$_REQUEST['product']."' AND status = '1'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)) {
            $html = '<label for="produtoItemRealizarPedido">Selecione o item do produto:</label>
                                            <select name="produtoItemRealizarPedido" id="produtoItemRealizarPedido" required class="form-control" onchange="selecionaProdutoItem(\''.$_REQUEST['product'].'\', \''.URL.'\', this.value)">
                                                <option value="">Selecione o item do produto abaixo corretamente...</option>
                                                ';
            while ($row = mysqli_fetch_array($query)) {
                $valor = (date('Y-m-d') > $row['validaty_promotion']) ? $row['promotion'] : $row['value'];
                $html .= '<option value="'.$row['id'].'">'.($row['name']).' - R$'.number_format($valor, 2, ',', '.').'</option>
';
            }
                                                $html .= '</select><div id="passo03" style="display: none"></div>';
        }
        else{
            $html = "Sem nenhum item do produto encontrado em nossa base de dados!";
        }
        echo "1|-|".$html;
        break;
    case "detalhesPedido":
        $sql = "SELECT * FROM requests WHERE id = '".$_REQUEST['id']."' AND client = '".$_SESSION['cliente']['id']."' ";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)) {
            $sql = "SELECT a.*, b.name AS nomeCliente, b.email AS emailCliente, b.document AS documentoCliente, c.name AS nomeTipoDocumento, d.name AS nomeFormaPagamento,
                    e.name AS nomeStatus, f.cep AS cepEndereco, f.address AS endereco, f.number, f.complement, f.neighborhood, f.city, f.state, f.referencia
                    FROM requests a
                    INNER JOIN clients b ON (a.client = b.id)
                    INNER JOIN type_documents c ON (b.typeDocument = c.id)
                    INNER JOIN payment_methods d ON (a.paymentMethod = d.id)
                    INNER JOIN requests_statuses e ON (a.status = e.id)
                    INNER JOIN requests_addresses f ON (a.id = f.idRequest)
                    WHERE a.id = '" . $_GET['id'] . "'";
            $query = mysqli_query($con, $sql);
            $rowPedido = mysqli_fetch_array($query);
            $sql = "SELECT a.* FROM requests_items a WHERE a.request = '" . $_GET['id'] . "'";
            $query = mysqli_query($con, $sql);
            while ($rowItensPedido = mysqli_fetch_array($query)) {
                $pedidosItens[] = $rowItensPedido;
            }
            echo '1|-|<div style="position:fixed; float:left; left:75%"><img src="'.URL.'assets/img/close-icon.svg" width="25" style="cursor:pointer" onclick=fecha("detalhesPedido")></div><h2>Detalhes do Pedido ' . sprintf("%06s\n", $_GET['id']) . '</h2>
                <h3><img src="' . URL.'admin/img/cliente.png" width="30"> Dados do Cliente</h3>
                <table width="100%" cellspacing="0" cellpadding="0" border="0">
                    <tr>
                        <th>Nome do cliente</th>
                        <th>Email do cliente</th>
                    </tr>
                    <tr>
                        <td style="text-align:center">' . ($rowPedido['nomeCliente']) . '</td>
                        <td style="text-align:center">' . $rowPedido['emailCliente'] . '</td>
                    </tr>
                   <tr>
                       <th>Tipo de Documento do cliente</th>
                       <th>Documento do cliente</th>
                    </tr>
                    <tr>
                        <td style="text-align:center">' . ($rowPedido['nomeTipoDocumento']) . '</td>
                        <td style="text-align:center">' . $rowPedido['documentoCliente'] . '</td>
                    </tr>
                </table>
                <h3><img src="' . URL.'admin/img/pedido.png" width="30"> Dados do Pedido</h3>
                <table width="100%" cellspacing="0" cellpadding="0" border="0">
                    <tr>
                        <th>Número do Pedido</th>
                        <th>Data do Pedido</th>
                    </tr>
                    <tr>
                        <td style="text-align:center">' . sprintf("%06s\n", $rowPedido['id']) . '</td>
                        <td style="text-align:center">';
            $vet = explode(" ", $rowPedido['created_at']);
            $vet2 = explode("-", $vet[0]);
            echo $vet2[2] . "/" . $vet2[1] . '/' . $vet2[0] . ' às ' . $vet[1] . 'h</td>
                    </tr>
                   <tr>
                       <th>Nome da Forma de Pagamento</th>
                       <th>Status do Pedido</th>
                    </tr>
                    <tr>
                        <td style="text-align:center">' . ($rowPedido['nomeFormaPagamento']) . '</td>
                        <td style="text-align:center">' . ($rowPedido['nomeStatus']);
            if ($rowPedido['status'] <= 3) {
                echo " - <a href='" . URL . "efetuarPagamento.php?id=" . base64_encode($rowPedido['id']) . "' target='_blank' title='Efetuar Pagamento - Pedido " . sprintf("%06s\n", $_GET['id']) . "'>Efetuar Pagamento</a>";
            }
            echo '</td>
                    </tr>
                </table>
                <h3><img src="' . URL.'admin/img/carrinho.png" width="30"> Produtos Comprados</h3>
                <table width="100%" cellspacing="0" cellpadding="0" border="0">
                    <tr>
                       <th style="text-align: center">Nome Produto</th>
                       <th style="text-align: center">Quantidade</th>
                       <th style="text-align: center">Valor Unitário</th>
                       <th style="text-align: center">Valor Total</th>
                    </tr>
                    ';
            foreach ($pedidosItens as $key => $itens) {
                foreach ($itens as $chave => $valor) {
                    $itens[$chave] = ($valor);
                }
                echo '<tr>
                            <td style="text-align: center">' . ($itens['name']);
                if ($itens['domine']) {
                    echo " - <a href='" . $itens['domine'] . "' target='_blank' title='" . $itens['domine'] . "'>" . substr(($itens['domine']), 0, 15) . "...</a>";
                }
                if ($itens['school_system']) {
                    $sql = "SELECT a.*, b.nome AS nomeTipoNota, c.name AS nomeTurno FROM school_system a INNER JOIN tipo_notas b ON (a.tipoNota = b.id) INNER JOIN turnos c ON (a.turno = c.id) WHERE a.id = '" . $itens['school_system'] . "'";
                    $query2 = mysqli_query($con, $sql);
                    $rowSistemaEscolar = mysqli_fetch_array($query2);
                    if ($rowSistemaEscolar['letra'] == "Un") {
                        $rowSistemaEscolar['letra'] = "Única";
                    }
                    echo ' - <a onclick="verInformacoesSistemaEscolarSistema(\'' . $itens['school_system'] . '\', \''.URL.'\', \'1\')" style="color: #0077A4; cursor: pointer" title="Ver informações do sistema">Ver Informações do Sistema</a>
                                <div id="verInformacoesSistemaEscolar' . $itens['school_system'] . '" style="display: none; position:absolute; width:92%; background-color:#FFFFFF; color:#000000">
                                    <div style="position:absolute; float:left; left:95%"><img src="'.URL.'assets/img/close-icon.svg" width="30" style="cursor:pointer" onclick=fecha("verInformacoesSistemaEscolar' . $itens['school_system'] . '")></div>
                                    <h3>Informações do Sistema Escolar</h3>
                                    <b>Nome da Escola:</b> ' . $rowSistemaEscolar['nome'] . '<br>
                                    <b>Email da Escola:</b> ' . $rowSistemaEscolar['email'] . '<br>
                                    <b>CEP da Escola:</b> ' . $rowSistemaEscolar['cep'] . '<br>
                                    <b>Logradouro da Escola:</b> ' . $rowSistemaEscolar['logradouro'] . '<br>
                                    <b>Número da Escola:</b> ' . $rowSistemaEscolar['numero'] . '<br>';
                    if ($rowSistemaEscolar['complemento']) {
                        echo '<b>Complemento:</b> ' . $rowSistemaEscolar['complemento'] . '<br>';
                    }
                    echo '<b>Bairro da Escola:</b> ' . $rowSistemaEscolar['bairro'] . '<br>
                                    <b>Cidade da Escola:</b> ' . $rowSistemaEscolar['cidade'] . '<br>
                                    <b>Estado da Escola:</b> ' . $rowSistemaEscolar['estado'] . '<br>
                                    <b>Tipo de Nota da Escola:</b> ' . $rowSistemaEscolar['nomeTipoNota'] . '<br>
                                    <b>Turno da Escola:</b> ' . $rowSistemaEscolar['nomeTurno'] . '<br>
                                    <b>Letra da Escola:</b> ' . $rowSistemaEscolar['letra'] . '<br>
                                    <input type="button" value="Fechar" class="btn btn-danger" onclick=fecha("verInformacoesSistemaEscolar' . $itens['school_system'] . '")>
                                </div>';
                }
                if ($itens['cashier_system']) {
                    $sql = "SELECT a.*, b.name AS nomeTipoEstabelecimento FROM cashier_system a INNER JOIN tipo_estabelecimentos b ON (a.tipoEstabelecimento = b.id) WHERE a.id = '" . $itens['cashier_system'] . "'";
                    $query2 = mysqli_query($con, $sql);
                    $rowSistemaCaixa = mysqli_fetch_array($query2);
                    echo ' - <a onclick="verInformacoesSistemaCaixaSistema(' . $itens['cashier_system'] . ',\''.URL.'\', 1)" style="color: #0077A4; cursor: pointer" title="Ver informações do sistema">Ver Informações do Sistema</a>
                        <div id="verInformacoesSistemaDeCaixa' . $itens['cashier_system'] . '" style="display: none; position:absolute; width:92%; background-color:#FFFFFF; color:#000000">
                                    <div style="position:absolute; float:left; left:95%"><img src="'.URL.'assets/img/close-icon.svg" width="30" style="cursor:pointer" onclick=fecha("verInformacoesSistemaDeCaixa' . $itens['cashier_system'] . '")></div>
                                    <h3>Informações do Sistema de Caixa</h3>
                                    <b>Razão Social:</b> ' . $rowSistemaCaixa['razao_social'] . '<br>
                                    <b>Nome Fantasia:</b> ' . $rowSistemaCaixa['nome_fantasia'] . '<br>
                                    <b>Email:</b> ' . $rowSistemaCaixa['email'] . '<br>
                                    <b>CNPJ:</b> ' . $rowSistemaCaixa['cnpj'] . '<br>
                                    <b>CEP:</b> ' . $rowSistemaCaixa['cep'] . '<br>
                                    <b>Logradouro:</b> ' . $rowSistemaCaixa['logradouro'] . '<br>
                                    <b>Número:</b> ' . $rowSistemaCaixa['numero'] . '<br>';
                    if ($rowSistemaCaixa['complemento']) {
                        echo '<b>Complemento:</b> ' . $rowSistemaCaixa['complemento'] . '<br>';
                    }
                    echo '<b>Bairro:</b> ' . $rowSistemaCaixa['bairro'] . '<br>
                                    <b>Cidade:</b> ' . $rowSistemaCaixa['cidade'] . '<br>
                                    <b>Estado:</b> ' . $rowSistemaCaixa['estado'] . '<br>
                                    <b>Tipo de Estabelecimento:</b> '.$rowSistemaCaixa['nomeTipoEstabelecimento'].'<br>
                                    <b>Quantidade de ';
                    if ($rowSistemaCaixa['tipoEstabelecimento'] == 1) {
                        echo 'Mesas';
                    } else {
                        echo 'Caixas';
                    }
                    echo ':</b> ' . $rowSistemaCaixa['quantidade'];
                    if ($rowSistemaCaixa['tipoEstabelecimento'] == 1) {
                        echo '<br>
                                    <b>Número Pessoas Por Mesa:</b> ' . $rowSistemaCaixa['numeroPessoasPorMesa'] . '<br>
                                    <b>Gorjeta do Garçom:</b> ' . $rowSistemaCaixa['percentual'] . '%<br>
                                    <input type="button" class="btn btn-danger" value="Fechar" onclick=fecha("verInformacoesSistemaDeCaixa'.$itens['cashier_system'].'")>
                                </div>';
                    }
                }
                echo '</td>
                     <td style="text-align: center">' . $itens['quantity'] . '</td>
                     <td style="text-align: center">R$ ' . number_format($itens['value'], 2, ',', '.') . '</td>
                     <td style="text-align: center">R$ ' . number_format($itens['value'] * $itens['quantity'], 2, ',', '.') . '</td>
                </tr>';
            }
            echo '
                    <tr>
                        <td colspan="3" style="text-align:right">Subtotal:</td>
                        <td style="font-weight:bold">R$ ' . number_format($rowPedido['subtotal'], 2, ',', '.') . '</td>
                    </tr>';
            if ($rowPedido['descontoAVista'] && $rowPedido['descontoAVista'] != '0') {
                echo '
                    <tr>
                        <td colspan="3" style="text-align:right">Desconto à Vista:</td>
                        <td style="font-weight:bold; color:#FF0000">- R$ ' . number_format($rowPedido['descontoAVista'], 2, ',', '.') . '</td>
                    </tr>';
            }
            echo '
                    <tr>
                        <td colspan="3" style="text-align:right">Total:</td>
                        <td style="font-weight:bold; color:#000033">R$ ' . number_format($rowPedido['total'], 2, ',', '.') . '</td>
                    </tr>
                </table>
                <h3><img src="' . URL.'admin/img/endereco.png" width="30"> Dados do Endereço</h3>
                <b>CEP do Endereço:</b> ' . ($rowPedido['cepEndereco']) . '<br>
                <b>Endereço:</b> ' . ($rowPedido['endereco'] . ', ' . $rowPedido['number']);
            if ($rowPedido['complement']) {
                echo ', ' . ($rowPedido['complement']);
            }
            echo " - B. " . ($rowPedido['neighborhood'] . " - " . $rowPedido['city'] . " - " . $rowPedido['state']);
            if ($rowPedido['referencia']){
                echo "<br><b>Ponto de Referência: </b>".($rowPedido['referencia']);
            }
            echo '<div id="adicionaMensagemAoPedido" style="position:absolute; display:none; width:100%; background-color:#FFFFFF; border:1px solid #e7e7e7; border-radius:15px; padding:10px;"></div>
                <h3><img src="' . URL.'admin/img/mensagem.svg" width="30"> Mensagens do Pedido <img src="' . URL.'admin/img/refresh.png" width="30" style="cursor:pointer" onclick=abreMensagensPedido("' . $rowPedido['id'] . '","' . URL . '")></h3>
                <h4 style="cursor:pointer" onclick=abre("adicionaMensagemAoPedido");abreAdicionarMensagemPedido("' . $rowPedido['id'] . '","' . URL . '")><img src="' . URL.'admin/img/plus.png" width="25"> Adicionar Mensagem ao Pedido</h4>
                <div id="pedidoMensagens">';
            echo '</div><h4 style="cursor:pointer" onclick=abre("adicionaMensagemAoPedido");abreAdicionarMensagemPedido("' . $rowPedido['id'] . '","' . URL . '")><img src="' . URL.'admin/img/plus.png" width="25"> Adicionar Mensagem ao Pedido</h4>
                <hr noshade="noshade">
				<a href="'.URL.'imprimirComprovante.php?id='.base64_encode($rowPedido['id']).'" target="_blank"><img src="'.URL.'admin/img//imprimir.png" width="50"> Imprimir Comprovante</a>
				<hr noshade="noshade">';
        }
        else{
            echo "0|-|Esse pedido não é seu! Tente novamente com um pedido seu!";
        }
        break;
    case 'excluirMensagemPedido':
        $sql = "SELECT * FROM requests_messages WHERE idMensagem = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        if (!mysqli_num_rows($query)) {
            $sql = "DELETE FROM requests_messages WHERE id = '" . $_REQUEST['id'] . "'";
            mysqli_query($con, $sql);
            echo "1";
        }
        else{
            echo "0|-|Existem filhos dessa mensagem no sistema! Exclua-os primeiro!";
        }
        break;
    case 'pegarPedidoMensagens':
        echo "1|-|";
        $sql = "SELECT * FROM requests_messages WHERE idRequest = '".$_REQUEST['id']."' AND idMensagem IS NULL ORDER BY created_at DESC";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            echo '<table width="100%" border="0" cellspacing="0" cellpadding="0">
                            <tr style="background-color:#e7e7e7">
                                <th width="18%" style="padding:5px">Comprador</th>
                                <th width="18%" style="padding:5px">Data</th>
                                <th width="18%" style="padding:5px">Assunto</th>
                                <th width="18%" style="padding:5px">Mensagem</th>
                                <th width="18%" style="padding:5px">Administrador</th>
                                <th width="10%" style="padding:5px">Ações</th>
                            </tr>';
            if ($_REQUEST['admin']){
                $height = '50';
            }
            else{
                $height = '100';
            }
            $i = 0;
            while ($row = mysqli_fetch_array($query)){
                $vet = explode(' ', $row['created_at']);
                $vet2 = explode('-', $vet[0]);
				if (!isset($_REQUEST['tipo'])){
					$_REQUEST['tipo'] = "";
				}
                $row['created_at'] = $vet2[2]."/".$vet2[1]."/".$vet2[0]." às ".$vet[1]."h";
                $sql = "SELECT * FROM requests_messages WHERE idRequest = '".$_REQUEST['id']."' AND idMensagem = '".$row['id']."' ORDER BY created_at DESC";
                ${"query_$i"} = mysqli_query($con, $sql);
                echo "<tr style='background:url(".URL."admin/img/seta-";
                if ($row['de'] == 1){ echo "right2";} else{ echo "left2"; }
                echo ".png); background-repeat: repeat-x; height:50px;'>
                        <td style='padding:5px'><img src='".URL."admin/img/comprador.png' height='".$height."'></td>
                        <td style='padding:5px; font-weight:bold'>".$row['created_at']."</td>
                        <td style='padding:5px; font-weight:bold'>".$row['assunto']."</td>
                        <td style='padding:5px; font-weight:bold'>".$row['mensagem']."</td>
                        <td style='padding:5px'><img src='".URL."admin/img/admin.png' height='".$height."'></td>
                        <td style='padding:5px'><img src='".URL."admin/img/visualizar.svg' width='25' style='cursor:pointer' onclick=visualizarMensagemPedido('".$row['id']."','".$row['idRequest']."','".URL."')><div id='visualizarMensagemPedido".$row['id']."' style='position:absolute; display:none; left:50%; width:250px; background-color:#FFFFFF; border-color:#E7E7E7; padding:5px'></div> ";
                        if (!mysqli_num_rows(${"query_$i"})){
                            echo "<img src='".URL."admin/img/return.svg' width='25' title='Responder' style='cursor:pointer' onclick=abreRetornoMensagem".$_REQUEST['tipo']."('".$row['id']."','".URL."'); limparCamposRetornoMensagem('".$row['id']."') ";
                            if (!$_REQUEST['tipo']){
                                echo " data-toggle='modal' data-target='#retornoMensagem'";
                            }
                            echo "><div id='abreRetornoMensagem".$row['id']."' style='position:absolute; display:none; left:50%; width:250px; background-color:#FFFFFF; border-color:#E7E7E7; padding:5px'></div>";
                        }                        
                        if ($_REQUEST['admin'] == 1){
                            echo "<img src='".URL."admin/img/editar.svg' width='25' title='Editar' style='cursor:pointer' onclick=editarMensagemPedido('".$row['id']."','".$row['idRequest']."','".URL."')><div id='editarMensagemPedido".$row['id']."' style='position:absolute; display:none; left:50%; width:250px; background-color:#FFFFFF; border-color:#E7E7E7; padding:5px'></div> ";
                        }
                        if (!mysqli_num_rows(${"query_$i"})){
                            if ($_REQUEST['admin'] == 1){
                                echo "<img src='".URL."admin/img/excluir.svg' width='25' title='Excluir' style='cursor:pointer' onclick=excluirMensagemPedido('".$row['id']."','".$row['idRequest']."','".URL."')>";
                            }
                        }
                echo "</td>
                    </tr>";
				if (mysqli_num_rows(${"query_$i"})){
                    while (${"row_$i"} = mysqli_fetch_array(${"query_$i"})) {
                        $vet = explode(' ', ${"row_$i"}['created_at']);
                        $vet2 = explode('-', $vet[0]);
                        ${"row_$i"}['created_at'] = $vet2[2] . "/" . $vet2[1] . "/" . $vet2[0] . " às " . $vet[1] . "h";
                        $sql = "SELECT * FROM requests_messages WHERE idRequest = '".$_REQUEST['id']."' AND idMensagem = '".${"row_$i"}['id']."' ORDER BY created_at DESC";
                        $queryMensagem = mysqli_query($con, $sql);
                        echo "<tr style='background:url(" . URL . "img/seta-";
                        if (${"row_$i"}['de'] == 1) {
                            echo "left2";
                        } else {
                            echo "right2";
                        }
                        $mensagem = (strlen(${"row_$i"}['mensagem']) < 30) ? ${"row_$i"}['mensagem'] : substr(${"row_$i"}['mensagem'], 0, 29)."...";
                        echo ".png); background-repeat: repeat-x; height:50px;'>
                        <td style='padding:5px'><img src='" . URL . "img/comprador.png' height='" . $height . "'></td>
                        <td style='padding:5px; font-weight:bold'>" . ${"row_$i"}['created_at'] . "</td>
                        <td style='padding:5px; font-weight:bold'>" . ${"row_$i"}['assunto'] . "</td>
                        <td style='padding:5px; font-weight:bold'>" . $mensagem. "</td>
                        <td style='padding:5px'><img src='" . URL . "img/admin.png' height='" . $height . "'></td>
                        <td style='padding:5px'><img src='".URL."admin/img/visualizar.svg' width='25' style='cursor:pointer' onclick=visualizarMensagemPedido('".${"row_$i"}['id']."','".${"row_$i"}['idRequest']."','".URL."')><div id='visualizarMensagemPedido".${"row_$i"}['id']."' style='position:absolute; display:none; left:50%; width:250px; background-color:#FFFFFF; border-color:#E7E7E7; padding:5px'></div>  ";
                        if (!mysqli_num_rows($queryMensagem)){
                            echo "<img src='" . URL . "img/return.svg' width='25' title='Responder' style='cursor:pointer' onclick=abreRetornoMensagem".$_REQUEST['tipo']."('" . ${"row_$i"}['id'] . "','" . URL . "')";
                            if (!$_REQUEST['tipo']){
                                echo " data-toggle='modal' data-target='#retornoMensagem'";
                            }
                            echo "><div id='abreRetornoMensagem".${"row_$i"}['id']."' style='position:absolute; display:none; left:50%; width:250px; background-color:#FFFFFF; border-color:#E7E7E7; padding:5px'></div>";
                        }
                        if ($_REQUEST['admin'] == 1){ 
                            echo "<img src='".URL."admin/img/editar.svg' width='25' title='Editar' style='cursor:pointer' onclick=editarMensagemPedido('".${"row_$i"}['id']."','".${"row_$i"}['idRequest']."','".URL."')><div id='editarMensagemPedido".${"row_$i"}['id']."' style='position:absolute; display:none; left:50%; width:250px; background-color:#FFFFFF; border-color:#E7E7E7; padding:5px'></div> ";
                        }
                        if (!mysqli_num_rows($queryMensagem)){
                            if ($_REQUEST['admin'] == 1){
                                echo "
                        <img src='".URL."admin/img/excluir.svg' width='25' title='Excluir' style='cursor:pointer' onclick=excluirMensagemPedido('".${"row_$i"}['id']."','".${"row_$i"}['idRequest']."','".URL."')>";
                            }
                        }
                        echo "</td>
                    </tr>";
                        $sql = "SELECT * FROM requests_messages WHERE idRequest = '".$_REQUEST['id']."' AND idMensagem = '".${"row_$i"}['id']."' ORDER BY created_at DESC";
                        ${"query_$i"} = mysqli_query($con, $sql);
                    }
					$i++;
                }
                else{
                    
                }
            }
            echo '
                        </table>';
        }
        else{
            echo '<button class="btn btn-danger" onclick=abre("adicionaMensagemAoPedido");abreAdicionarMensagemPedido("'.$_REQUEST['id'].'","'.URL.'")>Sem nenhuma mensagem adicionada ao pedido! Adicione uma agora!</button><br><br>
                ';
        }
        break;
    case 'visualizarMensagemPedido':
        $sql = "SELECT * FROM requests_messages WHERE id = '".$_REQUEST['id']."' AND idRequest = '".$_REQUEST['idPedido']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $row = mysqli_fetch_array($query);
            echo "1|-|<div style='position:absolute; float:left; left:95%; cursor:pointer' onclick=fecha('visualizarMensagemPedido".$row['id']."')>&times;</div>
            <label>Número do Pedido:</label> <b id='numPedidoAddMsgPedido'>" . sprintf("%06s\n", $row['id']) . "</b>
            <br><label>Assunto:</label><br>
            ".$row['assunto']."
            <br><label>Mensagem:</label><br>
            ".str_replace("\r\n", "<br>", $row['mensagem'])."<br>
            <input type='button' onclick=fecha('visualizarMensagemPedido".$_REQUEST['id']."') value='Fechar' class='btn btn-danger'>";
        }
        else{
            echo "0|-|Essa mensagem é inexistente em nosso site!";
        }
        break;
    case 'editarMensagemPedido':
        $sql = "SELECT * FROM requests_messages WHERE id = '".$_REQUEST['id']."' AND idRequest = '".$_REQUEST['idPedido']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $row = mysqli_fetch_array($query);
            echo "1|-|<div style='position:absolute; float:left; left:95%; cursor:pointer' onclick=fecha('editarMensagemPedido".$row['id']."')>&times;</div>
            <input type='hidden' name='urlAddMsgPedido' id='urlAddMsgPedido' value='".URL."'>
        <label for='numPedidoEditMsgPedido".$row['id']."'>Número do Pedido:</label> <b id='numPedidoEditMsgPedido".$row['id']."'>" . sprintf("%06s\n", $row['idRequest']) . "</b>
        <input type='hidden' value='" . $row['idRequest'] . "' style='width:100%' name='idPedidoEditMensagemPedido".$row['id']."' id='idPedidoEditMensagemPedido".$row['id']."'>
        <br><label for='assuntoEditMsgPedido".$row['id']."'>Assunto:</label>
        <input type='text' name='assuntoEditMsgPedido".$row['id']."' id='assuntoEditMsgPedido".$row['id']."' required class='form-control' style='width:100%' placeholder='Informe aqui o assunto da mensagem corretamente...' value='".$row['assunto']."'>
        <br><label for='msgEditMsgPedido".$row['id']."'>Mensagem:</label>
        <textarea name='msgEditMsgPedido".$row['id']."' id='msgEditMsgPedido".$row['id']."' required class='form-control' placeholder='Informe aqui a mensagem corretamente...' style='height:200px; width:100%'>".$row['mensagem']."</textarea>
        <input type='button' value='Editar' class='btn btn-primary' onclick=atualizaMensagemPedido('".$row['id']."','".$_REQUEST['idPedido']."','".URL."')>";
        }
        else{
            echo "0|-|Essa mensagem é inexistente em nosso site!";
        }
        break;
    case "atualizaMensagemPedido":
        $sql = "UPDATE requests_messages SET assunto = '".$_REQUEST['assuntoEditMsgPedido']."', mensagem = '".$_REQUEST['msgEditMsgPedido']."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['id']."'";
        mysqli_query($con, $sql) or die(mysqli_error($con));
        echo "1";
        break;
    case "cadastrarMensagemPedido":
        if ($_REQUEST['admin']){
            $ids = "'2', '1'";
        }
        else{
            $ids = "'1', '2'";
        }
        $sql = "INSERT INTO requests_messages (idRequest, assunto, mensagem, de, para, created_at, updated_at) VALUES ('".$_REQUEST['idPedido']."', '".$_REQUEST['assuntoAddMsgPedido']."', '".nl2br($_REQUEST['msgAddMsgPedido'])."', ".$ids.", '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        mysqli_query($con, $sql) or die(mysqli_error($con));
        echo "1";
        break;
    case "abreAdicionarMensagemPedido":
        $_SESSION['cliente']['id'] = ($_REQUEST['admin']) ? $_REQUEST['cliente'] : $_SESSION['cliente']['id'];
        $sql = "SELECT * FROM requests WHERE id = '".$_REQUEST['id']."' AND client = '".$_SESSION['cliente']['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)) {
            $row = mysqli_fetch_array($query);
            $html = "
            <div style='position:absolute; float:left; left:95%; cursor:pointer' onclick=fecha('adicionaMensagemAoPedido')>&times;</div>
        <input type='hidden' name='urlAddMsgPedido' id='urlAddMsgPedido' value='".URL."'>
        <label for='numPedidoAddMsgPedido'>Número do Pedido:</label> <b id='numPedidoAddMsgPedido'>" . sprintf("%06s\n", $row['id']) . "</b>
        <input type='hidden' value='" . $row['id'] . "' style='width:100%' name='idPedidoAddMensagemPedido' id='idPedidoAddMensagemPedido'>
        <br><label for='assuntoAddMsgPedido'>Assunto:</label>
        <input type='text' name='assuntoAddMsgPedido' id='assuntoAddMsgPedido' required class='form-control' style='width:100%' placeholder='Informe aqui o assunto da mensagem corretamente...'>
        <br><label for='msgAddMsgPedido'>Mensagem:</label>
        <textarea name='msgAddMsgPedido' id='msgAddMsgPedido' required class='form-control' placeholder='Informe aqui a mensagem corretamente...' style='height:200px; width:100%'></textarea>
        <input type='button' value='Enviar' class='btn btn-primary' onclick=cadastrarMensagemPedido('".$row['id']."','".URL."')>";
            echo '1|-|' . $html;
        }
        else{
            echo "0|-|Esse pedido não é seu! Tente novamente com um pedido seu!";
        }
        break;
    case "abreAdicionarMensagemPedido2":
        $sql = "SELECT * FROM requests WHERE id = '".$_REQUEST['id']."' AND client = '".$_SESSION['cliente']['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)) {
            $html = "
        <input type='hidden' name='urlAddMsgPedido2' id='urlAddMsgPedido2' value='".URL."'>
        <label for='numPedidoAddMsgPedido2'>Número do Pedido:</label> <b id='numPedidoAddMsgPedido2'>" . sprintf("%06s\n", $_GET['id']) . "</b>
        <input type='hidden' value='" . $_REQUEST['id'] . "' name='idPedidoAddMensagemPedido2' id='idPedidoAddMensagemPedido2'>
        <br><label for='assuntoAddMsgPedido2'>Assunto:</label>
        <input type='text' name='assuntoAddMsgPedido2' id='assuntoAddMsgPedido2' required class='form-control' placeholder='Informe aqui o assunto da mensagem corretamente...'>
        <br><label for='msgAddMsgPedido2'>Mensagem:</label>
        <textarea name='msgAddMsgPedido2' id='msgAddMsgPedido2' required class='form-control' placeholder='Informe aqui a mensagem corretamente...' style='height:200px'></textarea>
        <input type='submit' value='Enviar' class='btn btn-primary'>";
            echo '1|-|' . $html;
        }
        else{
            echo "0|-|Esse pedido não é seu! Tente novamente com um pedido seu!";
        }
        break;
    case "abreAdicionarMensagemPedidoAdmin":
        $sql = "SELECT * FROM requests WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)) {
            $html = "
        <input type='hidden' name='urlAddMsgPedido' id='urlAddMsgPedido' value='".URL."'>
        <label for='numPedidoAddMsgPedido'>Número do Pedido:</label> <b id='numPedidoAddMsgPedido'>" . sprintf("%06s\n", $_GET['id']) . "</b>
        <input type='hidden' value='" . $_REQUEST['id'] . "' name='idPedidoAddMensagemPedido' id='idPedidoAddMensagemPedido'>
        <br><label for='assuntoAddMsgPedido'>Assunto:</label>
        <input type='text' name='assuntoAddMsgPedido' id='assuntoAddMsgPedido' required class='form-control' placeholder='Informe aqui o assunto da mensagem corretamente...'>
        <br><label for='msgAddMsgPedido'>Mensagem:</label>
        <textarea name='msgAddMsgPedido' id='msgAddMsgPedido' required class='form-control' placeholder='Informe aqui a mensagem corretamente...' style='height:200px'></textarea>
        <input type='submit' value='Enviar' class='btn btn-primary'>";
            echo '1|-|' . $html;
        }
        else{
            echo "0|-|Esse pedido não existe!!";
        }
        break;
    case "carregarDadosMensagemPedido":
        $sql = "SELECT * FROM requests_messages WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        $html = "
    <input type='hidden' name='urlEditMsgPedido".$_REQUEST['id']."' id='urlEditMsgPedido' value='".URL."'>
    <input type='hidden' name='idEditMsgPedido' id='idEditMsgPedido' value='".$row['id']."'>
    <label for='numPedidoEditMsgPedido'>Número do Pedido:</label> <b id='numPedidoEditMsgPedido'>" . sprintf("%06s\n", $row['idRequest']) . "</b>
    <input type='hidden' value='" . $row['idRequest'] . "' name='idPedidoEditMsgPedido' id='idPedidoEditMsgPedido'>
    <br><label for='assuntoEditMsgPedido'>Assunto:</label>
    <input type='text' name='assuntoEditMsgPedido' id='assuntoEditMsgPedido' required class='form-control' placeholder='Informe aqui o assunto da mensagem corretamente...' value='".$row['assunto']."'>
    <br><label for='msgEditMsgPedido'>Mensagem:</label>
    <textarea name='msgEditMsgPedido' id='msgEditMsgPedido' required class='form-control' placeholder='Informe aqui a mensagem corretamente...' style='height:200px'>".str_replace('<br />', '', $row['mensagem'])."</textarea>
    <input type='submit' value='Enviar' class='btn btn-primary'>";
        echo '1|-|' . $html;
        break;
    case "abreRetornoMensagem":
        $sql = "SELECT * FROM requests_messages WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        $html = "<div style='position: absolute; float:left; left:95%; cursor:pointer;' onclick=fecha('abreRetornoMensagem".$_REQUEST['id']."')>&times;</div>
    <input type='hidden' name='urlAddRetornoMsg".$_REQUEST['id']."' id='urlAddRetornoMsg".$_REQUEST['id']."' value='".URL."'>
    <input type='hidden' name='idMensagemAddRetornoMsg".$_REQUEST['id']."' id='idMensagemAddRetornoMsg".$_REQUEST['id']."' value='".$_REQUEST['id']."'>
    <label for='numPedidoAddRetornoMsg".$_REQUEST['id']."'>Número do Pedido:</label> <b id='numPedidoAddRetornoMsg".$_REQUEST['id']."'>" . sprintf("%06s", $row['idRequest']) . "</b>
    <input type='hidden' value='" . $row['idRequest'] . "' name='idPedidoAddRetornoMsg".$_REQUEST['id']."' id='idPedidoAddRetornoMsg".$_REQUEST['id']."'>
    <br><label for='assuntoAddRetornoMsg".$_REQUEST['id']."'>Assunto:</label>
    <input type='text' name='assuntoAddRetornoMsg".$_REQUEST['id']."' id='assuntoAddRetornoMsg".$_REQUEST['id']."' value='Re: ".$row['assunto']."' readonly required class='form-control' placeholder='Informe aqui o assunto da mensagem corretamente...'>
    <br><label for='msgAddRetornoMsg".$_REQUEST['id']."'>Mensagem:</label>
    <textarea name='msgAddRetornoMsg".$_REQUEST['id']."' id='msgAddRetornoMsg".$_REQUEST['id']."' required class='form-control' placeholder='Informe aqui a mensagem corretamente...' style='height:200px'></textarea>
    <input type='button' onclick=enviarRetornoMsg('".$_REQUEST['id']."','".URL."') value='Enviar' class='btn btn-primary'> <input type='button' value='Fechar' class='btn btn-danger' onclick=fecha('abreRetornoMensagem".$_REQUEST['id']."')>";
        echo '1|-|' . $html;
        break;
    case "abreRetornoMensagem2":
        $sql = "SELECT * FROM requests_messages WHERE id = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        $html = "
    <input type='hidden' name='urlAddRetornoMsg2' id='urlAddRetornoMsg2' value='".URL."'>
    <input type='hidden' name='idMensagemAddRetornoMsg2' id='idMensagemAddRetornoMsg2' value='".$_REQUEST['id']."'>
    <label for='numPedidoAddRetornoMsg2'>Número do Pedido:</label> <b id='numPedidoAddRetornoMsg2'>" . sprintf("%06s", $row['idRequest']) . "</b>
    <input type='hidden' value='" . $row['idRequest'] . "' name='idPedidoAddRetornoMsg2' id='idPedidoAddRetornoMsg2'>
    <br><label for='assuntoAddRetornoMsg2'>Assunto:</label>
    <input type='text' name='assuntoAddRetornoMsg2' id='assuntoAddRetornoMsg2' value='Re: ".$row['assunto']."' readonly required class='form-control' placeholder='Informe aqui o assunto da mensagem corretamente...'>
    <br><label for='msgAddRetornoMsg2'>Mensagem:</label>
    <textarea name='msgAddRetornoMsg2' id='msgAddRetornoMsg2' required class='form-control' placeholder='Informe aqui a mensagem corretamente...' style='height:200px'></textarea>
    <input type='submit' value='Enviar' class='btn btn-primary'>";
        echo '1|-|' . $html;
        break;
    case "addMsgPedido":
        $sql = "SELECT * FROM requests WHERE id = '".$_REQUEST['idPedidoAddMensagemPedido']."' AND client = '".$_SESSION['cliente']['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)) {
            $sql = "INSERT INTO requests_messages (idRequest, assunto, mensagem, de, para, created_at, updated_at) VALUES ('".$_REQUEST['idPedidoAddMensagemPedido']."', '".$_REQUEST['assuntoAddMsgPedido']."', '".nl2br($_REQUEST['msgAddMsgPedido'])."', '2', '1', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
            mysqli_query($con, $sql) or die(mysqli_error($con));
            $htmlEmail = '<html><head><title>'.$parametrosSite['title'].' - Mensagem adicionada ao pedido '.sprintf("%06s", $_REQUEST['idPedidoAddMensagemPedido']).' - '.$_REQUEST['assuntoAddMsgPedido'].'</title></head><body><table width="100%" cellspacing="0" cellpadding="0" border="0"><tr><td width="250" style="text-align:center" valign="top"><img src="'.URL.'admin/img//logo.png" width="230"></td><td valign="top">Olá Equipe <b>'.$parametrosSite['title'].'</b>,<br><br>Foi adicionada uma nova mensagem ao pedido <b>'.sprintf("%06s", $_REQUEST['idPedidoAddMensagemPedido']).'</b>!<br><br><b>Assunto: </b>'.$_REQUEST['assuntoAddMsgPedido'].'<br><br><b>Mensagem:</b> '.nl2br($_REQUEST['msgAddMsgPedido']).'<br><br>Para ver e responder a essa mensagem, <a href="'.URL.'admin/listarPedidos/'.$_REQUEST['idPedidoAddMensagemPedido'].'">clique aqui</a>. Não responda por aqui, pois você estará respondendo a você mesmo.<br><br>Obrigado,<br><br>Equipe <b>'.$parametrosSite['title'].'</b></td></tr></table></body></html>';
            $assuntoEmail = $parametrosSite['title'].' - Mensagem adicionada ao pedido '.sprintf("%06s", $_REQUEST['idPedidoAddMensagemPedido']).' - '.$_REQUEST['assuntoAddMsgPedido'];
            $paraEmail = $parametrosSite['title']."<".$parametrosSite['email'].">";
            $cabecalhoEmail = "Content-Type: text/html; charset=iso-8859-1\n";
            $cabecalhoEmail .= "From: ".$parametrosSite['title']."<".$parametrosSite['email'].">\nReply-To: ".$parametrosSite['title']."<".$parametrosSite['email'].">";
            //enviarEmail($parametrosSite['email'], "Contato - ".$parametrosSite['title'], $parametrosSite['email'], "Contato - ".$parametrosSite['title'], ($assuntoEmail), ($htmlEmail));
            mail(($paraEmail), ($assuntoEmail), ($htmlEmail), ($cabecalhoEmail));
            //echo $htmlEmail;
            echo '1|-|' . $htmlEmail;
        }
        else{
            echo "0|-|Esse pedido não é seu! Tente novamente com um pedido seu!";
        }
        break;
    case "enviarRetornoMsg":
        if ($_REQUEST['admin']){
            $values = "'1', '2'";
        }
        else{
            $values = "'2', '1'";
        }
        $sql = "INSERT INTO requests_messages (idRequest, idMensagem, assunto, mensagem, de, para, created_at, updated_at) VALUES ('".$_REQUEST['idPedidoAddRetornoMsg']."', '".$_REQUEST['idMensagemAddRetornoMsg']."', '".$_REQUEST['assuntoAddRetornoMsg']."', '".nl2br($_REQUEST['msgAddRetornoMsg'])."', ".$values.", '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        mysqli_query($con, $sql) or die(mysqli_error($con));
        $htmlEmail = '<html><head><title>'.$parametrosSite['title'].' - Mensagem adicionada ao pedido '.sprintf("%06s", $_REQUEST['idPedidoAddMensagemPedido']).' - '.$_REQUEST['assuntoAddMsgPedido'].'</title></head><body><table width="100%" cellspacing="0" cellpadding="0" border="0"><tr><td width="250" style="text-align:center" valign="top"><img src="'.URL.'admin/img//logo.png" width="230"></td><td valign="top">Olá Equipe <b>'.$parametrosSite['title'].'</b>,<br><br>Foi adicionada uma nova mensagem ao pedido <b>'.sprintf("%06s", $_REQUEST['idPedidoAddMensagemPedido']).'</b>!<br><br><b>Assunto: </b>'.$_REQUEST['assuntoAddMsgPedido'].'<br><br><b>Mensagem:</b> '.nl2br($_REQUEST['msgAddMsgPedido']).'<br><br>Para ver e responder a essa mensagem, <a href="'.URL.'admin/listarPedidos/'.$_REQUEST['idPedidoAddMensagemPedido'].'">clique aqui</a>. Não responda por aqui, pois você estará respondendo a você mesmo.<br><br>Obrigado,<br><br>Equipe <b>'.$parametrosSite['title'].'</b></td></tr></table></body></html>';
        $assuntoEmail = $parametrosSite['title'].' - Mensagem adicionada ao pedido '.sprintf("%06s", $_REQUEST['idPedidoAddMensagemPedido']).' - '.$_REQUEST['assuntoAddMsgPedido'];
        $paraEmail = $parametrosSite['title']."<".$parametrosSite['email'].">";
        $cabecalhoEmail = "Content-Type: text/html; charset=iso-8859-1\n";
        $cabecalhoEmail .= "From: ".$parametrosSite['title']."<".$parametrosSite['email'].">\nReply-To: ".$parametrosSite['title']."<".$parametrosSite['email'].">";
        //enviarEmail($parametrosSite['email'], "Contato - ".$parametrosSite['title'], $parametrosSite['email'], "Contato - ".$parametrosSite['title'], ($assuntoEmail), ($htmlEmail));
        mail(($paraEmail), ($assuntoEmail), ($htmlEmail), ($cabecalhoEmail));
        //echo $htmlEmail;
        echo '1|-|' . $htmlEmail;
        break;
    case "addMsgPedido2":
        $sql = "SELECT * FROM requests WHERE id = '".$_REQUEST['idPedidoAddMensagemPedido2']."' AND client = '".$_SESSION['cliente']['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)) {
            $sql = "INSERT INTO requests_messages (idRequest, assunto, mensagem, de, para, created_at, updated_at) VALUES ('".$_REQUEST['idPedidoAddMensagemPedido2']."', '".$_REQUEST['assuntoAddMsgPedido2']."', '".nl2br($_REQUEST['msgAddMsgPedido2'])."', '2', '1', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
            mysqli_query($con, $sql) or die(mysqli_error($con));
            $htmlEmail = '<html><head><title>'.$parametrosSite['title'].' - Mensagem adicionada ao pedido '.sprintf("%06s", $_REQUEST['idPedidoAddMensagemPedido']).' - '.$_REQUEST['assuntoAddMsgPedido2'].'</title></head><body><table width="100%" cellspacing="0" cellpadding="0" border="0"><tr><td width="250" style="text-align:center" valign="top"><img src="'.URL.'admin/img//logo.png" width="230"></td><td valign="top">Olá Equipe <b>'.$parametrosSite['title'].'</b>,<br><br>Foi adicionada uma nova mensagem ao pedido <b>'.sprintf("%06s", $_REQUEST['idPedidoAddMensagemPedido2']).'</b>!<br><br><b>Assunto: </b>'.$_REQUEST['assuntoAddMsgPedido2'].'<br><br><b>Mensagem:</b> '.nl2br($_REQUEST['msgAddMsgPedido2']).'<br><br>Para ver e responder a essa mensagem, <a href="'.URL.'admin/listarPedidos/'.$_REQUEST['idPedidoAddMensagemPedido2'].'">clique aqui</a>. Não responda por aqui, pois você estará respondendo a você mesmo.<br><br>Obrigado,<br><br>Equipe <b>'.$parametrosSite['title'].'</b></td></tr></table></body></html>';
            $assuntoEmail = $parametrosSite['title'].' - Mensagem adicionada ao pedido '.sprintf("%06s", $_REQUEST['idPedidoAddMensagemPedido']).' - '.$_REQUEST['assuntoAddMsgPedido2'];
            $paraEmail = $parametrosSite['title']."<".$parametrosSite['email'].">";
            $cabecalhoEmail = "Content-Type: text/html; charset=iso-8859-1\n";
            $cabecalhoEmail .= "From: ".$parametrosSite['title']."<".$parametrosSite['email'].">\nReply-To: ".$parametrosSite['title']."<".$parametrosSite['email'].">";
            //enviarEmail($parametrosSite['email'], "Contato - ".$parametrosSite['title'], $parametrosSite['email'], "Contato - ".$parametrosSite['title'], ($assuntoEmail), ($htmlEmail));
			mail(($paraEmail), ($assuntoEmail), ($htmlEmail), ($cabecalhoEmail));
            //echo $htmlEmail;
            echo '1|-|' . $htmlEmail;
        }
        else{
            echo "0|-|Esse pedido não é seu! Tente novamente com um pedido seu!";
        }
        break;
    case "addMensagemPedidoAdmin":
        $sql = "SELECT a.*, b.name AS nomeCliente, b.email AS emailCliente FROM requests a INNER JOIN clients b ON (a.client = b.id) WHERE a.id = '".$_REQUEST['idPedidoAddMensagemPedido']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)) {
            $row = mysqli_fetch_array($query);
            $sql = "INSERT INTO requests_messages (idRequest, assunto, mensagem, de, para, created_at, updated_at) VALUES ('".$_REQUEST['idPedidoAddMensagemPedido']."', '".$_REQUEST['assuntoAddMsgPedido']."', '".nl2br($_REQUEST['msgAddMsgPedido'])."', '1', '2', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
            mysqli_query($con, $sql) or die(mysqli_error($con));
            $htmlEmail = '<html><head><title>'.$parametrosSite['title'].' - Mensagem adicionada ao pedido '.sprintf("%06s", $_REQUEST['idPedidoAddMensagemPedido']).' - '.$_REQUEST['assuntoAddMsgPedido'].'</title></head><body><table width="100%" cellspacing="0" cellpadding="0" border="0"><tr><td width="250" style="text-align:center" valign="top"><img src="'.URL.'admin/img//logo.png" width="230"></td><td valign="top">Olá <b>'.$row['nomeCliente'].'</b>,<br><br>Foi adicionada uma nova mensagem ao pedido <b>'.sprintf("%06s", $_REQUEST['idPedidoAddMensagemPedido']).'</b>!<br><br><b>Assunto: </b>'.$_REQUEST['assuntoAddMsgPedido'].'<br><br><b>Mensagem:</b> '.nl2br($_REQUEST['msgAddMsgPedido']).'<br><br>Para ver e responder a essa mensagem, acesse o nosso site, <a href="'.URL.'">clicando aqui</a>. Se logue em nosso site, clique em "Painel" no menu, clique em "Meus Pedidos" e clique sobre o pedido de número '.sprintf("%06s", $_REQUEST['idPedidoAddMensagemPedido']).'.<br><br>Obrigado,<br><br>Equipe <b>'.$parametrosSite['title'].'</b></td></tr></table></body></html>';
            $assuntoEmail = $parametrosSite['title'].' - Mensagem adicionada ao pedido '.sprintf("%06s", $_REQUEST['idPedidoAddMensagemPedido']).' - '.$_REQUEST['assuntoAddMsgPedido'];
            $paraEmail = $row['nomeCliente']."<".$row['emailCliente'].">";
            $cabecalhoEmail = "Content-Type: text/html; charset=iso-8859-1\n";
            $cabecalhoEmail .= "From: ".$parametrosSite['title']."<".$parametrosSite['email'].">\nReply-To: ".$parametrosSite['title']."<".$parametrosSite['email'].">";
            //enviarEmail($parametrosSite['email'], "Contato - ".$parametrosSite['title'], $row['emailCliente'], $row['nomeCliente'], ($assuntoEmail), $htmlEmail);
			mail(($paraEmail), ($assuntoEmail), ($htmlEmail), ($cabecalhoEmail));
            //echo $htmlEmail;
            echo '1|-|' . $htmlEmail;
        }
        else{
            echo "0|-|Esse pedido não existe!";
        }
        break;
    case "addRetornoMsg":
        $sql = "SELECT a.*, b.email AS emailCliente, b.name AS nomeCliente FROM requests a INNER JOIN clients b ON (a.client = b.id) WHERE a.id = '".$_REQUEST['idPedidoAddRetornoMsg']."' AND client = '".$_SESSION['cliente']['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)) {
            $row = mysqli_fetch_array($query);
            if (!$_REQUEST['admin']) {
                $sql = "INSERT INTO requests_messages (idRequest, idMensagem, assunto, mensagem, de, para, created_at, updated_at) VALUES ('" . $_REQUEST['idPedidoAddRetornoMsg'] . "', '" . $_REQUEST['idMensagemAddRetornoMsg'] . "', '" . $_REQUEST['assuntoAddRetornoMsg'] . "', '" . nl2br($_REQUEST['msgAddRetornoMsg']) . "', '2', '1', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
                mysqli_query($con, $sql) or die(mysqli_error($con));
                $htmlEmail = '<html><head><title>' . $parametrosSite['title'] . ' - Mensagem adicionada ao pedido ' . sprintf("%06s", $_REQUEST['idPedidoAddRetornoMsg']) . ' - ' . $_REQUEST['assuntoAddRetornoMsg'] . '</title></head><body><table width="100%" cellspacing="0" cellpadding="0" border="0"><tr><td width="250" style="text-align:center" valign="top"><img src="' . URL.'admin/img/logo.png" width="230"></td><td valign="top">Olá Equipe <b>' . $parametrosSite['title'] . '</b>,<br><br>Foi adicionada uma nova mensagem ao pedido <b>' . sprintf("%06s", $_REQUEST['idPedidoAddRetornoMsg']) . '</b>!<br><br><b>Assunto: </b>' . $_REQUEST['assuntoAddRetornoMsg'] . '<br><br><b>Mensagem:</b> ' . nl2br($_REQUEST['msgAddRetornoMsg']) . '<br><br>Para ver e responder a essa mensagem, <a href="' . URL . 'admin/listarPedidos/' . $_REQUEST['idPedidoAddRetornoMsg'] . '">clique aqui</a>. Não responda por aqui, pois você estará respondendo a você mesmo.<br><br>Obrigado,<br><br>Equipe <b>' . $parametrosSite['title'] . '</b></td></tr></table></body></html>';
                $assuntoEmail = $parametrosSite['title'] . ' - Mensagem adicionada ao pedido ' . sprintf("%06s", $_REQUEST['idPedidoAddRetornoMsg']) . ' - ' . $_REQUEST['assuntoAddRetornoMsg'];
                $paraEmail = $parametrosSite['title'] . "<" . $parametrosSite['email'] . ">";
                $cabecalhoEmail = "Content-Type: text/html; charset=iso-8859-1\n";
                $cabecalhoEmail .= "From: " . $parametrosSite['title'] . "<" . $parametrosSite['email'] . ">\nReply-To: " . $parametrosSite['title'] . "<" . $parametrosSite['email'] . ">";
                //enviarEmail($parametrosSite['email'], "Contato - ".$parametrosSite['title'], $parametrosSite['email'], "Contato - ".$parametrosSite['title'], ($assuntoEmail), ($htmlEmail));
                mail(($paraEmail), ($assuntoEmail), ($htmlEmail), ($cabecalhoEmail));
                //echo $htmlEmail;
            }
            else{
                $sql = "INSERT INTO requests_messages (idRequest, idMensagem, assunto, mensagem, de, para, created_at, updated_at) VALUES ('" . $_REQUEST['idPedidoAddRetornoMsg'] . "', '" . $_REQUEST['idMensagemAddRetornoMsg'] . "', '" . $_REQUEST['assuntoAddRetornoMsg'] . "', '" . nl2br($_REQUEST['msgAddRetornoMsg']) . "', '1', '2', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
                mysqli_query($con, $sql) or die(mysqli_error($con));
                $htmlEmail = '<html><head><title>' . $parametrosSite['title'] . ' - Mensagem adicionada ao pedido ' . sprintf("%06s", $_REQUEST['idPedidoAddRetornoMsg']) . ' - ' . $_REQUEST['assuntoAddRetornoMsg'] . '</title></head><body><table width="100%" cellspacing="0" cellpadding="0" border="0"><tr><td width="250" style="text-align:center" valign="top"><img src="' . URL.'admin/img/logo.png" width="230"></td><td valign="top">Olá Equipe <b>' . $parametrosSite['title'] . '</b>,<br><br>Foi adicionada uma nova mensagem ao pedido <b>' . sprintf("%06s", $_REQUEST['idPedidoAddRetornoMsg']) . '</b>!<br><br><b>Assunto: </b>' . $_REQUEST['assuntoAddRetornoMsg'] . '<br><br><b>Mensagem:</b> ' . nl2br($_REQUEST['msgAddRetornoMsg']) . '<br><br>Para ver e responder a essa mensagem, <a href="' . URL . 'admin/listarPedidos/' . $_REQUEST['idPedidoAddRetornoMsg'] . '">clique aqui</a>. Não responda por aqui, pois você estará respondendo a você mesmo.<br><br>Obrigado,<br><br>Equipe <b>' . $parametrosSite['title'] . '</b></td></tr></table></body></html>';
                $assuntoEmail = $parametrosSite['title'] . ' - Mensagem adicionada ao pedido ' . sprintf("%06s", $_REQUEST['idPedidoAddRetornoMsg']) . ' - ' . $_REQUEST['assuntoAddRetornoMsg'];
                $paraEmail = $parametrosSite['title'] . "<" . $parametrosSite['email'] . ">";
                $cabecalhoEmail = "Content-Type: text/html; charset=iso-8859-1\n";
                $cabecalhoEmail .= "From: " . $parametrosSite['title'] . "<" . $parametrosSite['email'] . ">\nReply-To: " . $parametrosSite['title'] . "<" . $parametrosSite['email'] . ">";
                //enviarEmail($parametrosSite['email'], "Contato - ".$parametrosSite['title'], $row['emailCliente'], $row['nomeCliente'], $assuntoEmail, $htmlEmail);
                mail(($paraEmail), ($assuntoEmail), ($htmlEmail), ($cabecalhoEmail));
            }
            echo '1|-|' . $htmlEmail;
        }
        else{
            echo "0|-|Esse pedido não é seu! Tente novamente com um pedido seu!";
        }
        break;
    case "addRetornoMsg2":
        $sql = "SELECT * FROM requests WHERE id = '".$_REQUEST['idPedidoAddRetornoMsg2']."' AND client = '".$_SESSION['cliente']['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)) {
            if (!$_REQUEST['admin']) {
                $sql = "INSERT INTO requests_messages (idRequest, idMensagem, assunto, mensagem, de, para, created_at, updated_at) VALUES ('" . $_REQUEST['idPedidoAddRetornoMsg2'] . "', '" . $_REQUEST['idMensagemAddRetornoMsg2'] . "', '" . $_REQUEST['assuntoAddRetornoMsg2'] . "', '" . nl2br($_REQUEST['msgAddRetornoMsg2']) . "', '2', '1', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
                mysqli_query($con, $sql) or die(mysqli_error($con));
                $htmlEmail = '<html><head><title>' . $parametrosSite['title'] . ' - Mensagem adicionada ao pedido ' . sprintf("%06s", $_REQUEST['idPedidoAddRetornoMsg2']) . ' - ' . $_REQUEST['assuntoAddRetornoMsg2'] . '</title></head><body><table width="100%" cellspacing="0" cellpadding="0" border="0"><tr><td width="250" style="text-align:center" valign="top"><img src="' . URL.'admin/img/logo.png" width="230"></td><td valign="top">Olá Equipe <b>' . $parametrosSite['title'] . '</b>,<br><br>Foi adicionada uma nova mensagem ao pedido <b>' . sprintf("%06s", $_REQUEST['idPedidoAddRetornoMsg2']) . '</b>!<br><br><b>Assunto: </b>' . $_REQUEST['assuntoAddRetornoMsg2'] . '<br><br><b>Mensagem:</b> ' . nl2br($_REQUEST['msgAddRetornoMsg2']) . '<br><br>Para ver e responder a essa mensagem, <a href="' . URL . 'admin/listarPedidos/' . $_REQUEST['idPedidoAddRetornoMsg2'] . '">clique aqui</a>. Não responda por aqui, pois você estará respondendo a você mesmo.<br><br>Obrigado,<br><br>Equipe <b>' . $parametrosSite['title'] . '</b></td></tr></table></body></html>';
                $assuntoEmail = $parametrosSite['title'] . ' - Mensagem adicionada ao pedido ' . sprintf("%06s", $_REQUEST['idPedidoAddRetornoMsg2']) . ' - ' . $_REQUEST['assuntoAddRetornoMsg2'];
                $paraEmail = $parametrosSite['title'] . "<" . $parametrosSite['email'] . ">";
                $cabecalhoEmail = "Content-Type: text/html; charset=iso-8859-1\n";
                $cabecalhoEmail .= "From: " . $parametrosSite['title'] . "<" . $parametrosSite['email'] . ">\nReply-To: " . $parametrosSite['title'] . "<" . $parametrosSite['email'] . ">";
                //enviarEmail($parametrosSite['email'], "Contato - ".$parametrosSite['title'], $parametrosSite['email'], "Contato - ".$parametrosSite['title'], ($assuntoEmail), ($htmlEmail));
                mail(($paraEmail), ($assuntoEmail), ($htmlEmail), ($cabecalhoEmail));
                //echo $htmlEmail;
            }
            else{
                $sql = "INSERT INTO requests_messages (idRequest, idMensagem, assunto, mensagem, de, para, created_at, updated_at) VALUES ('" . $_REQUEST['idPedidoesque'] . "', '" . $_REQUEST['idMensagemAddRetornoMsg2'] . "', '" . $_REQUEST['assuntoAddRetornoMsg2'] . "', '" . nl2br($_REQUEST['msgAddRetornoMsg2']) . "', '1', '2', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
                mysqli_query($con, $sql) or die(mysqli_error($con));
                $htmlEmail = '<html><head><title>' . $parametrosSite['title'] . ' - Mensagem adicionada ao pedido ' . sprintf("%06s", $_REQUEST['idPedidoAddRetornoMsg']) . ' - ' . $_REQUEST['assuntoAddRetornoMsg'] . '</title></head><body><table width="100%" cellspacing="0" cellpadding="0" border="0"><tr><td width="250" style="text-align:center" valign="top"><img src="' . URL.'admin/img/logo.png" width="230"></td><td valign="top">Olá Equipe <b>' . $parametrosSite['title'] . '</b>,<br><br>Foi adicionada uma nova mensagem ao pedido <b>' . sprintf("%06s", $_REQUEST['idPedidoAddRetornoMsg2']) . '</b>!<br><br><b>Assunto: </b>' . $_REQUEST['assuntoAddRetornoMsg2'] . '<br><br><b>Mensagem:</b> ' . nl2br($_REQUEST['msgAddRetornoMsg2']) . '<br><br>Para ver e responder a essa mensagem, <a href="' . URL . 'admin/listarPedidos/' . $_REQUEST['idPedidoAddRetornoMsg'] . '">clique aqui</a>. Não responda por aqui, pois você estará respondendo a você mesmo.<br><br>Obrigado,<br><br>Equipe <b>' . $parametrosSite['title'] . '</b></td></tr></table></body></html>';
                $assuntoEmail = $parametrosSite['title'] . ' - Mensagem adicionada ao pedido ' . sprintf("%06s", $_REQUEST['idPedidoAddRetornoMsg2']) . ' - ' . $_REQUEST['assuntoAddRetornoMsg2'];
                $paraEmail = $parametrosSite['title'] . "<" . $parametrosSite['email'] . ">";
                $cabecalhoEmail = "Content-Type: text/html; charset=iso-8859-1\n";
                $cabecalhoEmail .= "From: " . $parametrosSite['title'] . "<" . $parametrosSite['email'] . ">\nReply-To: " . $parametrosSite['title'] . "<" . $parametrosSite['email'] . ">";
                //enviarEmail($parametrosSite['email'], "Contato - ".$parametrosSite['title'], $row['email'], $row['nome'], $assuntoEmail, $htmlEmail);
                mail(($paraEmail), ($assuntoEmail), ($htmlEmail), ($cabecalhoEmail));
            }
            echo '1|-|' . $htmlEmail;
        }
        else{
            echo "0|-|Esse pedido não é seu! Tente novamente com um pedido seu!";
        }
        break;
    case "addRetornoMsgAdmin":
        $sql = "SELECT a.*, b.name AS nomeCliente, b.email AS emailCliente FROM requests a INNER JOIN clients b ON (a.client = b.id) WHERE a.id = '".$_REQUEST['idPedidoAddRetornoMsg']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        $sql = "INSERT INTO requests_messages (idRequest, idMensagem, assunto, mensagem, de, para, created_at, updated_at) VALUES ('" . $_REQUEST['idPedidoAddRetornoMsg'] . "', '" . $_REQUEST['idMensagemAddRetornoMsg'] . "', '" . $_REQUEST['assuntoAddRetornoMsg'] . "', '" . nl2br($_REQUEST['msgAddRetornoMsg']) . "', '1', '2', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        mysqli_query($con, $sql) or die(mysqli_error($con));
        $htmlEmail = '<html><head><title>' . $parametrosSite['title'] . ' - Mensagem adicionada ao pedido ' . sprintf("%06s", $_REQUEST['idPedidoAddRetornoMsg']) . ' - ' . $_REQUEST['assuntoAddRetornoMsg'] . '</title></head><body><table width="100%" cellspacing="0" cellpadding="0" border="0"><tr><td width="250" style="text-align:center" valign="top"><img src="' . URL.'admin/img/logo.png" width="230"></td><td valign="top">Olá <b>' . $row['nomeCliente'] . '</b>,<br><br>Foi adicionada uma nova mensagem ao pedido <b>' . sprintf("%06s", $_REQUEST['idPedidoAddRetornoMsg']) . '</b>!<br><br><b>Assunto: </b>' . $_REQUEST['assuntoAddRetornoMsg'] . '<br><br><b>Mensagem:</b> ' . nl2br($_REQUEST['msgAddRetornoMsg']) . '<br><br>Para ver e responder a essa mensagem, <a href="' . URL . 'mensagensPedido/'.base64_encode($_REQUEST['idPedidoAddRetornoMsg']).'">clique aqui</a>. Caso você não esteja logado no site, ele pedirá pra você efetuar o seu login e depois libera a informação pra você.<br><br>Obrigado,<br><br>Equipe <b>' . $parametrosSite['title'] . '</b></td></tr></table></body></html>';
        $assuntoEmail = $parametrosSite['title'] . ' - Mensagem adicionada ao pedido ' . sprintf("%06s", $_REQUEST['idPedidoAddRetornoMsg']) . ' - ' . $_REQUEST['assuntoAddRetornoMsg'];
        $paraEmail = $row['nomeCliente'] . "<" . $row['emailCliente'] . ">";
        $cabecalhoEmail = "Content-Type: text/html; charset=iso-8859-1\n";
        $cabecalhoEmail .= "From: " . $parametrosSite['title'] . "<" . $parametrosSite['email'] . ">\nReply-To: " . $parametrosSite['title'] . "<" . $parametrosSite['email'] . ">";
        //enviarEmail($parametrosSite['email'], "Contato - ".$parametrosSite['title'], $row['emailCliente'], $row['nomeCliente'], ($assuntoEmail), $htmlEmail);
        //enviarEmail($parametrosSite['email'], "Contato - ".$parametrosSite['title'], $row['emailCliente'], $row['nomeCliente'], ($assuntoEmail), $htmlEmail);
		mail(($paraEmail), ($assuntoEmail), ($htmlEmail), ($cabecalhoEmail));
        echo '1|-|' . $htmlEmail;
        break;
    case "editMsgPedido":
        $sql = "UPDATE requests_messages SET assunto = '".$_REQUEST['assuntoEditMsgPedido']."', mensagem = '".nl2br($_REQUEST['msgEditMsgPedido'])."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEditMsgPedido']."'";
        mysqli_query($con, $sql);
        echo '1';
        break;
    case "pegaPedidos":
        $sql = "SELECT a.*, b.name AS nomeClient, c.name AS nomeStatus, d.name AS nomeFormaPagamento
                FROM requests a INNER JOIN clients b ON (a.client = b.id)
                INNER JOIN requests_statuses c ON (a.status = c.id)
                INNER JOIN payment_methods d ON (a.paymentMethod = d.id)
                WHERE a.client = '".$_SESSION['cliente']['id']."' ORDER BY a.created_at DESC";
        $query = mysqli_query($con, $sql);
        $html = "<a id='topoPedidos'></a>";
        if (!mysqli_num_rows($query)){
            $html .= '<div style="background-color: #FF0000; color: #FFFFFF; padding:15px; text-align: center"><h5>Nenhum pedido encontrado!</h5></div>';
        }
        else{
            while ($row = mysqli_fetch_array($query)) {
                if ($row['status'] == 1){
                    $backgroundColor = "#000000";
                    $color = "#FFFFFF";
                }
                elseif ($row['status'] == 2){
                    $backgroundColor = "#FFFF00";
                    $color = "#000000";
                }
                elseif ($row['status'] == 3){
                    $backgroundColor = "#006600";
                    $color = "#FFFFFF";
                }
                elseif ($row['status'] == 4){
                    $backgroundColor = "#000033";
                    $color = "#FFFFFF";
                }
                elseif ($row['status'] == 5){
                    $backgroundColor = "#FF0000";
                    $color = "#FFFFFF";
                }
                elseif ($row['status'] == 6){
                    $backgroundColor = "#FF0000";
                    $color = "#FFFFFF";
                }
                $html .= '<div onclick="abreDetalhesPedido(\''.$row['id'].'\', \''.URL.'\'); location.href=\'#topoPedidos\'" style="float:left; width:33%; padding:15px; cursor:pointer; background-color: '.$backgroundColor.'; color: '.$color.'; text-align: center"><h5>Pedido '.sprintf("%06s\n", $row['id']).'</h5><p>Cliente: <b>'.($row['nomeClient']).'</b><br>Forma de Pagamento: <b>'.($row['nomeFormaPagamento']).'</b><br>Status do Pedido: <b>'.($row['nomeStatus']).'</b></p></div>';
            }
        }
        echo "1|-|".$html;
        break;
    case "pegaEnderecos":
        $sql = "SELECT * FROM addresses WHERE idClient = '".$_SESSION['cliente']['id']."' ";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            while ($row = mysqli_fetch_array($query)){
                $html .= '<div class="col-md-12">
                <div style="position: absolute; left:80%"><img src="'.URL.'admin/img//editar.png" width="20" style="cursor:pointer" onclick=editaEndereco("'.$row['id'].'","'.URL.'")> <img src="'.URL.'admin/img//excluir.png" width="20" style="cursor:pointer" onclick=excluirEndereco("'.$row['id'].'","'.URL.'")></div>
                '.($row['address'].' - '.($row['number']));
                if ($row['complement']){ $html .= " - ".($row['complement']);}
                $html .= ' - Bairro: '.($row['neighborhood']).'<br>
                '.($row['city']." - ".$row['state']." - CEP: ".$row['cep']).'<br>
                '.($row['referencia']).'
                </div>';
                $i++;
            }
        }
        else{
            $html .= "<center>Sem nenhum endereço cadastrado!</center>";
        }
        echo "1|-|".$html;
        break;
    case "enviarAnuncieAqui":
        $sql = ("INSERT INTO anuncie_aqui (name, email, subject, phone, text, status, nome_banner, link_banner, target_banner, posicao_banner, tipo_banner, created_at, updated_at) VALUES ('".$_REQUEST['nome']."', '".$_REQUEST['email']."', '".$_REQUEST['assunto']."', '".$_REQUEST['phone']."', '".$_REQUEST['mensagem']."', '1', '".$_REQUEST['nome_banner']."', '".$_REQUEST['link_banner']."', '".$_REQUEST['target_banner']."', '".$_REQUEST['posicao_banner']."', '".$_REQUEST['tipo_banner']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
        $query = mysqli_query($con, $sql);
        $idAnuncieAqui = mysqli_insert_id($con);
        if (preg_match("/jpg/", $_FILES['banner']['name']) || preg_match("/jpeg/", $_FILES['banner']['name'])){
            $img = "anuncieAqui".$idAnuncieAqui.".jpg";
        }
        elseif (preg_match("/gif/", $_FILES['banner']['name'])){
            $img = "anuncieAqui".$idAnuncieAqui.".gif";
        }
        elseif (preg_match("/png/", $_FILES['banner']['name'])){
            $img = "anuncieAqui".$idAnuncieAqui.".png";
        }
        elseif (preg_match("/bmp/", $_FILES['banner']['name'])){
            $img = "anuncieAqui".$idAnuncieAqui.".bmp";
        }
        elseif (preg_match("/webp/", $_FILES['banner']['name'])){
            $img = "anuncieAqui".$idAnuncieAqui.".webp";
        }
        if ($img){
            copy($_FILES['banner']['tmp_name'], DIRETORIO."assets/img/upload/".$img);
        }
        $sql = "UPDATE anuncie_aqui SET img = '".$img."' WHERE id = '".$idAnuncieAqui."'";
        $query = mysqli_query($con, $sql);
        $htmlEmail = ("<html><head><title>Email Enviado pelo formulário do anuncie aqui do ".$parametrosSite['title']."</title></head><body><table width='100%' border='0' cellpadding='0' cellspacing='0'><tr><td width='150' valign='top'><img src='".URL."admin/img/logo.png'></td><td valign='top'>Olá <b>Equipe ".$parametrosSite['title']."</b>,<br>Foi enviado um email pelo formulário de anuncie aqui do ".$parametrosSite['title']."<br><br>Dados da Mensagem:<br><br>Nome: <b>".$_REQUEST['nome']."</b><br>Email: <b>".$_REQUEST['email']."</b><br>Assunto: <b>".$_REQUEST['assunto']."</b><br>Telefone: <b>".$_REQUEST['phone']."</b><br>Mensagem: <b>".$_REQUEST['message']."</b><br>Data/Hora de Envio: <b>".date('d/m/Y H:i:s')."</b>");
        $htmlEmail .= "<br><br>Para ver essa mensagem no admin, <a href='".URL."admin/faleConosco'>clique aqui.</a><br><br></br>Atenciosamente,<br><br>Equipe ".$parametrosSite['title']."<hr noshade><center>Email Desenvolvido Pela <a href='https://www.bhcommerce.com.br/'>BH Commerce</a></center><hr noshade></body></html>";
        $assunto = $parametrosSite['title'].(" - Email enviado pelo formulário de Anuncie Aqui do Site");
        $paraNome = $row['nome'];
        $paraEmail = $row['email'];
        $cabecalhoEmail = "Content-Type: text/html; charset=iso-8859-1\n";
        $cabecalhoEmail .= "From: ".$parametrosSite['title']."<".$parametrosSite['email'].">\nReply-To: ".$parametrosSite['title']."<".$parametrosSite['email'].">";
        //enviarEmail($parametrosSite['email'], $parametrosSite['title'], $parametrosSite['email'], $parametrosSite['title'], $assunto, $htmlEmail);
        mail($parametrosSite['title']."<".$parametrosSite['email'].">", $assunto, $htmlEmail, $cabecalhoEmail);
        echo "1|-|".($_SESSION['cliente']['nome'])."|-|".$_SESSION['cliente']['email'];
        break;
    case "editarEndereco":
        $sql = "SELECT * FROM addresses WHERE id = '".$_REQUEST['id']."' AND idClient = '".$_SESSION['cliente']['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)) {
            $row = mysqli_fetch_array($query);
            echo ("1|-|" . $row['id'] . "|-|" . $row['cep'] . "|-|" . $row['address'] . "|-|" . $row['number'] . "|-|" . $row['complement'] . "|-|" . $row['neighborhood'] . "|-|" . $row['city'] . "|-|" . $row['state']."|-|".$row['referencia']);
        }
        else{
            echo "0|-|Não foi encontrado o endereço para o cliente!";
        }
        break;
    case "excluirEndereco":
        $_REQUEST['cliente'] = ($_REQUEST['cliente']) ? $_REQUEST['cliente'] : $_SESSION['cliente']['id'];
        $sql = "SELECT * FROM addresses WHERE id = '".$_REQUEST['id']."' AND idClient = '".$_REQUEST['cliente']."' ";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)) {
            $sql = "SELECT * FROM addresses WHERE id = '" . $_REQUEST['id'] . "'";
            $query = mysqli_query($con, $sql);
            $row = mysqli_fetch_array($query);
            $sql = "INSERT INTO logs (user, action, created_at, updated_at) VALUES ('" . $_REQUEST['user'] . "', '" . ("Excluiu o endereço do cliente ") . $row['idClient'] . " - ID: " . $_REQUEST['id'] . "', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
            mysqli_query($con, $sql);
            $sql = "UPDATE addresses SET deleted_at = '".date('Y-m-d H:i:s')."' WHERE id = '" . $_REQUEST['id'] . "'";
            mysqli_query($con, $sql);
            echo '1';
        }
        else{
            echo "0|-|Este endereço não é seu! Só é possível excluir seus endereços!";
        }
        break;
    case "cadastraEndereco":
        $sql = ("INSERT INTO addresses (idClient, name, cep, address, number, complement, neighborhood, city, state, referencia, created_at, updated_at) VALUES ('".$_REQUEST['idCliente']."', '".$_REQUEST['nome']."', '".$_REQUEST['cepEndereco']."', '".$_REQUEST['logradouroEndereco']."', '".$_REQUEST['numeroEndereco']."', '".$_REQUEST['complementoEndereco']."', '".$_REQUEST['bairroEndereco']."', '".$_REQUEST['cidadeEndereco']."', '".$_REQUEST['estadoEndereco']."', '".$_REQUEST['referenciaEndereco']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
        mysqli_query($con, $sql);
        echo "1";
        break;
    case "salvarEndereco":
        $sql = ("INSERT INTO addresses (idClient, name, cep, address, number, complement, neighborhood, city, state, created_at, updated_at) VALUES ('".$_REQUEST['idClienteEndereco']."', '".$_REQUEST['nome']."', '".$_REQUEST['cepEndereco']."', '".$_REQUEST['logradouroEndereco']."', '".$_REQUEST['numeroEndereco']."', '".$_REQUEST['complementoEndereco']."', '".$_REQUEST['bairroEndereco']."', '".$_REQUEST['cidadeEndereco']."', '".$_REQUEST['estadoEndereco']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
        mysqli_query($con, $sql);
        echo "1";
        break;
    case "atualizarEndereco":
        $sql = ("UPDATE addresses SET idClient = '".$_SESSION['cliente']['id']."', cep = '".$_REQUEST['cepEditarEndereco']."', address = '".$_REQUEST['logradouroEditarEndereco']."', number = '".$_REQUEST['numeroEditarEndereco']."', complement = '".$_REQUEST['complementoEditarEndereco']."', neighborhood = '".$_REQUEST['bairroEditarEndereco']."', city = '".$_REQUEST['cidadeEditarEndereco']."', state = '".$_REQUEST['estadoEditarEndereco']."', referencia = '".$_REQUEST['referenciaEditarEndereco']."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_REQUEST['idEditarEndereco']."'");
        mysqli_query($con, $sql);
        echo "1";
        break;
    case "visualizaEnderecos":
        echo '1|-|';
        $sql = "INSERT INTO logs (user, action, created_at, updated_at) VALUES ('".$_REQUEST['user']."', '".("Visualizou os endereços do cliente ").$_REQUEST['id']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        mysqli_query($con, $sql);
        echo '<button type="button" class="btn btn-primary" onclick=abre("modalCadastraEndereco")>Cadastrar novo</button>
                <div style="display:none; position:absolute; width: 100%" id="modalCadastraEndereco" tabindex="-1">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">'.("Cadastro de Endereço").'</h5>
                                <button type="button" class="close" onclick=fecha("modalCadastraEndereco")>
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <form action="#" method="get" id="formAtualizaEndereco">
                                <div class="modal-body">
                                    <input type="hidden" id="idCliente" name="idCliente" value="'.$_REQUEST['id'].'">
                                    <input type="hidden" id="urlEndereco" nome="urlEndereco" value="'.URL.'">
                                    <label for="cepEndereco">Cep:</label>
                                    <input type="text" placeholder="Cep..." name="cepEndereco" value="" onkeypress=mascara(this,"00000-000",event) id="cepEndereco" required class="form-control" onkeyup=verificacepcadastraendereco(this.value)>
                                    <sup>Somente Números</sup><br>
                                    <label for="logradouroEndereco">Logradouro:</label>
                                    <input type="text" placeholder="Logradouro..." value="" name="logradouroEndereco" id="logradouroEndereco" required class="form-control">
                                    <label for="numeroEndereco">Número:</label>
                                    <input type="text" placeholder="Número..." value="" name="numeroEndereco" id="numeroEndereco" required class="form-control">
                                    <label for="complementoEndereco">Complemento:</label>
                                    <input type="text" placeholder="Complemento..." value="" name="complementoEndereco" id="complementoEndereco" class="form-control">
                                    <label for="bairroEndereco">Bairro:</label>
                                    <input type="text" placeholder="Bairro..." value="" name="bairroEndereco" id="bairroEndereco" required class="form-control">
                                    <label for="cidadeEndereco">Cidade:</label>
                                    <input type="text" placeholder="Cidade..." value="" name="cidadeEndereco" id="cidadeEndereco" required class="form-control">
                                    <label for="estadoEndereco">Estado:</label>
                                    <select name="estadoEndereco" id="estadoEndereco" required class="form-control">
                                        <option value="">UF</option>
                                        ';
        $sql = "SELECT * FROM states ORDER BY sigla ASC";
        $query2 = mysqli_query($con, $sql);
        while ($row2 = mysqli_fetch_array($query2)) {
            echo '
                                        <option value="'.$row2['sigla'].'">'.$row2['sigla'].'</option>';
        }
        echo '
                                    </select>
                                    <label for="referenciaEndereco">Ponto de Referência:</label>
                                    <input type="text" placeholder="Ponto de Referência..." value="" name="referenciaEndereco" id="referenciaEndereco" required class="form-control">
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" onclick=fecha("modalCadastraEndereco")>Fechar</button>
                                    <button type="button" class="btn btn-primary" onClick=cadastrarEndereco("","'.URL.'","'.$_REQUEST['id'].'","'.$_REQUEST['user'].'")>Cadastrar Endereço</button>
                                </div>
                                </form>
                            </div>
                            </div>
                            </div>';
        $sql = "SELECT * FROM addresses WHERE idClient = '".$_REQUEST['id']."' ";
        $query = mysqli_query($con, $sql);
        if (!mysqli_num_rows($query)){
            echo "<div style='width:100%; background-color:#990000; color:#FFFFFF; text-align: center' id='registros'>Nenhum endereço encontrado!</div>";
        }
        else{
            echo '<table border="0" width="100%" cellpadding="0" cellspacing="0"><tr><th>CEP do Endereço</th><th>Endereço</th><th>Ações</th></tr>';
            while($row = mysqli_fetch_array($query)){
                echo ('<tr');
                if ($i % 2 == 1){
                    echo ' style="background-color:#e7e7e7"';
                }
                echo ('><td>'.$row['cep'].'</td><td>'.$row['address'].' - '.$row['number']);
                if ($row['complement']){
                    echo (' - '.$row['complement']);
                }
                echo (' - B. '.$row['neighborhood'].' - '.$row['city'].' - '.$row['state'].' - '.$row['referencia'].'</td><td><a onclick=abre("modalAtualizaEndereco'.$row['id'].$_REQUEST['id'].'") style="cursor:pointer"><img src="'.URL.'admin/img//editar.png" width="20"></a> <img src="'.URL.'admin/img//excluir.png" style="cursor: pointer" onclick=excluirEndereco("'.$row['id'].'","'.URL.'","'.$_REQUEST['id'].'","'.$_REQUEST['user'].'") width="20"></td></tr>');
                echo '<script>
function retornoCEPAtualizaEndereco'.$row['id'].$_REQUEST['id'].'(conteudo) {
    if (!("erro" in conteudo)) {
        //Atualiza os campos com os valores.
        document.getElementById("logradouroEndereco'.$row['id'].$_REQUEST['id'].'").value=(conteudo.logradouro);
        document.getElementById(\'numeroEndereco'.$row['id'].$_REQUEST['id'].'\').value="";
        document.getElementById(\'complementoEndereco'.$row['id'].$_REQUEST['id'].'\').value="";
        document.getElementById(\'bairroEndereco'.$row['id'].$_REQUEST['id'].'\').value=(conteudo.bairro);
        document.getElementById(\'cidadeEndereco'.$row['id'].$_REQUEST['id'].'\').value=(conteudo.localidade);
        document.getElementById(\'estadoEndereco'.$row['id'].$_REQUEST['id'].'\').value=(conteudo.uf);
        document.getElementById(\'numeroEndereco'.$row['id'].$_REQUEST['id'].'\').focus();
    } //end if.
    else {
        //CEP não Encontrado.
        alert("CEP não encontrado. Digeite as informações manualmente!");
        document.getElementById(\'logradouroEndereco'.$row['id'].$_REQUEST['id'].'\').value="";
        document.getElementById(\'bairroEndereco'.$row['id'].$_REQUEST['id'].'\').value="";
        document.getElementById(\'numeroEndereco'.$row['id'].$_REQUEST['id'].'\').value="";
        document.getElementById(\'complementoEndereco'.$row['id'].$_REQUEST['id'].'\').value="";
        document.getElementById(\'cidadeEndereco'.$row['id'].$_REQUEST['id'].'\').value="";
        document.getElementById(\'estadoEndereco'.$row['id'].$_REQUEST['id'].'\').value="";
        document.getElementById(\'logradouroEndereco'.$row['id'].$_REQUEST['id'].'\').focus();
    }
}
                </script>
                <div style="display:none; position:absolute; width: 100%" id="modalAtualizaEndereco'.$row['id'].$_REQUEST['id'].'" tabindex="-1">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">'.("Atualização de Endereço").'</h5>
                                <button type="button" class="close" onclick=fecha("modalAtualizaEndereco'.$row['id'].$_REQUEST['id'].'")>
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <form action="#" method="get" id="formAtualizaEndereco">
                                <div class="modal-body">
                                    <input type="hidden" id="idCliente'.$row['id'].$_REQUEST['id'].'" name="idCliente'.$row['id'].$_REQUEST['id'].'" value="'.$_REQUEST['id'].'">
                                    <input type="hidden" id="idEndereco'.$row['id'].$_REQUEST['id'].'" name="idEndereco'.$row['id'].$_REQUEST['id'].'" value="'.$row['id'].'">
                                    <input type="hidden" id="urlEndereco" nome="urlEndereco" value="'.URL.'">
                                    <label for="cepEndereco'.$row['id'].$_REQUEST['id'].'">Cep:</label>
                                    <input type="text" placeholder="Cep..." name="cepEndereco'.$row['id'].$_REQUEST['id'].'" value="'.$row['cep'].'" onkeypress="return mascara(this, \'00000-000\', event)" id="cepEndereco'.$row['id'].$_REQUEST['id'].'" required class="form-control" onkeyup=verificacepatualizaendereco(this.value,"'.$row['id'].'","'.$_REQUEST['id'].'")>
                                    <sup>Somente Números</sup><br>
                                    <label for="logradouroEnderecoo'.$row['id'].$_REQUEST['id'].'">Logradouro:</label>
                                    <input type="text" placeholder="Logradouro..." value="'.($row['address']).'" name="logradouroEndereco'.$row['id'].$_REQUEST['id'].'" id="logradouroEndereco'.$row['id'].$_REQUEST['id'].'" required class="form-control">
                                    <label for="numeroEndereco'.$row['id'].$_REQUEST['id'].'">Número:</label>
                                    <input type="text" placeholder="Número..." value="'.($row['number']).'" name="numeroEndereco'.$row['id'].$_REQUEST['id'].'" id="numeroEndereco'.$row['id'].$_REQUEST['id'].'" required class="form-control">
                                    <label for="complementoEndereco'.$row['id'].$_REQUEST['id'].'">Complemento:</label>
                                    <input type="text" placeholder="Complemento..." value="'.($row['complement']).'" name="complementoEndereco'.$row['id'].$_REQUEST['id'].'" id="complementoEndereco'.$row['id'].$_REQUEST['id'].'" class="form-control">
                                    <label for="bairroEndereco'.$row['id'].$_REQUEST['id'].'">Bairro:</label>
                                    <input type="text" placeholder="Bairro..." value="'.($row['neighborhood']).'" name="bairroEndereco'.$row['id'].$_REQUEST['id'].'" id="bairroEndereco'.$row['id'].$_REQUEST['id'].'" required class="form-control">
                                    <label for="cidadeEndereco'.$row['id'].$_REQUEST['id'].'">Cidade:</label>
                                    <input type="text" placeholder="Cidade..." value="'.($row['city']).'" name="cidadeEndereco'.$row['id'].$_REQUEST['id'].'" id="cidadeEndereco'.$row['id'].$_REQUEST['id'].'" required class="form-control">
                                    <label for="estadoEndereco'.$row['id'].$_REQUEST['id'].'">Estado:</label>
                                    <select name="estadoEndereco'.$row['id'].$_REQUEST['id'].'" id="estadoEndereco'.$row['id'].$_REQUEST['id'].'" required class="form-control">
                                        <option value="">UF</option>
                                        ';
        $sql = "SELECT * FROM states ORDER BY sigla ASC";
        $query2 = mysqli_query($con, $sql);
        while ($row2 = mysqli_fetch_array($query2)) {
            echo '
                                        <option value="'.$row2['sigla'].'" ';
            if ($row['state'] == $row2['sigla']){
                echo 'selected';
            }
            echo '>'.($row2['sigla']).'</option>';
        }
        echo ('
                                    </select>
                                    <label for="referenciaEndereco'.$row['id'].$_REQUEST['id'].'">'.('Ponto de Referência').':</label>
                                    <input type="text" placeholder="Ponto de Referência..." value="'.($row['referencia']).'" name="referenciaEndereco'.$row['id'].$_REQUEST['id'].'" id="referenciaEndereco'.$row['id'].$_REQUEST['id'].'" required class="form-control">
                                   
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                                    <button type="button" class="btn btn-primary" onClick=atualizarEndereco("'.$row['id'].'","'.URL.'","'.$_REQUEST['id'].'","'.$_REQUEST['user'].'")>'.("Atualizar Endereço").'</button>
                                </div>
                                </form>
                            </div>
                            </div>');
                $i++;
            }
            echo '</table>';
        }   echo '</div>';
        break;
    case "cadastro":
        $sql = "SELECT * FROM clients WHERE email = '" . $_REQUEST['emailCadastro'] . "'";
        $query = mysqli_query($con, $sql);
        if (!mysqli_num_rows($query)) {
            $sql = ("INSERT INTO clients (name, email, cel, typeDocument, document, password, created_at, updated_at) VALUES ('" . $_REQUEST['nomeCadastro'] . "', '" . $_REQUEST['emailCadastro'] . "', '" . $_REQUEST['celCadastro'] . "', '" . $_REQUEST['tipoDocumentoCadastro'] . "', '" . $_REQUEST['documentoCadastro'] . "', '" . md5($_REQUEST['senhaCadastro']) . "', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')");
            $query = mysqli_query($con, $sql);
            $idCliente = mysqli_insert_id($con);
            $_SESSION['cliente']['id'] = $idCliente;
            $_SESSION['cliente']['nome'] = ($_REQUEST['nomeCadastro']);
            $_SESSION['cliente']['email'] = $_REQUEST['emailCadastro'];
            echo '1';
        }
        else{
            echo "0|-|Já existe esse email cadastrado em nosso banco de dados!";
        }
        break;
    case "atualizarCadastro":
        $sql = "SELECT * FROM clients WHERE id = '".$_SESSION['cliente']['id']."'";
        $query = mysqli_query($con, $sql);
        $row = mysqli_fetch_array($query);
        if ($row['email'] != $_REQUEST['emailMeuCadastro']){
            $sql = "SELECT * FROM clients WHERE id != '".$_SESSION['cliente']['id']."' AND email = '".$_REQUEST['emailMeuCadastro']."'";
            $query = mysqli_query($con, $sql);
            if (mysqli_num_rows($query)){
                echo "0|-|Já existe outro cliente cadastrado com esse email. Utilize outro.";
            }
            else{
                $sql = ("UPDATE clients SET name = '".$_REQUEST['nomeMeuCadastro']."', email = '".$_REQUEST['emailMeuCadastro']."', cel = '".$_REQUEST['telefoneMeuCadastro']."', typeDocument = '".$_REQUEST['tipoDocumentoMeuCadastro']."', document = '".$_REQUEST['documentoMeuCadastro']."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_SESSION['cliente']['id']."'");
                mysqli_query($con, $sql);
                echo '1|-|'.$_REQUEST['nomeMeuCadastro'];
            }
        }
        else {
            $sql = ("UPDATE clients SET name = '".$_REQUEST['nomeMeuCadastro']."', email = '".$_REQUEST['emailMeuCadastro']."', cel = '".$_REQUEST['telefoneMeuCadastro']."', typeDocument = '".$_REQUEST['tipoDocumentoMeuCadastro']."', document = '".$_REQUEST['documentoMeuCadastro']."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_SESSION['cliente']['id']."'");
            mysqli_query($con, $sql) or die (mysqli_error($sql)."\r\n".$sql);
            echo ('1|-|'.$_REQUEST['nomeMeuCadastro']);
        }
        break;
    case "atualizarSenha":
        $sql = "SELECT * FROM clients WHERE id = '".$_SESSION['cliente']['id']."' AND password = '".md5($_REQUEST['senhaAtualAlterarSenha'])."'";
        $query = mysqli_query($con, $sql);
        if (!mysqli_num_rows($query)){
            echo "0|-|Senha informada incorretamente!|-|senhaAtualAlterarSenha";
        }
        elseif($_REQUEST['novaSenhaAlterarSenha'] != $_REQUEST['redigitoSenhaAlterarSenha']){
            echo "0|-|Nova senha e redígito devem estar iguais!|-|novaSenhaAlterarSenha";
        }
        else{
            $sql = ("UPDATE clients SET password = '".md5($_REQUEST['novaSenhaAlterarSenha'])."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$_SESSION['cliente']['id']."'");
            mysqli_query($con, $sql);
            echo '1';
        }
        break;
    case "alterarSenha":
        if ($_REQUEST['novaSenhaAlterarSenha'] != $_REQUEST['redigitoSenhaAlterarSenha']){
            echo "0|-|As senhas digitadas não coincidem!";
        }
        else{
            $sql = "UPDATE clients SET password = '".md5($_REQUEST['senhaAtualAlterarSenha'])."', updated_at = '".date('Y-m-d H:i:s')."', remember_token = '' WHERE id = '".$_REQUEST['idCliente']."'";
            mysqli_query($con, $sql);
            $sql = "SELECT * FROM clients WHERE id = '".$_REQUEST['idCliente']."'";
            $query = mysqli_query($con, $sql);
            $row = mysqli_fetch_array($query);
            $_SESSION['cliente']['id'] = $row['id'];
            $_SESSION['cliente']['nome'] = $row['name'];
            $_SESSION['cliente']['email'] = $row['email'];
            echo "1|-|Senha alterada com sucesso!";
        }
        break;
    case "logout":
        $_SESSION['cliente']['id'] = "";
        $_SESSION['cliente']['nome'] = "";
        $_SESSION['cliente']['email'] = "";
        echo "1";
        break;
    case "enviarEsqueceuSuaSenha":
        $sql = "SELECT * FROM clients WHERE email = '".$_REQUEST['emailEsqueceuSuaSenha']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)) {
            $row = mysqli_fetch_array($query);
            $remember_token = (rand(0, 9).rand(0,9).rand(0, 9).rand(0, 9).rand(0,9).rand(0,9));
            $sql = "UPDATE clients SET remember_token = '".$remember_token."', updated_at = '".date('Y-m-d H:i:s')."' WHERE id = '".$row['id']."'";
            mysqli_query($con, $sql);
            $htmlEmail = '<html><head><title>Email de recuperação de senha - BH Commerce</title></head><body><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td width="250" style="width: 250px; text-align: center;"><img src="'.URL.'files/logo.png" width="200"></td><td>Olá '.($row['name']).',<br><br>Para acessar o link para alterar a sua senha, <a href="'.URL.'alterar-senha/'.$remember_token.'">clique aqui</a>.<br><br>Atenciosamente,<br><br>Equipe BH Commerce</td></tr></table></body></html>';
            //echo $htmlEmail;
            $assuntoEmail = "Email de recuperação de senha - BH Commerce";
            $paraEmail = $row['nome']."<".$row['email'].">";
            $cabecalhoEmail = "Content-Type: text/html; charset=iso-8859-1\n";
            $cabecalhoEmail .= "From: Contato - BH Commerce<contato@bhcommerce.com.br>\nReply-To: Contato - BH Commerce<contato@bhcommerce.com.br>";
            //enviarEmail($parametrosSite['email'], "Contato - ".$parametrosSite['title'], $row['email'], $row['nome'], ($assuntoEmail), ($htmlEmail));
            mail(($paraEmail), ($assuntoEmail), ($htmlEmail), ($cabecalhoEmail));
            echo "1";
        }
        else{
            echo "0|-|Email não encontrado em nossa base de dados!";
        }
        break;
    case "realizarLogin":
		$_REQUEST['emailLogin'] = ($_REQUEST['emailLogin']) ? $_REQUEST['emailLogin'] : $_REQUEST['emailLogin2'];
		$_REQUEST['senhaLogin'] = ($_REQUEST['senhaLogin']) ? $_REQUEST['senhaLogin'] : $_REQUEST['senhaLogin2'];
        $sql = "SELECT * FROM clients  WHERE email = '".$_REQUEST['emailLogin']."' AND password = '".md5($_REQUEST['senhaLogin'])."'";
		$query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $row = mysqli_fetch_array($query);
            $_SESSION['cliente']['nome'] = $row['name'];
            $_SESSION['cliente']['email'] = $row['email'];
            $_SESSION['cliente']['id'] = $row['id'];
            echo "1";
        }
        else{
            echo "0|-|Não existe cliente com o email ou senha informados!";
        }
        break;
    case "salvarNews":
        $email['nome'] = "Contato - ".$parametrosSite['title']."<".$parametrosSite['email'].">";
        $email['assunto'] = "Email cadastrado na newsletter com sucesso! - BH Commerce";
        $email['cabecalho'] = "Content-Type: text/html; charset=iso-8859-1\n";
        $email['cabecalho'] .= "From: Contato - ".$parametrosSite['title']."<".$parametrosSite['email'].">\nReply-To: Contato - ".$parametrosSite['title']."<".$parametrosSite['email'].">";
        $email['corpo'] = '<html><head><title>'.$email['assunto'].'</title></head><body><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td width="250" style="width: 250px; text-align: center;"><img src="'.URL_SITE.'img/logo.png" width="200"></td><td>Olá, o email <b>"'.$_REQUEST['emailNews'].'"</b>, foi cadastrado em nossa newsletter em '.date('d/m/Y H:i').'h.<br><br>Atenciosamente,<br><br>Equipe <a href="https://www.bhcommerce.com.br">BH Commerce</a></td></tr></table></body></html>';
        //enviarEmail($parametrosSite['email'], "Contato - ".$parametrosSite['title'], $parametrosSite['email'], "Contato - ".$parametrosSite['title'], ($email['assunto']), ($email['corpo']));
        mail("Contato - ".$parametrosSite['title']."<".$parametrosSite['email'].">", ($email['assunto']), ($email['corpo']), $email['cabecalho']);
        $sql = "SELECT * FROM newsletters WHERE email = '".$_REQUEST['emailNews']."'";
        $query = mysqli_query($con, $sql);
        if (!mysqli_num_rows($query)) {
            $sql = "INSERT INTO newsletters (name, email, created_at, updated_at) VALUES ('" . ($_REQUEST['nomeNews'] . "', '" . $_REQUEST['emailNews']) . "', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        }
        else{
            $sql = "UPDATE newsletters SET name = '".$_REQUEST['nomeNews']."', updated_at = '".date('Y-m-d H:i:s')."', deleted_at = NULL WHERE email = '".$_REQUEST['emailNews']."'";
        }
        mysqli_query($con, $sql);
        echo "1|-|".($_SESSION['cliente']['nome'])."|-|".$_SESSION['cliente']['email'];
        break;
    case "salvarContato":
        $email['nome'] = $parametrosSite['title']." <".$parametrosSite['email'].">";
        $email['assunto'] = ("Email enviado pelo formulário de Fale Conosco do Site - BH Commerce");
        $email['cabecalho'] = "Content-Type: text/html; charset=iso-8859-1\n";
        $email['cabecalho'] .= "From: Contato - ".$parametrosSite['title']." <".$parametrosSite['email'].">\nReply-To: Contato - ".$parametrosSite['title']." <".$parametrosSite['email'].">";
        $email['corpo'] = ('<html><head><title>'.$email['assunto'].'</title></head><body><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td width="250" style="width: 250px; text-align: center;"><img src="'.URL.'admin/img//logo.png" width="200"></td><td>Olá, foi enviado um novo email a partir do formulário de fale conosco do site. <br><b>Nome: </b> '.$_REQUEST['nomeContato'].'<br><b>Email: </b> '.$_REQUEST['emailContato'].'<br><b>Telefone: </b> '.$_REQUEST['phoneContato'].'<br><b>Assunto: </b> '.($email['assunto']).'<br><b>Mensagem: </b> '.nl2br($_REQUEST['mensagemContato']).'<br><b></b>Data/Hora do envio: <b>'.date('d/m/Y').' às '.date('H:i:s').'h</b><br><br>Para visualizar esse contato no admin, <a href="'.URL_SITE.'admin/faleConosco">clique aqui</a>.<br><br>Atenciosamente,<br><br>Equipe <a href="https://www.bhcommerce.com.br">BH Commerce</a></td></tr></table></body></html>');
        //enviarEmail($parametrosSite['email'], "Contato - ".$parametrosSite['title'], $parametrosSite['email'], "Contato - ".$parametrosSite['title'], $email['assunto'], $email['corpo']);
        mail($email['nome'], $email['assunto'], $email['corpo'], $email['cabecalho']);
        $sql = "INSERT INTO messages (name, email, subject, phone, text, status, created_at, updated_at) VALUES ('".($_REQUEST['nomeContato']."', '".$_REQUEST['emailContato']."', '".($email['assunto'])."', '".$_REQUEST['phoneContato']."', '".$_REQUEST['mensagemContato'])."', '1', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        mysqli_query($con, $sql) or die(mysqli_error($con)."\r\n".$sql);
        echo "1|-|".($_SESSION['cliente']['nome'])."|-|".$_SESSION['cliente']['email'];
        break;
    case "salvarBugTracking":
        $sql = "SELECT * FROM  types_services WHERE id = '".$_REQUEST['tipoServicoBugTracking']."'";
        $query = mysqli_query($con, $sql);
        $rowTipoServico = mysqli_fetch_array($query);
        $sql = "SELECT * FROM  type_versions WHERE id = '".$_REQUEST['tipoVersaoBugTracking']."'";
        $query = mysqli_query($con, $sql);
        $rowTipoVersao = mysqli_fetch_array($query);
        $sql = "SELECT * FROM  priorities WHERE id = '".$_REQUEST['prioridadeBugTracking']."'";
        $query = mysqli_query($con, $sql);
        $rowPrioridade = mysqli_fetch_array($query);
        $sql = "SELECT * FROM  categories WHERE id = '".$_REQUEST['categoriaBugTracking']."'";
        $query = mysqli_query($con, $sql);
        $rowCategoria = mysqli_fetch_array($query);
        $email['nome'] = "BH Commerce <henrique@bhcommerce.com.br>";
        $email['assunto'] = ("Email enviado pelo formulário de Bug Tracking do Site - BH Commerce - ".$_REQUEST['tituloBugTracking']);
        $email['cabecalho'] = "Content-Type: text/html; charset=iso-8859-1\n";
        $email['cabecalho'] .= "From: Henrique Marcandier - BH Commerce<henrique@bhcommerce.com.br>\nReply-To: Henrique Marcandier - BH Commerce<henrique@bhcommerce.com.br>";
        $email['corpo'] = ('<html><head><title>'.$email['assunto'].'</title></head><body><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td width="250" style="width: 250px; text-align: center;" valign="top"><img src="'.URL.'admin/img//logo.png" width="200"></td><td>Olá, foi enviado um novo email a partir do formulário de bug tracking do site. <br><b>Nome: </b> '.$_REQUEST['nomeBugTracking'].'<br><b>Email: </b> '.$_REQUEST['emailBugTracking'].'<br><b>Tipo de Serviço: </b> '.($rowTipoServico['name']).'<br><b>Versão: </b> '.($rowTipoVersao['name']).'<br><b>Prioridade: </b> '.($rowPrioridade['name']).'<br><b>Categoria: </b> '.($rowCategoria['name']).'<br><b>Título: </b> '.$_REQUEST['tituloBugTracking'].'<br><b>Mensagem: </b> '.nl2br($_REQUEST['mensagemBugTracking']).'<br><b>Status: </b>Enviado<br><br>Atenciosamente,<br><br>Equipe <a href="https://www.bhcommerce.com.br">BH Commerce</a></td></tr></table></body></html>');
        enviarEmail($parametrosSite['email'], "Contato - ".$parametrosSite['title'], $parametrosSite['email'], "Contato - ".$parametrosSite['title'], $email['assunto'], $email['corpo']);
        //mail($email['nome'], $email['assunto'], $email['corpo'], $email['cabecalho']);
        $sql = "INSERT INTO bug_trackings (typeService, typeVersion, priority, category, name, email, title, message, created_at, updated_at) VALUES ('".($_REQUEST['tipoServicoBugTracking']."', '".$_REQUEST['tipoVersaoBugTracking']."', '".$_REQUEST['prioridadeBugTracking']."', '".$_REQUEST['categoriaBugTracking']."', '".$_REQUEST['nomeBugTracking']."', '".$_REQUEST['emailBugTracking']."', '".$_REQUEST['tituloBugTracking']."', '".$_REQUEST['mensagemBugTracking'])."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        mysqli_query($con, $sql) or die(mysqli_error($con)."<br>".$sql);
        echo "1|-|".($_SESSION['cliente']['nome'])."|-|".$_SESSION['cliente']['email'];
        break;
    case 'selecionaTipoServicoAdmin':
        echo "1|-|<select name=\"typeVersion\" id=\"typeVersion\" required class='form-control'>
                                <option value=\"\">Selecione a versão corretamente</option>";
        $sql = "SELECT * FROM type_versions WHERE typeService = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            while ($row = mysqli_fetch_array($query)){
                echo "<option value=\"".$row['id']."\" ";
                if ($_REQUEST['version'] == $row['id']){
                    echo " selected";
                }
                echo ">".($row['name'])."</option>";
            }
        }
        echo "</select>|-|<select name=\"priority\" id=\"priority\" required class='form-control'>
                       <option value=\"\">Selecione a prioridade corretamente</option>";
        $sql = "SELECT * FROM priorities";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            while ($row = mysqli_fetch_array($query)){
                echo "<option value=\"".$row['id']."\" ";
                if ($_REQUEST['priority'] == $row['id']){
                    echo " selected";
                }
                echo "> ".($row['name'])."</option>";
            }
        }
        echo "</select>|-|<select name=\"category\" id=\"category\" required class='form-control'>
                                <option value=\"\">Selecione a categoria corretamente</option>";
        $sql = "SELECT * FROM categories WHERE typeService = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            while ($row = mysqli_fetch_array($query)){
                echo "<option value=\"".$row['id']."\" ";
                if ($_REQUEST['category'] == $row['id']){
                    echo " selected";
                }
                echo "> ".($row['name'])."</option>";
            }
        }
        echo "</select>";
        break;
    case 'adicionaProdutoPedido':
        echo "1|-|<input type='hidden' id='pedidoAdd' name='pedidoAdd' value='".$_REQUEST['id']."'><input type='hidden' id='idUserAdd' name='idUserAdd' value='".$_REQUEST['idUser']."'><label for='produtoAdd'>Produto: </label>
                  <select name='produtoAdd' id='produtoAdd' class='form-control' onchange=selecionaProdutoPedido(this.value,'".URL."')><option value=''>Selecione o produto abaixo corretamente...</option>";
        $sql = "SELECT * FROM products";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            while ($row = mysqli_fetch_array($query)){
                echo "<option value='".$row['id']."'>".($row['name'])."</option>";
            }
        }
        echo "</select><div id='itensProdutoPedido'></div>";
        break;
    case "selecionaProdutoPedido":
        echo "1|-|<label for='itemVendaAdd'>Item de Venda: </label>
                  <select name='itemVendaAdd' id='itemVendaAdd' class='form-control' onchange=selecionaItemVendaPedido(this.value,'".$_REQUEST['id']."','".URL."')><option value=''>Selecione o item de venda abaixo corretamente...</option>";
        $sql = "SELECT * FROM products_items WHERE product = '".$_REQUEST['id']."'";
        $query = mysqli_query($con, $sql);
        if ($_REQUEST['id'] != 8) {
            if (mysqli_num_rows($query)) {
                while ($row = mysqli_fetch_array($query)) {
                    echo "<option value='" . $row['id'] . "'>" . ($row['name']) . " - ";
                    if ($row['promotion'] && $row['vlidity_promotion'] <= date('Y-m-d')) {
                        echo "R$" . number_format($row['promotion'], 2, ',', '.');
                    } else {
                        echo "R$" . number_format($row['value'], 2, ',', '.');
                    }
                    echo "</option>";
                }
            }
        }
        else{
            $row = mysqli_fetch_array($query);
            $sql = "SELECT * FROM subitems WHERE page = '5'";
            $query2 = mysqli_query($con, $sql);
            if (mysqli_num_rows($query2)){
                while ($row2 = mysqli_fetch_array($query2)){
                    echo "<option value='" . $row2['id'] . "'>" . ($row2['name'])." - ";
                    if ($row['promotion'] && $row['vlidity_promotion'] <= date('Y-m-d')) {
                        echo "R$" . number_format($row['promotion'], 2, ',', '.');
                    } else {
                        echo "R$" . number_format($row['value'], 2, ',', '.');
                    }
                    echo "</option>";
                }
            }
        }
        echo "</select><div id='itensVendaPedidoProduto'></div>";
        break;
    case "selecionaItemVendaPedido":
        if ($_REQUEST['idProduto'] != 3 && $_REQUEST['idProduto'] != 4){
            $html = "<label for='dominioAdd'>Domínio: </label><input type='text' name='dominioAdd' id='dominioAdd' class='form-control'>";
        }
        elseif($_REQUEST['idProduto'] == 3){
            $html = "<label for='razaoSocialAdd'>Razão Social: </label><input type='text' name='razaoSocialAdd' id='razaoSocialAdd' class='form-control'>
                    <label for='nomeFantasiaAdd'>Nome Fantasia: </label><input type='text' name='nomeFantasiaAdd' id='nomeFantasiaAdd' class='form-control'>
                    <label for='cnpjAdd'>CNPJ: </label><input type='text' name='cnpjAdd' id='cnpjAdd' class='form-control' maxlength='18' onkeyup=formataCampo(this,'XX.XXX.XXX/XXXX-XX',event)>
                    <label for='emailAdd'>Email: </label><input type='email' name='emailaAdd' id='emailAdd' class='form-control'>
                    <label for='cepAdd'>CEP: </label><input type='cepAdd' name='cepAdd' id='cepAdd' class='form-control' maxlength='9' onkeyup=formataCampo(this,'XXXXX-XXX',event);verificaCepCaixa(this.value)>
                    <label for='logradouroAdd'>Logradouro </label><input type='text' name='logradouroAdd' id='logradouroAdd' class='form-control'>
                    <label for='numeroAdd'>Número </label><input type='text' name='numeroAdd' id='numeroAdd' class='form-control'>
                    <label for='complementoAdd'>Complemento </label><input type='text' name='complementoAdd' id='complementoAdd' class='form-control'>
                    <label for='bairroAdd'>Bairro </label><input type='text' name='bairroAdd' id='bairroAdd' class='form-control'>
                    <label for='cidadeAdd'>Cidade </label><input type='text' name='cidadeAdd' id='cidadeAdd' class='form-control'>
                    <label for='estadoAdd'>Estado </label><select name='estadoAdd' id='estadoAdd' class='form-control'><option value=''>Selecione o estado abaixo...</option>";
            $sql = "SELECT * FROM states ORDER BY sigla ASC";
            $query = mysqli_query($con, $sql);
            if (mysqli_num_rows($query)){
                while ($row = mysqli_fetch_array($query)){
                    $html .= "<option value='".$row['sigla']."'>".($row['nome'])."</option>";
                }
            }
            $html .= "</select>
                    <label forr='tipoEstabelecimentoAdd'>Tipo do Estabelecimento: </label>
                    <select name='tipoEstabelecimentoAdd' id='tipoEstabelecimentoAdd' class='form-control' onchange='selecionaTipoEstabelecimentoAdd(this.value)'>
                        <option value=''>Selecione o tipo do estabelecimento abaixo...</option>
                        <option value='1'>Mesas</option>
                        <option value='2'>Caixas</option>
                    </select>
                    <div id='outrosItensAdd'></div>";
        }
        elseif($_REQUEST['idProduto'] == 3){
            $html = "<label for='razaoSocialAdd'>Razão Social: </label><input type='text' name='razaoSocialAdd' id='razaoSocialAdd' class='form-control'>
                    <label for='nomeFantasiaAdd'>Nome Fantasia: </label><input type='text' name='nomeFantasiaAdd' id='nomeFantasiaAdd' class='form-control'>
                    <label for='cnpjAdd'>CNPJ: </label><input type='text' name='cnpjAdd' id='cnpjAdd' class='form-control' maxlength='18' onkeyup=formataCampo(this,'XX.XXX.XXX/XXXX-XX',event)>
                    <label for='emailAdd'>Email: </label><input type='email' name='emailaAdd' id='emailAdd' class='form-control'>
                    <label for='cepAdd'>CEP: </label><input type='cepAdd' name='cepAdd' id='cepAdd' class='form-control' maxlength='9' onkeyup=formataCampo(this,'XXXXX-XXX',event);verificaCepCaixa(this.value)>
                    <label for='logradouroAdd'>Logradouro </label><input type='text' name='logradouroAdd' id='logradouroAdd' class='form-control'>
                    <label for='numeroAdd'>Número </label><input type='text' name='numeroAdd' id='numeroAdd' class='form-control'>
                    <label for='complementoAdd'>Complemento </label><input type='text' name='complementoAdd' id='complementoAdd' class='form-control'>
                    <label for='bairroAdd'>Bairro </label><input type='text' name='bairroAdd' id='bairroAdd' class='form-control'>
                    <label for='cidadeAdd'>Cidade </label><input type='text' name='cidadeAdd' id='cidadeAdd' class='form-control'>
                    <label for='estadoAdd'>Estado </label><select name='estadoAdd' id='estadoAdd' class='form-control'><option value=''>Selecione o estado abaixo...</option>";
            $sql = "SELECT * FROM states ORDER BY sigla ASC";
            $query = mysqli_query($con, $sql);
            if (mysqli_num_rows($query)){
                while ($row = mysqli_fetch_array($query)){
                    $html .= "<option value='".$row['sigla']."'>".($row['nome'])."</option>";
                }
            }
            $html .= "</select>
                    <label forr='tipoEstabelecimentoAdd'>Tipo do Estabelecimento: </label>
                    <select name='tipoEstabelecimentoAdd' id='tipoEstabelecimentoAdd' class='form-control' onchange='selecionaTipoEstabelecimentoAdd(this.value)'>
                        <option value=''>Selecione o tipo do estabelecimento abaixo...</option>
                        <option value='1'>Mesas</option>
                        <option value='2'>Caixas</option>
                    </select>
                    <div id='outrosItensAdd'></div>";
        }
        elseif($_REQUEST['idProduto'] == 3){
            $html = "<label for='razaoSocialAdd'>Razão Social: </label><input type='text' name='razaoSocialAdd' id='razaoSocialAdd' class='form-control'>
                    <label for='nomeFantasiaAdd'>Nome Fantasia: </label><input type='text' name='nomeFantasiaAdd' id='nomeFantasiaAdd' class='form-control'>
                    <label for='cnpjAdd'>CNPJ: </label><input type='text' name='cnpjAdd' id='cnpjAdd' class='form-control' maxlength='18' onkeyup=formataCampo(this,'XX.XXX.XXX/XXXX-XX',event)>
                    <label for='emailAdd'>Email: </label><input type='email' name='emailaAdd' id='emailAdd' class='form-control'>
                    <label for='cepAdd'>CEP: </label><input type='cepAdd' name='cepAdd' id='cepAdd' class='form-control' maxlength='9' onkeyup=formataCampo(this,'XXXXX-XXX',event);verificaCepCaixa(this.value)>
                    <label for='logradouroAdd'>Logradouro </label><input type='text' name='logradouroAdd' id='logradouroAdd' class='form-control'>
                    <label for='numeroAdd'>Número </label><input type='text' name='numeroAdd' id='numeroAdd' class='form-control'>
                    <label for='complementoAdd'>Complemento </label><input type='text' name='complementoAdd' id='complementoAdd' class='form-control'>
                    <label for='bairroAdd'>Bairro </label><input type='text' name='bairroAdd' id='bairroAdd' class='form-control'>
                    <label for='cidadeAdd'>Cidade </label><input type='text' name='cidadeAdd' id='cidadeAdd' class='form-control'>
                    <label for='estadoAdd'>Estado </label><select name='estadoAdd' id='estadoAdd' class='form-control'><option value=''>Selecione o estado abaixo...</option>";
            $sql = "SELECT * FROM states ORDER BY sigla ASC";
            $query = mysqli_query($con, $sql);
            if (mysqli_num_rows($query)){
                while ($row = mysqli_fetch_array($query)){
                    $html .= "<option value='".$row['sigla']."'>".($row['nome'])."</option>";
                }
            }
            $html .= "</select>
                    <label forr='tipoEstabelecimentoAdd'>Tipo do Estabelecimento: </label>
                    <select name='tipoEstabelecimentoAdd' id='tipoEstabelecimentoAdd' class='form-control' onchange='selecionaTipoEstabelecimentoAdd(this.value)'>
                        <option value=''>Selecione o tipo do estabelecimento abaixo...</option>
                        <option value='1'>Mesas</option>
                        <option value='2'>Caixas</option>
                    </select>
                    <div id='outrosItensAdd'></div>";
        }
        elseif($_REQUEST['idProduto'] == 4){
            $html = "<label for='nomeEscolaAdd'>Nome da Escola: </label><input type='text' name='nomeEscolaAdd' id='nomeEscolaAdd' class='form-control'>
                    <label for='emailAdd'>Email da Escola: </label><input type='email' name='emailAdd' id='emailAdd' class='form-control'>
                    <label for='cepAdd'>CEP da Escola: </label><input type='cepAdd' name='cepAdd' id='cepAdd' class='form-control' maxlength='9' onkeyup=formataCampo(this,'XXXXX-XXX',event);verificaCepCaixa(this.value)>
                    <label for='logradouroAdd'>Logradouro da Escola: </label><input type='text' name='logradouroAdd' id='logradouroAdd' class='form-control'>
                    <label for='numeroAdd'>Número da Escola: </label><input type='text' name='numeroAdd' id='numeroAdd' class='form-control'>
                    <label for='complementoAdd'>Complemento da Escola: </label><input type='text' name='complementoAdd' id='complementoAdd' class='form-control'>
                    <label for='bairroAdd'>Bairro da Escola: </label><input type='text' name='bairroAdd' id='bairroAdd' class='form-control'>
                    <label for='cidadeAdd'>Cidade da Escola: </label><input type='text' name='cidadeAdd' id='cidadeAdd' class='form-control'>
                    <label for='estadoAdd'>Estado da Escola: </label><select name='estadoAdd' id='estadoAdd' class='form-control'><option value=''>Selecione o estado abaixo...</option>";
            $sql = "SELECT * FROM states ORDER BY sigla ASC";
            $query = mysqli_query($con, $sql);
            if (mysqli_num_rows($query)){
                while ($row = mysqli_fetch_array($query)){
                    $html .= "<option value='".$row['sigla']."'>".($row['nome'])."</option>";
                }
            }
            $html .= "</select>
                    <label forr='tipoNotaAdd'>Tipo de Nota: </label>
                    <select name='tipoNotaAdd' id='tipoNotaAdd' class='form-control'>
                        <option value=''>Selecione o tipo de nota abaixo...</option>
                        <option value='1'>Bimestral</option>
                        <option value='2'>Trimestral</option>
                        <option value='3'>Semestral</option>
                        <option value='4'>Anual</option>
                    </select>
                    <label forr='turnoAdd'>Turno da escola: </label>
                    <select name='turnoAdd' id='turnoAdd' class='form-control'>
                        <option value=''>Selecione o turno da escola abaixo...</option>
                        <option value='1'>Manhã</option>
                        <option value='2'>Tarde</option>
                        <option value='3'>Noite</option>
                        <option value='4'>Único</option>
                        <option value='5'>Todos</option>
                    </select>
                    <label forr='letraAdd'>Até que letra  as turmas da escola vão: </label>
                    <select name='letraAdd' id='letraAdd' class='form-control'>
                        <option value=''>Selecione a letra da escola abaixo...</option>
                        <option value='Un'>Única</option>
                        ";
           for ($i = 1; $i <= 26; $i++){
               if ($i == 1){
                   $letra = "a";
               }
               elseif ($i == 2){
                   $letra = "b";
               }
               elseif ($i == 3){
                   $letra = "c";
               }
               elseif ($i == 4){
                   $letra = "d";
               }
               elseif ($i == 5){
                   $letra = "e";
               }
               elseif ($i == 6){
                   $letra = "f";
               }
               elseif ($i == 7){
                   $letra = "g";
               }
               elseif ($i == 8){
                   $letra = "h";
               }
               elseif ($i == 9){
                   $letra = "i";
               }
               elseif ($i == 10){
                   $letra = "j";
               }
               elseif ($i == 11){
                   $letra = "k";
               }
               elseif ($i == 12){
                   $letra = "l";
               }
               elseif ($i == 13){
                   $letra = "m";
               }
               elseif ($i == 14){
                   $letra = "n";
               }
               elseif ($i == 15){
                   $letra = "o";
               }
               elseif ($i == 16){
                   $letra = "p";
               }
               elseif ($i == 17){
                   $letra = "q";
               }
               elseif ($i == 18){
                   $letra = "r";
               }
               elseif ($i == 19){
                   $letra = "s";
               }
               elseif ($i == 20){
                   $letra = "t";
               }
               elseif ($i == 21){
                   $letra = "u";
               }
               elseif ($i == 22){
                   $letra = "v";
               }
               elseif ($i == 23){
                   $letra = "w";
               }
               elseif ($i == 24){
                   $letra = "x";
               }
               elseif ($i == 25){
                   $letra = "y";
               }
               elseif ($i == 26){
                   $letra = "z";
               }
               $html .=  "<option value='".$letra."'>".$letra."</option>";
           }
           $html .= "
                    </select>";
        }
        $html .= "<input type='button' class='btn btn-primary' value='Cadastrar' onclick=adicionarProdutoPedido($('#produtoAdd').val(),$('#itemVendaAdd').val(),$('#dominioAdd').val(),'".URL."')>";
        echo "1|-|".$html;
        break;
    case 'adicionarProdutoPedido':
        if($_REQUEST['idProduto'] == 8){
            $sql = "SELECT * FROM products_items WHERE product = '" . $_REQUEST['idProduto'] . "'";
            $query = mysqli_query($con, $sql);
            $row = mysqli_fetch_array($query);
            $sql = "SELECT * FROM subitems WHERE id = '". $_REQUEST['idItVenda'] ."'";
            $query2 = mysqli_query($con, $sql);
            $row2 = mysqli_fetch_array($query2);
            $row['name'] .= " - ".$row2['name'];
        }
        else {
            $sql = "SELECT * FROM products_items WHERE id = '" . $_REQUEST['idItVenda'] . "'";
            $query = mysqli_query($con, $sql);
            $row = mysqli_fetch_array($query);
        }
        $valor = ($row['promotion'] && $row['validity_promotion'] >= date('Y-m-d')) ? $row['promotion'] : $row['value'];
        $sql = "INSERT INTO requests_items (request, product, product_item, name, domine, quantity, value, created_at, updated_at) VALUES ('".$_REQUEST['idPedido']."', '".$_REQUEST['idProduto']."', '".$_REQUEST['idItVenda']."', '".$row['name']."', '".$_REQUEST['dominio']."', '1', '".$valor."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
        //echo $sql;
        mysqli_query($con, $sql) or die(mysqli_error($con));
        $idRequestItem = mysqli_insert_id($con);
        if ($_REQUEST['idProduto'] == 3){
            $sql = "INSERT INTO cashier_system (razao_social, nome_fantasia, email, cnpj, cep, logradouro, numero, complemento, bairro, cidade, estado, tipoEstabelecimento, quantidade, numeroPessoasPorMesa, percentual, created_at, updated_at) VALUES ('".$_REQUEST['razaoSocial']."', '".$_REQUEST['nomeFantasia']."', '".$_REQUEST['email']."', '".$_REQUEST['cnpj']."', '".$_REQUEST['cep']."', '".$_REQUEST['logradouro']."', '".$_REQUEST['numero']."', '".$_REQUEST['complemento']."', '".$_REQUEST['bairro']."', '".$_REQUEST['cidade']."', '".$_REQUEST['estado']."', '".$_REQUEST['tipoEstabelecimento']."', '".$_REQUEST['quantidade']."', '".$_REQUEST['numPessoas']."', '".$_REQUEST['percentual']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
            mysqli_query($con, $sql) or die(mysqli_error($con)." - ".$sql);
            $idCashierSystem = mysqli_insert_id($con);
            $sql = "UPDATE requests_items SET cashier_system = '".$idCashierSystem."' WHERE id = '".$idRequestItem."'";
            mysqli_query($con, $sql) or die(mysqli_error($con));
        }
        if ($_REQUEST['idProduto'] == 4){
            $sql = "INSERT INTO school_system (nome, email, cep, logradouro, numero, complemento, bairro, cidade, estado, tipoNota, turno, letra, created_at, updated_at) VALUES ('".$_REQUEST['nome']."', '".$_REQUEST['email']."', '".$_REQUEST['cep']."', '".$_REQUEST['logradouro']."', '".$_REQUEST['numero']."', '".$_REQUEST['complemento']."', '".$_REQUEST['bairro']."', '".$_REQUEST['cidade']."', '".$_REQUEST['estado']."', '".$_REQUEST['tipoNota']."', '".$_REQUEST['turno']."', '".$_REQUEST['letra']."', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."')";
            mysqli_query($con, $sql) or die(mysqli_error($con)." - ".$sql);
            $idSchoolSystem = mysqli_insert_id($con);
            $sql = "UPDATE requests_items SET school_system = '".$idSchoolSystem."' WHERE id = '".$idRequestItem."'";
            mysqli_query($con, $sql) or die(mysqli_error($con));
        }
        echo "1|-|".$idRequestItem."|-|".$idCashierSystem;
        break;
    case 'excluirProdutoPedido':
        $sql = "DELETE FROM requests_items WHERE id = '".$_REQUEST['id']."'";
        mysqli_query($con, $sql) or die(mysqli_error($con));
        echo "1";
        break;
    case "vaiRedeSocial":
        $sql = "SELECT * FROM social_networks WHERE id = '" . $_REQUEST['id'] . "'";
        $query = mysqli_query($con, $sql) or die(mysqli_error($con));
        $row = mysqli_fetch_array($query);
        $cliques = $row['cliques'] + 1;
        $sql = "UPDATE social_networks SET cliques = '".$cliques."' WHERE id = '".$_REQUEST['id']."'";
        mysqli_query($con, $sql) or die(mysqli_error($con));
        echo "1|-|".($row['link']);
        break;
    default:
        echo "0|-|Não foi encontrada a ação pesquisada!";
        break;
}
function retirarAcentos($name){
    $slug = (strtolower(str_replace(' ', '-', $name)));
    $slug = str_replace("+", "-", $slug);
    $slug = str_replace("/", "", $slug);
    $slug = str_replace("%", "", $slug);
    $slug = str_replace("&", "e", $slug);
    $slug = str_replace("?", "", $slug);
    $slug = str_replace("!", "", $slug);
    $slug = str_replace("á", "a", $slug);
    $slug = str_replace("à", "a", $slug);
    $slug = str_replace("ã", "a", $slug);
    $slug = str_replace("â", "a", $slug);
    $slug = str_replace("ª", "a", $slug);
    $slug = str_replace("é", "e", $slug);
    $slug = str_replace("è", "e", $slug);
    $slug = str_replace("ê", "e", $slug);
    $slug = str_replace("í", "i", $slug);
    $slug = str_replace("ì", "i", $slug);
    $slug = str_replace("ó", "o", $slug);
    $slug = str_replace("ò", "o", $slug);
    $slug = str_replace("ô", "o", $slug);
    $slug = str_replace("õ", "o", $slug);
    $slug = str_replace("º", "o", $slug);
    $slug = str_replace("ú", "u", $slug);
    $slug = str_replace("ù", "u", $slug);
    $slug = str_replace("û", "u", $slug);
    $slug = str_replace("ç", "c", $slug);
    return $slug;
}
function br2newline( $input ) {
    $out = str_replace( "<br>", "\n", $input );
    $out = str_replace( "<br/>", "\n", $out );
    $out = str_replace( "<br />", "\n", $out );
    $out = str_replace( "<BR>", "\n", $out );
    $out = str_replace( "<BR/>", "\n", $out );
    $out = str_replace( "<BR />", "\n", $out );
    return $out;
}
function br2nl( $input ) {
    return preg_replace('/<br(\s+)?\/?>/i', "\n", $input);
}
function enviarEmail($deEmail, $deNome, $paraEmail, $paraNome, $assunto, $mensagem){
    $urlEnvio = URL."enviaremail.php";
    // URL:
    $ch = curl_init($urlEnvio);
    // Obter retorno em $resultado:
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    // -F
    // Definir como POST:
    curl_setopt($ch, CURLOPT_POST, true);
    // -F
    // Definir corpo, como multipart/form-data:
    curl_setopt($ch, CURLOPT_POSTFIELDS, [
        'deEmail' => ($deEmail),
        'deNome' => ($deNome),
        'paraEmail' => ($paraEmail),
        'paraNome' => ($paraNome),
        'assunto' => ($assunto),
        'mensagem' => ($mensagem)
    ]);
    // -u
    $resultado = curl_exec($ch);
    curl_close ($ch);
    return $resultado;
}
?>
