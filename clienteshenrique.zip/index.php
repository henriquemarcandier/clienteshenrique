<?php
error_reporting(1);
ini_set('display_erros', 'on');
@session_start();
$url = $_SERVER['REQUEST_URI'];
$vet = explode("/", $url);
array_shift($vet);
array_shift($vet);
$exp = explode('?', $vet[0]);
$vet[0] = $exp[0];
$link = "https://localhost/clienteshenrique/";
if($vet[0]){
    $link .= $vet[0]."/";
}
if ($vet[1]){
    $link .= $vet[1]."/";
}
if ($vet[2]){
    $link .= $vet[2]."/";
}
if (!$_SERVER['HTTPS']){
    header('location: '.$link);
}
require_once('connect.php');
require_once(DIRETORIO."pegaSqls.php");
require_once(DIRETORIO."paginas/cabecalho.php");
if (!$vet[0] || $vet[0] == 'home'){
    require_once(DIRETORIO.'paginas/index.php');
}
elseif ($vet[0] == 'pagina'){
    require_once(DIRETORIO.'paginas/pagina.php');
}
elseif ($vet[0] == 'redeSocial'){
    require_once(DIRETORIO.'paginas/redeSocial.php');
}
elseif ($vet[0] == 'banner'){
    require_once(DIRETORIO.'paginas/banner.php');
}
elseif ($vet[0] == 'modelo'){
    require_once(DIRETORIO.'paginas/modelo.php');
}
elseif ($vet[0] == 'cliente'){
    require_once(DIRETORIO.'paginas/cliente.php');
}
else{
    require_once(DIRETORIO."paginas/pagina404.php");
}
require_once(DIRETORIO."paginas/rodape.php");
?>