<?php
error_reporting(1);
ini_set('display_errors', 'on');
@session_start();
date_default_timezone_set("America/Sao_Paulo");
setlocale(LC_ALL, 'pt_BR');
$url = "https://localhost/clienteshenrique/";
$url_site = "https://localhost/clienteshenrique/";
$diretorio_site = "C:/xampp7/htdocs/clienteshenrique/";
$diretorio = "C:/xampp7/htdocs/clienteshenrique/";
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "clienteshenrique";
$con = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname) or die(mysqli_error($con));
define("URL", $url);
define("URL_SITE", $url_site);
define("DIRETORIO_SITE", $diretorio_site);
define("DIRETORIO", $diretorio);
?>
