/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : clienteshenrique

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2022-02-10 14:31:03
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `categories`
-- ----------------------------
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `status` enum('0','1') DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of categories
-- ----------------------------
INSERT INTO `categories` VALUES ('1', 'Aplicativos', '1', '2022-02-09 17:55:58', '2022-02-09 17:55:58');
INSERT INTO `categories` VALUES ('2', 'Cartões', '1', '2022-02-09 17:57:50', '2022-02-09 17:57:50');
INSERT INTO `categories` VALUES ('3', 'Web-Sites', '1', '2022-02-09 17:58:07', '2022-02-09 17:58:07');

-- ----------------------------
-- Table structure for `counters`
-- ----------------------------
DROP TABLE IF EXISTS `counters`;
CREATE TABLE `counters` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `data` date NOT NULL,
  `acessos` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of counters
-- ----------------------------
INSERT INTO `counters` VALUES ('1', '2022-02-10', '14', '2022-02-10 02:50:17', '2022-02-10 11:45:22');

-- ----------------------------
-- Table structure for `counters_pages`
-- ----------------------------
DROP TABLE IF EXISTS `counters_pages`;
CREATE TABLE `counters_pages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `page` bigint(20) unsigned NOT NULL,
  `data` date NOT NULL,
  `acessos` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of counters_pages
-- ----------------------------
INSERT INTO `counters_pages` VALUES ('1', '0', '2022-02-10', '9', '2022-02-10 02:50:17', '2022-02-10 02:58:25');
INSERT INTO `counters_pages` VALUES ('2', '1', '2022-02-10', '14', '2022-02-10 02:52:14', '2022-02-10 14:19:42');
INSERT INTO `counters_pages` VALUES ('3', '2', '2022-02-10', '5', '2022-02-10 02:59:45', '2022-02-10 12:33:22');
INSERT INTO `counters_pages` VALUES ('4', '3', '2022-02-10', '6', '2022-02-10 12:31:15', '2022-02-10 14:19:44');

-- ----------------------------
-- Table structure for `counters_subitems`
-- ----------------------------
DROP TABLE IF EXISTS `counters_subitems`;
CREATE TABLE `counters_subitems` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `subitem` bigint(20) unsigned NOT NULL,
  `data` date NOT NULL,
  `acessos` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of counters_subitems
-- ----------------------------
INSERT INTO `counters_subitems` VALUES ('1', '1', '2022-02-10', '1', '2022-02-10 14:02:02', '2022-02-10 14:02:02');
INSERT INTO `counters_subitems` VALUES ('2', '2', '2022-02-10', '1', '2022-02-10 14:02:26', '2022-02-10 14:02:26');

-- ----------------------------
-- Table structure for `logs`
-- ----------------------------
DROP TABLE IF EXISTS `logs`;
CREATE TABLE `logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user` bigint(20) unsigned NOT NULL,
  `action` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=444 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of logs
-- ----------------------------
INSERT INTO `logs` VALUES ('1', '1', 'Se logou no sistema', '2022-02-06 15:46:03', '2022-02-06 15:46:03');
INSERT INTO `logs` VALUES ('2', '1', 'Visualizou os Produtos', '2022-02-06 15:46:03', '2022-02-06 15:46:03');
INSERT INTO `logs` VALUES ('3', '1', 'Visualizou os Produtos', '2022-02-06 19:39:42', '2022-02-06 19:39:42');
INSERT INTO `logs` VALUES ('4', '1', 'Visualizou os Produtos', '2022-02-06 19:39:42', '2022-02-06 19:39:42');
INSERT INTO `logs` VALUES ('5', '1', 'Visualizou os Produtos', '2022-02-06 19:39:42', '2022-02-06 19:39:42');
INSERT INTO `logs` VALUES ('6', '1', 'Se logou no sistema', '2022-02-06 21:27:40', '2022-02-06 21:27:40');
INSERT INTO `logs` VALUES ('7', '1', 'Visualizou os Produtos', '2022-02-06 21:27:41', '2022-02-06 21:27:41');
INSERT INTO `logs` VALUES ('8', '1', 'Se logou no sistema', '2022-02-07 12:15:58', '2022-02-07 12:15:58');
INSERT INTO `logs` VALUES ('9', '1', 'Visualizou os Produtos', '2022-02-07 12:15:58', '2022-02-07 12:15:58');
INSERT INTO `logs` VALUES ('10', '1', 'Visualizou os Produtos', '2022-02-07 14:38:14', '2022-02-07 14:38:14');
INSERT INTO `logs` VALUES ('11', '0', 'Exportou os produtos do site', '2022-02-07 14:59:44', '2022-02-07 14:59:44');
INSERT INTO `logs` VALUES ('12', '0', 'Exportou os produtos do site', '2022-02-07 15:02:42', '2022-02-07 15:02:42');
INSERT INTO `logs` VALUES ('13', '0', 'Exportou os produtos do site', '2022-02-07 15:10:32', '2022-02-07 15:10:32');
INSERT INTO `logs` VALUES ('14', '0', 'Exportou os produtos do site', '2022-02-07 15:11:40', '2022-02-07 15:11:40');
INSERT INTO `logs` VALUES ('15', '1', 'Visualizou as Páginas', '2022-02-07 17:15:47', '2022-02-07 17:15:47');
INSERT INTO `logs` VALUES ('16', '1', 'Atualizou a pagina 17', '2022-02-07 17:18:53', '2022-02-07 17:18:53');
INSERT INTO `logs` VALUES ('17', '1', 'Atualizou a pagina 18', '2022-02-07 17:26:20', '2022-02-07 17:26:20');
INSERT INTO `logs` VALUES ('18', '1', 'Se logou no sistema', '2022-02-08 19:45:35', '2022-02-08 19:45:35');
INSERT INTO `logs` VALUES ('19', '1', 'Visualizou as Páginas', '2022-02-08 19:45:36', '2022-02-08 19:45:36');
INSERT INTO `logs` VALUES ('20', '1', 'Visualizou os Produtos', '2022-02-08 19:45:41', '2022-02-08 19:45:41');
INSERT INTO `logs` VALUES ('21', '1', 'Visualizou os módulos do sistema', '2022-02-09 15:25:28', '2022-02-09 15:25:28');
INSERT INTO `logs` VALUES ('22', '1', 'Excluiu o modulo 39', '2022-02-09 15:25:36', '2022-02-09 15:25:36');
INSERT INTO `logs` VALUES ('23', '1', 'Excluiu o modulo 40', '2022-02-09 15:25:41', '2022-02-09 15:25:41');
INSERT INTO `logs` VALUES ('24', '1', 'Excluiu o modulo 41', '2022-02-09 15:25:44', '2022-02-09 15:25:44');
INSERT INTO `logs` VALUES ('25', '1', 'Excluiu o modulo 42', '2022-02-09 15:25:48', '2022-02-09 15:25:48');
INSERT INTO `logs` VALUES ('26', '1', 'Excluiu o modulo 57', '2022-02-09 15:25:54', '2022-02-09 15:25:54');
INSERT INTO `logs` VALUES ('27', '1', 'Visualizou os módulos do sistema', '2022-02-09 15:25:58', '2022-02-09 15:25:58');
INSERT INTO `logs` VALUES ('28', '1', 'Excluiu o modulo 55', '2022-02-09 15:26:04', '2022-02-09 15:26:04');
INSERT INTO `logs` VALUES ('29', '1', 'Visualizou os módulos do sistema', '2022-02-09 15:26:06', '2022-02-09 15:26:06');
INSERT INTO `logs` VALUES ('30', '1', 'Visualizou os tipos de módulo do sistema', '2022-02-09 15:27:25', '2022-02-09 15:27:25');
INSERT INTO `logs` VALUES ('31', '1', 'Excluiu o tipoModulo 3', '2022-02-09 15:27:31', '2022-02-09 15:27:31');
INSERT INTO `logs` VALUES ('32', '1', 'Visualizou os tipos de módulo do sistema', '2022-02-09 15:27:33', '2022-02-09 15:27:33');
INSERT INTO `logs` VALUES ('33', '1', 'Visualizou os módulos do sistema', '2022-02-09 15:27:44', '2022-02-09 15:27:44');
INSERT INTO `logs` VALUES ('34', '1', 'Visualizou os módulos do sistema', '2022-02-09 15:28:14', '2022-02-09 15:28:14');
INSERT INTO `logs` VALUES ('35', '1', 'Visualizou os módulos do sistema', '2022-02-09 15:29:46', '2022-02-09 15:29:46');
INSERT INTO `logs` VALUES ('36', '1', 'Visualizou os módulos do sistema', '2022-02-09 15:30:26', '2022-02-09 15:30:26');
INSERT INTO `logs` VALUES ('37', '1', 'Visualizou as permissões do sistema', '2022-02-09 15:30:31', '2022-02-09 15:30:31');
INSERT INTO `logs` VALUES ('38', '1', 'Visualizou os logs de usuários do sistema', '2022-02-09 15:30:35', '2022-02-09 15:30:35');
INSERT INTO `logs` VALUES ('39', '1', 'Visualizou os usuários pré-cadastrados do sistema', '2022-02-09 15:30:42', '2022-02-09 15:30:42');
INSERT INTO `logs` VALUES ('40', '1', 'Visualizou os logs de usuários do sistema', '2022-02-09 15:30:46', '2022-02-09 15:30:46');
INSERT INTO `logs` VALUES ('41', '1', 'Visualizou as permissões do sistema', '2022-02-09 15:30:49', '2022-02-09 15:30:49');
INSERT INTO `logs` VALUES ('42', '0', 'Visualizou os módulos do sistema', '2022-02-09 15:31:21', '2022-02-09 15:31:21');
INSERT INTO `logs` VALUES ('43', '1', 'Visualizou as permissões do sistema', '2022-02-09 15:31:27', '2022-02-09 15:31:27');
INSERT INTO `logs` VALUES ('44', '1', 'Visualizou as permissões do usuário  1', '2022-02-09 15:31:30', '2022-02-09 15:31:30');
INSERT INTO `logs` VALUES ('45', '1', 'Visualizou as permissões do usuário  2', '2022-02-09 15:31:36', '2022-02-09 15:31:36');
INSERT INTO `logs` VALUES ('46', '1', 'Visualizou as permissões do sistema', '2022-02-09 15:32:55', '2022-02-09 15:32:55');
INSERT INTO `logs` VALUES ('47', '1', 'Visualizou as permissões do usuário  1', '2022-02-09 15:32:57', '2022-02-09 15:32:57');
INSERT INTO `logs` VALUES ('48', '1', 'Visualizou as permissões do usuário  2', '2022-02-09 15:33:02', '2022-02-09 15:33:02');
INSERT INTO `logs` VALUES ('49', '1', 'Adicionou a permissão de view o módulo 27  do usuário  2', '2022-02-09 15:33:44', '2022-02-09 15:33:44');
INSERT INTO `logs` VALUES ('50', '1', 'Adicionou a permissão de register o módulo 27  do usuário  2', '2022-02-09 15:33:46', '2022-02-09 15:33:46');
INSERT INTO `logs` VALUES ('51', '1', 'Adicionou a permissão de delete o módulo 27  do usuário  2', '2022-02-09 15:33:47', '2022-02-09 15:33:47');
INSERT INTO `logs` VALUES ('52', '1', 'Visualizou as permissões do sistema', '2022-02-09 15:33:48', '2022-02-09 15:33:48');
INSERT INTO `logs` VALUES ('53', '1', 'Visualizou as permissões do usuário  2', '2022-02-09 15:33:50', '2022-02-09 15:33:50');
INSERT INTO `logs` VALUES ('54', '1', 'Adicionou a permissão de view o módulo 28  do usuário  2', '2022-02-09 15:33:58', '2022-02-09 15:33:58');
INSERT INTO `logs` VALUES ('55', '1', 'Adicionou a permissão de register o módulo 28  do usuário  2', '2022-02-09 15:34:00', '2022-02-09 15:34:00');
INSERT INTO `logs` VALUES ('56', '1', 'Adicionou a permissão de delete o módulo 28  do usuário  2', '2022-02-09 15:34:02', '2022-02-09 15:34:02');
INSERT INTO `logs` VALUES ('57', '1', 'Adicionou a permissão de view o módulo 29  do usuário  2', '2022-02-09 15:34:04', '2022-02-09 15:34:04');
INSERT INTO `logs` VALUES ('58', '1', 'Adicionou a permissão de register o módulo 29  do usuário  2', '2022-02-09 15:34:05', '2022-02-09 15:34:05');
INSERT INTO `logs` VALUES ('59', '1', 'Adicionou a permissão de delete o módulo 29  do usuário  2', '2022-02-09 15:34:08', '2022-02-09 15:34:08');
INSERT INTO `logs` VALUES ('60', '1', 'Adicionou a permissão de delete o módulo 32  do usuário  2', '2022-02-09 15:34:09', '2022-02-09 15:34:09');
INSERT INTO `logs` VALUES ('61', '1', 'Adicionou a permissão de register o módulo 32  do usuário  2', '2022-02-09 15:34:10', '2022-02-09 15:34:10');
INSERT INTO `logs` VALUES ('62', '1', 'Adicionou a permissão de view o módulo 32  do usuário  2', '2022-02-09 15:34:11', '2022-02-09 15:34:11');
INSERT INTO `logs` VALUES ('63', '1', 'Visualizou as permissões do sistema', '2022-02-09 15:34:15', '2022-02-09 15:34:15');
INSERT INTO `logs` VALUES ('64', '1', 'Visualizou as permissões do usuário  2', '2022-02-09 15:34:17', '2022-02-09 15:34:17');
INSERT INTO `logs` VALUES ('65', '1', 'Adicionou a permissão de register o módulo 32  do usuário  2', '2022-02-09 15:34:22', '2022-02-09 15:34:22');
INSERT INTO `logs` VALUES ('66', '1', 'Adicionou a permissão de delete o módulo 32  do usuário  2', '2022-02-09 15:34:24', '2022-02-09 15:34:24');
INSERT INTO `logs` VALUES ('67', '1', 'Visualizou as permissões do sistema', '2022-02-09 15:34:25', '2022-02-09 15:34:25');
INSERT INTO `logs` VALUES ('68', '1', 'Visualizou as permissões do usuário  2', '2022-02-09 15:34:27', '2022-02-09 15:34:27');
INSERT INTO `logs` VALUES ('69', '1', 'Visualizou as versões do administrativo', '2022-02-09 15:34:54', '2022-02-09 15:34:54');
INSERT INTO `logs` VALUES ('70', '1', 'Visualizou as versões do administrativo', '2022-02-09 15:35:49', '2022-02-09 15:35:49');
INSERT INTO `logs` VALUES ('71', '1', 'Visualizou as versões do administrativo', '2022-02-09 15:36:06', '2022-02-09 15:36:06');
INSERT INTO `logs` VALUES ('72', '1', 'Visualizou as versões do administrativo', '2022-02-09 15:36:21', '2022-02-09 15:36:21');
INSERT INTO `logs` VALUES ('73', '1', 'Visualizou as versões do administrativo', '2022-02-09 15:36:40', '2022-02-09 15:36:40');
INSERT INTO `logs` VALUES ('74', '1', 'Visualizou as versões do administrativo', '2022-02-09 15:37:12', '2022-02-09 15:37:12');
INSERT INTO `logs` VALUES ('75', '1', 'Atualizou a versao 1', '2022-02-09 15:39:10', '2022-02-09 15:39:10');
INSERT INTO `logs` VALUES ('76', '1', 'Atualizou a versao 1', '2022-02-09 15:39:53', '2022-02-09 15:39:53');
INSERT INTO `logs` VALUES ('77', '1', 'Visualizou o versao 1', '2022-02-09 15:39:58', '2022-02-09 15:39:58');
INSERT INTO `logs` VALUES ('78', '1', 'Visualizou o versao 1', '2022-02-09 15:40:25', '2022-02-09 15:40:25');
INSERT INTO `logs` VALUES ('79', '1', 'Visualizou as versões do administrativo', '2022-02-09 15:40:29', '2022-02-09 15:40:29');
INSERT INTO `logs` VALUES ('80', '1', 'Visualizou as versões do administrativo', '2022-02-09 15:42:00', '2022-02-09 15:42:00');
INSERT INTO `logs` VALUES ('81', '1', 'Visualizou o versao 1', '2022-02-09 15:42:23', '2022-02-09 15:42:23');
INSERT INTO `logs` VALUES ('82', '1', 'Atualizou a versao 1', '2022-02-09 15:42:33', '2022-02-09 15:42:33');
INSERT INTO `logs` VALUES ('83', '1', 'Visualizou as versões do administrativo', '2022-02-09 15:42:35', '2022-02-09 15:42:35');
INSERT INTO `logs` VALUES ('84', '1', 'Visualizou as versões do administrativo', '2022-02-09 15:51:35', '2022-02-09 15:51:35');
INSERT INTO `logs` VALUES ('85', '1', 'Atualizou a versao 1', '2022-02-09 15:52:19', '2022-02-09 15:52:19');
INSERT INTO `logs` VALUES ('86', '1', 'Visualizou as versões do administrativo', '2022-02-09 15:52:21', '2022-02-09 15:52:21');
INSERT INTO `logs` VALUES ('87', '1', 'Visualizou as versões do administrativo', '2022-02-09 15:52:41', '2022-02-09 15:52:41');
INSERT INTO `logs` VALUES ('88', '1', 'Visualizou as versões do administrativo', '2022-02-09 15:53:00', '2022-02-09 15:53:00');
INSERT INTO `logs` VALUES ('89', '1', 'Atualizou a versao 1', '2022-02-09 15:53:23', '2022-02-09 15:53:23');
INSERT INTO `logs` VALUES ('90', '1', 'Visualizou as versões do administrativo', '2022-02-09 15:53:26', '2022-02-09 15:53:26');
INSERT INTO `logs` VALUES ('91', '1', 'Atualizou a versao 1', '2022-02-09 15:53:44', '2022-02-09 15:53:44');
INSERT INTO `logs` VALUES ('92', '1', 'Visualizou as versões do administrativo', '2022-02-09 15:53:46', '2022-02-09 15:53:46');
INSERT INTO `logs` VALUES ('93', '1', 'Atualizou a versao 1', '2022-02-09 15:54:00', '2022-02-09 15:54:00');
INSERT INTO `logs` VALUES ('94', '1', 'Visualizou as versões do administrativo', '2022-02-09 15:54:54', '2022-02-09 15:54:54');
INSERT INTO `logs` VALUES ('95', '1', 'Visualizou as versões do administrativo', '2022-02-09 15:54:58', '2022-02-09 15:54:58');
INSERT INTO `logs` VALUES ('96', '1', 'Visualizou as versões do administrativo', '2022-02-09 15:55:04', '2022-02-09 15:55:04');
INSERT INTO `logs` VALUES ('97', '1', 'Visualizou os usuários pré-cadastrados do sistema', '2022-02-09 15:55:16', '2022-02-09 15:55:16');
INSERT INTO `logs` VALUES ('98', '1', 'Visualizou os logs de usuários do sistema', '2022-02-09 15:56:36', '2022-02-09 15:56:36');
INSERT INTO `logs` VALUES ('99', '1', 'Visualizou as versões do administrativo', '2022-02-09 15:57:21', '2022-02-09 15:57:21');
INSERT INTO `logs` VALUES ('100', '1', 'Visualizou os logs de usuários do sistema', '2022-02-09 15:59:18', '2022-02-09 15:59:18');
INSERT INTO `logs` VALUES ('101', '1', 'Visualizou os parâmetros do administrativo', '2022-02-09 15:59:29', '2022-02-09 15:59:29');
INSERT INTO `logs` VALUES ('102', '1', 'Visualizou os parâmetros do administrativo', '2022-02-09 16:00:06', '2022-02-09 16:00:06');
INSERT INTO `logs` VALUES ('103', '0', 'Visualizou os logs de usuários do sistema', '2022-02-09 16:01:21', '2022-02-09 16:01:21');
INSERT INTO `logs` VALUES ('104', '1', 'Visualizou os parâmetros do administrativo', '2022-02-09 16:10:09', '2022-02-09 16:10:09');
INSERT INTO `logs` VALUES ('105', '1', 'Visualizou os parâmetros do site', '2022-02-09 16:10:14', '2022-02-09 16:10:14');
INSERT INTO `logs` VALUES ('106', '1', 'Visualizou os parâmetros do administrativo', '2022-02-09 16:10:18', '2022-02-09 16:10:18');
INSERT INTO `logs` VALUES ('107', '1', 'Visualizou os parâmetros do site', '2022-02-09 16:10:21', '2022-02-09 16:10:21');
INSERT INTO `logs` VALUES ('108', '1', 'Visualizou os parâmetros do administrativo', '2022-02-09 16:10:22', '2022-02-09 16:10:22');
INSERT INTO `logs` VALUES ('109', '1', 'Visualizou os parâmetros do administrativo', '2022-02-09 16:10:43', '2022-02-09 16:10:43');
INSERT INTO `logs` VALUES ('110', '1', 'Atualizou o parametroAdmin 1', '2022-02-09 16:11:06', '2022-02-09 16:11:06');
INSERT INTO `logs` VALUES ('111', '1', 'Visualizou os parâmetros do administrativo', '2022-02-09 16:11:08', '2022-02-09 16:11:08');
INSERT INTO `logs` VALUES ('112', '1', 'Atualizou o parametroAdmin 1', '2022-02-09 16:11:25', '2022-02-09 16:11:25');
INSERT INTO `logs` VALUES ('113', '1', 'Visualizou os parâmetros do administrativo', '2022-02-09 16:11:27', '2022-02-09 16:11:27');
INSERT INTO `logs` VALUES ('114', '1', 'Visualizou os parâmetros do administrativo', '2022-02-09 16:12:06', '2022-02-09 16:12:06');
INSERT INTO `logs` VALUES ('115', '1', 'Visualizou os parâmetros do administrativo', '2022-02-09 16:13:04', '2022-02-09 16:13:04');
INSERT INTO `logs` VALUES ('116', '1', 'Efetuou logout no sistema!', '2022-02-09 16:13:21', '2022-02-09 16:13:21');
INSERT INTO `logs` VALUES ('117', '1', 'Se logou no sistema', '2022-02-09 16:17:17', '2022-02-09 16:17:17');
INSERT INTO `logs` VALUES ('118', '1', 'Visualizou a tela inicial do sistema', '2022-02-09 16:17:17', '2022-02-09 16:17:17');
INSERT INTO `logs` VALUES ('119', '1', 'Visualizou os módulos do sistema', '2022-02-09 16:17:30', '2022-02-09 16:17:30');
INSERT INTO `logs` VALUES ('120', '1', 'Atualizou o modulo 14', '2022-02-09 16:19:23', '2022-02-09 16:19:23');
INSERT INTO `logs` VALUES ('121', '1', 'Atualizou o modulo 17', '2022-02-09 16:19:40', '2022-02-09 16:19:40');
INSERT INTO `logs` VALUES ('122', '1', 'Visualizou os módulos do sistema', '2022-02-09 16:19:44', '2022-02-09 16:19:44');
INSERT INTO `logs` VALUES ('123', '1', 'Excluiu o modulo 18', '2022-02-09 16:19:59', '2022-02-09 16:19:59');
INSERT INTO `logs` VALUES ('124', '1', 'Excluiu o modulo 19', '2022-02-09 16:20:02', '2022-02-09 16:20:02');
INSERT INTO `logs` VALUES ('125', '1', 'Excluiu o modulo 20', '2022-02-09 16:20:05', '2022-02-09 16:20:05');
INSERT INTO `logs` VALUES ('126', '1', 'Excluiu o modulo 43', '2022-02-09 16:20:08', '2022-02-09 16:20:08');
INSERT INTO `logs` VALUES ('127', '1', 'Excluiu o modulo 44', '2022-02-09 16:20:11', '2022-02-09 16:20:11');
INSERT INTO `logs` VALUES ('128', '1', 'Excluiu o modulo 45', '2022-02-09 16:20:14', '2022-02-09 16:20:14');
INSERT INTO `logs` VALUES ('129', '1', 'Excluiu o modulo 46', '2022-02-09 16:20:17', '2022-02-09 16:20:17');
INSERT INTO `logs` VALUES ('130', '1', 'Excluiu o modulo 54', '2022-02-09 16:20:22', '2022-02-09 16:20:22');
INSERT INTO `logs` VALUES ('131', '1', 'Excluiu o modulo 47', '2022-02-09 16:20:36', '2022-02-09 16:20:36');
INSERT INTO `logs` VALUES ('132', '1', 'Excluiu o modulo 48', '2022-02-09 16:20:40', '2022-02-09 16:20:40');
INSERT INTO `logs` VALUES ('133', '1', 'Excluiu o modulo 49', '2022-02-09 16:20:44', '2022-02-09 16:20:44');
INSERT INTO `logs` VALUES ('134', '1', 'Excluiu o modulo 50', '2022-02-09 16:20:48', '2022-02-09 16:20:48');
INSERT INTO `logs` VALUES ('135', '1', 'Excluiu o modulo 51', '2022-02-09 16:20:52', '2022-02-09 16:20:52');
INSERT INTO `logs` VALUES ('136', '1', 'Excluiu o modulo 53', '2022-02-09 16:20:55', '2022-02-09 16:20:55');
INSERT INTO `logs` VALUES ('137', '1', 'Excluiu o modulo 56', '2022-02-09 16:21:00', '2022-02-09 16:21:00');
INSERT INTO `logs` VALUES ('138', '1', 'Visualizou os módulos do sistema', '2022-02-09 16:21:03', '2022-02-09 16:21:03');
INSERT INTO `logs` VALUES ('139', '1', 'Visualizou os tipos de módulo do sistema', '2022-02-09 16:21:06', '2022-02-09 16:21:06');
INSERT INTO `logs` VALUES ('140', '0', 'Visualizou os módulos do sistema', '2022-02-09 16:21:21', '2022-02-09 16:21:21');
INSERT INTO `logs` VALUES ('141', '1', 'Visualizou os endereços do cliente 1', '2022-02-09 16:33:32', '2022-02-09 16:33:32');
INSERT INTO `logs` VALUES ('142', '1', 'Visualizou o clientes 1', '2022-02-09 16:33:38', '2022-02-09 16:33:38');
INSERT INTO `logs` VALUES ('143', '1', 'Visualizou o clientes 1', '2022-02-09 16:36:49', '2022-02-09 16:36:49');
INSERT INTO `logs` VALUES ('144', '1', 'Visualizou os endereços do cliente 1', '2022-02-09 16:36:54', '2022-02-09 16:36:54');
INSERT INTO `logs` VALUES ('145', '1', 'Visualizou os subítens do site', '2022-02-09 16:39:55', '2022-02-09 16:39:55');
INSERT INTO `logs` VALUES ('146', '1', 'Visualizou os subítens do site', '2022-02-09 16:40:27', '2022-02-09 16:40:27');
INSERT INTO `logs` VALUES ('147', '1', 'Visualizou os subítens do site', '2022-02-09 16:40:39', '2022-02-09 16:40:39');
INSERT INTO `logs` VALUES ('148', '1', 'Visualizou os módulos do sistema', '2022-02-09 16:40:45', '2022-02-09 16:40:45');
INSERT INTO `logs` VALUES ('149', '1', 'Atualizou o modulo 15', '2022-02-09 16:40:52', '2022-02-09 16:40:52');
INSERT INTO `logs` VALUES ('150', '1', 'Visualizou os módulos do sistema', '2022-02-09 16:40:57', '2022-02-09 16:40:57');
INSERT INTO `logs` VALUES ('151', '1', 'Visualizou as páginas do site', '2022-02-09 16:41:02', '2022-02-09 16:41:02');
INSERT INTO `logs` VALUES ('152', '1', 'Excluiu a pagina 2', '2022-02-09 16:42:53', '2022-02-09 16:42:53');
INSERT INTO `logs` VALUES ('153', '1', 'Excluiu a pagina 6', '2022-02-09 16:42:57', '2022-02-09 16:42:57');
INSERT INTO `logs` VALUES ('154', '1', 'Atualizou a pagina 7', '2022-02-09 16:46:37', '2022-02-09 16:46:37');
INSERT INTO `logs` VALUES ('155', '1', 'Visualizou as páginas do site', '2022-02-09 16:48:33', '2022-02-09 16:48:33');
INSERT INTO `logs` VALUES ('156', '1', 'Visualizou as páginas do site', '2022-02-09 16:48:34', '2022-02-09 16:48:34');
INSERT INTO `logs` VALUES ('157', '1', 'Atualizou a pagina 7', '2022-02-09 16:57:15', '2022-02-09 16:57:15');
INSERT INTO `logs` VALUES ('158', '1', 'Excluiu a pagina 10', '2022-02-09 16:57:37', '2022-02-09 16:57:37');
INSERT INTO `logs` VALUES ('159', '1', 'Excluiu a pagina 11', '2022-02-09 16:57:41', '2022-02-09 16:57:41');
INSERT INTO `logs` VALUES ('160', '1', 'Excluiu a pagina 12', '2022-02-09 16:57:44', '2022-02-09 16:57:44');
INSERT INTO `logs` VALUES ('161', '1', 'Excluiu a pagina 13', '2022-02-09 16:57:48', '2022-02-09 16:57:48');
INSERT INTO `logs` VALUES ('162', '1', 'Visualizou os subítens do site', '2022-02-09 16:57:51', '2022-02-09 16:57:51');
INSERT INTO `logs` VALUES ('163', '1', 'Excluiu o subitem 74', '2022-02-09 16:57:58', '2022-02-09 16:57:58');
INSERT INTO `logs` VALUES ('164', '1', 'Visualizou os subítens do site', '2022-02-09 16:58:13', '2022-02-09 16:58:13');
INSERT INTO `logs` VALUES ('165', '1', 'Visualizou as páginas do site', '2022-02-09 16:58:17', '2022-02-09 16:58:17');
INSERT INTO `logs` VALUES ('166', '1', 'Excluiu a pagina 14', '2022-02-09 16:58:25', '2022-02-09 16:58:25');
INSERT INTO `logs` VALUES ('167', '1', 'Excluiu a pagina 15', '2022-02-09 16:58:29', '2022-02-09 16:58:29');
INSERT INTO `logs` VALUES ('168', '1', 'Excluiu a pagina 16', '2022-02-09 16:58:33', '2022-02-09 16:58:33');
INSERT INTO `logs` VALUES ('169', '1', 'Excluiu a pagina 17', '2022-02-09 16:58:36', '2022-02-09 16:58:36');
INSERT INTO `logs` VALUES ('170', '1', 'Excluiu a pagina 18', '2022-02-09 16:58:39', '2022-02-09 16:58:39');
INSERT INTO `logs` VALUES ('171', '1', 'Excluiu a pagina 19', '2022-02-09 16:58:42', '2022-02-09 16:58:42');
INSERT INTO `logs` VALUES ('172', '1', 'Excluiu a pagina 20', '2022-02-09 16:58:47', '2022-02-09 16:58:47');
INSERT INTO `logs` VALUES ('173', '1', 'Excluiu a pagina 21', '2022-02-09 16:58:51', '2022-02-09 16:58:51');
INSERT INTO `logs` VALUES ('174', '1', 'Excluiu a pagina 22', '2022-02-09 16:58:54', '2022-02-09 16:58:54');
INSERT INTO `logs` VALUES ('175', '1', 'Visualizou as páginas do site', '2022-02-09 16:58:58', '2022-02-09 16:58:58');
INSERT INTO `logs` VALUES ('176', '1', 'Visualizou as páginas do site', '2022-02-09 16:59:21', '2022-02-09 16:59:21');
INSERT INTO `logs` VALUES ('177', '1', 'Visualizou os módulos do sistema', '2022-02-09 16:59:36', '2022-02-09 16:59:36');
INSERT INTO `logs` VALUES ('178', '1', 'Excluiu o modulo 14', '2022-02-09 16:59:44', '2022-02-09 16:59:44');
INSERT INTO `logs` VALUES ('179', '1', 'Excluiu o modulo 52', '2022-02-09 17:01:00', '2022-02-09 17:01:00');
INSERT INTO `logs` VALUES ('180', '1', 'Excluiu o modulo 37', '2022-02-09 17:01:04', '2022-02-09 17:01:04');
INSERT INTO `logs` VALUES ('181', '1', 'Excluiu o modulo 36', '2022-02-09 17:01:08', '2022-02-09 17:01:08');
INSERT INTO `logs` VALUES ('182', '1', 'Excluiu o modulo 35', '2022-02-09 17:01:14', '2022-02-09 17:01:14');
INSERT INTO `logs` VALUES ('183', '1', 'Excluiu o modulo 34', '2022-02-09 17:01:17', '2022-02-09 17:01:17');
INSERT INTO `logs` VALUES ('184', '1', 'Excluiu o modulo 33', '2022-02-09 17:01:23', '2022-02-09 17:01:23');
INSERT INTO `logs` VALUES ('185', '1', 'Excluiu o modulo 4', '2022-02-09 17:01:26', '2022-02-09 17:01:26');
INSERT INTO `logs` VALUES ('186', '1', 'Visualizou os módulos do sistema', '2022-02-09 17:01:38', '2022-02-09 17:01:38');
INSERT INTO `logs` VALUES ('187', '1', 'Visualizou os usuários pré-cadastrados do sistema', '2022-02-09 17:01:53', '2022-02-09 17:01:53');
INSERT INTO `logs` VALUES ('188', '1', 'Visualizou os usuários pré-cadastrados do sistema', '2022-02-09 17:06:18', '2022-02-09 17:06:18');
INSERT INTO `logs` VALUES ('189', '1', 'Visualizou os usuários pré-cadastrados do sistema', '2022-02-09 17:06:45', '2022-02-09 17:06:45');
INSERT INTO `logs` VALUES ('190', '1', 'Visualizou os usuários pré-cadastrados do sistema', '2022-02-09 17:07:30', '2022-02-09 17:07:30');
INSERT INTO `logs` VALUES ('191', '1', 'Visualizou o contador do site', '2022-02-09 17:07:37', '2022-02-09 17:07:37');
INSERT INTO `logs` VALUES ('192', '1', 'Visualizou os usuários pré-cadastrados do sistema', '2022-02-09 17:08:04', '2022-02-09 17:08:04');
INSERT INTO `logs` VALUES ('193', '1', 'Visualizou as páginas do site', '2022-02-09 17:08:09', '2022-02-09 17:08:09');
INSERT INTO `logs` VALUES ('194', '1', 'Visualizou as páginas do site', '2022-02-09 17:09:03', '2022-02-09 17:09:03');
INSERT INTO `logs` VALUES ('195', '1', 'Visualizou as páginas do site', '2022-02-09 17:09:30', '2022-02-09 17:09:30');
INSERT INTO `logs` VALUES ('196', '1', 'Atualizou a pagina 2', '2022-02-09 17:09:41', '2022-02-09 17:09:41');
INSERT INTO `logs` VALUES ('197', '1', 'Atualizou a pagina 1', '2022-02-09 17:13:21', '2022-02-09 17:13:21');
INSERT INTO `logs` VALUES ('198', '1', 'Atualizou a pagina 2', '2022-02-09 17:15:26', '2022-02-09 17:15:26');
INSERT INTO `logs` VALUES ('199', '1', 'Visualizou as páginas do site', '2022-02-09 17:18:18', '2022-02-09 17:18:18');
INSERT INTO `logs` VALUES ('200', '1', 'Atualizou a pagina 3', '2022-02-09 17:18:42', '2022-02-09 17:18:42');
INSERT INTO `logs` VALUES ('201', '0', 'Visualizou a tela inicial do sistema', '2022-02-09 17:25:54', '2022-02-09 17:25:54');
INSERT INTO `logs` VALUES ('202', '1', 'Se logou no sistema', '2022-02-09 17:26:00', '2022-02-09 17:26:00');
INSERT INTO `logs` VALUES ('203', '1', 'Visualizou a tela inicial do sistema', '2022-02-09 17:26:00', '2022-02-09 17:26:00');
INSERT INTO `logs` VALUES ('204', '1', 'Visualizou as páginas do site', '2022-02-09 17:26:04', '2022-02-09 17:26:04');
INSERT INTO `logs` VALUES ('205', '1', 'Visualizou os subítens do site', '2022-02-09 17:26:06', '2022-02-09 17:26:06');
INSERT INTO `logs` VALUES ('206', '1', 'Cadastrou a subitem 1', '2022-02-09 17:42:14', '2022-02-09 17:42:14');
INSERT INTO `logs` VALUES ('207', '1', 'Visualizou os subítens do site', '2022-02-09 17:43:09', '2022-02-09 17:43:09');
INSERT INTO `logs` VALUES ('208', '1', 'Cadastrou a subitem 2', '2022-02-09 17:43:58', '2022-02-09 17:43:58');
INSERT INTO `logs` VALUES ('209', '1', 'Visualizou os subítens do site', '2022-02-09 17:44:31', '2022-02-09 17:44:31');
INSERT INTO `logs` VALUES ('210', '1', 'Visualizou os módulos do sistema', '2022-02-09 17:44:38', '2022-02-09 17:44:38');
INSERT INTO `logs` VALUES ('211', '1', 'Atualizou o modulo 15', '2022-02-09 17:45:04', '2022-02-09 17:45:04');
INSERT INTO `logs` VALUES ('212', '1', 'Atualizou o modulo 16', '2022-02-09 17:45:21', '2022-02-09 17:45:21');
INSERT INTO `logs` VALUES ('213', '1', 'Atualizou o modulo 17', '2022-02-09 17:45:33', '2022-02-09 17:45:33');
INSERT INTO `logs` VALUES ('214', '1', 'Visualizou os módulos do sistema', '2022-02-09 17:45:38', '2022-02-09 17:45:38');
INSERT INTO `logs` VALUES ('215', '1', 'Visualizou os módulos do sistema', '2022-02-09 17:45:46', '2022-02-09 17:45:46');
INSERT INTO `logs` VALUES ('216', '1', 'Atualizou o modulo 16', '2022-02-09 17:45:54', '2022-02-09 17:45:54');
INSERT INTO `logs` VALUES ('217', '1', 'Visualizou os módulos do sistema', '2022-02-09 17:45:59', '2022-02-09 17:45:59');
INSERT INTO `logs` VALUES ('218', '1', 'Visualizou as páginas do site', '2022-02-09 17:46:03', '2022-02-09 17:46:03');
INSERT INTO `logs` VALUES ('219', '1', 'Visualizou os módulos do sistema', '2022-02-09 17:46:18', '2022-02-09 17:46:18');
INSERT INTO `logs` VALUES ('220', '1', 'Atualizou o modulo 17', '2022-02-09 17:46:28', '2022-02-09 17:46:28');
INSERT INTO `logs` VALUES ('221', '1', 'Visualizou os módulos do sistema', '2022-02-09 17:46:30', '2022-02-09 17:46:30');
INSERT INTO `logs` VALUES ('222', '1', 'Visualizou os subítens do site', '2022-02-09 17:46:33', '2022-02-09 17:46:33');
INSERT INTO `logs` VALUES ('223', '1', 'Cadastrou a categoria 1', '2022-02-09 17:55:58', '2022-02-09 17:55:58');
INSERT INTO `logs` VALUES ('224', '1', 'Cadastrou a categoria 2', '2022-02-09 17:57:50', '2022-02-09 17:57:50');
INSERT INTO `logs` VALUES ('225', '1', 'Cadastrou a categoria 3', '2022-02-09 17:58:07', '2022-02-09 17:58:07');
INSERT INTO `logs` VALUES ('226', '1', 'Visualizou os subítens do site', '2022-02-09 17:59:42', '2022-02-09 17:59:42');
INSERT INTO `logs` VALUES ('227', '1', 'Visualizou os subítens do site', '2022-02-09 18:06:12', '2022-02-09 18:06:12');
INSERT INTO `logs` VALUES ('228', '1', 'Visualizou os subítens do site', '2022-02-09 18:06:53', '2022-02-09 18:06:53');
INSERT INTO `logs` VALUES ('229', '1', 'Visualizou os subítens do site', '2022-02-09 18:07:43', '2022-02-09 18:07:43');
INSERT INTO `logs` VALUES ('230', '1', 'Visualizou os subítens do site', '2022-02-09 18:07:43', '2022-02-09 18:07:43');
INSERT INTO `logs` VALUES ('231', '1', 'Atualizou o subitem 1', '2022-02-09 18:13:05', '2022-02-09 18:13:05');
INSERT INTO `logs` VALUES ('232', '1', 'Visualizou os subítens do site', '2022-02-09 18:15:39', '2022-02-09 18:15:39');
INSERT INTO `logs` VALUES ('233', '1', 'Visualizou os subítens do site', '2022-02-09 18:17:52', '2022-02-09 18:17:52');
INSERT INTO `logs` VALUES ('234', '1', 'Visualizou os subítens do site', '2022-02-09 18:18:48', '2022-02-09 18:18:48');
INSERT INTO `logs` VALUES ('235', '1', 'Visualizou os subítens do site', '2022-02-09 18:18:51', '2022-02-09 18:18:51');
INSERT INTO `logs` VALUES ('236', '1', 'Atualizou o subitem 2', '2022-02-09 18:19:04', '2022-02-09 18:19:04');
INSERT INTO `logs` VALUES ('237', '1', 'Cadastrou a subitem 3', '2022-02-09 18:19:34', '2022-02-09 18:19:34');
INSERT INTO `logs` VALUES ('238', '1', 'Atualizou o subitem 3', '2022-02-09 18:19:42', '2022-02-09 18:19:42');
INSERT INTO `logs` VALUES ('239', '1', 'Cadastrou a subitem 4', '2022-02-09 19:27:50', '2022-02-09 19:27:50');
INSERT INTO `logs` VALUES ('240', '1', 'Atualizou o subitem 4', '2022-02-09 19:27:58', '2022-02-09 19:27:58');
INSERT INTO `logs` VALUES ('241', '1', 'Visualizou os parâmetros do administrativo', '2022-02-09 19:30:57', '2022-02-09 19:30:57');
INSERT INTO `logs` VALUES ('242', '1', 'Atualizou o parametroAdmin 1', '2022-02-09 19:31:32', '2022-02-09 19:31:32');
INSERT INTO `logs` VALUES ('243', '1', 'Visualizou os parâmetros do administrativo', '2022-02-09 19:31:32', '2022-02-09 19:31:32');
INSERT INTO `logs` VALUES ('244', '1', 'Visualizou os subítens do site', '2022-02-09 19:31:44', '2022-02-09 19:31:44');
INSERT INTO `logs` VALUES ('245', '1', 'Visualizou os subítens do site', '2022-02-09 19:32:37', '2022-02-09 19:32:37');
INSERT INTO `logs` VALUES ('246', '1', 'Cadastrou a subitem 5', '2022-02-09 19:32:59', '2022-02-09 19:32:59');
INSERT INTO `logs` VALUES ('247', '1', 'Cadastrou a subitem 6', '2022-02-09 19:33:25', '2022-02-09 19:33:25');
INSERT INTO `logs` VALUES ('248', '1', 'Cadastrou a subitem 7', '2022-02-09 19:33:53', '2022-02-09 19:33:53');
INSERT INTO `logs` VALUES ('249', '1', 'Cadastrou a subitem 8', '2022-02-09 19:34:15', '2022-02-09 19:34:15');
INSERT INTO `logs` VALUES ('250', '1', 'Cadastrou a subitem 9', '2022-02-09 19:34:43', '2022-02-09 19:34:43');
INSERT INTO `logs` VALUES ('251', '1', 'Atualizou o subitem 1', '2022-02-09 19:36:11', '2022-02-09 19:36:11');
INSERT INTO `logs` VALUES ('252', '1', 'Visualizou o subitem 1', '2022-02-09 19:36:16', '2022-02-09 19:36:16');
INSERT INTO `logs` VALUES ('253', '1', 'Atualizou o subitem 2', '2022-02-09 19:36:30', '2022-02-09 19:36:30');
INSERT INTO `logs` VALUES ('254', '1', 'Visualizou o subitem 2', '2022-02-09 19:36:33', '2022-02-09 19:36:33');
INSERT INTO `logs` VALUES ('255', '1', 'Visualizou o subitem 3', '2022-02-09 19:36:37', '2022-02-09 19:36:37');
INSERT INTO `logs` VALUES ('256', '1', 'Atualizou o subitem 3', '2022-02-09 19:36:47', '2022-02-09 19:36:47');
INSERT INTO `logs` VALUES ('257', '1', 'Atualizou o subitem 4', '2022-02-09 19:36:56', '2022-02-09 19:36:56');
INSERT INTO `logs` VALUES ('258', '1', 'Atualizou o subitem 5', '2022-02-09 19:37:07', '2022-02-09 19:37:07');
INSERT INTO `logs` VALUES ('259', '1', 'Visualizou o subitem 5', '2022-02-09 19:37:19', '2022-02-09 19:37:19');
INSERT INTO `logs` VALUES ('260', '1', 'Visualizou o subitem 6', '2022-02-09 19:37:24', '2022-02-09 19:37:24');
INSERT INTO `logs` VALUES ('261', '1', 'Atualizou o subitem 6', '2022-02-09 19:37:34', '2022-02-09 19:37:34');
INSERT INTO `logs` VALUES ('262', '1', 'Atualizou o subitem 7', '2022-02-09 19:37:44', '2022-02-09 19:37:44');
INSERT INTO `logs` VALUES ('263', '1', 'Atualizou o subitem 8', '2022-02-09 19:37:54', '2022-02-09 19:37:54');
INSERT INTO `logs` VALUES ('264', '1', 'Atualizou o subitem 9', '2022-02-09 19:38:06', '2022-02-09 19:38:06');
INSERT INTO `logs` VALUES ('265', '1', 'Visualizou o subitem 9', '2022-02-09 19:38:10', '2022-02-09 19:38:10');
INSERT INTO `logs` VALUES ('266', '1', 'Visualizou o subitem 8', '2022-02-09 19:38:14', '2022-02-09 19:38:14');
INSERT INTO `logs` VALUES ('267', '1', 'Visualizou os subítens do site', '2022-02-09 19:40:25', '2022-02-09 19:40:25');
INSERT INTO `logs` VALUES ('268', '1', 'Visualizou o subitem 1', '2022-02-09 19:40:32', '2022-02-09 19:40:32');
INSERT INTO `logs` VALUES ('269', '1', 'Visualizou as páginas do site', '2022-02-09 19:40:51', '2022-02-09 19:40:51');
INSERT INTO `logs` VALUES ('270', '1', 'Atualizou a pagina 1', '2022-02-09 19:41:09', '2022-02-09 19:41:09');
INSERT INTO `logs` VALUES ('271', '1', 'Atualizou a pagina 1', '2022-02-09 19:41:27', '2022-02-09 19:41:27');
INSERT INTO `logs` VALUES ('272', '1', 'Atualizou a pagina 1', '2022-02-09 19:42:50', '2022-02-09 19:42:50');
INSERT INTO `logs` VALUES ('273', '1', 'Atualizou a pagina 1', '2022-02-09 19:43:17', '2022-02-09 19:43:17');
INSERT INTO `logs` VALUES ('274', '1', 'Atualizou a pagina 1', '2022-02-09 19:43:32', '2022-02-09 19:43:32');
INSERT INTO `logs` VALUES ('275', '1', 'Atualizou a pagina 1', '2022-02-09 19:43:57', '2022-02-09 19:43:57');
INSERT INTO `logs` VALUES ('276', '1', 'Atualizou a pagina 1', '2022-02-09 19:44:17', '2022-02-09 19:44:17');
INSERT INTO `logs` VALUES ('277', '1', 'Atualizou a pagina 1', '2022-02-09 19:44:44', '2022-02-09 19:44:44');
INSERT INTO `logs` VALUES ('278', '1', 'Visualizou os parâmetros do site', '2022-02-09 19:55:11', '2022-02-09 19:55:11');
INSERT INTO `logs` VALUES ('279', '1', 'Visualizou os parâmetros do site', '2022-02-09 19:56:06', '2022-02-09 19:56:06');
INSERT INTO `logs` VALUES ('280', '1', 'Visualizou os parâmetros do site', '2022-02-09 19:57:07', '2022-02-09 19:57:07');
INSERT INTO `logs` VALUES ('281', '1', 'Excluiu o parametro_do_site 26', '2022-02-09 19:57:13', '2022-02-09 19:57:13');
INSERT INTO `logs` VALUES ('282', '1', 'Excluiu o parametro_do_site 25', '2022-02-09 19:57:16', '2022-02-09 19:57:16');
INSERT INTO `logs` VALUES ('283', '1', 'Excluiu o parametro_do_site 24', '2022-02-09 19:57:20', '2022-02-09 19:57:20');
INSERT INTO `logs` VALUES ('284', '1', 'Excluiu o parametro_do_site 22', '2022-02-09 19:57:28', '2022-02-09 19:57:28');
INSERT INTO `logs` VALUES ('285', '1', 'Excluiu o parametro_do_site 19', '2022-02-09 19:57:39', '2022-02-09 19:57:39');
INSERT INTO `logs` VALUES ('286', '1', 'Excluiu o parametro_do_site 20', '2022-02-09 19:57:44', '2022-02-09 19:57:44');
INSERT INTO `logs` VALUES ('287', '1', 'Atualizou o parametroSite 18', '2022-02-09 19:58:15', '2022-02-09 19:58:15');
INSERT INTO `logs` VALUES ('288', '1', 'Excluiu o parametro_do_site 16', '2022-02-09 19:58:23', '2022-02-09 19:58:23');
INSERT INTO `logs` VALUES ('289', '1', 'Excluiu o parametro_do_site 15', '2022-02-09 19:58:27', '2022-02-09 19:58:27');
INSERT INTO `logs` VALUES ('290', '1', 'Excluiu o parametro_do_site 14', '2022-02-09 19:58:31', '2022-02-09 19:58:31');
INSERT INTO `logs` VALUES ('291', '1', 'Excluiu o parametro_do_site 13', '2022-02-09 19:58:37', '2022-02-09 19:58:37');
INSERT INTO `logs` VALUES ('292', '1', 'Excluiu o parametro_do_site 12', '2022-02-09 19:58:42', '2022-02-09 19:58:42');
INSERT INTO `logs` VALUES ('293', '1', 'Excluiu o parametro_do_site 11', '2022-02-09 19:58:45', '2022-02-09 19:58:45');
INSERT INTO `logs` VALUES ('294', '1', 'Excluiu o parametro_do_site 10', '2022-02-09 19:58:49', '2022-02-09 19:58:49');
INSERT INTO `logs` VALUES ('295', '1', 'Excluiu o parametro_do_site 9', '2022-02-09 19:58:53', '2022-02-09 19:58:53');
INSERT INTO `logs` VALUES ('296', '1', 'Excluiu o parametro_do_site 8', '2022-02-09 19:58:57', '2022-02-09 19:58:57');
INSERT INTO `logs` VALUES ('297', '1', 'Excluiu o parametro_do_site 7', '2022-02-09 19:59:01', '2022-02-09 19:59:01');
INSERT INTO `logs` VALUES ('298', '1', 'Excluiu o parametro_do_site 6', '2022-02-09 19:59:06', '2022-02-09 19:59:06');
INSERT INTO `logs` VALUES ('299', '1', 'Excluiu o parametro_do_site 5', '2022-02-09 19:59:09', '2022-02-09 19:59:09');
INSERT INTO `logs` VALUES ('300', '1', 'Excluiu o parametro_do_site 2', '2022-02-09 19:59:16', '2022-02-09 19:59:16');
INSERT INTO `logs` VALUES ('301', '1', 'Excluiu o parametro_do_site 1', '2022-02-09 19:59:19', '2022-02-09 19:59:19');
INSERT INTO `logs` VALUES ('302', '1', 'Atualizou o parametroSite 3', '2022-02-09 19:59:40', '2022-02-09 19:59:40');
INSERT INTO `logs` VALUES ('303', '1', 'Atualizou o parametroSite 4', '2022-02-09 20:00:16', '2022-02-09 20:00:16');
INSERT INTO `logs` VALUES ('304', '1', 'Atualizou o parametroSite 18', '2022-02-09 20:00:48', '2022-02-09 20:00:48');
INSERT INTO `logs` VALUES ('305', '1', 'Cadastrou o parametroSite 27', '2022-02-09 20:02:18', '2022-02-09 20:02:18');
INSERT INTO `logs` VALUES ('306', '0', 'Visualizou a tela inicial do sistema', '2022-02-09 20:02:56', '2022-02-09 20:02:56');
INSERT INTO `logs` VALUES ('307', '1', 'Visualizou os módulos do sistema', '2022-02-09 20:13:47', '2022-02-09 20:13:47');
INSERT INTO `logs` VALUES ('308', '1', 'Cadastrou o modulo 58', '2022-02-09 20:14:12', '2022-02-09 20:14:12');
INSERT INTO `logs` VALUES ('309', '1', 'Visualizou os módulos do sistema', '2022-02-09 20:14:15', '2022-02-09 20:14:15');
INSERT INTO `logs` VALUES ('310', '1', 'Visualizou as permissões do sistema', '2022-02-09 20:14:27', '2022-02-09 20:14:27');
INSERT INTO `logs` VALUES ('311', '1', 'Visualizou as permissões do usuário  1', '2022-02-09 20:14:30', '2022-02-09 20:14:30');
INSERT INTO `logs` VALUES ('312', '1', 'Adicionou a permissão de view o módulo 58  do usuário  1', '2022-02-09 20:14:32', '2022-02-09 20:14:32');
INSERT INTO `logs` VALUES ('313', '1', 'Adicionou a permissão de register o módulo 58  do usuário  1', '2022-02-09 20:14:34', '2022-02-09 20:14:34');
INSERT INTO `logs` VALUES ('314', '1', 'Adicionou a permissão de delete o módulo 58  do usuário  1', '2022-02-09 20:14:36', '2022-02-09 20:14:36');
INSERT INTO `logs` VALUES ('315', '1', 'Visualizou as permissões do sistema', '2022-02-09 20:20:05', '2022-02-09 20:20:05');
INSERT INTO `logs` VALUES ('316', '1', 'Visualizou as permissões do usuário  1', '2022-02-09 20:20:13', '2022-02-09 20:20:13');
INSERT INTO `logs` VALUES ('317', '1', 'Visualizou as permissões do usuário  2', '2022-02-09 20:20:17', '2022-02-09 20:20:17');
INSERT INTO `logs` VALUES ('318', '1', 'Adicionou a permissão de view o módulo 24  do usuário  2', '2022-02-09 20:20:21', '2022-02-09 20:20:21');
INSERT INTO `logs` VALUES ('319', '1', 'Adicionou a permissão de register o módulo 24  do usuário  2', '2022-02-09 20:20:22', '2022-02-09 20:20:22');
INSERT INTO `logs` VALUES ('320', '1', 'Adicionou a permissão de delete o módulo 24  do usuário  2', '2022-02-09 20:20:25', '2022-02-09 20:20:25');
INSERT INTO `logs` VALUES ('321', '1', 'Adicionou a permissão de delete o módulo 58  do usuário  2', '2022-02-09 20:20:26', '2022-02-09 20:20:26');
INSERT INTO `logs` VALUES ('322', '1', 'Adicionou a permissão de register o módulo 58  do usuário  2', '2022-02-09 20:20:28', '2022-02-09 20:20:28');
INSERT INTO `logs` VALUES ('323', '1', 'Adicionou a permissão de view o módulo 58  do usuário  2', '2022-02-09 20:20:30', '2022-02-09 20:20:30');
INSERT INTO `logs` VALUES ('324', '1', 'Visualizou as permissões do sistema', '2022-02-09 20:20:31', '2022-02-09 20:20:31');
INSERT INTO `logs` VALUES ('325', '1', 'Visualizou as permissões do usuário  2', '2022-02-09 20:20:34', '2022-02-09 20:20:34');
INSERT INTO `logs` VALUES ('326', '1', 'Adicionou a permissão de register o módulo 58  do usuário  2', '2022-02-09 20:20:36', '2022-02-09 20:20:36');
INSERT INTO `logs` VALUES ('327', '1', 'Adicionou a permissão de delete o módulo 58  do usuário  2', '2022-02-09 20:20:38', '2022-02-09 20:20:38');
INSERT INTO `logs` VALUES ('328', '1', 'Visualizou as permissões do sistema', '2022-02-09 20:20:39', '2022-02-09 20:20:39');
INSERT INTO `logs` VALUES ('329', '1', 'Visualizou as permissões do usuário  2', '2022-02-09 20:21:32', '2022-02-09 20:21:32');
INSERT INTO `logs` VALUES ('330', '1', 'Visualizou as redes sociais do site', '2022-02-09 20:35:36', '2022-02-09 20:35:36');
INSERT INTO `logs` VALUES ('331', '1', 'Visualizou as redes sociais do site', '2022-02-09 20:36:30', '2022-02-09 20:36:30');
INSERT INTO `logs` VALUES ('332', '1', 'Visualizou as redes sociais do site', '2022-02-09 20:36:49', '2022-02-09 20:36:49');
INSERT INTO `logs` VALUES ('333', '1', 'Visualizou as redes sociais do site', '2022-02-09 20:37:20', '2022-02-09 20:37:20');
INSERT INTO `logs` VALUES ('334', '1', 'Visualizou as redes sociais do site', '2022-02-09 20:38:04', '2022-02-09 20:38:04');
INSERT INTO `logs` VALUES ('335', '1', 'Visualizou as redes sociais do site', '2022-02-09 20:39:07', '2022-02-09 20:39:07');
INSERT INTO `logs` VALUES ('336', '1', 'Visualizou o social_networks 1', '2022-02-09 20:39:21', '2022-02-09 20:39:21');
INSERT INTO `logs` VALUES ('337', '1', 'Visualizou as redes sociais do site', '2022-02-09 20:40:59', '2022-02-09 20:40:59');
INSERT INTO `logs` VALUES ('338', '1', 'Visualizou as redes sociais do site', '2022-02-09 20:41:55', '2022-02-09 20:41:55');
INSERT INTO `logs` VALUES ('339', '1', 'Visualizou as redes sociais do site', '2022-02-09 20:42:08', '2022-02-09 20:42:08');
INSERT INTO `logs` VALUES ('340', '1', 'Atualizou  redesSociais 4', '2022-02-09 20:55:15', '2022-02-09 20:55:15');
INSERT INTO `logs` VALUES ('341', '1', 'Atualizou  redesSociais 4', '2022-02-09 20:56:41', '2022-02-09 20:56:41');
INSERT INTO `logs` VALUES ('342', '0', 'Atualizou  redesSociais 4', '2022-02-09 20:57:25', '2022-02-09 20:57:25');
INSERT INTO `logs` VALUES ('343', '1', 'Atualizou  redesSociais 4', '2022-02-09 21:32:34', '2022-02-09 21:32:34');
INSERT INTO `logs` VALUES ('344', '1', 'Atualizou  redesSociais 4', '2022-02-09 21:34:27', '2022-02-09 21:34:27');
INSERT INTO `logs` VALUES ('345', '1', 'Atualizou o redesSociais 4', '2022-02-09 22:02:49', '2022-02-09 22:02:49');
INSERT INTO `logs` VALUES ('346', '1', 'Visualizou os parâmetros do site', '2022-02-09 22:38:07', '2022-02-09 22:38:07');
INSERT INTO `logs` VALUES ('347', '1', 'Visualizou as páginas do site', '2022-02-09 22:55:02', '2022-02-09 22:55:02');
INSERT INTO `logs` VALUES ('348', '1', 'Visualizou os subítens do site', '2022-02-09 22:55:04', '2022-02-09 22:55:04');
INSERT INTO `logs` VALUES ('349', '1', 'Visualizou os subítens do site', '2022-02-09 23:16:20', '2022-02-09 23:16:20');
INSERT INTO `logs` VALUES ('350', '1', 'Visualizou as redes sociais do site', '2022-02-10 00:06:45', '2022-02-10 00:06:45');
INSERT INTO `logs` VALUES ('351', '1', 'Visualizou o social_networks 1', '2022-02-10 00:06:53', '2022-02-10 00:06:53');
INSERT INTO `logs` VALUES ('352', '1', 'Visualizou os subítens do site', '2022-02-10 01:22:27', '2022-02-10 01:22:27');
INSERT INTO `logs` VALUES ('353', '1', 'Atualizou o subitem 1', '2022-02-10 01:23:22', '2022-02-10 01:23:22');
INSERT INTO `logs` VALUES ('354', '1', 'Atualizou o subitem 1', '2022-02-10 01:25:18', '2022-02-10 01:25:18');
INSERT INTO `logs` VALUES ('355', '1', 'Atualizou o subitem 1', '2022-02-10 01:25:37', '2022-02-10 01:25:37');
INSERT INTO `logs` VALUES ('356', '1', 'Atualizou o subitem 2', '2022-02-10 01:26:08', '2022-02-10 01:26:08');
INSERT INTO `logs` VALUES ('357', '1', 'Atualizou o subitem 2', '2022-02-10 01:26:39', '2022-02-10 01:26:39');
INSERT INTO `logs` VALUES ('358', '1', 'Atualizou o subitem 2', '2022-02-10 01:27:28', '2022-02-10 01:27:28');
INSERT INTO `logs` VALUES ('359', '1', 'Atualizou o subitem 2', '2022-02-10 01:29:25', '2022-02-10 01:29:25');
INSERT INTO `logs` VALUES ('360', '1', 'Atualizou o subitem 1', '2022-02-10 01:29:48', '2022-02-10 01:29:48');
INSERT INTO `logs` VALUES ('361', '1', 'Atualizou o subitem 3', '2022-02-10 01:32:17', '2022-02-10 01:32:17');
INSERT INTO `logs` VALUES ('362', '1', 'Atualizou o subitem 4', '2022-02-10 01:33:48', '2022-02-10 01:33:48');
INSERT INTO `logs` VALUES ('363', '1', 'Atualizou o subitem 4', '2022-02-10 01:34:05', '2022-02-10 01:34:05');
INSERT INTO `logs` VALUES ('364', '1', 'Atualizou o subitem 5', '2022-02-10 01:34:55', '2022-02-10 01:34:55');
INSERT INTO `logs` VALUES ('365', '1', 'Atualizou o subitem 6', '2022-02-10 01:36:15', '2022-02-10 01:36:15');
INSERT INTO `logs` VALUES ('366', '1', 'Atualizou o subitem 7', '2022-02-10 01:36:40', '2022-02-10 01:36:40');
INSERT INTO `logs` VALUES ('367', '1', 'Atualizou o subitem 8', '2022-02-10 01:36:52', '2022-02-10 01:36:52');
INSERT INTO `logs` VALUES ('368', '1', 'Atualizou o subitem 9', '2022-02-10 01:37:06', '2022-02-10 01:37:06');
INSERT INTO `logs` VALUES ('369', '1', 'Visualizou os parâmetros do site', '2022-02-10 01:56:04', '2022-02-10 01:56:04');
INSERT INTO `logs` VALUES ('370', '1', 'Visualizou a tela inicial do sistema', '2022-02-10 02:00:44', '2022-02-10 02:00:44');
INSERT INTO `logs` VALUES ('371', '1', 'Visualizou os Fale Conoscos do Site', '2022-02-10 02:01:02', '2022-02-10 02:01:02');
INSERT INTO `logs` VALUES ('372', '1', 'Visualizou os Fale Conoscos do Site', '2022-02-10 02:03:50', '2022-02-10 02:03:50');
INSERT INTO `logs` VALUES ('373', '1', 'Visualizou os Fale Conoscos do Site', '2022-02-10 02:04:05', '2022-02-10 02:04:05');
INSERT INTO `logs` VALUES ('374', '1', 'Visualizou os Fale Conoscos do Site', '2022-02-10 02:04:51', '2022-02-10 02:04:51');
INSERT INTO `logs` VALUES ('375', '1', 'Visualizou os Fale Conoscos do Site', '2022-02-10 02:18:03', '2022-02-10 02:18:03');
INSERT INTO `logs` VALUES ('376', '1', 'Visualizou os Fale Conoscos do Site', '2022-02-10 02:24:05', '2022-02-10 02:24:05');
INSERT INTO `logs` VALUES ('377', '1', 'Visualizou os Fale Conoscos do Site', '2022-02-10 02:26:42', '2022-02-10 02:26:42');
INSERT INTO `logs` VALUES ('378', '1', 'Visualizou os Fale Conoscos do Site', '2022-02-10 02:28:11', '2022-02-10 02:28:11');
INSERT INTO `logs` VALUES ('379', '1', 'Atualizou o faleConosco 3', '2022-02-10 02:28:22', '2022-02-10 02:28:22');
INSERT INTO `logs` VALUES ('380', '1', 'Atualizou o faleConosco 3', '2022-02-10 02:28:35', '2022-02-10 02:28:35');
INSERT INTO `logs` VALUES ('381', '1', 'Visualizou o contador do site', '2022-02-10 02:29:04', '2022-02-10 02:29:04');
INSERT INTO `logs` VALUES ('382', '1', 'Visualizou o contador do site', '2022-02-10 02:30:45', '2022-02-10 02:30:45');
INSERT INTO `logs` VALUES ('383', '1', 'Visualizou o contador por página', '2022-02-10 02:30:54', '2022-02-10 02:30:54');
INSERT INTO `logs` VALUES ('384', '1', 'Visualizou o contador por subítem', '2022-02-10 02:30:57', '2022-02-10 02:30:57');
INSERT INTO `logs` VALUES ('385', '1', 'Visualizou o contador do site', '2022-02-10 02:32:07', '2022-02-10 02:32:07');
INSERT INTO `logs` VALUES ('386', '1', 'Visualizou o contador do site', '2022-02-10 02:32:15', '2022-02-10 02:32:15');
INSERT INTO `logs` VALUES ('387', '1', 'Visualizou o contador do site', '2022-02-10 02:32:20', '2022-02-10 02:32:20');
INSERT INTO `logs` VALUES ('388', '1', 'Visualizou os Fale Conoscos do Site', '2022-02-10 02:33:56', '2022-02-10 02:33:56');
INSERT INTO `logs` VALUES ('389', '1', 'Visualizou os Fale Conoscos do Site', '2022-02-10 02:34:06', '2022-02-10 02:34:06');
INSERT INTO `logs` VALUES ('390', '1', 'Visualizou o contador do site', '2022-02-10 02:34:19', '2022-02-10 02:34:19');
INSERT INTO `logs` VALUES ('391', '1', 'Visualizou o contador do site', '2022-02-10 02:34:43', '2022-02-10 02:34:43');
INSERT INTO `logs` VALUES ('392', '1', 'Visualizou o contador por página', '2022-02-10 02:34:47', '2022-02-10 02:34:47');
INSERT INTO `logs` VALUES ('393', '1', 'Visualizou o contador por página', '2022-02-10 02:35:40', '2022-02-10 02:35:40');
INSERT INTO `logs` VALUES ('394', '1', 'Visualizou o contador por subítem', '2022-02-10 02:35:44', '2022-02-10 02:35:44');
INSERT INTO `logs` VALUES ('395', '1', 'Visualizou as redes sociais do site', '2022-02-10 02:36:58', '2022-02-10 02:36:58');
INSERT INTO `logs` VALUES ('396', '1', 'Visualizou o contador do site', '2022-02-10 02:45:21', '2022-02-10 02:45:21');
INSERT INTO `logs` VALUES ('397', '1', 'Visualizou o contador do site', '2022-02-10 02:48:26', '2022-02-10 02:48:26');
INSERT INTO `logs` VALUES ('398', '0', 'Visualizou o contador por página', '2022-02-10 02:52:54', '2022-02-10 02:52:54');
INSERT INTO `logs` VALUES ('399', '1', 'Se logou no sistema', '2022-02-10 02:53:02', '2022-02-10 02:53:02');
INSERT INTO `logs` VALUES ('400', '1', 'Visualizou o contador por página', '2022-02-10 02:53:02', '2022-02-10 02:53:02');
INSERT INTO `logs` VALUES ('401', '1', 'Visualizou o contador por subítem', '2022-02-10 02:53:07', '2022-02-10 02:53:07');
INSERT INTO `logs` VALUES ('402', '1', 'Visualizou o contador por subítem', '2022-02-10 02:56:57', '2022-02-10 02:56:57');
INSERT INTO `logs` VALUES ('403', '1', 'Visualizou o contador por página', '2022-02-10 02:57:00', '2022-02-10 02:57:00');
INSERT INTO `logs` VALUES ('404', '1', 'Visualizou o contador do site', '2022-02-10 02:57:04', '2022-02-10 02:57:04');
INSERT INTO `logs` VALUES ('405', '1', 'Visualizou o contador do site', '2022-02-10 02:58:32', '2022-02-10 02:58:32');
INSERT INTO `logs` VALUES ('406', '1', 'Visualizou o contador por subítem', '2022-02-10 03:00:09', '2022-02-10 03:00:09');
INSERT INTO `logs` VALUES ('407', '0', 'Visualizou o contador por subítem', '2022-02-10 11:45:01', '2022-02-10 11:45:01');
INSERT INTO `logs` VALUES ('408', '1', 'Se logou no sistema', '2022-02-10 11:45:10', '2022-02-10 11:45:10');
INSERT INTO `logs` VALUES ('409', '1', 'Visualizou o contador por subítem', '2022-02-10 11:45:10', '2022-02-10 11:45:10');
INSERT INTO `logs` VALUES ('410', '1', 'Visualizou o contador por página', '2022-02-10 11:45:18', '2022-02-10 11:45:18');
INSERT INTO `logs` VALUES ('411', '1', 'Visualizou o contador do site', '2022-02-10 11:45:19', '2022-02-10 11:45:19');
INSERT INTO `logs` VALUES ('412', '1', 'Visualizou o contador do site', '2022-02-10 12:02:55', '2022-02-10 12:02:55');
INSERT INTO `logs` VALUES ('413', '1', 'Visualizou o contador do site', '2022-02-10 12:05:20', '2022-02-10 12:05:20');
INSERT INTO `logs` VALUES ('414', '1', 'Visualizou o contador do site', '2022-02-10 12:14:56', '2022-02-10 12:14:56');
INSERT INTO `logs` VALUES ('415', '1', 'Visualizou o contador do site', '2022-02-10 12:27:37', '2022-02-10 12:27:37');
INSERT INTO `logs` VALUES ('416', '1', 'Visualizou o contador do site', '2022-02-10 12:27:49', '2022-02-10 12:27:49');
INSERT INTO `logs` VALUES ('417', '1', 'Visualizou o contador do site', '2022-02-10 12:28:25', '2022-02-10 12:28:25');
INSERT INTO `logs` VALUES ('418', '1', 'Visualizou o contador do site', '2022-02-10 12:28:35', '2022-02-10 12:28:35');
INSERT INTO `logs` VALUES ('419', '1', 'Visualizou o contador por página', '2022-02-10 12:31:02', '2022-02-10 12:31:02');
INSERT INTO `logs` VALUES ('420', '1', 'Visualizou o contador por página', '2022-02-10 12:31:35', '2022-02-10 12:31:35');
INSERT INTO `logs` VALUES ('421', '1', 'Visualizou o contador por subítem', '2022-02-10 12:31:47', '2022-02-10 12:31:47');
INSERT INTO `logs` VALUES ('422', '1', 'Visualizou o contador por subítem', '2022-02-10 12:33:17', '2022-02-10 12:33:17');
INSERT INTO `logs` VALUES ('423', '1', 'Visualizou o contador por subítem', '2022-02-10 12:33:35', '2022-02-10 12:33:35');
INSERT INTO `logs` VALUES ('424', '1', 'Visualizou o contador por subítem', '2022-02-10 12:34:16', '2022-02-10 12:34:16');
INSERT INTO `logs` VALUES ('425', '1', 'Visualizou o contador por subítem', '2022-02-10 12:36:37', '2022-02-10 12:36:37');
INSERT INTO `logs` VALUES ('426', '0', 'Visualizou o contador por subítem', '2022-02-10 13:58:38', '2022-02-10 13:58:38');
INSERT INTO `logs` VALUES ('427', '1', 'Se logou no sistema', '2022-02-10 13:58:45', '2022-02-10 13:58:45');
INSERT INTO `logs` VALUES ('428', '1', 'Visualizou o contador por subítem', '2022-02-10 13:58:45', '2022-02-10 13:58:45');
INSERT INTO `logs` VALUES ('429', '1', 'Visualizou o contador por subítem', '2022-02-10 14:00:28', '2022-02-10 14:00:28');
INSERT INTO `logs` VALUES ('430', '1', 'Visualizou o contador por subítem', '2022-02-10 14:02:10', '2022-02-10 14:02:10');
INSERT INTO `logs` VALUES ('431', '1', 'Visualizou o contador por subítem', '2022-02-10 14:02:33', '2022-02-10 14:02:33');
INSERT INTO `logs` VALUES ('432', '1', 'Visualizou o contador por página', '2022-02-10 14:09:48', '2022-02-10 14:09:48');
INSERT INTO `logs` VALUES ('433', '1', 'Visualizou o contador por página', '2022-02-10 14:09:59', '2022-02-10 14:09:59');
INSERT INTO `logs` VALUES ('434', '1', 'Visualizou o contador por página', '2022-02-10 14:10:13', '2022-02-10 14:10:13');
INSERT INTO `logs` VALUES ('435', '1', 'Visualizou o contador por página', '2022-02-10 14:10:32', '2022-02-10 14:10:32');
INSERT INTO `logs` VALUES ('436', '1', 'Visualizou o contador do site', '2022-02-10 14:10:58', '2022-02-10 14:10:58');
INSERT INTO `logs` VALUES ('437', '1', 'Visualizou a tela inicial do sistema', '2022-02-10 14:11:06', '2022-02-10 14:11:06');
INSERT INTO `logs` VALUES ('438', '1', 'Visualizou o contador do site', '2022-02-10 14:11:13', '2022-02-10 14:11:13');
INSERT INTO `logs` VALUES ('439', '1', 'Visualizou a tela inicial do sistema', '2022-02-10 14:11:17', '2022-02-10 14:11:17');
INSERT INTO `logs` VALUES ('440', '1', 'Visualizou a tela inicial do sistema', '2022-02-10 14:12:59', '2022-02-10 14:12:59');
INSERT INTO `logs` VALUES ('441', '1', 'Visualizou a tela inicial do sistema', '2022-02-10 14:13:20', '2022-02-10 14:13:20');
INSERT INTO `logs` VALUES ('442', '1', 'Visualizou os Fale Conoscos do Site', '2022-02-10 14:13:27', '2022-02-10 14:13:27');
INSERT INTO `logs` VALUES ('443', '1', 'Visualizou o contador do site', '2022-02-10 14:13:45', '2022-02-10 14:13:45');

-- ----------------------------
-- Table structure for `messages`
-- ----------------------------
DROP TABLE IF EXISTS `messages`;
CREATE TABLE `messages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_answer` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of messages
-- ----------------------------
INSERT INTO `messages` VALUES ('1', 'Henrique', 'henrique.marcandier@gmail.com', 'oi', '', 'oi', '1', null, '0000-00-00 00:00:00', '2022-02-10 02:34:03', '2022-02-10 02:34:03');
INSERT INTO `messages` VALUES ('2', 'Henrique', 'henrique.marcandier@gmail.com', 'oi', '', 'oi', '1', null, '0000-00-00 00:00:00', '2022-02-10 14:14:10', '2022-02-10 14:14:10');
INSERT INTO `messages` VALUES ('3', '', '', 'Email enviado pelo formulário de Fale Conosco do Site - BH Commerce', '', '', '1', null, '0000-00-00 00:00:00', '2022-02-10 14:15:56', '2022-02-10 14:15:56');
INSERT INTO `messages` VALUES ('4', '', '', 'Email enviado pelo formulário de Fale Conosco do Site - BH Commerce', '', '', '1', null, '0000-00-00 00:00:00', '2022-02-10 14:16:00', '2022-02-10 14:16:00');
INSERT INTO `messages` VALUES ('5', '', '', 'Email enviado pelo formulário de Fale Conosco do Site - BH Commerce', '', '', '1', null, '0000-00-00 00:00:00', '2022-02-10 14:19:59', '2022-02-10 14:19:59');
INSERT INTO `messages` VALUES ('6', '', '', 'Email enviado pelo formulário de Fale Conosco do Site - BH Commerce', '', '', '1', null, '0000-00-00 00:00:00', '2022-02-10 14:20:02', '2022-02-10 14:20:02');

-- ----------------------------
-- Table structure for `modules`
-- ----------------------------
DROP TABLE IF EXISTS `modules`;
CREATE TABLE `modules` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `typeModule` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ordem` int(11) DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `modules_typemodule_foreign` (`typeModule`) USING BTREE,
  CONSTRAINT `modules_ibfk_1` FOREIGN KEY (`typeModule`) REFERENCES `type_modules` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of modules
-- ----------------------------
INSERT INTO `modules` VALUES ('1', '2', 'Contador do Site', 'contadorSite', '1', '1', '2020-01-29 11:07:24', '2020-01-29 11:37:20');
INSERT INTO `modules` VALUES ('2', '2', 'Contador por Página', 'contadorPagina', '2', '1', '2020-01-29 11:11:24', '2020-01-29 11:20:22');
INSERT INTO `modules` VALUES ('3', '2', 'Contador por Subítem', 'contadorSubitem', '3', '1', '2020-01-29 11:16:09', '2020-01-29 11:16:09');
INSERT INTO `modules` VALUES ('15', '4', 'Categorias', 'categorias', null, '1', '2020-01-29 12:43:27', '2022-02-09 17:45:04');
INSERT INTO `modules` VALUES ('16', '4', 'Páginas', 'pagina', null, '1', '2020-01-29 12:44:15', '2022-02-09 17:45:54');
INSERT INTO `modules` VALUES ('17', '4', 'Subítens', 'subitems', null, '1', '2020-01-29 12:45:01', '2022-02-09 17:46:28');
INSERT INTO `modules` VALUES ('21', '5', 'Parâmetros do Site', 'paramSite', null, '1', '2020-01-29 12:48:24', '2020-02-01 12:26:27');
INSERT INTO `modules` VALUES ('22', '5', 'Parâmetros do Admin', 'paramAdmin', null, '1', '2020-01-29 12:49:10', '2020-02-16 09:09:29');
INSERT INTO `modules` VALUES ('24', '5', 'Versão do Sistema', 'versao', null, '1', '2020-01-29 12:50:58', '2020-02-16 08:50:20');
INSERT INTO `modules` VALUES ('26', '6', 'Usuários', 'usuarios', null, '1', '2020-01-29 12:52:10', '2020-01-29 12:52:10');
INSERT INTO `modules` VALUES ('27', '6', 'Tipos de Módulo', 'tiposModulo', null, '1', '2020-01-29 12:53:08', '2020-01-29 12:53:08');
INSERT INTO `modules` VALUES ('28', '6', 'Módulos', 'modulos', null, '1', '2020-01-29 12:53:52', '2020-01-29 12:53:52');
INSERT INTO `modules` VALUES ('29', '6', 'Permissão', 'permissao', null, '1', '2020-01-29 12:54:24', '2020-02-19 13:17:48');
INSERT INTO `modules` VALUES ('31', '6', 'Logs de Acesso', 'logsAcesso', null, '1', '2020-02-19 13:16:43', '2020-02-19 13:17:02');
INSERT INTO `modules` VALUES ('32', '6', 'Usuários Pre-Cadastrados', 'usuarios-pre', null, '1', '2020-04-10 11:32:47', '2020-04-10 11:32:47');
INSERT INTO `modules` VALUES ('38', '2', 'Fale Conosco ', 'faleConosco', null, '1', '2020-04-14 11:20:04', '2020-04-14 11:20:04');
INSERT INTO `modules` VALUES ('58', '5', 'Redes Sociais', 'redesSociais', null, '1', '2022-02-09 20:14:12', '2022-02-09 20:14:12');

-- ----------------------------
-- Table structure for `pages`
-- ----------------------------
DROP TABLE IF EXISTS `pages`;
CREATE TABLE `pages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_menu` varchar(0) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `appearsMenu` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `appearsSite` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `img` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of pages
-- ----------------------------
INSERT INTO `pages` VALUES ('1', 'Home', null, 'home', 'Home', '1', '1', '1', '', '2020-01-22 04:53:48', '2020-02-08 09:15:17');
INSERT INTO `pages` VALUES ('2', 'Clientes', '', 'clientes', 'Clientes', '1', '1', '1', 'pagina7.png', '2020-01-22 05:02:11', '2022-02-09 16:57:15');
INSERT INTO `pages` VALUES ('3', 'Contato', null, 'contato', 'Entre em contato conosco através do formulário abaixo, ou pelo telefone (31) 99330 9790', '1', '1', '1', 'pagina9.png', '2020-01-22 05:03:31', '2020-03-16 14:52:37');

-- ----------------------------
-- Table structure for `pages_descriptions`
-- ----------------------------
DROP TABLE IF EXISTS `pages_descriptions`;
CREATE TABLE `pages_descriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page` int(11) DEFAULT NULL,
  `num` int(11) DEFAULT NULL,
  `text` text DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of pages_descriptions
-- ----------------------------
INSERT INTO `pages_descriptions` VALUES ('2', '2', '1', 'Veja todos os nossos clientes abaixo.', 'h1', '2022-02-09 17:15:26', '2022-02-09 17:15:26');
INSERT INTO `pages_descriptions` VALUES ('3', '3', '1', 'Entre em contato pelo formulário abaixo.', 'h1', '2022-02-09 17:18:42', '2022-02-09 17:18:42');
INSERT INTO `pages_descriptions` VALUES ('27', '1', '1', 'Henrique Marcandier', 'h1', '2022-02-09 19:44:44', '2022-02-09 19:44:44');
INSERT INTO `pages_descriptions` VALUES ('28', '1', '2', 'Sou um', 'p', '2022-02-09 19:44:44', '2022-02-09 19:44:44');
INSERT INTO `pages_descriptions` VALUES ('29', '1', '3', 'Desenvolvedor PHP', 'p', '2022-02-09 19:44:44', '2022-02-09 19:44:44');
INSERT INTO `pages_descriptions` VALUES ('30', '1', '4', 'Desenvolvedor CSS', 'h1', '2022-02-09 19:44:44', '2022-02-09 19:44:44');
INSERT INTO `pages_descriptions` VALUES ('31', '1', '5', 'Desenvolvedor HTML', 'p', '2022-02-09 19:44:44', '2022-02-09 19:44:44');
INSERT INTO `pages_descriptions` VALUES ('32', '1', '6', 'Desenvolvedor Jquery', 'h1', '2022-02-09 19:44:44', '2022-02-09 19:44:44');
INSERT INTO `pages_descriptions` VALUES ('33', '1', '7', 'Desenvolvedor Full Stack', 'h1', '2022-02-09 19:44:44', '2022-02-09 19:44:44');

-- ----------------------------
-- Table structure for `param_admins`
-- ----------------------------
DROP TABLE IF EXISTS `param_admins`;
CREATE TABLE `param_admins` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of param_admins
-- ----------------------------
INSERT INTO `param_admins` VALUES ('1', 'title', 'Sistema Administrativo<br> do Teste do Henrique Marcandier', '2020-02-16 09:19:56', '2022-02-09 19:31:32');

-- ----------------------------
-- Table structure for `param_sites`
-- ----------------------------
DROP TABLE IF EXISTS `param_sites`;
CREATE TABLE `param_sites` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of param_sites
-- ----------------------------
INSERT INTO `param_sites` VALUES ('3', 'title', 'Teste do Henrique Marcandier', 'text', '2020-02-01 15:14:14', '2022-02-09 19:59:40');
INSERT INTO `param_sites` VALUES ('4', 'email', 'henrique.marcandier@gmail.com', 'text', '2020-02-13 04:06:02', '2022-02-09 20:00:16');
INSERT INTO `param_sites` VALUES ('17', 'celular', '(31) 99330-9790', 'text', '2020-07-25 15:41:50', '2020-07-25 15:41:50');
INSERT INTO `param_sites` VALUES ('18', 'endereco', 'R. Jorn. Geraldo Bicalho, 66, ap 101 - B. Nova Suíssa - Belo Horizonte - MG', 'textarea', '2020-07-25 16:04:47', '2022-02-09 20:00:48');
INSERT INTO `param_sites` VALUES ('21', 'author', 'BH Commerce', 'text', '2021-05-07 03:05:42', '2021-05-07 03:05:42');
INSERT INTO `param_sites` VALUES ('23', 'celularDiscar', '+5531993309790', 'text', '2021-05-07 03:50:42', '2021-05-07 03:50:42');
INSERT INTO `param_sites` VALUES ('27', 'mapa', 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3750.6890147453173!2d-43.9808478851508!3d-19.937505643691253!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xa697aa459bcb79%3A0xc0ab9851ad95b517!2sR.%20Jorn.%20Geraldo%20Bicalho%2C%2066%20-%20Nova%20Su%C3%AD%C3%A7a%2C%20Belo%20Horizonte%20-%20MG%2C%2030421-108!5e0!3m2!1spt-BR!2sbr!4v1644426745113!5m2!1spt-BR!2sbr', '', '2022-02-09 20:02:18', '2022-02-09 20:02:18');

-- ----------------------------
-- Table structure for `permissions`
-- ----------------------------
DROP TABLE IF EXISTS `permissions`;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user` bigint(20) unsigned NOT NULL,
  `module` bigint(20) unsigned NOT NULL,
  `view` int(11) NOT NULL DEFAULT 0,
  `register` int(11) NOT NULL DEFAULT 0,
  `delete` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=219 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of permissions
-- ----------------------------
INSERT INTO `permissions` VALUES ('1', '1', '1', '1', '1', '1', '2020-02-19 08:07:33', '2020-02-19 08:07:33');
INSERT INTO `permissions` VALUES ('2', '1', '1', '1', '0', '0', '2020-02-19 08:07:56', '2020-02-19 08:07:56');
INSERT INTO `permissions` VALUES ('3', '1', '1', '1', '0', '0', '2020-02-19 08:08:46', '2020-02-19 08:08:46');
INSERT INTO `permissions` VALUES ('4', '1', '1', '1', '0', '0', '2020-02-19 08:18:12', '2020-02-19 08:18:12');
INSERT INTO `permissions` VALUES ('5', '1', '1', '1', '0', '0', '2020-02-19 08:18:41', '2020-02-19 08:18:41');
INSERT INTO `permissions` VALUES ('6', '1', '1', '1', '0', '0', '2020-02-19 08:18:50', '2020-02-19 08:18:50');
INSERT INTO `permissions` VALUES ('7', '1', '1', '1', '0', '0', '2020-02-19 08:19:45', '2020-02-19 08:19:45');
INSERT INTO `permissions` VALUES ('8', '1', '1', '1', '0', '0', '2020-02-19 08:20:51', '2020-02-19 08:20:51');
INSERT INTO `permissions` VALUES ('9', '2', '1', '1', '1', '1', '2020-02-19 08:30:34', '2020-02-19 08:30:34');
INSERT INTO `permissions` VALUES ('10', '1', '2', '1', '1', '1', '2020-02-19 18:16:12', '2020-02-19 18:16:12');
INSERT INTO `permissions` VALUES ('11', '1', '3', '1', '1', '1', '2020-02-19 18:16:20', '2020-02-19 18:16:20');
INSERT INTO `permissions` VALUES ('12', '1', '4', '1', '1', '1', '2020-02-19 18:16:26', '2020-02-19 18:16:26');
INSERT INTO `permissions` VALUES ('13', '1', '5', '1', '1', '1', '2020-02-19 18:16:47', '2020-02-19 18:16:47');
INSERT INTO `permissions` VALUES ('14', '1', '6', '1', '1', '1', '2020-02-19 18:18:15', '2020-02-19 18:18:15');
INSERT INTO `permissions` VALUES ('16', '1', '30', '1', '1', '1', '2020-02-19 18:18:23', '2020-02-19 18:18:23');
INSERT INTO `permissions` VALUES ('18', '1', '7', '1', '1', '1', '2020-02-19 18:18:28', '2020-02-19 18:18:28');
INSERT INTO `permissions` VALUES ('20', '1', '8', '1', '1', '1', '2020-02-19 18:18:33', '2020-02-19 18:18:33');
INSERT INTO `permissions` VALUES ('21', '1', '9', '1', '1', '1', '2020-02-19 18:18:38', '2020-02-19 18:18:38');
INSERT INTO `permissions` VALUES ('22', '1', '10', '1', '1', '1', '2020-02-19 18:18:41', '2020-02-19 18:18:41');
INSERT INTO `permissions` VALUES ('23', '1', '11', '1', '1', '1', '2020-02-19 18:18:46', '2020-02-19 18:18:46');
INSERT INTO `permissions` VALUES ('24', '1', '12', '1', '1', '1', '2020-02-19 18:18:52', '2020-02-19 18:18:52');
INSERT INTO `permissions` VALUES ('25', '1', '13', '1', '1', '1', '2020-02-19 18:19:19', '2020-02-19 18:19:19');
INSERT INTO `permissions` VALUES ('26', '1', '14', '1', '1', '1', '2020-02-19 18:19:28', '2020-02-19 18:19:28');
INSERT INTO `permissions` VALUES ('27', '1', '15', '1', '1', '1', '2020-02-19 18:19:33', '2020-02-19 18:19:33');
INSERT INTO `permissions` VALUES ('28', '1', '16', '1', '1', '1', '2020-02-19 18:19:39', '2020-02-19 18:19:39');
INSERT INTO `permissions` VALUES ('29', '1', '17', '1', '1', '1', '2020-02-19 18:19:45', '2020-02-19 18:19:45');
INSERT INTO `permissions` VALUES ('30', '1', '18', '1', '1', '1', '2020-02-19 18:19:49', '2020-02-19 18:19:49');
INSERT INTO `permissions` VALUES ('31', '1', '19', '1', '1', '1', '2020-02-19 18:19:55', '2020-02-19 18:19:55');
INSERT INTO `permissions` VALUES ('32', '1', '20', '1', '1', '1', '2020-02-19 18:20:01', '2020-02-19 18:20:01');
INSERT INTO `permissions` VALUES ('33', '1', '21', '1', '1', '1', '2020-02-19 18:20:06', '2020-02-19 18:20:06');
INSERT INTO `permissions` VALUES ('34', '1', '22', '1', '1', '1', '2020-02-19 18:20:17', '2020-02-19 18:20:17');
INSERT INTO `permissions` VALUES ('35', '1', '24', '1', '1', '1', '2020-02-19 18:20:24', '2020-02-19 18:20:24');
INSERT INTO `permissions` VALUES ('36', '1', '26', '1', '1', '1', '2020-02-19 18:20:32', '2020-02-19 18:20:32');
INSERT INTO `permissions` VALUES ('37', '1', '27', '1', '1', '1', '2020-02-19 18:20:36', '2020-02-19 18:20:36');
INSERT INTO `permissions` VALUES ('38', '1', '28', '1', '1', '1', '2020-02-19 18:20:41', '2020-02-19 18:20:41');
INSERT INTO `permissions` VALUES ('39', '1', '29', '1', '1', '1', '2020-02-19 18:20:47', '2020-02-19 18:20:47');
INSERT INTO `permissions` VALUES ('40', '1', '31', '1', '1', '1', '2020-02-19 18:20:52', '2020-02-19 18:20:52');
INSERT INTO `permissions` VALUES ('41', '2', '2', '1', '1', '1', '2020-02-19 18:21:28', '2020-02-19 18:21:28');
INSERT INTO `permissions` VALUES ('42', '2', '3', '1', '1', '1', '2020-02-19 18:21:36', '2020-02-19 18:21:36');
INSERT INTO `permissions` VALUES ('43', '2', '4', '1', '1', '1', '2020-02-19 18:21:42', '2020-02-19 18:21:42');
INSERT INTO `permissions` VALUES ('44', '2', '5', '1', '1', '1', '2020-02-19 18:21:49', '2020-02-19 18:21:49');
INSERT INTO `permissions` VALUES ('45', '2', '6', '1', '1', '1', '2020-02-19 18:21:51', '2020-02-19 18:21:51');
INSERT INTO `permissions` VALUES ('46', '2', '30', '1', '1', '1', '2020-02-19 18:21:51', '2020-02-19 18:21:51');
INSERT INTO `permissions` VALUES ('47', '2', '7', '1', '1', '1', '2020-02-19 18:22:01', '2020-02-19 18:22:01');
INSERT INTO `permissions` VALUES ('48', '2', '8', '1', '1', '1', '2020-02-19 18:22:06', '2020-02-19 18:22:06');
INSERT INTO `permissions` VALUES ('49', '2', '9', '1', '1', '1', '2020-02-19 18:22:11', '2020-02-19 18:22:11');
INSERT INTO `permissions` VALUES ('50', '2', '10', '1', '1', '1', '2020-02-19 18:22:18', '2020-02-19 18:22:18');
INSERT INTO `permissions` VALUES ('51', '2', '11', '1', '1', '1', '2020-02-19 18:22:23', '2020-02-19 18:22:23');
INSERT INTO `permissions` VALUES ('52', '2', '12', '1', '1', '1', '2020-02-19 18:22:24', '2020-02-19 18:22:24');
INSERT INTO `permissions` VALUES ('53', '2', '13', '1', '1', '1', '2020-02-19 18:22:25', '2020-02-19 18:22:25');
INSERT INTO `permissions` VALUES ('54', '2', '14', '1', '1', '1', '2020-02-19 18:22:37', '2020-02-19 18:22:37');
INSERT INTO `permissions` VALUES ('55', '2', '15', '1', '1', '1', '2020-02-19 18:24:07', '2020-02-19 18:24:07');
INSERT INTO `permissions` VALUES ('56', '2', '16', '1', '1', '1', '2020-02-19 18:24:12', '2020-02-19 18:24:12');
INSERT INTO `permissions` VALUES ('57', '2', '17', '1', '1', '1', '2020-02-19 18:24:17', '2020-02-19 18:24:17');
INSERT INTO `permissions` VALUES ('58', '2', '18', '1', '1', '1', '2020-02-19 18:24:23', '2020-02-19 18:24:23');
INSERT INTO `permissions` VALUES ('59', '2', '19', '1', '1', '1', '2020-02-19 18:24:31', '2020-02-19 18:24:31');
INSERT INTO `permissions` VALUES ('60', '2', '20', '1', '1', '1', '2020-02-19 18:24:38', '2020-02-19 18:24:38');
INSERT INTO `permissions` VALUES ('61', '2', '21', '1', '1', '1', '2020-02-19 18:24:45', '2020-02-19 18:24:45');
INSERT INTO `permissions` VALUES ('62', '2', '22', '1', '1', '1', '2020-02-19 18:24:46', '2020-02-19 18:24:46');
INSERT INTO `permissions` VALUES ('63', '2', '24', '1', '1', '1', '2020-02-19 18:24:47', '2020-02-19 18:24:47');
INSERT INTO `permissions` VALUES ('64', '2', '26', '1', '1', '1', '2020-02-19 18:24:58', '2020-02-19 18:24:58');
INSERT INTO `permissions` VALUES ('65', '2', '31', '1', '1', '1', '2020-02-19 18:25:04', '2020-02-19 18:25:04');
INSERT INTO `permissions` VALUES ('68', '2', '27', '1', '1', '1', '2020-03-29 03:05:08', '2020-03-29 03:05:08');
INSERT INTO `permissions` VALUES ('97', '1', '32', '1', '1', '1', '2020-04-10 02:33:02', '2020-04-10 02:33:02');
INSERT INTO `permissions` VALUES ('98', '3', '1', '1', '1', '1', '2020-04-10 06:16:11', '2020-04-10 06:16:11');
INSERT INTO `permissions` VALUES ('99', '3', '2', '1', '1', '1', '2020-04-10 06:16:16', '2020-04-10 06:16:16');
INSERT INTO `permissions` VALUES ('100', '3', '3', '1', '1', '1', '2020-04-10 06:16:21', '2020-04-10 06:16:21');
INSERT INTO `permissions` VALUES ('101', '3', '4', '1', '1', '1', '2020-04-10 06:16:26', '2020-04-10 06:16:26');
INSERT INTO `permissions` VALUES ('102', '3', '5', '1', '1', '1', '2020-04-10 06:16:32', '2020-04-10 06:16:32');
INSERT INTO `permissions` VALUES ('103', '3', '6', '1', '1', '1', '2020-04-10 06:16:36', '2020-04-10 06:16:36');
INSERT INTO `permissions` VALUES ('104', '3', '30', '1', '1', '1', '2020-04-10 06:16:41', '2020-04-10 06:16:41');
INSERT INTO `permissions` VALUES ('105', '3', '7', '1', '1', '1', '2020-04-10 06:16:46', '2020-04-10 06:16:46');
INSERT INTO `permissions` VALUES ('106', '3', '8', '1', '1', '1', '2020-04-10 06:16:50', '2020-04-10 06:16:50');
INSERT INTO `permissions` VALUES ('107', '3', '9', '1', '1', '1', '2020-04-10 06:16:53', '2020-04-10 06:16:53');
INSERT INTO `permissions` VALUES ('108', '3', '10', '1', '1', '1', '2020-04-10 06:16:58', '2020-04-10 06:16:58');
INSERT INTO `permissions` VALUES ('109', '3', '11', '1', '1', '1', '2020-04-10 06:16:59', '2020-04-10 06:16:59');
INSERT INTO `permissions` VALUES ('110', '3', '12', '1', '1', '1', '2020-04-10 06:17:04', '2020-04-10 06:17:04');
INSERT INTO `permissions` VALUES ('111', '3', '13', '1', '1', '1', '2020-04-10 06:17:05', '2020-04-10 06:17:05');
INSERT INTO `permissions` VALUES ('112', '3', '14', '1', '1', '1', '2020-04-10 06:17:14', '2020-04-10 06:17:14');
INSERT INTO `permissions` VALUES ('113', '3', '15', '1', '1', '1', '2020-04-10 06:17:22', '2020-04-10 06:17:22');
INSERT INTO `permissions` VALUES ('114', '3', '16', '1', '1', '1', '2020-04-10 06:17:29', '2020-04-10 06:17:29');
INSERT INTO `permissions` VALUES ('115', '3', '17', '1', '1', '1', '2020-04-10 06:17:35', '2020-04-10 06:17:35');
INSERT INTO `permissions` VALUES ('116', '3', '18', '1', '1', '1', '2020-04-10 06:17:41', '2020-04-10 06:17:41');
INSERT INTO `permissions` VALUES ('117', '3', '19', '1', '1', '1', '2020-04-10 06:17:45', '2020-04-10 06:17:45');
INSERT INTO `permissions` VALUES ('118', '3', '20', '1', '1', '1', '2020-04-10 06:17:51', '2020-04-10 06:17:51');
INSERT INTO `permissions` VALUES ('119', '3', '21', '1', '1', '1', '2020-04-10 06:17:57', '2020-04-10 06:17:57');
INSERT INTO `permissions` VALUES ('120', '3', '22', '1', '1', '1', '2020-04-10 06:17:58', '2020-04-10 06:17:58');
INSERT INTO `permissions` VALUES ('121', '3', '24', '0', '0', '0', '2020-04-10 06:17:59', '2020-04-10 06:17:59');
INSERT INTO `permissions` VALUES ('122', '3', '26', '1', '1', '1', '2020-04-10 06:18:07', '2020-04-10 06:18:07');
INSERT INTO `permissions` VALUES ('123', '3', '31', '1', '1', '1', '2020-04-10 06:18:14', '2020-04-10 06:18:14');
INSERT INTO `permissions` VALUES ('124', '1', '33', '1', '1', '1', '2020-04-14 02:20:44', '2020-04-14 02:20:44');
INSERT INTO `permissions` VALUES ('125', '1', '34', '1', '1', '1', '2020-04-14 02:20:47', '2020-04-14 02:20:47');
INSERT INTO `permissions` VALUES ('126', '1', '35', '1', '1', '1', '2020-04-14 02:20:53', '2020-04-14 02:20:53');
INSERT INTO `permissions` VALUES ('127', '1', '36', '1', '1', '1', '2020-04-14 02:20:59', '2020-04-14 02:20:59');
INSERT INTO `permissions` VALUES ('128', '1', '37', '1', '1', '1', '2020-04-14 02:21:03', '2020-04-14 02:21:03');
INSERT INTO `permissions` VALUES ('129', '1', '38', '1', '1', '1', '2020-04-14 02:21:04', '2020-04-14 02:21:04');
INSERT INTO `permissions` VALUES ('130', '1', '39', '1', '1', '1', '2020-04-14 18:18:58', '2020-04-14 18:18:58');
INSERT INTO `permissions` VALUES ('131', '1', '40', '1', '1', '1', '2020-04-14 18:19:03', '2020-04-14 18:19:03');
INSERT INTO `permissions` VALUES ('132', '1', '41', '1', '1', '1', '2020-04-14 18:19:08', '2020-04-14 18:19:08');
INSERT INTO `permissions` VALUES ('133', '1', '42', '1', '1', '1', '2020-04-14 18:19:12', '2020-04-14 18:19:12');
INSERT INTO `permissions` VALUES ('134', '1', '43', '1', '1', '1', '2020-04-14 18:53:18', '2020-04-14 18:53:18');
INSERT INTO `permissions` VALUES ('135', '1', '44', '1', '1', '1', '2020-04-14 18:53:22', '2020-04-14 18:53:22');
INSERT INTO `permissions` VALUES ('136', '1', '45', '1', '1', '1', '2020-04-14 18:53:23', '2020-04-14 18:53:23');
INSERT INTO `permissions` VALUES ('137', '1', '46', '1', '1', '1', '2020-04-14 18:53:24', '2020-04-14 18:53:24');
INSERT INTO `permissions` VALUES ('138', '1', '52', '1', '1', '1', '2020-04-23 00:39:52', '2020-04-23 00:39:52');
INSERT INTO `permissions` VALUES ('139', '1', '47', '1', '1', '1', '2020-04-23 00:39:55', '2020-04-23 00:39:55');
INSERT INTO `permissions` VALUES ('140', '1', '48', '1', '1', '1', '2020-04-23 00:40:01', '2020-04-23 00:40:01');
INSERT INTO `permissions` VALUES ('141', '1', '49', '1', '1', '1', '2020-04-23 00:40:02', '2020-04-23 00:40:02');
INSERT INTO `permissions` VALUES ('142', '1', '50', '1', '1', '1', '2020-04-23 00:40:03', '2020-04-23 00:40:03');
INSERT INTO `permissions` VALUES ('143', '1', '51', '1', '1', '1', '2020-04-23 00:40:06', '2020-04-23 00:40:06');
INSERT INTO `permissions` VALUES ('144', '1', '53', '1', '1', '1', '2020-05-08 01:49:24', '2020-05-08 01:49:24');
INSERT INTO `permissions` VALUES ('145', '2', '33', '1', '1', '1', '2020-05-08 01:52:02', '2020-05-08 01:52:02');
INSERT INTO `permissions` VALUES ('146', '2', '34', '1', '1', '1', '2020-05-08 01:52:12', '2020-05-08 01:52:12');
INSERT INTO `permissions` VALUES ('147', '2', '35', '1', '1', '1', '2020-05-08 01:52:53', '2020-05-08 01:52:53');
INSERT INTO `permissions` VALUES ('148', '2', '36', '1', '1', '1', '2020-05-08 01:53:43', '2020-05-08 01:53:43');
INSERT INTO `permissions` VALUES ('149', '2', '37', '1', '1', '1', '2020-05-08 01:53:50', '2020-05-08 01:53:50');
INSERT INTO `permissions` VALUES ('150', '2', '38', '1', '1', '1', '2020-05-08 01:53:58', '2020-05-08 01:53:58');
INSERT INTO `permissions` VALUES ('151', '2', '39', '1', '1', '1', '2020-05-08 01:54:05', '2020-05-08 01:54:05');
INSERT INTO `permissions` VALUES ('152', '2', '40', '1', '1', '1', '2020-05-08 01:54:14', '2020-05-08 01:54:14');
INSERT INTO `permissions` VALUES ('153', '2', '41', '1', '1', '1', '2020-05-08 01:54:28', '2020-05-08 01:54:28');
INSERT INTO `permissions` VALUES ('154', '2', '42', '1', '1', '1', '2020-05-08 01:54:34', '2020-05-08 01:54:34');
INSERT INTO `permissions` VALUES ('155', '2', '43', '1', '1', '1', '2020-05-08 01:54:42', '2020-05-08 01:54:42');
INSERT INTO `permissions` VALUES ('156', '2', '44', '1', '1', '1', '2020-05-08 01:54:50', '2020-05-08 01:54:50');
INSERT INTO `permissions` VALUES ('157', '2', '45', '1', '1', '1', '2020-05-08 01:54:57', '2020-05-08 01:54:57');
INSERT INTO `permissions` VALUES ('158', '2', '46', '1', '1', '1', '2020-05-08 01:55:04', '2020-05-08 01:55:04');
INSERT INTO `permissions` VALUES ('159', '2', '52', '1', '1', '1', '2020-05-08 01:55:11', '2020-05-08 01:55:11');
INSERT INTO `permissions` VALUES ('160', '2', '47', '1', '1', '1', '2020-05-08 01:55:25', '2020-05-08 01:55:25');
INSERT INTO `permissions` VALUES ('161', '2', '48', '1', '1', '1', '2020-05-08 01:55:35', '2020-05-08 01:55:35');
INSERT INTO `permissions` VALUES ('162', '2', '49', '1', '1', '1', '2020-05-08 01:55:43', '2020-05-08 01:55:43');
INSERT INTO `permissions` VALUES ('163', '2', '50', '1', '1', '1', '2020-05-08 01:55:47', '2020-05-08 01:55:47');
INSERT INTO `permissions` VALUES ('164', '2', '51', '1', '1', '1', '2020-05-08 01:55:50', '2020-05-08 01:55:50');
INSERT INTO `permissions` VALUES ('165', '2', '53', '1', '1', '1', '2020-05-08 01:55:51', '2020-05-08 01:55:51');
INSERT INTO `permissions` VALUES ('166', '1', '54', '1', '1', '1', '2020-06-02 23:11:35', '2020-06-02 23:11:35');
INSERT INTO `permissions` VALUES ('167', '2', '54', '1', '1', '1', '2020-06-02 23:11:49', '2020-06-02 23:11:49');
INSERT INTO `permissions` VALUES ('168', '1', '55', '1', '1', '1', '2020-07-10 06:42:03', '2020-07-10 06:42:03');
INSERT INTO `permissions` VALUES ('169', '2', '55', '1', '1', '1', '2020-07-23 22:31:15', '2020-07-23 22:31:15');
INSERT INTO `permissions` VALUES ('170', '5', '1', '1', '1', '1', '2021-05-14 15:29:52', '2021-05-14 15:29:52');
INSERT INTO `permissions` VALUES ('171', '5', '2', '1', '1', '1', '2021-05-14 15:29:54', '2021-05-14 15:29:54');
INSERT INTO `permissions` VALUES ('172', '5', '3', '1', '1', '1', '2021-05-14 15:30:00', '2021-05-14 15:30:00');
INSERT INTO `permissions` VALUES ('173', '5', '4', '1', '1', '1', '2021-05-14 15:30:01', '2021-05-14 15:30:01');
INSERT INTO `permissions` VALUES ('174', '5', '33', '1', '1', '1', '2021-05-14 15:30:03', '2021-05-14 15:30:03');
INSERT INTO `permissions` VALUES ('175', '5', '34', '1', '1', '1', '2021-05-14 15:30:49', '2021-05-14 15:30:49');
INSERT INTO `permissions` VALUES ('176', '5', '35', '1', '1', '1', '2021-05-14 15:30:52', '2021-05-14 15:30:52');
INSERT INTO `permissions` VALUES ('177', '5', '36', '1', '1', '1', '2021-05-14 15:30:56', '2021-05-14 15:30:56');
INSERT INTO `permissions` VALUES ('178', '5', '37', '1', '1', '1', '2021-05-14 15:30:59', '2021-05-14 15:30:59');
INSERT INTO `permissions` VALUES ('179', '5', '38', '1', '1', '1', '2021-05-14 15:31:02', '2021-05-14 15:31:02');
INSERT INTO `permissions` VALUES ('180', '5', '7', '1', '1', '1', '2021-05-14 15:31:07', '2021-05-14 15:31:07');
INSERT INTO `permissions` VALUES ('181', '5', '39', '1', '1', '1', '2021-05-14 15:31:09', '2021-05-14 15:31:09');
INSERT INTO `permissions` VALUES ('182', '5', '40', '1', '1', '1', '2021-05-14 15:31:11', '2021-05-14 15:31:11');
INSERT INTO `permissions` VALUES ('183', '5', '41', '1', '1', '1', '2021-05-14 15:31:13', '2021-05-14 15:31:13');
INSERT INTO `permissions` VALUES ('184', '5', '42', '1', '1', '1', '2021-05-14 15:31:17', '2021-05-14 15:31:17');
INSERT INTO `permissions` VALUES ('185', '5', '55', '1', '1', '1', '2021-05-14 15:31:20', '2021-05-14 15:31:20');
INSERT INTO `permissions` VALUES ('186', '5', '14', '1', '1', '1', '2021-05-14 15:31:25', '2021-05-14 15:31:25');
INSERT INTO `permissions` VALUES ('187', '5', '15', '1', '1', '1', '2021-05-14 15:31:29', '2021-05-14 15:31:29');
INSERT INTO `permissions` VALUES ('188', '5', '16', '1', '1', '1', '2021-05-14 15:31:31', '2021-05-14 15:31:31');
INSERT INTO `permissions` VALUES ('189', '5', '17', '1', '1', '1', '2021-05-14 15:31:37', '2021-05-14 15:31:37');
INSERT INTO `permissions` VALUES ('190', '5', '18', '1', '1', '1', '2021-05-14 15:31:37', '2021-05-14 15:31:37');
INSERT INTO `permissions` VALUES ('191', '5', '19', '1', '1', '1', '2021-05-14 15:31:38', '2021-05-14 15:31:38');
INSERT INTO `permissions` VALUES ('192', '5', '20', '1', '1', '1', '2021-05-14 15:31:43', '2021-05-14 15:31:43');
INSERT INTO `permissions` VALUES ('193', '5', '43', '1', '1', '1', '2021-05-14 15:31:44', '2021-05-14 15:31:44');
INSERT INTO `permissions` VALUES ('194', '5', '44', '1', '1', '1', '2021-05-14 15:31:46', '2021-05-14 15:31:46');
INSERT INTO `permissions` VALUES ('195', '5', '45', '1', '1', '1', '2021-05-14 15:31:49', '2021-05-14 15:31:49');
INSERT INTO `permissions` VALUES ('196', '5', '46', '1', '1', '1', '2021-05-14 15:31:49', '2021-05-14 15:31:49');
INSERT INTO `permissions` VALUES ('197', '5', '52', '1', '1', '1', '2021-05-14 15:31:50', '2021-05-14 15:31:50');
INSERT INTO `permissions` VALUES ('198', '5', '54', '1', '1', '1', '2021-05-14 15:31:56', '2021-05-14 15:31:56');
INSERT INTO `permissions` VALUES ('199', '5', '21', '1', '1', '1', '2021-05-14 15:31:57', '2021-05-14 15:31:57');
INSERT INTO `permissions` VALUES ('200', '5', '22', '0', '0', '0', '2021-05-14 15:31:59', '2021-05-14 15:31:59');
INSERT INTO `permissions` VALUES ('201', '5', '24', '1', '1', '1', '2021-05-14 15:32:01', '2021-05-14 15:32:01');
INSERT INTO `permissions` VALUES ('202', '5', '47', '1', '1', '1', '2021-05-14 15:32:04', '2021-05-14 15:32:04');
INSERT INTO `permissions` VALUES ('203', '5', '48', '1', '1', '1', '2021-05-14 15:32:07', '2021-05-14 15:32:07');
INSERT INTO `permissions` VALUES ('204', '5', '49', '1', '1', '1', '2021-05-14 15:32:12', '2021-05-14 15:32:12');
INSERT INTO `permissions` VALUES ('205', '5', '50', '1', '1', '1', '2021-05-14 15:32:18', '2021-05-14 15:32:18');
INSERT INTO `permissions` VALUES ('206', '5', '51', '1', '1', '1', '2021-05-14 15:32:19', '2021-05-14 15:32:19');
INSERT INTO `permissions` VALUES ('207', '5', '53', '1', '1', '1', '2021-05-14 15:32:24', '2021-05-14 15:32:24');
INSERT INTO `permissions` VALUES ('208', '5', '26', '1', '1', '1', '2021-05-14 15:32:27', '2021-05-14 15:32:27');
INSERT INTO `permissions` VALUES ('209', '5', '31', '1', '1', '1', '2021-05-14 15:32:32', '2021-05-14 15:32:32');
INSERT INTO `permissions` VALUES ('211', '5', '56', '1', '1', '1', null, null);
INSERT INTO `permissions` VALUES ('212', '1', '57', '1', '1', '1', '2021-06-13 22:12:06', '2021-06-13 22:12:06');
INSERT INTO `permissions` VALUES ('213', '1', '56', '1', '1', '1', null, null);
INSERT INTO `permissions` VALUES ('214', '2', '28', '1', '1', '1', '2022-02-09 15:33:58', '2022-02-09 15:33:58');
INSERT INTO `permissions` VALUES ('215', '2', '29', '1', '1', '1', '2022-02-09 15:34:04', '2022-02-09 15:34:04');
INSERT INTO `permissions` VALUES ('216', '2', '32', '1', '1', '1', '2022-02-09 15:34:11', '2022-02-09 15:34:11');
INSERT INTO `permissions` VALUES ('217', '1', '58', '1', '1', '1', '2022-02-09 20:14:32', '2022-02-09 20:14:32');
INSERT INTO `permissions` VALUES ('218', '2', '58', '1', '1', '1', '2022-02-09 20:20:30', '2022-02-09 20:20:30');

-- ----------------------------
-- Table structure for `social_networks`
-- ----------------------------
DROP TABLE IF EXISTS `social_networks`;
CREATE TABLE `social_networks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `img` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cliques` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of social_networks
-- ----------------------------
INSERT INTO `social_networks` VALUES ('1', 'Facebook', 'facebook', 'Link Facebook', 'https://www.facebook.com/bhcommerce', '1', 'social_network1.png', '3', '2020-05-09 13:12:19', '2020-05-09 13:12:19');
INSERT INTO `social_networks` VALUES ('2', 'Twitter', 'twitter', 'Link Twitter', 'https://www.twitter.com/bhcommerce', '1', 'social_network2.png', '1', '2020-05-09 13:15:11', '2020-05-09 13:15:11');
INSERT INTO `social_networks` VALUES ('3', 'Instagram', 'instagram', 'Link Instagram', 'https://www.instagram.com/bhcommerce', '1', 'social_network3.png', '1', '2020-05-09 13:16:21', '2020-05-09 13:16:21');
INSERT INTO `social_networks` VALUES ('4', 'WhatsApp', 'whatsapp', 'Link Whats App', 'https://api.whatsapp.com/send?l=pt&phone=5531993309790&text=Escreva%20a%20sua%20mensagem%20para%20BH%20Commerce%20aqui', '1', 'social_network4.png', '1', '2020-05-09 13:17:26', '2022-02-09 22:02:49');

-- ----------------------------
-- Table structure for `subitems`
-- ----------------------------
DROP TABLE IF EXISTS `subitems`;
CREATE TABLE `subitems` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `page` bigint(20) unsigned NOT NULL,
  `categorie` bigint(20) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description2` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description3` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `img` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `appearsImg` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `subitems_page_foreign` (`page`) USING BTREE,
  CONSTRAINT `subitems_ibfk_1` FOREIGN KEY (`page`) REFERENCES `pages` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of subitems
-- ----------------------------
INSERT INTO `subitems` VALUES ('1', '2', '1', 'Cliente 1', 'cliente-1', 'https://www.cliente1.com.br', 'Este é um exemplo de Cliente', 'Autem ipsum nam porro corporis rerum. Quis eos dolorem eos itaque inventore commodi labore quia quia. ', 'Exercitationem repudiandae officiis neque suscipit non officia eaque itaque enim. Voluptatem officia accusantium nesciunt est omnis tempora consectetur dignissimos. Sequi nulla at esse enim cum deserunt eius. ', 'subitem1.jpg', '1', '1', '2022-02-09 17:42:14', '2022-02-10 01:29:48');
INSERT INTO `subitems` VALUES ('2', '2', '2', 'Cliente 2', 'cliente-2', 'https://www.cliente2.com.br', 'Este é um exemplo de Cliente', 'Autem ipsum nam porro corporis rerum. Quis eos dolorem eos itaque inventore commodi labore quia quia. ', 'Exercitationem repudiandae officiis neque suscipit non officia eaque itaque enim. Voluptatem officia accusantium nesciunt est omnis tempora consectetur dignissimos. Sequi nulla at esse enim cum deserunt eius. ', 'subitem2.jpg', '1', '1', '2022-02-09 17:43:58', '2022-02-10 01:29:25');
INSERT INTO `subitems` VALUES ('3', '2', '3', 'Cliente 3', 'cliente-3', 'https://www.cliente3.com.br', 'Este é um exemplo de Cliente', 'Autem ipsum nam porro corporis rerum. Quis eos dolorem eos itaque inventore commodi labore quia quia. ', 'Exercitationem repudiandae officiis neque suscipit non officia eaque itaque enim. Voluptatem officia accusantium nesciunt est omnis tempora consectetur dignissimos. Sequi nulla at esse enim cum deserunt eius. ', 'subitem3.jpg', '1', '1', '2022-02-09 18:19:34', '2022-02-10 01:32:17');
INSERT INTO `subitems` VALUES ('4', '2', '1', 'Cliente 4', 'cliente-4', 'https://www.cliente4.com.br', '', '', '', 'subitem4.jpg', '1', '1', '2022-02-09 19:27:50', '2022-02-10 01:34:05');
INSERT INTO `subitems` VALUES ('5', '2', '2', 'Cliente 5', 'cliente-5', 'https://www.cliente5.com.br', '', '', '', 'subitem5.jpg', '1', '1', '2022-02-09 19:32:59', '2022-02-10 01:34:55');
INSERT INTO `subitems` VALUES ('6', '2', '3', 'Cliente 6', 'cliente-6', 'https://www.cliente6.com.br', '', '', '', 'subitem6.jpg', '1', '1', '2022-02-09 19:33:25', '2022-02-10 01:36:15');
INSERT INTO `subitems` VALUES ('7', '2', '1', 'Cliente 7', 'cliente-7', 'https://www.cliente7.com.br', '', '', '', 'subitem7.jpg', '1', '1', '2022-02-09 19:33:53', '2022-02-10 01:36:40');
INSERT INTO `subitems` VALUES ('8', '2', '2', 'Cliente 8', 'cliente-8', 'https://www.cliente8.com.br', '', '', '', 'subitem8.jpg', '1', '1', '2022-02-09 19:34:15', '2022-02-10 01:36:52');
INSERT INTO `subitems` VALUES ('9', '2', '3', 'Cliente 9', 'cliente-9', 'https://www.cliente9.com.br', '', '', '', 'subitem9.jpg', '1', '1', '2022-02-09 19:34:43', '2022-02-10 01:37:06');

-- ----------------------------
-- Table structure for `type_modules`
-- ----------------------------
DROP TABLE IF EXISTS `type_modules`;
CREATE TABLE `type_modules` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of type_modules
-- ----------------------------
INSERT INTO `type_modules` VALUES ('1', 'Página Inicial', '1', '2020-01-29 03:56:49', '2020-01-29 03:56:49');
INSERT INTO `type_modules` VALUES ('2', 'Contadores', '1', '2020-01-29 04:08:13', '2020-01-29 04:30:32');
INSERT INTO `type_modules` VALUES ('4', 'Cadastros', '1', '2020-01-29 04:32:39', '2020-01-29 04:32:39');
INSERT INTO `type_modules` VALUES ('5', 'Outros Cadastros', '1', '2020-01-29 04:37:07', '2020-01-29 04:37:07');
INSERT INTO `type_modules` VALUES ('6', 'Usuário', '1', '2020-01-29 04:37:30', '2020-01-29 04:37:30');

-- ----------------------------
-- Table structure for `user_pres`
-- ----------------------------
DROP TABLE IF EXISTS `user_pres`;
CREATE TABLE `user_pres` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of user_pres
-- ----------------------------

-- ----------------------------
-- Table structure for `users`
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `img` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES ('1', 'Henrique', 'henrique.marcandier@gmail.com', null, '3aa002e8906a4caeeb1daff642af9d04', 'usuarios1.png', null, '2020-01-22 13:41:52', '2020-08-10 09:32:18');
INSERT INTO `users` VALUES ('2', 'Usuário', 'usuario@bhcommerce.com.br', null, '3aa002e8906a4caeeb1daff642af9d04', null, null, '2020-01-23 03:28:26', '2020-07-24 06:16:05');

-- ----------------------------
-- Table structure for `versions`
-- ----------------------------
DROP TABLE IF EXISTS `versions`;
CREATE TABLE `versions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `img` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of versions
-- ----------------------------
INSERT INTO `versions` VALUES ('1', '1.0', 'versao1.png', '2022-01-09', 'Versão Inicial do Sistema Administrativo do Teste do Henrique Marcandier', '2020-02-16 08:29:04', '2022-02-09 15:54:00');
