<?php
    $sql = "SELECT * FROM param_sites";
    $query = mysqli_query($con, $sql);
    if (mysqli_num_rows($query)){
        while($row = mysqli_fetch_array($query)){
        $paramSite[$row['name']] = ($row['value']);
        }
    }
    $sql = "SELECT * FROM social_networks WHERE status = '1'";
    $query = mysqli_query($con, $sql);
    if (mysqli_num_rows($query)){
        while ($row = mysqli_fetch_object($query)){
            $socialNetworks[] = $row;
        }
    }
    $sql = "SELECT * FROM categories WHERE status = '1'";
    $query = mysqli_query($con, $sql);
    if (mysqli_num_rows($query)){
        while ($row = mysqli_fetch_object($query)){
            $categories[] = $row;
        }
    }
    $sql = "SELECT * FROM pages WHERE status = '1'";
    $query = mysqli_query($con, $sql);
    $i = 0;
    if (mysqli_num_rows($query)){
        while ($row = mysqli_fetch_object($query)){
            $pages[$i] = $row;
            if ($row->appearsMenu){
                $menuTopo[] = $row;
            }
            $sql = "SELECT * FROM pages_descriptions WHERE page = '".$pages[$i]->id."'";
            $query2 = mysqli_query($con, $sql);
            if (mysqli_num_rows($query2)){
                while ($row2 = mysqli_fetch_object($query2)){
                    $pages[$i]->paginaDescricao[] = $row2;
                }
            }
            $i++;
        }
    }
    $sql = "SELECT * FROM subitems WHERE status = '1'";
    $query = mysqli_query($con, $sql);
    $i = 0;
    if (mysqli_num_rows($query)){
        while ($row = mysqli_fetch_object($query)){
            $subitems[$i] = $row;
            $i++;
        }
    }
    if ($vet[0] == 'cliente'){
        $sql = "SELECT a.*, b.name AS nomeCategoria FROM subitems a INNER JOIN categories b ON (a.categorie = b.id) WHERE a.slug = '".$vet[1]."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $cliente = mysqli_fetch_object($query);
        }
        else{
            ?><script>alert('Cliente não encontrado!'); location.href="<?=URL?>";</script><?php
        }
    }
    elseif ($vet[0] == 'redeSocial'){
        $sql = "SELECT * FROM social_networks WHERE slug = '".$vet[1]."'";
        $query = mysqli_query($con, $sql);
        if (mysqli_num_rows($query)){
            $pagina = mysqli_fetch_object($query);
            $pagina->name = ($pagina->name);
        }
        else{
            ?>
            <script>
                alert('Rede social não encontrada!');
                window.close();
            </script>
            <?php
        }
    }
?>