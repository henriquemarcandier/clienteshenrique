        <?php if (!$_SESSION['cliente']['id']){
            ?><script>alert('Você deve estar logado no site para ver essa página'); location.href='<?=URL?>';</script><?php
            die();   
        }?>        
        <header class="masthead" style="height:100px">
            <div class="container">
                <div class="text-center">
                    <h2 class="section-heading text-uppercase">Solicite</h2>
                    <h3 class="section-subheading text-muted">Utilize o formulário abaixo para solicitar o seu serviço:</h3>
                </div>
                <form name="solicite" id="solicite">

                </form>
            </div>
        </header>
        <div style="width: 100%;"><a href="<?=URL?>banner/<?=$bannersMeioPagina[0]->id?>"><img src="<?=URL?>img/upload/<?=$bannersMeioPagina[0]->img?>" style="width: 100%;"></a></div>
        <div style="width: 100%;"><a href="<?=URL?>banner/<?=$bannersMeioPagina[1]->id?>"><img src="<?=URL?>img/upload/<?=$bannersMeioPagina[1]->img?>" style="width: 100%;"></a></div>