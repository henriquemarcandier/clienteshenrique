        <!-- Masthead-->
        <header class="masthead">
            <div class="container">
                <div class="masthead-subheading">Aguarde... Redirecionando para a página do</div>
                <div class="masthead-heading text-uppercase"><?=$modelo->name?>!</div>
            </div>
        </header>
        <div style="width: 100%;"><a href="<?=URL?>banner/<?=$bannersMeioPagina[0]->id?>"><img src="<?=URL?>img/upload/<?=$bannersMeioPagina[0]->img?>" style="width: 100%;"></a></div>
        <script>
            location.href="<?=$modelo->subname?>";
        </script>