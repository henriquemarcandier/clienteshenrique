  <!-- ======= Hero Section ======= -->
  <section id="<?=$pages[0]->slug?>" class="d-flex flex-column justify-content-center align-items-center">
    <div class="hero-container" data-aos="fade-in">
      <h1><?=$pages[0]->paginaDescricao[0]->text?></h1>
      <p><?=$pages[0]->paginaDescricao[1]->text?> <span class="typed" data-typed-items="<?=$pages[0]->paginaDescricao[2]->text?>, <?=$pages[0]->paginaDescricao[3]->text?>, <?=$pages[0]->paginaDescricao[4]->text?>, <?=$pages[0]->paginaDescricao[5]->text?>"></span></p>
    </div>
  </section><!-- End Hero -->

  <main id="main">
    <!-- ======= Portfolio Section ======= -->
    <section id="portfolio" class="portfolio section-bg">
      <div class="container">

        <div class="section-title">
          <h2><?=$pages[1]->name?></h2>
          <p><?=$pages[1]->paginaDescricao[0]->text?></p>
        </div>

        <div class="row" data-aos="fade-up">
          <div class="col-lg-12 d-flex justify-content-center">
            <ul id="portfolio-flters">

              <li data-filter="*" class="filter-active">Todos</li>
              <?php foreach ($categories as $key => $value){
                  if ($key == 0){?>
              <li data-filter=".filter-app"><?=$value->name?></li>
                    <?php } elseif ($key == 1){?>
              <li data-filter=".filter-card"><?=$value->name?></li>
              <?php } elseif ($key == 2){?>
              <li data-filter=".filter-web"><?=$value->name?></li>
              <?php } 
            } ?>
            </ul>
          </div>
        </div>

        <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="100">
          <?php foreach ($subitems as $key => $value){
              if ($value->categorie == 1){
                $slug = "app";   
              }
              elseif ($value->categorie == 2){
                $slug = "card";   
              }              
              elseif ($value->categorie == 3){
                $slug = "web";   
              }?>
          <div class="col-lg-4 col-md-6 portfolio-item filter-<?=$slug?>">
            <div class="portfolio-wrap">
              <img src="<?=URL?>assets/img/upload/<?=$value->img?>" class="img-fluid" alt="">
              <div class="portfolio-links">
                <a href="<?=URL?>assets/img/upload/<?=$value->img?>" data-gallery="portfolioGallery" class="portfolio-lightbox" title="<?=$value->name?>"><i class="bx bx-plus"></i></a>
                <a href="<?=URL?>cliente/<?=$value->slug?>" title="Mais Detalhes"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>
          <?php } ?>
        </div>

      </div>
    </section><!-- End Portfolio Section -->

    <!-- ======= Contact Section ======= -->
    <section id="<?=$pages[2]->slug?>" class="contact">
      <div class="container">

        <div class="section-title">
          <h2><?=$pages[2]->name?></h2>
          <p><?=$pages[2]->paginaDescricao[0]->text?></p>
        </div>

        <div class="row" data-aos="fade-in">

          <div class="col-lg-5 d-flex align-items-stretch">
            <div class="info">
              <div class="address">
                <i class="bi bi-geo-alt"></i>
                <h4>Localização:</h4>
                <p><?=$paramSite['endereco']?></p>
              </div>

              <div class="email">
                <i class="bi bi-envelope"></i>
                <h4>Email:</h4>
                <p><a href="mailto:<?=$paramSite['email']?>"><?=$paramSite['email']?></a></p>
              </div>

              <div class="phone">
                <i class="bi bi-phone"></i>
                <h4>Telefone:</h4>
                <p><?=$paramSite['celular']?></p>
              </div>
              <iframe src="<?=$paramSite['mapa']?>" frameborder="0" style="border:0; width: 100%; height: 290px;" allowfullscreen></iframe>
            </div>

          </div>

          <div class="col-lg-7 mt-5 mt-lg-0 d-flex align-items-stretch">
            <form action="" method="post" role="form" id="formContato" style="width:100%">
              <div class="row">
                <div class="form-group col-md-6">
                  <label for="name">Seu nome:</label>
                  <input type="text" name="name" class="form-control" id="name" required>
                </div>
                <div class="form-group col-md-6">
                  <label for="name">Seu email:</label>
                  <input type="email" class="form-control" name="email" id="email" required>
                </div>
              </div>
              <div class="form-group">
                <label for="name">Assunto</label>
                <input type="text" class="form-control" name="subject" id="subject" required>
              </div>
              <div class="form-group">
                <label for="name">Mensagem</label>
                <textarea class="form-control" name="message" rows="10" id="message" required></textarea>
              </div><br>
              <div class="text-center"><button type="submit" class="btn btn-primary">Enviar Mensagem</button></div>
            </form>
          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->