<main id="main">

<!-- ======= Breadcrumbs ======= -->
<section id="breadcrumbs" class="breadcrumbs">
  <div class="container">

    <div class="d-flex justify-content-between align-items-center">
      <h2>Detalhe do Cliente "<?=$cliente->name?>"</h2>
      <ol>
        <li><a href="<?=URL?>">Home</a></li>
        <li>Detalhes do Cliente "<?=$cliente->name?>"</li>
      </ol>
    </div>

  </div>
</section><!-- End Breadcrumbs -->

<!-- ======= Portfolio Details Section ======= -->
<section id="portfolio-details" class="portfolio-details">
  <div class="container">

    <div class="row gy-4">

      <div class="col-lg-8">
        <div class="portfolio-details-slider swiper">
          <div class="swiper-wrapper align-items-center">

            <div class="swiper-slide">
              <img src="<?=URL?>assets/img/upload/<?=$cliente->img?>" alt="">
            </div>

          </div>
          <div class="swiper-pagination"></div>
        </div>
      </div>

      <div class="col-lg-4">
        <div class="portfolio-info">
          <h3>Informações do Cliente</h3>
          <ul>
            <li><strong>Categoria</strong>: <?=$cliente->nomeCategoria?></li>
            <li><strong>Cliente</strong>: <?=$cliente->name?></li>
            <?php if ($cliente->subname){?>
            <li><strong>URL do Cliente</strong>: <a href="<?=$cliente->subname?>" target="_blank"><?=$cliente->subname?></a></li>
            <?php } ?>
         </ul>
        </div>
        <div class="portfolio-description">
          <h2><?=$cliente->description?></h2>
          <p>
            <?=$cliente->description2?>
          </p>
          <p>
            <?=$cliente->description3?>
          </p>
        </div>
      </div>

    </div>

  </div>
</section><!-- End Portfolio Details Section -->

</main><!-- End #main -->