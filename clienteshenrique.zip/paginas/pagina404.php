
	<div class="container text-center">
		<div class="logo-404">
			<a href="index.html"><img src="images/home/logo.png" alt="" /></a>
		</div>
		<div class="content-404">
			<img src="<?=URL?>img/404.png" class="img-responsive" alt="" />
			<h1><b>OPPS!</b> Página 404!</h1>
            <h3>Página não encontrada!</h3>
			<p>Ops! A página procurada não existe em nossa lista de páginas! Tente novamente, ou clique sobre o botão abaixo!</p>
			<button class='btn btn-primary' onclick='location.href="<?=URL?>"'>Ir Para a Página Inicial</button>
		</div>
	</div>