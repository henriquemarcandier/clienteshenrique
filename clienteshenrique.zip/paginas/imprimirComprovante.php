<html>
    <head>
        <title><?=$paramSite['title']?> - Impressão do Comprovante <?=sprintf("%06s", $pedido['id'])?></title>
    </head>
    <body>
        <center>
            <img src="<?=URL?>img/logo.png" width="100"><br>
        <?php 
        $html = '<h2 style="color:#000000">Dados do Orçamento '.sprintf("%06s", $pedido['id']).'</h2>';
        $html .= '<div class="row"><h4>Dados do Orçamento</h4></div><table width="100%" border="0" cellpadding="0" cellspacing="0"><tr><td class="col-3">Número do Orçamento</td><td class="col-3"><b>'.sprintf("%06s", $pedido['id']).'</b></td><td class="col-3">Data do Orçamento</td><td class="col-3"><b>'.$pedido['dtPedido'].'</b></td></tr><tr><td class="col-3">Status do Orçamento</td><td class="col-3"><b>'.$pedido['nomeStatus'].'</b></td>';
        $html .= '</b></td></tr></table>';
        $html .= '</b><hr noshade="noshade"><div class="row"><h4>Produtos</h4></div>';
        if (count($pedidoItens)){
            $html .= '<table width="100%" border="0" cellpadding="0" cellspacing="0"><tr><th width="20%">Nome</th><th width="20%">Valor Unitário</th><th width="20%">Quantidade</th><th width="20%">Total</th></tr>';
            $valorTotal = 0;
            foreach ($pedidoItens as $chave => $row2){
                $html .= '<tr><td style="text-align:center"><b>'.utf8_encode($row2['name']);
                if ($row2['vale']){
                    $html .= " - <img src='".URL."img/visualizar.svg' width='25' style='cursor:pointer' onclick=visualizarVale('".$row2['vale']."','".URL."')><div id='vale' style='position:absolute; display:none; background-color:#FFFFFF; border:1px solid #e7e7e7; border-radius:15px; width:450px'></div>";
                }
                $html .= '</b></td><td style="text-align:center"><b>R$ '.number_format($row2['value'], 2, ',', '.').'</b></td><td style="text-align:center"><b>'.$row2['quantity'].'</b></td><td style="text-align:center"><b>R$ '.number_format($row2['value'] * $row2['quantity'], 2, ',', '.').'</b></td></tr>';
                $valorTotal += $row2['value'] * $row2['quantity'];
                $lista = $row2['lista'];
            }
            $html .= '<tr><td colspan="4" style="text-align: right;">Subtotal: </td><td><b>R$ '.number_format($valorTotal, 2, ',', '.').'</b></td></tr><tr><td colspan="4" style="text-align: right;">Desconto: </td><td><b style="color:#003300">- R$ '.number_format($pedido['valueDiscount'], 2, ',', '.').' ';
            $html .= '</b></td></tr><tr><td colspan="4" style="text-align: right;">Valor Total: </td><td><b style="color:#00345F">R$ '.number_format($valorTotal - $pedido['valueDiscount'], 2, ',', '.').'</b></td></tr></table><hr noshade="noshade"><div class="row"><h4>Dados do Cliente</h4></div>'; 
        }
        if ($pedido['type_person'] == 'F') {
            $html .= '<table width="100%" border="0" cellpadding="0" cellspacing="0" xmlns="http://www.w3.org/1999/html"><tr><td class="col-3">Nome do Cliente</td><td class="col-3"><b>' . utf8_decode($pedido['nomeCliente']) . '</b></td><td class="col-3">Email</td><td class="col-3"><b>' . $pedido['email'] . '</b></td></tr><tr><td class="col-3">CPF</td><td class="col-3"><b>' . $pedido['cpf'] . '</b></td> <td class="col-3">RG</td><td class="col-3"><b>' . $pedido['rg'] . '</b></td></tr><tr><td class="col-3">Celular</td><td class="col-3"><b>' . $pedido['cel'] . '</b></td><td class="col-3">Data de Nascimento</td><td class="col-3"><b>';
            $vet = explode("-", $pedido['dtNasc']);
            $html .= $vet[2]."/".$vet[1]."/".$vet[0];
            $html .= '</b></td></tr><tr><td class="col-3">Nacionalidade</td><td class="col-3"><b>'.$pedido['nomeNacionalidade'].'</b></td><td>&nbsp;</td><td>&nbsp;</td></tr></table>';
        }
        else{
            $html .= '<table width="100%" border="0" cellpadding="0" cellspacing="0" xmlns="http://www.w3.org/1999/html">
            <tr>
                <td class="col-3">Razão Social</td>
                <td class="col-3"><b>' . utf8_decode($pedido['razaoSocial']) . '</b></td>
                <td class="col-3">Nome Fantasia</td>
                <td class="col-3"><b>' . utf8_decode($pedido['nomeFantasia']) . '</b></td>
        </tr>
        <tr>
            <td class="col-3">Nome do Contato</td>
            <td class="col-3"><b>' . utf8_decode($pedido['contato']) . '</b></td>
            <td class="col-3">CNPJ</td>
            <td class="col-3"><b>' . $pedido['cnpj'] . '</b></td>
        </tr>
        <tr>
            <td class="col-3">Inscrição Estadual</td>
            <td class="col-3"><b>' . $pedido['ie'] . '</b></td>
            <td class="col-3">Inscrição Municipal</td>
            <td class="col-3"><b>' . $pedido['im'] . '</b></td>
        </tr>
        <tr>
            <td class="col-3">Email</td>
            <td class="col-3"><b>' . $pedido['email'] . '</b></td>
            <td class="col-3">Celular</td>
            <td class="col-3"><b>' . $pedido['cel2'] . '</b></td>
        </tr>
        <tr>
            <td class="col-3">Telefone</td>
            <td class="col-3"><b>' . $pedido['telefone'] . '</b></td>
            <td class="col-3">Data de Abertura</td>
            <td class="col-3"><b>';
            $vet = explode("-", $pedido['dataAbertura']);
            $html .= $vet[2]."/".$vet[1]."/".$vet[0];
            $html .= '</b></td>
        </tr>
        <tr>
        <td class="col-3">Nacionalidade da Empresa</td><td class="col-3"><b>'.$pedido['nomeNacionalidadeEmpresa'].'</b></td><td colspan="2">&nbsp;</td></tr>
        </table>
        ';
        }
        $html .= '<hr noshade="noshade"><div class="row"><h4>Dados do Endereço à Retirar o Orçamento</h4></div>
        Imprima e leve este comprovante até a nossa loja, no endereço abaixo, para retirar os seus produtos.<br><br><b>'.($paramSite['endereco1'].'<br>'.$paramSite['endereco2'].'<br>'.$paramSite['endereco3']).'</b><br>';
        echo $html;
        ?>
        </center>
        <script>
            window.print();
            window.close();
        </script>
    </body>
</html>