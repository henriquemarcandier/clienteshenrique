<section id="contato" class="d-flex flex-column justify-content-center align-items-center">
    <div class="hero-container" data-aos="fade-in">
      <h2>Aguarde... Redirecionando para a página do <?=$pagina->name?>...</h2>
    </div>
    <?php 
    $cliques = $pagina->cliques + 1;
    $sql = "UPDATE social_networks SET cliques = '".$cliques."' WHERE slug = '".$vet[1]."'";
    mysqli_query($con, $sql);?>
    <script>
        window.setTimeout('location.href="<?=$pagina->link?>"', 1000);
    </script>
</section>